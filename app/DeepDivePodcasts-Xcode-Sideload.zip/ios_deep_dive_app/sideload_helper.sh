#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJ="$SCRIPT_DIR/DeepDivePodcasts.xcodeproj"
BUILD_OUT="/tmp/deepdive_ios_build"

echo "============================================================"
echo "  Deep Dive Podcasts + Estudia! — Free Xcode Sideload Tool"
echo "============================================================"

if [ ! -d "/Applications/Xcode.app" ]; then
  echo ""
  echo "[!] Full Xcode.app is not installed on this Mac yet (only CommandLineTools)."
  echo "    To compile or sideload to your iPhone for \$0:"
  echo "    1. Open the Mac App Store and install 'Xcode' (free from Apple)."
  echo "    2. Run: sudo xcode-select -s /Applications/Xcode.app/Contents/Developer"
  echo "    3. Double-click: $PROJ"
  echo ""
  exit 0
fi

if [ "${1:-}" = "--ipa" ]; then
  echo "[*] Building unsigned .ipa for AltStore / SideStore..."
  rm -rf "$BUILD_OUT"
  mkdir -p "$BUILD_OUT/Payload"
  /Applications/Xcode.app/Contents/Developer/usr/bin/xcodebuild \
    -project "$PROJ" \
    -scheme DeepDivePodcasts \
    -configuration Release \
    -sdk iphoneos \
    -derivedDataPath "$BUILD_OUT/DerivedData" \
    CODE_SIGNING_ALLOWED=NO \
    CODE_SIGNING_REQUIRED=NO \
    CODE_SIGN_IDENTITY="" \
    build
  APP_PATH="$(find "$BUILD_OUT/DerivedData" -name 'DeepDivePodcasts.app' | head -n 1)"
  cp -R "$APP_PATH" "$BUILD_OUT/Payload/"
  (cd "$BUILD_OUT" && zip -qry "$SCRIPT_DIR/DeepDivePodcasts-AltStore.ipa" Payload)
  echo "[✓] Built $SCRIPT_DIR/DeepDivePodcasts-AltStore.ipa"
else
  echo "[*] Opening DeepDivePodcasts.xcodeproj in Xcode..."
  open "$PROJ"
fi
