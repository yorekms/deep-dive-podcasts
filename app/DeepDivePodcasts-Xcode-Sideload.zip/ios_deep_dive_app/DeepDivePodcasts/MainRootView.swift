import SwiftUI

enum AppDestination: String, CaseIterable {
    case player = "Player"
    case estudia = "Estudia! Cards"
    case clampflow = "ClampFlow"
    case hubs = "12 Hubs"

    var iconName: String {
        switch self {
        case .player: return "headphones"
        case .estudia: return "graduationcap.fill"
        case .clampflow: return "waveform.path.ecg"
        case .hubs: return "square.grid.2x2.fill"
        }
    }

    var rootURL: URL {
        switch self {
        case .player:
            return URL(string: "https://yorekms.github.io/deep-dive-podcasts/resonance/?view=listen")!
        case .estudia:
            return URL(string: "https://yorekms.github.io/deep-dive-podcasts/estudia/")!
        case .clampflow:
            return URL(string: "https://yorekms.github.io/deep-dive-podcasts/clampflow/")!
        case .hubs:
            return URL(string: "https://yorekms.github.io/deep-dive-podcasts/")!
        }
    }
}

struct MainRootView: View {
    @State private var selectedTab: AppDestination = .player
    @State private var estudiaURL: URL = AppDestination.estudia.rootURL
    @State private var playerURL: URL = AppDestination.player.rootURL

    var body: some View {
        TabView(selection: $selectedTab) {
            PersistentWebShell(
                url: $playerURL,
                onCrossAppDeepLink: handleCrossAppDeepLink
            )
            .ignoresSafeArea(edges: .top)
            .tabItem {
                Label(AppDestination.player.rawValue, systemImage: AppDestination.player.iconName)
            }
            .tag(AppDestination.player)

            PersistentWebShell(
                url: $estudiaURL,
                onCrossAppDeepLink: handleCrossAppDeepLink
            )
            .ignoresSafeArea(edges: .top)
            .tabItem {
                Label(AppDestination.estudia.rawValue, systemImage: AppDestination.estudia.iconName)
            }
            .tag(AppDestination.estudia)

            PersistentWebShell(
                url: .constant(AppDestination.clampflow.rootURL),
                onCrossAppDeepLink: handleCrossAppDeepLink
            )
            .ignoresSafeArea(edges: .top)
            .tabItem {
                Label(AppDestination.clampflow.rawValue, systemImage: AppDestination.clampflow.iconName)
            }
            .tag(AppDestination.clampflow)

            PersistentWebShell(
                url: .constant(AppDestination.hubs.rootURL),
                onCrossAppDeepLink: handleCrossAppDeepLink
            )
            .ignoresSafeArea(edges: .top)
            .tabItem {
                Label(AppDestination.hubs.rawValue, systemImage: AppDestination.hubs.iconName)
            }
            .tag(AppDestination.hubs)
        }
        .tint(Color(red: 56/255, green: 189/255, blue: 248/255))
    }

    private func handleCrossAppDeepLink(_ incoming: URL) -> Bool {
        let path = incoming.path.lowercased()
        if path.contains("/estudia") {
            estudiaURL = incoming
            selectedTab = .estudia
            return true
        }
        if path.contains("/resonance") {
            playerURL = incoming
            selectedTab = .player
            return true
        }
        return false
    }
}
