import SwiftUI
import AVFoundation

@main
struct DeepDivePodcastsApp: App {
    init() {
        configureBackgroundSpokenAudio()
    }

    var body: some Scene {
        WindowGroup {
            MainRootView()
                .preferredColorScheme(.dark)
        }
    }

    private func configureBackgroundSpokenAudio() {
        do {
            let session = AVAudioSession.sharedInstance()
            try session.setCategory(
                .playback,
                mode: .spokenAudio,
                options: [.allowAirPlay, .allowBluetoothA2DP]
            )
            try session.setActive(true)
        } catch {
            print("[DeepDivePodcasts] AudioSession warning: \(error)")
        }
    }
}
