import SwiftUI
import WebKit
import UIKit

struct PersistentWebShell: UIViewRepresentable {
    @Binding var url: URL
    var onCrossAppDeepLink: ((URL) -> Bool)?

    func makeCoordinator() -> Coordinator {
        Coordinator(parent: self)
    }

    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        config.websiteDataStore = .default()
        config.allowsInlineMediaPlayback = true
        config.allowsAirPlayForMediaPlayback = true
        config.mediaTypesRequiringUserActionForPlayback = []

        let prefs = WKWebpagePreferences()
        prefs.allowsContentJavaScript = true
        config.defaultWebpagePreferences = prefs

        // Request persistent offline storage inside WKWebView on load
        let persistScript = WKUserScript(
            source: """
            try {
              if (navigator.storage && navigator.storage.persist) {
                navigator.storage.persist();
              }
              window.__DEEP_DIVE_NATIVE_IOS = true;
            } catch (e) {}
            """,
            injectionTime: .atDocumentStart,
            forMainFrameOnly: true
        )
        config.userContentController.addUserScript(persistScript)

        let webView = WKWebView(frame: .zero, configuration: config)
        webView.navigationDelegate = context.coordinator
        webView.uiDelegate = context.coordinator
        webView.allowsBackForwardNavigationGestures = true
        webView.isOpaque = false
        webView.backgroundColor = UIColor(red: 6/255, green: 11/255, blue: 22/255, alpha: 1.0)
        webView.scrollView.backgroundColor = webView.backgroundColor
        webView.scrollView.contentInsetAdjustmentBehavior = .always

        let refresh = UIRefreshControl()
        refresh.tintColor = UIColor(red: 56/255, green: 189/255, blue: 248/255, alpha: 1.0)
        refresh.addTarget(context.coordinator, action: #selector(Coordinator.handlePullToRefresh(_:)), for: .valueChanged)
        webView.scrollView.refreshControl = refresh

        context.coordinator.lastLoadedURL = url
        webView.load(URLRequest(url: url))
        return webView
    }

    func updateUIView(_ webView: WKWebView, context: Context) {
        if context.coordinator.lastLoadedURL != url {
            context.coordinator.lastLoadedURL = url
            webView.load(URLRequest(url: url))
        }
    }

    final class Coordinator: NSObject, WKNavigationDelegate, WKUIDelegate {
        var parent: PersistentWebShell
        var lastLoadedURL: URL?

        init(parent: PersistentWebShell) {
            self.parent = parent
        }

        @objc func handlePullToRefresh(_ sender: UIRefreshControl) {
            if let webView = sender.superview?.superview as? WKWebView {
                webView.reload()
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.65) {
                sender.endRefreshing()
            }
        }

        func webView(
            _ webView: WKWebView,
            decidePolicyFor navigationAction: WKNavigationAction,
            decisionHandler: @escaping (WKNavigationActionPolicy) -> Void
        ) {
            guard let targetURL = navigationAction.request.url,
                  let scheme = targetURL.scheme?.lowercased() else {
                decisionHandler(.allow)
                return
            }

            // Native podcast & mail/share schemes open directly in iOS apps (Apple Podcasts, Overcast, Pocket Casts)
            if ["podcast", "pcast", "itpc", "overcast", "pktc", "mailto"].contains(scheme) {
                UIApplication.shared.open(targetURL, options: [:], completionHandler: nil)
                decisionHandler(.cancel)
                return
            }

            // Route cross-tab links (e.g. Estudia! "Hear @ mm:ss" -> Player tab, or Player -> Estudia! tab)
            if navigationAction.targetFrame == nil {
                if let route = parent.onCrossAppDeepLink, route(targetURL) {
                    decisionHandler(.cancel)
                    return
                }
                webView.load(URLRequest(url: targetURL))
                decisionHandler(.cancel)
                return
            }

            decisionHandler(.allow)
        }

        func webView(
            _ webView: WKWebView,
            createWebViewWith configuration: WKWebViewConfiguration,
            for navigationAction: WKNavigationAction,
            windowFeatures: WKWindowFeatures
        ) -> WKWebView? {
            if let targetURL = navigationAction.request.url {
                if let route = parent.onCrossAppDeepLink, route(targetURL) {
                    return nil
                }
                webView.load(URLRequest(url: targetURL))
            }
            return nil
        }
    }
}
