# Deep Dive Podcasts + Estudia! — Zero-\$99 iPhone Sideload & Universal Access Guide

Apple charges \$99/year just to list an app on the App Store or TestFlight. To avoid paying Apple \$99/year **while still giving both you and 100% of public listeners a real iPhone app**, this project combines two complementary \$0 paths:

---

## Path A — Native Xcode / SideStore Sideloading (\$0 Personal Apple ID)
Your complete native SwiftUI + `AVAudioSession` background-audio iOS project lives here on Google Drive:
`My Drive/LLM Statistical Software/ios_deep_dive_app/DeepDivePodcasts.xcodeproj`

It bundles **4 native tabs** in one iOS binary (`DeepDivePodcasts.app`):
1. **Player** — Deep Dive Pocket Player (`1.5x` running mode, offline downloads, synchronized word-level transcripts, lock-screen & AirPods `AVAudioSession` playback)
2. **Estudia! Cards** — All 7,612 Deep Dive transcript Q&A study cards + High School/AP decks (3D Flashcards, 4-Option Quiz, Write & Spell, Match Grid, and `▶ Hear @ mm:ss` cross-tab audio jumps)
3. **ClampFlow** — Current-Clamp & Voltage-Clamp `.abf` analyzer
4. **12 Hubs** — Full Deep Dive Podcast Network directory

### How to Sideload Onto Your iPhone with Free Xcode (No \$99 Fee)
1. Install **Xcode** (free) from the Mac App Store on this Mac (currently only `CommandLineTools` is installed, so `/Applications/Xcode.app` isn't present yet).
2. Open `DeepDivePodcasts.xcodeproj` in Xcode.
3. Click **DeepDivePodcasts** in the left sidebar &rarr; **Signing & Capabilities**:
   - Check **Automatically manage signing**
   - Under **Team**, click **Add an Account...**, sign in with your normal free Apple ID (`yorekms@gmail.com` or iCloud ID), and select **(Your Name) (Personal Team)**.
   - Set **Bundle Identifier** to something unique to your Apple ID (e.g. `com.yorekms.deepdive`).
4. Plug in your iPhone via USB (or pair over Wi-Fi), enable **Settings &rarr; Privacy & Security &rarr; Developer Mode** on your iPhone, and press **Run (`⌘R`)**!
5. On your iPhone, open **Settings &rarr; General &rarr; VPN & Device Management &rarr; Developer App** and tap **Trust**.

> **Tip to avoid the 7-day free certificate refresh**: If you install free **[SideStore](https://sidestore.io)** or **[AltStore](https://altstore.io)** once, run `./sideload_helper.sh --ipa` to export `DeepDivePodcasts-AltStore.ipa`. SideStore automatically refreshes your free Personal Team signature in the background over Wi-Fi so it never expires!

---

## Path B — How *Everyone Else* Gets the iPhone App for \$0 (Without a Mac or \$99 Apple Fee)
Because iOS blocks raw `.ipa` files downloaded from websites unless each user signs the `.ipa` with their own Apple ID (via Xcode, AltStore, or SideStore), **99% of public visitors without a Mac** get instant 1-tap iPhone access via:
`https://yorekms.github.io/deep-dive-podcasts/app/`

On that page, every iPhone visitor has three \$0 options:
1. **Option 1 — 1-Tap Apple Podcasts / Overcast / Pocket Casts (`podcast://`)**: Native iOS background audio, offline downloads, CarPlay & AirPods with 1 tap.
2. **Option 2 — Standalone Deep Dive Player Home Screen App (`DD` Icon)**: Full-screen standalone iOS app (`apple-mobile-web-app-capable`) with `navigator.storage.persist()` persistent offline episode cache, word-level transcripts, and `MediaSession` lock-screen controls — **never expires after 7 days**.
3. **Option 3 — Standalone Estudia! Study Cards Home Screen App (`Estudia!` Icon)**: Full-screen 3D Flashcards, Quiz, Write & Match app across all 7,612 transcript Q&A cards — plus a collapsible **Developer Xcode / AltStore Sideload** download right on `/app/` for visitors who *do* use Xcode or SideStore!
