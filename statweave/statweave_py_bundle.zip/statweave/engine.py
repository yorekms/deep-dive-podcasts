"""Explicit, local statistical routines. No test selection or row deletion by significance."""
from __future__ import annotations

import copy
import math
import re
import warnings as pywarnings

import numpy as np
import pandas as pd
from scipy import stats
from statsmodels.duration.hazard_regression import PHReg
from statsmodels.duration.survfunc import SurvfuncRight, survdiff
from statsmodels.regression.linear_model import OLS
from statsmodels.tools.tools import add_constant

from .curves import compare_shared_midpoint, fit_four_param_curve, predict_curve_grid
from .data import Dataset

METHODS = {
    "describe",
    "ttest",
    "paired_t",
    "wilcoxon",
    "anova",
    "rm_anova",
    "friedman",
    "two_way_anova",
    "rm_two_way",
    "timecourse_compare",
    "survival",
    "dose_response",
    "boltzmann",
    "ap_waveform",
    "kruskal",
    "mannwhitney",
    "pearson",
    "spearman",
    "regression",
    "chi2",
    "fisher_exact",
    "batch_compare",
}

POSTHOCS = {"none", "tukey", "dunnett", "holm_welch", "holm_mannwhitney"}

MISSING_TOKENS = {
    "na",
    "n/a",
    "#n/a",
    "nan",
    "null",
    "none",
    "missing",
    "undetermined",
    ".",
}

_PRUNING_REASON_RE = re.compile(
    r"\b(?:outlier\w*|significan\w*|p[ -]?values?|p\s*[<=>]|tighter|cleaner|anomal\w*|best\s+result|improve\s+p|p[ -]?hack\w*)\b",
    re.I,
)
_UNIT_COLUMN_RE = re.compile(
    r"^(?:(?:animal|mouse|mice|rat|donor|patient|subject|litter|participant|person|cage)(?:[_\s-]*id)?|(?:cell|neuron|slice|recording)[_\s-]*id)$",
    re.I,
)
_COUNT_COLUMN_RE = re.compile(
    r"^(?:count|counts|freq|frequency|n|total|cases|observations|weight|weights)$",
    re.I,
)


def _safe(value):
    if isinstance(value, dict):
        return {str(k): _safe(v) for k, v in value.items()}
    if isinstance(value, (tuple, list, np.ndarray)):
        return [_safe(v) for v in value]
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.bool_,)):
        return bool(value)
    if isinstance(value, (np.floating, float)):
        return float(value) if np.isfinite(value) else None
    if value is None or isinstance(value, (str, int, bool)):
        return value
    return str(value)


def _table(title, rows, columns=None):
    return {"title": title, "columns": columns or (list(rows[0]) if rows else []), "rows": _safe(rows)}


def _blank(v):
    if v is None or (isinstance(v, str) and not v.strip()):
        return True
    try:
        return bool(pd.isna(v))
    except (TypeError, ValueError):
        return False


def _is_missing_token(v) -> bool:
    return isinstance(v, str) and v.strip().casefold() in MISSING_TOKENS


def _column(ds, name, role):
    if not isinstance(name, str) or not name.strip():
        raise ValueError(f"Choose a column for {role}.")
    if name in ds.df.columns:
        return name
    matches = [c for c in ds.df.columns if c.casefold() == name.casefold()]
    if len(matches) == 1:
        return matches[0]
    if len(matches) > 1:
        raise ValueError(f"Column '{name}' is ambiguous; use its exact name.")
    raise ValueError(f"Column '{name}' was not found for {role}. Available columns: {', '.join(ds.df.columns)}")


def _excluded_mask(ds: Dataset, plan: dict) -> tuple[np.ndarray, list[str], list[dict]]:
    raw_exclusions = plan.get("excluded_rows")
    n = len(ds.df)
    allowed = np.ones(n, dtype=bool)
    reasons = [""] * n
    if not raw_exclusions:
        plan.pop("excluded_rows", None)
        return allowed, reasons, []
    if not isinstance(raw_exclusions, list) or len(raw_exclusions) > 500:
        raise ValueError("excluded_rows must be a list of at most 500 explicit {row, reason} entries.")
    row_to_idx = {int(r): idx for idx, r in enumerate(ds.row_numbers)}
    normalized = []
    seen = set()
    for entry in raw_exclusions:
        if not isinstance(entry, dict):
            raise ValueError("Each excluded row entry must provide 'row' and 'reason'.")
        row_num = entry.get("row")
        reason = entry.get("reason", "")
        if isinstance(row_num, bool) or not isinstance(row_num, int) or row_num not in row_to_idx:
            raise ValueError(f"Source row {row_num!r} does not exist in this sheet (valid rows: {ds.row_numbers[0]}–{ds.row_numbers[-1]}).")
        if not isinstance(reason, str) or not reason.strip() or len(reason.strip()) > 500:
            raise ValueError(f"Source row {row_num}: provide a brief technical or protocol reason (1–500 characters) for masking a row.")
        clean_reason = reason.strip()
        if _PRUNING_REASON_RE.search(clean_reason):
            raise ValueError(
                "Row exclusions require a technical, experimental, or protocol reason "
                "(for example seal loss, equipment fault, or contamination), not outlier or significance-based pruning."
            )
        if row_num in seen:
            continue
        seen.add(row_num)
        idx = row_to_idx[row_num]
        allowed[idx] = False
        reasons[idx] = f"Excluded row ({clean_reason})"
        normalized.append({"row": row_num, "reason": clean_reason})
    normalized.sort(key=lambda item: item["row"])
    plan["excluded_rows"] = normalized
    return allowed, reasons, normalized


def _numeric(ds, col):
    raw = ds.df[col]
    blank_mask = raw.map(_blank)
    token_mask = raw.map(_is_missing_token)
    missing = blank_mask | token_mask
    converted = pd.to_numeric(raw.where(~missing, np.nan), errors="coerce")
    invalid = ~missing & converted.isna()
    if invalid.any():
        examples = [f"row {ds.row_numbers[i]}: {raw.iloc[i]!r}" for i in np.flatnonzero(invalid.to_numpy())[:8]]
        raise ValueError(
            f"'{col}' contains nonnumeric entries ({'; '.join(examples)}). "
            f"Correct these cells or explicitly mark them as missing before analysis. "
            f"If '{col}' is a categorical group or timepoint/factor column, pass it via group='{col}' "
            f"(or x='{col}' with method='timecourse_compare' / 'two_way_anova' / plot='timecourse'), not as a numeric measurement column."
        )
    array = converted.to_numpy(dtype=float, na_value=np.nan)
    finite = np.isfinite(array)
    reasons = []
    for i in range(len(raw)):
        if blank_mask.iloc[i]:
            reasons.append(f"Missing value in '{col}'")
        elif token_mask.iloc[i]:
            reasons.append(f"Missing token {str(raw.iloc[i]).strip()!r} in '{col}'")
        elif not finite[i]:
            reasons.append(f"Nonfinite value in '{col}'")
        else:
            reasons.append("")
    return array, finite, reasons


def _format_cat_value(v) -> str:
    if hasattr(v, "strftime"):
        try:
            if getattr(v, "hour", 0) == 0 and getattr(v, "minute", 0) == 0 and getattr(v, "second", 0) == 0:
                return v.strftime("%Y-%m-%d")
            return v.strftime("%Y-%m-%d %H:%M")
        except Exception:
            pass
    s = str(v).strip() if isinstance(v, str) else str(v)
    return re.sub(r"^(\d{4}-\d{2}-\d{2})\s+00:00:00(?:\.0+)?$", r"\1", s)


def _sort_strata_naturally(levels: list[str]) -> list[str]:
    """Preserve sheet order for text/date labels, but sort purely numeric discrete strata ascending."""
    if len(levels) < 2:
        return list(levels)
    parsed: list[tuple[float, int, str]] = []
    for idx, lv in enumerate(levels):
        try:
            fv = float(str(lv).strip())
            if not math.isfinite(fv):
                return list(levels)
            parsed.append((fv, idx, lv))
        except (TypeError, ValueError):
            return list(levels)
    return [item[2] for item in sorted(parsed, key=lambda t: (t[0], t[1]))]


def _categorical(ds, col):
    values, valid, reasons = [], [], []
    for v in ds.df[col]:
        missing = _blank(v)
        nonfinite = isinstance(v, (float, np.floating)) and not np.isfinite(v)
        valid.append(not missing and not nonfinite)
        values.append(None if missing or nonfinite else _format_cat_value(v))
        reasons.append(f"Missing value in '{col}'" if missing else f"Nonfinite value in '{col}'" if nonfinite else "")
    return np.asarray(values, dtype=object), np.asarray(valid, dtype=bool), reasons


def _account(ds, mask, reason_lists, by_variable=None, excluded_rows=None):
    mask = np.asarray(mask, dtype=bool)
    omitted = []
    for i in np.flatnonzero(~mask):
        reason = "; ".join(dict.fromkeys(r[i] for r in reason_lists if r[i]))
        omitted.append({"row": ds.row_numbers[i], "reason": reason or "Required values are unavailable"})
    out = {"total": len(ds.df), "used": int(mask.sum()), "omitted": int((~mask).sum()), "omitted_rows": omitted}
    if by_variable is not None:
        out["by_variable"] = by_variable
    if excluded_rows:
        out["excluded_rows"] = list(excluded_rows)
    return out


def _var_account(ds, name, valid, reasons):
    return {"variable": name, "used": int(valid.sum()), "omitted": int((~valid).sum()), "omitted_rows": [{"row": ds.row_numbers[i], "reason": reasons[i]} for i in np.flatnonzero(~valid)]}


def _summary(name, values, with_ci=False):
    a = np.asarray(values, dtype=float)
    n = len(a)
    if not n:
        return {"variable": name, "n": 0, "mean": None, "sd": None, "sem": None, "median": None, "q1": None, "q3": None, "min": None, "max": None, "ci_low": None, "ci_high": None}
    mean = float(np.mean(a))
    if n > 1:
        scale = float(np.max(np.abs(a))) or 1.0
        sd = float(np.std((a - mean) / scale, ddof=1) * scale)
        sem = float(sd / np.sqrt(n))
    else:
        sd = None
        sem = None
    half = float(stats.t.ppf(.975, n - 1) * sem) if sem is not None and with_ci else None
    return {
        "variable": name,
        "n": n,
        "mean": mean,
        "sd": sd,
        "sem": sem,
        "median": float(np.median(a)),
        "q1": float(np.quantile(a, .25)),
        "q3": float(np.quantile(a, .75)),
        "min": float(a.min()),
        "max": float(a.max()),
        "ci_low": mean - half if half is not None else None,
        "ci_high": mean + half if half is not None else None,
    }


def _finish(ds, plan, method, summary, tables, warnings, accounting, extra=None):
    if accounting.get("excluded_rows"):
        n_excl = len(accounting["excluded_rows"])
        warnings.append(f"{n_excl} source row(s) were explicitly masked with recorded technical reasons; raw source values remain intact and masks are reversible.")
    if accounting["omitted"]:
        warnings.append(f"{accounting['omitted']} of {accounting['total']} source rows were omitted; each is listed in row accounting.")
    payload = {
        "method": method,
        "summary": summary,
        "tables": tables,
        "warnings": list(dict.fromkeys(warnings)),
        "row_accounting": accounting,
        "plan": plan,
    }
    if extra:
        payload.update(extra)
    return _safe(payload)


def _require_independent(plan):
    if plan.get("design") != "independent":
        raise ValueError("Confirm that observations are independent before this analysis (design='independent'). Repeated measurements and technical replicates must not be treated as independent units.")


def _check_unpooled_replicates(ds: Dataset, plan: dict, mask: np.ndarray, used_columns: set[str]) -> None:
    if plan.get("design") != "independent" or plan.get("pool_by") or plan.get("allow_replicate_rows"):
        return
    n_used = int(np.sum(mask))
    if n_used < 3:
        return
    for col in ds.df.columns:
        if col in used_columns:
            continue
        if not _UNIT_COLUMN_RE.match(col.strip()):
            continue
        vals, vmask, _ = _categorical(ds, col)
        active = mask & vmask
        n_active = int(np.sum(active))
        if n_active < 3:
            continue
        distinct = list(dict.fromkeys(vals[active]))
        if 1 <= len(distinct) < n_active:
            raise ValueError(
                f"Column '{col}' contains repeated unit identifiers ({n_active} rows across {len(distinct)} distinct '{col}' units). "
                f"Treating repeated sweeps, cells, or timepoints from the same '{col}' as independent inflates sample size (pseudoreplication). "
                f"Pool within '{col}' first (pool_by='{col}'), use method='timecourse_compare' or 'two_way_anova' with x='<Timepoint>' if rows represent longitudinal timepoints, "
                f"use a paired design if comparing two conditions within '{col}', "
                f"or set allow_replicate_rows=True only if each row is genuinely an independent experimental unit."
            )


def _wide_columns(ds, plan):
    cols = plan.get("columns")
    if cols is None:
        return None
    if not isinstance(cols, list) or not cols:
        raise ValueError("Choose a nonempty list of numeric columns.")
    resolved = [_column(ds, c, "numeric values") for c in cols]
    if len(set(resolved)) != len(resolved):
        raise ValueError("A column was selected more than once. Choose each column once.")
    return resolved


def _pool_grouped_units(
    ds: Dataset,
    values: np.ndarray,
    vy: np.ndarray,
    ry: list[str],
    labels: np.ndarray,
    vg: np.ndarray,
    rg: list[str],
    unit_col: str,
    pool_stat: str,
    allowed: np.ndarray,
    r_excl: list[str],
):
    if pool_stat not in {"mean", "median"}:
        raise ValueError("pool_stat must be 'mean' or 'median'.")
    units, vu, ru = _categorical(ds, unit_col)
    mask = vy & vg & vu & allowed
    names = list(dict.fromkeys(labels[vg & allowed]))
    unit_group: dict[str, str] = {}
    buckets: dict[tuple[str, str], list[tuple[int, float]]] = {}
    for idx in np.flatnonzero(mask):
        u = str(units[idx])
        g = str(labels[idx])
        if u in unit_group and unit_group[u] != g:
            raise ValueError(
                f"Unit '{u}' in '{unit_col}' appears in multiple groups ('{unit_group[u]}' and '{g}'). "
                "Use a paired or within-subject design rather than independent-groups pooling."
            )
        unit_group[u] = g
        buckets.setdefault((g, u), []).append((int(ds.row_numbers[idx]), float(values[idx])))

    arrays = []
    unit_rows = []
    units_per_group = {}
    for name in names:
        grp_vals = []
        for (g, u), items in buckets.items():
            if g != name:
                continue
            raw_vals = [v for _, v in items]
            pooled_val = float(np.mean(raw_vals)) if pool_stat == "mean" else float(np.median(raw_vals))
            grp_vals.append(pooled_val)
            unit_rows.append({
                "unit": u,
                "group": g,
                "n_subreplicates": len(raw_vals),
                "value": pooled_val,
                "source_rows": [r for r, _ in items],
                "raw_values": raw_vals,
            })
        arrays.append(np.asarray(grp_vals, dtype=float))
        units_per_group[str(name)] = len(grp_vals)

    unit_accounting = {
        "unit_column": unit_col,
        "pool_stat": pool_stat,
        "n_raw_observations": int(mask.sum()),
        "n_units": len(unit_rows),
        "units_per_group": units_per_group,
        "unit_rows": unit_rows,
    }
    return names, arrays, mask, [ry, rg, ru, r_excl], unit_accounting


def _describe(ds, plan, warnings):
    allowed, r_excl, excluded = _excluded_mask(ds, plan)
    group = _column(ds, plan["group"], "group labels") if plan.get("group") else None
    pool_by = _column(ds, plan["pool_by"], "unit identifiers") if plan.get("pool_by") else None
    subj_col = _column(ds, plan["subject"], "subject identifiers") if plan.get("subject") else None
    pool_stat = plan.get("pool_stat", "mean")
    if pool_by:
        plan["pool_by"] = pool_by
        plan["pool_stat"] = pool_stat
    if subj_col:
        plan["subject"] = subj_col

    stratum_col: str | None = None
    cols = _wide_columns(ds, plan)
    if cols is None:
        if plan.get("x") is not None and plan.get("y") is not None:
            x_cand = _column(ds, plan["x"], "horizontal variable")
            y_cand = _column(ds, plan["y"], "descriptive values")
            raw_x = ds.df[x_cand]
            non_miss_x = ~(raw_x.map(_blank) | raw_x.map(_is_missing_token))
            conv_x = pd.to_numeric(raw_x.where(non_miss_x, np.nan), errors="coerce")
            x_is_cat = bool((non_miss_x & conv_x.isna()).any())
            if x_is_cat or plan.get("plot") in {"timecourse", "spaghetti", "grouped_bar", "grouped_box"}:
                stratum_col = x_cand
                plan["x"] = x_cand
                plan["y"] = y_cand
                cols = [y_cand]
            else:
                cols = list(dict.fromkeys([y_cand, x_cand]))
        else:
            explicit = [c for c in [plan.get("y"), plan.get("x")] if c is not None]
            if explicit:
                cols = list(dict.fromkeys(_column(ds, c, "descriptive values") for c in explicit))
            else:
                cols = []
                for c in ds.df.columns:
                    if c in {group, pool_by, subj_col}:
                        continue
                    raw = ds.df[c]
                    non_missing = ~(raw.map(_blank) | raw.map(_is_missing_token))
                    converted = pd.to_numeric(raw.where(non_missing, np.nan), errors="coerce")
                    if converted.notna().any() and not (non_missing & converted.isna()).any():
                        cols.append(c)
    elif plan.get("x") is not None and plan.get("plot") in {"timecourse", "spaghetti"}:
        stratum_col = _column(ds, plan["x"], "horizontal axis / timepoint")
        plan["x"] = stratum_col

    if not cols:
        raise ValueError("No numeric columns were found. Choose numeric data or check the header row.")
    plan["columns"] = cols
    rows, by_var, masks, reasons = [], [], [], [r_excl]
    if group:
        plan["group"] = group
        labels, vg, rg = _categorical(ds, group)
        names = list(dict.fromkeys(labels[vg & allowed]))
        if not names:
            raise ValueError("No nonmissing group labels were found.")
        reasons.append(rg)
    extra = {}
    for c in cols:
        arr, mask_num, reason_num = _numeric(ds, c)
        mask = mask_num & allowed
        reason = ["; ".join(v for v in (r_excl[i], reason_num[i]) if v) for i in range(len(mask))]
        if group and pool_by and c != pool_by and group != pool_by:
            names_p, arrays_p, mask_p, r_lists, unit_acc = _pool_grouped_units(
                ds, arr, mask_num, reason_num, labels, vg, rg, pool_by, pool_stat, allowed, r_excl
            )
            mask = mask_p
            reason = ["; ".join(dict.fromkeys(rl[i] for rl in r_lists if rl[i])) for i in range(len(mask))]
            for name, u_arr in zip(names_p, arrays_p):
                row = _summary(c, u_arr, with_ci=plan.get("design") == "independent")
                row["group"] = name
                row["missing_or_nonfinite"] = int(((vg & allowed & (labels == name)) & ~mask).sum())
                rows.append(row)
            if len(cols) == 1:
                extra["unit_accounting"] = unit_acc
        elif group:
            mask = mask & vg
            reason = ["; ".join(v for v in (reason[i], rg[i]) if v) for i in range(len(mask))]
            for name in names:
                selected = vg & allowed & (labels == name)
                row = _summary(c, arr[mask & selected], with_ci=plan.get("design") == "independent")
                row["group"] = name
                row["missing_or_nonfinite"] = int((selected & ~mask).sum())
                rows.append(row)
        else:
            row = _summary(c, arr[mask], with_ci=plan.get("design") == "independent")
            row["missing_or_nonfinite"] = int((~mask).sum())
            rows.append(row)
        by_var.append(_var_account(ds, c, mask, reason))
        masks.append(mask)
        reasons.append(reason)
    overall_mask = np.logical_or.reduce(masks)
    used_cols_set = set(cols) | ({group} if group else set()) | ({stratum_col} if stratum_col else set()) | ({subj_col} if subj_col else set())
    if stratum_col is None:
        _check_unpooled_replicates(ds, plan, overall_mask, used_cols_set)
    accounting = _account(ds, overall_mask, reasons, by_var, excluded)
    if any(x["omitted"] for x in by_var):
        warnings.append("Descriptive statistics use available values separately for each column; per-variable omissions are listed in row accounting.")
    if plan.get("design") != "independent":
        warnings.append("Experimental units have not been confirmed independent; mean confidence intervals are not calculated.")

    tables = [_table("Descriptive statistics", rows)]
    if stratum_col and len(cols) == 1:
        s_labels, vs, _ = _categorical(ds, stratum_col)
        s_names = _sort_strata_naturally(list(dict.fromkeys(s_labels[vs & allowed])))
        arr_c, mask_c, _ = _numeric(ds, cols[0])
        stratum_rows = []
        for s_name in s_names:
            s_sel = vs & allowed & (s_labels == s_name)
            if group:
                for g_name in names:
                    cell_mask = s_sel & vg & (labels == g_name) & mask_c
                    s_row = _summary(cols[0], arr_c[cell_mask], with_ci=plan.get("design") == "independent")
                    s_row = {"stratum": str(s_name), "group": str(g_name), **s_row}
                    stratum_rows.append(s_row)
            else:
                cell_mask = s_sel & mask_c
                s_row = _summary(cols[0], arr_c[cell_mask], with_ci=plan.get("design") == "independent")
                s_row = {"stratum": str(s_name), **s_row}
                stratum_rows.append(s_row)
        if stratum_rows:
            tables.append(_table("Descriptive statistics by stratum", stratum_rows))

    unit_phrase = f" pooled by {pool_by} ({pool_stat})" if (group and pool_by) else ""
    stratum_phrase = f" across {stratum_col}" if stratum_col else ""
    summary = f"Descriptive statistics for {len(cols)} numeric column(s){' by ' + group if group else ''}{stratum_phrase}{unit_phrase}, using available finite values in each column."
    return _finish(ds, plan, "describe", summary, tables, warnings, accounting, extra=extra or None)


def _groups(ds, plan):
    allowed, r_excl, excluded = _excluded_mask(ds, plan)
    cols = _wide_columns(ds, plan)
    if cols is not None:
        if plan.get("pool_by"):
            raise ValueError("Within-unit pooling (pool_by) requires long-format data with outcome ('y'), group ('group'), and unit ('pool_by') columns.")
        plan["columns"] = cols
        arrays, masks, reasons, by_var = [], [], [r_excl], []
        for c in cols:
            arr, mask_num, reason_num = _numeric(ds, c)
            mask = mask_num & allowed
            reason = ["; ".join(v for v in (r_excl[i], reason_num[i]) if v) for i in range(len(mask))]
            arrays.append(arr[mask])
            masks.append(mask)
            reasons.append(reason)
            by_var.append(_var_account(ds, c, mask, reason))
        overall = np.logical_or.reduce(masks)
        _check_unpooled_replicates(ds, plan, overall, set(cols))
        return cols, arrays, _account(ds, overall, reasons, by_var, excluded), None
    y = _column(ds, plan.get("y") or plan.get("x"), "the numeric outcome")
    group = _column(ds, plan.get("group"), "group labels")
    if y == group:
        raise ValueError("The outcome and group labels must be different columns.")
    plan.update(y=y, group=group)
    values, vy, ry = _numeric(ds, y)
    labels, vg, rg = _categorical(ds, group)
    if plan.get("pool_by"):
        unit_col = _column(ds, plan["pool_by"], "biological/cluster unit identifier")
        if unit_col in {y, group}:
            raise ValueError("The unit column (pool_by) must be distinct from the outcome and group columns.")
        pool_stat = plan.get("pool_stat", "mean")
        plan["pool_by"] = unit_col
        plan["pool_stat"] = pool_stat
        names, arrays, mask, r_lists, unit_acc = _pool_grouped_units(
            ds, values, vy, ry, labels, vg, rg, unit_col, pool_stat, allowed, r_excl
        )
        return names, arrays, _account(ds, mask, r_lists, excluded_rows=excluded), unit_acc
    mask = vy & vg & allowed
    _check_unpooled_replicates(ds, plan, mask, {y, group})
    # Keep groups with missing outcomes visible, so a whole group is never silently dropped.
    names = list(dict.fromkeys(labels[vg & allowed]))
    arrays = [values[mask & (labels == name)] for name in names]
    return names, arrays, _account(ds, mask, [r_excl, ry, rg], excluded_rows=excluded), None


def _scale_welch(a: np.ndarray, b: np.ndarray):
    n1, n2 = len(a), len(b)
    m1, m2 = float(np.mean(a)), float(np.mean(b))
    scale = max(float(np.max(np.abs(a))), float(np.max(np.abs(b))), 1.0)
    sa = (a - m1) / scale
    sb = (b - m2) / scale
    sv1, sv2 = float(np.var(sa, ddof=1)), float(np.var(sb, ddof=1))
    sse2 = sv1 / n1 + sv2 / n2
    if sse2 <= 0:
        raise ValueError("A Welch t-test cannot estimate uncertainty because both groups have zero variance.")
    df = sse2 ** 2 / ((sv1 / n1) ** 2 / (n1 - 1) + (sv2 / n2) ** 2 / (n2 - 1))
    diff_scaled = float(np.mean(a / scale) - np.mean(b / scale))
    t = diff_scaled / math.sqrt(sse2)
    p = float(2 * stats.t.sf(abs(t), df))
    se_orig = math.sqrt(sse2) * scale
    difference = m1 - m2
    half = float(stats.t.ppf(.975, df) * se_orig)
    spooled = math.sqrt(((n1 - 1) * sv1 + (n2 - 1) * sv2) / (n1 + n2 - 2))
    d = diff_scaled / spooled if spooled > 0 else None
    return t, df, p, difference, half, d


def _scale_anova(arrays: list[np.ndarray]):
    all_values = np.concatenate(arrays)
    scale = float(np.max(np.abs(all_values))) or 1.0
    scaled_arrays = [a / scale for a in arrays]
    all_scaled = np.concatenate(scaled_arrays)
    grand = float(np.mean(all_scaled))
    ssb = sum(len(sa) * (float(np.mean(sa)) - grand) ** 2 for sa in scaled_arrays)
    ssw = sum(float(np.sum((sa - np.mean(sa)) ** 2)) for sa in scaled_arrays)
    if ssw <= 0:
        raise ValueError("ANOVA cannot estimate residual variation: within-group variance is zero.")
    df1, df2 = len(arrays) - 1, len(all_values) - len(arrays)
    f = (ssb / df1) / (ssw / df2)
    p = float(stats.f.sf(f, df1, df2))
    eta = ssb / (ssb + ssw)
    return f, df1, df2, p, eta


def _group_test(ds, plan, method, warnings):
    _require_independent(plan)
    names, arrays, accounting, unit_acc = _groups(ds, plan)
    required = 2 if method in {"ttest", "mannwhitney"} else None
    if (required and len(names) != required) or (not required and len(names) < 2):
        raise ValueError(f"{method} requires {'exactly two' if required else 'at least two'} groups; {len(names)} were found.")
    minimum = 2 if method in {"ttest", "anova"} else 1
    unit_word = f"distinct '{unit_acc['unit_column']}' unit(s)" if unit_acc else "finite observation(s)"
    for name, values in zip(names, arrays):
        if len(values) < minimum:
            raise ValueError(f"Group '{name}' has {len(values)} {unit_word}; {method} requires at least {minimum} per group.")
    table_rows = [_summary(str(name), a, with_ci=method in {"ttest", "anova"}) for name, a in zip(names, arrays)]
    tables = [_table("Group summaries", table_rows)]
    if unit_acc is not None:
        tables.append(
            _table(
                "Biological unit summaries",
                [
                    {
                        "unit": r["unit"],
                        "group": r["group"],
                        "n_subreplicates": r["n_subreplicates"],
                        "value": r["value"],
                    }
                    for r in unit_acc["unit_rows"]
                ],
            )
        )
        warnings.append(
            f"Nested observations ({unit_acc['n_raw_observations']} rows) were pooled within {unit_acc['n_units']} "
            f"distinct '{unit_acc['unit_column']}' unit(s) using {unit_acc['pool_stat']} before group inference to prevent pseudoreplication."
        )
    if "by_variable" in accounting and any(v["omitted"] for v in accounting["by_variable"]):
        warnings.append("Wide-format groups use available values per column; partial-row omissions are enumerated under by_variable.")
    posthoc_req = str(plan.get("posthoc") or "none").strip().lower()
    if posthoc_req not in POSTHOCS:
        raise ValueError(f"Unsupported post-hoc procedure {posthoc_req!r}. Choose from: {', '.join(sorted(POSTHOCS))}.")
    if posthoc_req != "none":
        plan["posthoc"] = posthoc_req
    else:
        plan.pop("posthoc", None)

    if method == "ttest":
        a, b = arrays
        t, df, p, difference, half, d = _scale_welch(a, b)
        tables.append(_table("Welch t-test", [{"group_1": names[0], "group_2": names[1], "t": t, "df": df, "p": p, "mean_difference": difference, "ci_low": difference - half, "ci_high": difference + half, "cohens_d_pooled": d}]))
        warnings.append("The confidence interval is the Welch 95% interval for mean(group 1) minus mean(group 2). Cohen's d uses the pooled sample SD and is descriptive under unequal variances.")
        summary = f"Welch independent-samples t-test: t({df:.3g}) = {t:.4g}, p = {p:.4g}; mean difference ({names[0]} − {names[1]}) = {difference:.4g}, 95% CI [{difference-half:.4g}, {difference+half:.4g}]."
    elif method == "mannwhitney":
        a, b = arrays
        if np.unique(np.concatenate([a, b])).size < 2:
            raise ValueError("Mann–Whitney U cannot compare groups when all observations are identical.")
        result = stats.mannwhitneyu(a, b, alternative="two-sided", method="auto")
        if not math.isfinite(float(result.pvalue)):
            raise ValueError("Mann–Whitney U p-value is undefined for these degenerate ranks.")
        effect = 2 * float(result.statistic) / (len(a) * len(b)) - 1
        tables.append(_table("Mann–Whitney U", [{"group_1": names[0], "group_2": names[1], "U": result.statistic, "p": result.pvalue, "rank_biserial": effect}]))
        warnings.append("Two-sided Mann–Whitney U uses SciPy's automatic exact/asymptotic choice. It tests a distributional comparison; a median-shift interpretation needs additional shape assumptions. Rank-biserial sign is positive when group 1 tends to be larger.")
        summary = f"Mann–Whitney U = {result.statistic:.4g}, two-sided p = {result.pvalue:.4g}; rank-biserial effect = {effect:.4g}."
    elif method == "anova":
        f, df1, df2, p, eta = _scale_anova(arrays)
        tables.append(_table("One-way ANOVA", [{"F": f, "df_between": df1, "df_within": df2, "p": p, "eta_squared": eta}]))
        summary = f"One-way ANOVA: F({df1}, {df2}) = {f:.4g}, p = {p:.4g}; eta-squared = {eta:.4g}."
        if posthoc_req == "none":
            warnings.append("Classical one-way ANOVA assumes independent observations, approximately normal residuals, and a common variance. No automatic post-hoc comparisons or multiplicity correction were performed.")
        else:
            ph_rows, ph_note, ph_summary = _compute_posthoc_rows(names, arrays, method, posthoc_req, plan)
            tables.append(_table("Post-hoc pairwise comparisons", ph_rows))
            warnings.append("Classical one-way ANOVA assumes independent observations, approximately normal residuals, and a common variance. " + ph_note)
            if ph_summary:
                summary += " " + ph_summary
    else:
        if np.unique(np.concatenate(arrays)).size < 2:
            raise ValueError("Kruskal–Wallis cannot compare groups when all values are identical.")
        result = stats.kruskal(*arrays)
        n, k = sum(map(len, arrays)), len(arrays)
        effect = max(0., (float(result.statistic) - k + 1) / (n - k)) if n > k else None
        tables.append(_table("Kruskal–Wallis", [{"H": result.statistic, "df": k - 1, "p": result.pvalue, "eta_squared_H": effect}]))
        summary = f"Kruskal–Wallis H({k-1}) = {result.statistic:.4g}, p = {result.pvalue:.4g}."
        if posthoc_req == "none":
            warnings.append("Kruskal–Wallis compares rank distributions, with a tie correction and asymptotic p-value. A location-only interpretation needs comparable distribution shapes. No pairwise post-hoc tests were performed.")
        else:
            eff_ph = "holm_mannwhitney" if posthoc_req in {"tukey", "dunnett"} else posthoc_req
            plan["posthoc"] = eff_ph
            ph_rows, ph_note, ph_summary = _compute_posthoc_rows(names, arrays, method, eff_ph, plan)
            tables.append(_table("Post-hoc pairwise comparisons", ph_rows))
            warnings.append("Kruskal–Wallis compares rank distributions, with a tie correction and asymptotic p-value. " + ph_note)
            if ph_summary:
                summary += " " + ph_summary
        warnings.append("The reported rank-based eta-squared estimate is max(0, (H − k + 1) / (N − k)); it is unavailable when N equals k.")
        if min(map(len, arrays)) < 5:
            warnings.append("At least one group has fewer than five observations; the asymptotic Kruskal–Wallis p-value may be unreliable.")
    if unit_acc is not None:
        summary += f" (Pooled {unit_acc['n_raw_observations']} observations into {unit_acc['n_units']} '{unit_acc['unit_column']}' {unit_acc['pool_stat']}s.)"
    extra = {"unit_accounting": unit_acc} if unit_acc is not None else None
    return _finish(ds, plan, method, summary, tables, warnings, accounting, extra=extra)


_CONTROL_LABEL_RE = re.compile(r"^(?:control|ctrl|vehicle|veh|wt|wild[ _-]?type|sham|baseline|untreated|placebo|0)$", re.I)


def _compute_posthoc_rows(
    names: list[str],
    arrays: list[np.ndarray],
    method: str,
    posthoc: str,
    plan: dict,
) -> tuple[list[dict], str, str]:
    str_names = [str(nm) for nm in names]
    rows: list[dict] = []

    if posthoc == "tukey":
        if method != "anova":
            raise ValueError("Tukey–Kramer HSD post-hoc comparisons require method='anova'.")
        tk = stats.tukey_hsd(*arrays)
        ci = tk.confidence_interval(confidence_level=0.95)
        for i in range(len(str_names)):
            for j in range(i + 1, len(str_names)):
                diff = float(np.mean(arrays[j]) - np.mean(arrays[i]))
                rows.append({
                    "group_1": str_names[i],
                    "group_2": str_names[j],
                    "comparison": f"{str_names[j]} − {str_names[i]}",
                    "method": "Tukey–Kramer HSD",
                    "difference": diff,
                    "ci_low": float(ci.low[j, i]),
                    "ci_high": float(ci.high[j, i]),
                    "p_adjusted": float(tk.pvalue[j, i]),
                })
        sig = [f"{r['group_2']} vs {r['group_1']} (p = {r['p_adjusted']:.3g})" for r in rows if r["p_adjusted"] < 0.05]
        note = "Post-hoc pairwise comparisons use the family-wise Tukey–Kramer studentized range distribution (95% simultaneous confidence intervals)."
        summ = f"Tukey HSD significant pairs: {', '.join(sig[:5])}." if sig else "Tukey HSD: no pairwise differences < 0.05."
        return rows, note, summ

    if posthoc == "dunnett":
        if method != "anova":
            raise ValueError("Dunnett's many-to-one post-hoc test requires method='anova'.")
        ctrl_spec = str(plan.get("control_group") or "").strip()
        ctrl_idx = None
        if ctrl_spec:
            for idx, nm in enumerate(str_names):
                if nm == ctrl_spec or nm.casefold() == ctrl_spec.casefold():
                    ctrl_idx = idx
                    break
            if ctrl_idx is None:
                raise ValueError(f"Control group {ctrl_spec!r} not found in groups {str_names}.")
        else:
            for idx, nm in enumerate(str_names):
                if _CONTROL_LABEL_RE.match(nm.strip()):
                    ctrl_idx = idx
                    break
            if ctrl_idx is None:
                ctrl_idx = 0
        ctrl_name = str_names[ctrl_idx]
        plan["control_group"] = ctrl_name
        treat_idxs = [i for i in range(len(str_names)) if i != ctrl_idx]
        treat_arrs = [arrays[i] for i in treat_idxs]
        dn = stats.dunnett(*treat_arrs, control=arrays[ctrl_idx], rng=np.random.default_rng(20261118))
        ci = dn.confidence_interval(confidence_level=0.95)
        stat_vec = np.atleast_1d(dn.statistic)
        p_vec = np.atleast_1d(dn.pvalue)
        lo_vec = np.atleast_1d(ci.low)
        hi_vec = np.atleast_1d(ci.high)
        for m, tidx in enumerate(treat_idxs):
            diff = float(np.mean(arrays[tidx]) - np.mean(arrays[ctrl_idx]))
            rows.append({
                "group_1": ctrl_name,
                "group_2": str_names[tidx],
                "comparison": f"{str_names[tidx]} − {ctrl_name}",
                "method": "Dunnett vs control",
                "difference": diff,
                "statistic": float(stat_vec[m]),
                "ci_low": float(lo_vec[m]),
                "ci_high": float(hi_vec[m]),
                "p_adjusted": float(p_vec[m]),
            })
        sig = [f"{r['group_2']} vs {ctrl_name} (p = {r['p_adjusted']:.3g})" for r in rows if r["p_adjusted"] < 0.05]
        note = f"Dunnett's many-to-one post-hoc procedure compares each treatment group against '{ctrl_name}' with family-wise 95% intervals."
        summ = f"Dunnett vs {ctrl_name}: {', '.join(sig[:5])}." if sig else f"Dunnett vs {ctrl_name}: no comparisons < 0.05."
        return rows, note, summ

    if posthoc == "holm_welch":
        raw_ps: list[float | None] = []
        for i in range(len(str_names)):
            for j in range(i + 1, len(str_names)):
                t_v, df_v, p_v, diff, half, _d = _scale_welch(arrays[j], arrays[i])
                raw_ps.append(p_v)
                rows.append({
                    "group_1": str_names[i],
                    "group_2": str_names[j],
                    "comparison": f"{str_names[j]} − {str_names[i]}",
                    "method": "Welch t-test (Holm)",
                    "difference": diff,
                    "statistic": t_v,
                    "df": df_v,
                    "ci_low": diff - half,
                    "ci_high": diff + half,
                    "p_unadjusted": p_v,
                    "p_adjusted": None,
                })
        for r, padj in zip(rows, _holm_adjust(raw_ps)):
            r["p_adjusted"] = padj
        sig = [f"{r['group_2']} vs {r['group_1']} (Holm p = {r['p_adjusted']:.3g})" for r in rows if r["p_adjusted"] is not None and r["p_adjusted"] < 0.05]
        note = "Post-hoc pairwise comparisons use Welch two-sample t-tests with step-down Holm–Bonferroni multiplicity adjustment."
        summ = f"Holm–Welch significant pairs: {', '.join(sig[:5])}." if sig else "Holm–Welch: no pairwise differences < 0.05."
        return rows, note, summ

    if posthoc == "holm_mannwhitney":
        raw_ps = []
        for i in range(len(str_names)):
            for j in range(i + 1, len(str_names)):
                if np.unique(np.concatenate([arrays[i], arrays[j]])).size < 2:
                    raw_ps.append(1.0)
                    u_stat, rb = float(len(arrays[i]) * len(arrays[j])) / 2.0, 0.0
                else:
                    mw = stats.mannwhitneyu(arrays[j], arrays[i], alternative="two-sided", method="auto")
                    raw_ps.append(float(mw.pvalue))
                    u_stat = float(mw.statistic)
                    rb = 2.0 * u_stat / (len(arrays[i]) * len(arrays[j])) - 1.0
                rows.append({
                    "group_1": str_names[i],
                    "group_2": str_names[j],
                    "comparison": f"{str_names[j]} − {str_names[i]}",
                    "method": "Mann–Whitney U (Holm)",
                    "difference": float(np.median(arrays[j]) - np.median(arrays[i])),
                    "statistic": u_stat,
                    "rank_biserial": rb,
                    "p_unadjusted": raw_ps[-1],
                    "p_adjusted": None,
                })
        for r, padj in zip(rows, _holm_adjust(raw_ps)):
            r["p_adjusted"] = padj
        sig = [f"{r['group_2']} vs {r['group_1']} (Holm p = {r['p_adjusted']:.3g})" for r in rows if r["p_adjusted"] is not None and r["p_adjusted"] < 0.05]
        note = "Nonparametric post-hoc pairwise comparisons use two-sided Mann–Whitney U tests with step-down Holm–Bonferroni adjustment."
        summ = f"Holm–Mann–Whitney significant pairs: {', '.join(sig[:5])}." if sig else "Holm–Mann–Whitney: no pairwise differences < 0.05."
        return rows, note, summ

    raise ValueError(f"Unsupported post-hoc method {posthoc!r}.")


def _holm_adjust(p_values: list[float | None]) -> list[float | None]:
    indexed = [(idx, p) for idx, p in enumerate(p_values) if p is not None and math.isfinite(p)]
    m = len(indexed)
    out: list[float | None] = [None] * len(p_values)
    if not m:
        return out
    ordered = sorted(indexed, key=lambda item: item[1])
    running_max = 0.0
    for rank, (orig_idx, p) in enumerate(ordered):
        adj = min(1.0, p * (m - rank))
        running_max = max(running_max, adj)
        out[orig_idx] = running_max
    return out


def _batch_compare(ds: Dataset, plan: dict, warnings: list[str]) -> dict:
    _require_independent(plan)
    allowed, r_excl, excluded = _excluded_mask(ds, plan)
    group = _column(ds, plan.get("group"), "group labels")
    cols = _wide_columns(ds, plan)
    if not cols or len(cols) < 2:
        raise ValueError("batch_compare requires at least two numeric outcome columns in 'columns' and a 'group' column.")
    if len(cols) > 12:
        raise ValueError("batch_compare supports at most 12 outcome columns per figure/table panel.")
    if group in cols:
        raise ValueError("The group column cannot also be listed as an outcome column.")
    pool_by = _column(ds, plan["pool_by"], "biological/cluster unit identifier") if plan.get("pool_by") else None
    if pool_by and (pool_by == group or pool_by in cols):
        raise ValueError("The unit column (pool_by) must be distinct from the group and outcome columns.")
    pool_stat = plan.get("pool_stat", "mean")
    plan["group"] = group
    plan["columns"] = cols
    if pool_by:
        plan["pool_by"] = pool_by
        plan["pool_stat"] = pool_stat

    labels, vg, rg = _categorical(ds, group)
    group_names = list(dict.fromkeys(labels[vg & allowed]))
    if len(group_names) < 2:
        raise ValueError(f"batch_compare requires at least two groups in '{group}'; {len(group_names)} were found.")

    nonparametric = bool(plan.get("nonparametric", False))
    requested_test = plan.get("test")
    if requested_test is None:
        if len(group_names) == 2:
            test_name = "mannwhitney" if nonparametric else "ttest"
        else:
            test_name = "kruskal" if nonparametric else "anova"
    else:
        if requested_test not in {"ttest", "mannwhitney", "anova", "kruskal"}:
            raise ValueError("batch_compare 'test' must be 'ttest', 'mannwhitney', 'anova', or 'kruskal'.")
        if requested_test in {"ttest", "mannwhitney"} and len(group_names) != 2:
            raise ValueError(f"{requested_test} requires exactly two groups; {len(group_names)} were found.")
        test_name = requested_test
    plan["test"] = test_name

    summary_rows = []
    comparison_rows = []
    by_var = []
    masks = []
    reason_lists = [r_excl, rg]
    unit_acc_by_var = {}

    for col in cols:
        arr, vy, ry = _numeric(ds, col)
        if pool_by:
            names, arrays, mask, r_lists, unit_acc = _pool_grouped_units(
                ds, arr, vy, ry, labels, vg, rg, pool_by, pool_stat, allowed, r_excl
            )
            unit_acc_by_var[col] = unit_acc
            reason = ["; ".join(dict.fromkeys(rl[i] for rl in r_lists if rl[i])) for i in range(len(mask))]
        else:
            mask = vy & vg & allowed
            _check_unpooled_replicates(ds, plan, mask, set(cols) | {group})
            names = group_names
            arrays = [arr[mask & (labels == g)] for g in names]
            reason = ["; ".join(v for v in (r_excl[i], ry[i], rg[i]) if v) for i in range(len(mask))]
        masks.append(mask)
        reason_lists.append(reason)
        by_var.append(_var_account(ds, col, mask, reason))

        minimum = 2 if test_name in {"ttest", "anova"} else 1
        for g_name, g_arr in zip(names, arrays):
            if len(g_arr) < minimum:
                raise ValueError(f"Column '{col}', group '{g_name}' has {len(g_arr)} observation(s); {test_name} requires at least {minimum}.")
            s_row = _summary(col, g_arr, with_ci=test_name in {"ttest", "anova"})
            s_row["group"] = g_name
            summary_rows.append(s_row)

        if test_name == "ttest":
            t_val, df_val, p_val, diff, half, d_val = _scale_welch(arrays[0], arrays[1])
            comparison_rows.append({
                "variable": col, "test": "Welch t-test", "group_1": names[0], "group_2": names[1],
                "statistic": t_val, "df": df_val, "p_unadjusted": p_val, "p_holm": None,
                "mean_difference": diff, "ci_low": diff - half, "ci_high": diff + half,
                "effect_size": d_val, "effect_type": "cohens_d_pooled",
            })
        elif test_name == "mannwhitney":
            if np.unique(np.concatenate(arrays)).size < 2:
                raise ValueError(f"Column '{col}' has identical values across groups; Mann–Whitney U is undefined.")
            res = stats.mannwhitneyu(arrays[0], arrays[1], alternative="two-sided", method="auto")
            rb = 2 * float(res.statistic) / (len(arrays[0]) * len(arrays[1])) - 1
            comparison_rows.append({
                "variable": col, "test": "Mann–Whitney U", "group_1": names[0], "group_2": names[1],
                "statistic": float(res.statistic), "df": None, "p_unadjusted": float(res.pvalue), "p_holm": None,
                "effect_size": rb, "effect_type": "rank_biserial",
            })
        elif test_name == "anova":
            f_val, df1, df2, p_val, eta = _scale_anova(arrays)
            comparison_rows.append({
                "variable": col, "test": "One-way ANOVA", "statistic": f_val,
                "df": f"{df1}, {df2}", "p_unadjusted": p_val, "p_holm": None,
                "effect_size": eta, "effect_type": "eta_squared",
            })
        else:
            if np.unique(np.concatenate(arrays)).size < 2:
                raise ValueError(f"Column '{col}' has identical values across groups; Kruskal–Wallis is undefined.")
            res = stats.kruskal(*arrays)
            n_tot, k_grp = sum(map(len, arrays)), len(arrays)
            eff = max(0., (float(res.statistic) - k_grp + 1) / (n_tot - k_grp)) if n_tot > k_grp else None
            comparison_rows.append({
                "variable": col, "test": "Kruskal–Wallis", "statistic": float(res.statistic),
                "df": k_grp - 1, "p_unadjusted": float(res.pvalue), "p_holm": None,
                "effect_size": eff, "effect_type": "eta_squared_H",
            })

    adjusted = _holm_adjust([row["p_unadjusted"] for row in comparison_rows])
    for row, p_adj in zip(comparison_rows, adjusted):
        row["p_holm"] = p_adj

    overall_mask = np.logical_or.reduce(masks)
    accounting = _account(ds, overall_mask, reason_lists, by_var, excluded)
    warnings.append(
        f"Batch comparison across {len(cols)} endpoints includes step-down Holm–Bonferroni multiplicity-adjusted p-values (p_holm) alongside unadjusted p-values."
    )
    if pool_by:
        warnings.append(
            f"Each endpoint was pooled within '{pool_by}' ({pool_stat}) prior to group testing so nested observations are not treated as independent units."
        )
    parts = [f"{r['variable']}: p = {r['p_unadjusted']:.4g} (Holm {r['p_holm']:.4g})" for r in comparison_rows]
    summary = f"Batch {comparison_rows[0]['test']} across {len(cols)} measures by {group}" + (f" (pooled by {pool_by})" if pool_by else "") + ": " + "; ".join(parts) + "."
    tables = [
        _table("Batch group summaries", summary_rows),
        _table("Batch comparisons", comparison_rows),
    ]
    extra = {"batch_unit_accounting": unit_acc_by_var} if unit_acc_by_var else None
    return _finish(ds, plan, "batch_compare", summary, tables, warnings, accounting, extra=extra)


def _paired(ds, plan, warnings):
    if plan.get("design") != "paired":
        raise ValueError("Confirm the paired design before a paired t-test (design='paired'). Each pair must represent the same independent experimental unit.")
    allowed, r_excl, excluded = _excluded_mask(ds, plan)
    pair_rows = []
    if plan.get("subject") and plan.get("group"):
        subject = _column(ds, plan.get("subject"), "subject identifiers")
        group = _column(ds, plan.get("group"), "the two measurement conditions")
        y = _column(ds, plan.get("y") or plan.get("x"), "the numeric outcome")
        if len({subject, group, y}) != 3:
            raise ValueError("Subject, group, and numeric outcome must be three different columns for long-format paired data.")
        plan.update(subject=subject, group=group, y=y)
        subjects, vs, rs = _categorical(ds, subject)
        groups, vg, rg = _categorical(ds, group)
        values, vy, ry = _numeric(ds, y)
        names = list(dict.fromkeys(groups[vg & allowed]))
        if len(names) != 2:
            raise ValueError(f"Long-format paired data require exactly two groups; {len(names)} were found.")
        lookup = {}
        for i in np.flatnonzero(vs & vg & allowed):
            key = (subjects[i], groups[i])
            if key in lookup:
                raise ValueError(f"Subject '{subjects[i]}' has duplicate rows in group '{groups[i]}' (source rows {ds.row_numbers[lookup[key]]} and {ds.row_numbers[i]}). Resolve technical replicates or use a model that represents them.")
            lookup[key] = i
        mask = np.zeros(len(ds.df), dtype=bool)
        unmatched_reason = [""] * len(ds.df)
        for subj in dict.fromkeys(subjects[vs & allowed]):
            ia, ib = lookup.get((subj, names[0])), lookup.get((subj, names[1]))
            if ia is not None and ib is not None and vy[ia] and vy[ib]:
                mask[[ia, ib]] = True
                pair_rows.append({"subject": subj, "x": values[ia], "y": values[ib], "x_row": ds.row_numbers[ia], "y_row": ds.row_numbers[ib]})
            else:
                for i in np.flatnonzero(vs & allowed & (subjects == subj)):
                    unmatched_reason[i] = f"No complete pair for subject '{subj}' across '{names[0]}' and '{names[1]}'"
        accounting = _account(ds, mask, [r_excl, rs, rg, ry, unmatched_reason], excluded_rows=excluded)
        a = np.asarray([r["x"] for r in pair_rows])
        b = np.asarray([r["y"] for r in pair_rows])
    else:
        cols = _wide_columns(ds, plan)
        if cols is not None:
            if len(cols) != 2:
                raise ValueError("A wide-format paired t-test requires exactly two numeric columns.")
            x, y = cols
        else:
            x = _column(ds, plan.get("x"), "the first paired measurement")
            y = _column(ds, plan.get("y"), "the second paired measurement")
        if x == y:
            raise ValueError("Choose two different columns for paired measurements.")
        plan.update(x=x, y=y)
        values_x, vx, rx = _numeric(ds, x)
        values_y, vy, ry = _numeric(ds, y)
        mask = vx & vy & allowed
        accounting = _account(ds, mask, [r_excl, rx, ry], excluded_rows=excluded)
        a, b, names = values_x[mask], values_y[mask], [x, y]
        for i in np.flatnonzero(mask):
            pair_rows.append({"subject": str(ds.row_numbers[i]), "x": values_x[i], "y": values_y[i], "x_row": ds.row_numbers[i], "y_row": ds.row_numbers[i]})
    n = len(a)
    if n < 2:
        raise ValueError(f"A paired t-test needs at least two complete pairs; {n} were found.")
    diff = a - b
    scale = float(np.max(np.abs(diff))) or 1.0
    mean = float(np.mean(diff))
    sd = float(np.std((diff - mean) / scale, ddof=1) * scale)
    if sd <= 0:
        raise ValueError("All paired differences are identical; the paired t-test cannot estimate their uncertainty.")
    se = sd / np.sqrt(n)
    t, df = mean / se, n - 1
    p = float(2 * stats.t.sf(abs(t), df))
    half = float(stats.t.ppf(.975, df) * se)
    accounting["pairs"] = n
    warnings.append("The paired t-test assumes pairs are independent experimental units and their differences are approximately normal. The 95% confidence interval describes the mean paired difference. Individual-condition intervals are not calculated for this repeated design.")
    tables = [
        _table("Paired condition summaries", [_summary(str(names[0]), a), _summary(str(names[1]), b)]),
        _table("Paired t-test", [{"condition_1": names[0], "condition_2": names[1], "pairs": n, "t": t, "df": df, "p": p, "mean_difference": mean, "ci_low": mean - half, "ci_high": mean + half, "cohens_dz": mean / sd}]),
        _table("Paired observations", pair_rows),
    ]
    summary = f"Paired t-test on {n} complete pairs: t({df}) = {t:.4g}, p = {p:.4g}; mean paired difference ({names[0]} − {names[1]}) = {mean:.4g}, 95% CI [{mean-half:.4g}, {mean+half:.4g}]."
    return _finish(ds, plan, "paired_t", summary, tables, warnings, accounting)


def _xy(ds, plan):
    allowed, r_excl, excluded = _excluded_mask(ds, plan)
    x = _column(ds, plan.get("x"), "the x variable")
    y = _column(ds, plan.get("y"), "the y variable")
    if x == y:
        raise ValueError("Choose two different columns for x and y.")
    plan.update(x=x, y=y)
    a, va, ra = _numeric(ds, x)
    b, vb, rb = _numeric(ds, y)
    mask = va & vb & allowed
    _check_unpooled_replicates(ds, plan, mask, {x, y})
    return a[mask], b[mask], _account(ds, mask, [r_excl, ra, rb], excluded_rows=excluded)


def _association(ds, plan, method, warnings):
    _require_independent(plan)
    a, b, accounting = _xy(ds, plan)
    n = len(a)
    if n < 3:
        raise ValueError(f"{method} requires at least three complete observations; {n} were found.")
    if np.ptp(a) == 0:
        raise ValueError("The x variable has no variation; this analysis is undefined.")
    if method != "regression" and np.ptp(b) == 0:
        raise ValueError("The y variable has no variation; correlation is undefined.")
    tables = [_table("Variable summaries", [_summary(plan["x"], a, True), _summary(plan["y"], b, True)])]
    if method == "regression":
        if np.ptp(b) == 0:
            const_y = float(b[0])
            rows = [
                {"term": "Intercept", "estimate": const_y, "standard_error": 0.0, "t": None, "p": None, "ci_low": const_y, "ci_high": const_y},
                {"term": plan["x"], "estimate": 0.0, "standard_error": 0.0, "t": None, "p": None, "ci_low": 0.0, "ci_high": 0.0},
            ]
            fit = {"n": n, "r_squared": None, "adjusted_r_squared": None, "df_residual": float(n - 2), "residual_sd": 0.0}
            tables.extend([_table("OLS coefficients", rows), _table("OLS model fit", [fit])])
            warnings.append("OLS assumes independent errors and a correctly specified linear mean relation; conventional coefficient intervals also assume homoscedastic errors. Residual diagnostics and confounding assessment remain the analyst's responsibility. Association does not establish causation.")
            warnings.append("The outcome is constant; R-squared and t-statistics are undefined and are reported as unavailable.")
            summary = f"Ordinary least squares: {plan['y']} = {const_y:.4g} + 0 × {plan['x']}; n = {n} (constant outcome; slope p is undefined)."
        else:
            with pywarnings.catch_warnings():
                pywarnings.simplefilter("ignore", RuntimeWarning)
                model = OLS(b, add_constant(a, has_constant="add")).fit()
                intervals = model.conf_int(alpha=.05)
                rows = [{"term": term, "estimate": model.params[i], "standard_error": model.bse[i], "t": model.tvalues[i], "p": model.pvalues[i], "ci_low": intervals[i, 0], "ci_high": intervals[i, 1]} for i, term in enumerate(["Intercept", plan["x"]])]
                fit = {"n": n, "r_squared": model.rsquared, "adjusted_r_squared": model.rsquared_adj, "df_residual": model.df_resid, "residual_sd": np.sqrt(model.mse_resid)}
            tables.extend([_table("OLS coefficients", rows), _table("OLS model fit", [fit])])
            warnings.append("OLS assumes independent errors and a correctly specified linear mean relation; conventional coefficient intervals also assume homoscedastic errors. Residual diagnostics and confounding assessment remain the analyst's responsibility. Association does not establish causation.")
            summary = f"Ordinary least squares: {plan['y']} = {model.params[0]:.4g} + {model.params[1]:.4g} × {plan['x']}; n = {n}, slope p = {model.pvalues[1]:.4g}."
    else:
        result = stats.pearsonr(a, b) if method == "pearson" else stats.spearmanr(a, b)
        r, p = float(result.statistic), float(result.pvalue)
        lo = hi = None
        if method == "pearson" and n > 3:
            if abs(r) >= 1:
                lo = hi = r
            else:
                z = np.arctanh(r)
                half = stats.norm.ppf(.975) / np.sqrt(n - 3)
                lo, hi = np.tanh(z - half), np.tanh(z + half)
        tables.append(_table("Correlation", [{"x": plan["x"], "y": plan["y"], "n": n, "coefficient": r, "p": p, "ci_low": lo, "ci_high": hi}]))
        if method == "pearson":
            warnings.append("Pearson correlation measures linear association; its conventional p-value and Fisher-transform 95% interval rely on independent observations and distributional assumptions. Correlation does not establish causation.")
            if n <= 3:
                warnings.append("A finite Fisher-transform confidence interval needs more than three complete observations; no correlation interval was calculated.")
        else:
            warnings.append("Spearman correlation uses ranks with averaged ties and an asymptotic two-sided p-value. No confidence interval is estimated in this version. Correlation does not establish causation.")
            if n < 500:
                warnings.append("For this sample size, a permutation procedure may be preferable to Spearman's asymptotic p-value; a permutation test is not implemented in this version.")
        summary = f"{'Pearson r' if method == 'pearson' else 'Spearman rho'} = {r:.4g}, two-sided p = {p:.4g}, n = {n} complete observations."
    return _finish(ds, plan, method, summary, tables, warnings, accounting)


def _chi2(ds, plan, warnings):
    _require_independent(plan)
    allowed, r_excl, excluded = _excluded_mask(ds, plan)
    x = _column(ds, plan.get("x"), "the first categorical variable")
    y = _column(ds, plan.get("y") or plan.get("group"), "the second categorical variable")
    if x == y:
        raise ValueError("Choose two different categorical columns.")
    plan.update(x=x, y=y)
    a, va, ra = _categorical(ds, x)
    b, vb, rb = _categorical(ds, y)
    weight_col_spec = plan.get("count") or plan.get("weight")
    if weight_col_spec:
        count_col = _column(ds, weight_col_spec, "pre-aggregated cell counts")
        if count_col in {x, y}:
            raise ValueError("The count column must be distinct from both categorical columns.")
        plan["count"] = count_col
        plan.pop("weight", None)
        w_vals, vw, rw = _numeric(ds, count_col)
        mask = va & vb & vw & allowed
        if not mask.any():
            raise ValueError("No complete weighted categorical cells were found.")
        active_w = w_vals[mask]
        if np.any(active_w < 0) or not np.all(np.isclose(active_w, np.round(active_w), atol=1e-9)):
            raise ValueError(f"Count column '{count_col}' must contain nonnegative whole-number counts for a chi-square contingency test.")
        int_w = np.round(active_w).astype(int)
        if int(int_w.sum()) <= 0:
            raise ValueError(f"Count column '{count_col}' sums to zero.")
        counts = pd.crosstab(pd.Series(a[mask], name=x), pd.Series(b[mask], name=y), values=int_w, aggfunc="sum").fillna(0).astype(int)
        reason_lists = [r_excl, ra, rb, rw]
        n = int(counts.to_numpy().sum())
    else:
        mask = va & vb & allowed
        if not mask.any():
            raise ValueError("No complete categorical observations were found.")
        _check_unpooled_replicates(ds, plan, mask, {x, y})
        counts = pd.crosstab(pd.Series(a[mask], name=x), pd.Series(b[mask], name=y))
        if (counts.to_numpy() <= 1).all():
            for cand in ds.df.columns:
                if cand in {x, y} or not _COUNT_COLUMN_RE.match(cand.strip()):
                    continue
                raw = ds.df[cand]
                non_missing = ~(raw.map(_blank) | raw.map(_is_missing_token))
                conv = pd.to_numeric(raw.where(non_missing, np.nan), errors="coerce")
                if conv.notna().any() and not (non_missing & conv.isna()).any() and (conv.dropna() > 1).any():
                    raise ValueError(
                        f"Every ({x}, {y}) combination appears at most once while column '{cand}' contains numeric counts. "
                        f"Specify count='{cand}' (for example 'chi-square of {x} by {y} weighted by {cand}') so pre-aggregated cell counts are tested rather than row counts."
                    )
        reason_lists = [r_excl, ra, rb]
        n = int(mask.sum())

    if len(counts.index) > 200 or len(counts.columns) > 200:
        raise ValueError("A categorical variable has more than 200 levels. Check whether an identifier or continuous measurement was selected.")
    if min(counts.shape) < 2:
        raise ValueError("A chi-square independence test requires at least two observed categories in each variable.")
    if np.any(counts.sum(axis=0) == 0) or np.any(counts.sum(axis=1) == 0):
        raise ValueError("At least one category row or column has a total count of zero; chi-square expected frequencies are undefined.")
    chi, p, df, expected = stats.chi2_contingency(counts.to_numpy(), correction=False)
    effect = np.sqrt(chi / (n * min(counts.shape[0] - 1, counts.shape[1] - 1)))
    labels = [str(c) for c in counts.columns]
    # Prefix category fields to avoid collision with the first row-label field.
    fields = [f"{y}: {c}" for c in labels]
    observed_rows = [{"category": str(index), **{field: int(counts.iloc[i, j]) for j, field in enumerate(fields)}} for i, index in enumerate(counts.index)]
    expected_rows = [{"category": str(index), **{field: float(expected[i, j]) for j, field in enumerate(fields)}} for i, index in enumerate(counts.index)]
    tables = [
        _table("Chi-square independence test", [{"chi_squared": chi, "df": df, "p": p, "n": n, "cramers_v": effect, "expected_cells_below_5": int((expected < 5).sum())}]),
        _table("Observed counts", observed_rows),
        _table("Expected counts", expected_rows),
    ]
    if weight_col_spec:
        warnings.append(f"Pearson's chi-square independence test was computed from pre-aggregated integer counts in '{plan['count']}' (total n = {n}) without Yates correction.")
    else:
        warnings.append("Pearson's chi-square independence test is calculated without Yates correction. Input rows are individual independent observations unless an explicit count column is specified.")
    if (expected < 5).any():
        warnings.append("Some expected cell counts are below five; the chi-square approximation may be unreliable. Review an exact or simulation-based alternative; no automatic replacement test was run.")
    summary = f"Pearson chi-square({df}) = {chi:.4g}, p = {p:.4g}; Cramér's V = {effect:.4g}, n = {n}."
    return _finish(ds, plan, "chi2", summary, tables, warnings, _account(ds, mask, reason_lists, excluded_rows=excluded))


def _per_stratum_tests(
    strata: np.ndarray,
    stratum_order: list[str],
    labels: np.ndarray,
    group_names: list[str],
    values: np.ndarray,
    mask: np.ndarray,
    test_name: str,
) -> tuple[list[dict], list[dict]]:
    """Compute per-stratum (e.g. per-timepoint) group summaries and Holm-adjusted comparisons."""
    summary_rows: list[dict] = []
    comp_rows: list[dict] = []
    with_ci = test_name in {"ttest", "anova"}
    minimum = 2 if test_name in {"ttest", "anova"} else 1

    for s_name in stratum_order:
        s_mask = mask & (strata == s_name)
        arrays = [values[s_mask & (labels == g_name)] for g_name in group_names]
        for g_name, g_arr in zip(group_names, arrays):
            s_row = _summary(str(g_name), g_arr, with_ci=with_ci)
            summary_rows.append({
                "stratum": str(s_name),
                "group": str(g_name),
                **{k: v for k, v in s_row.items() if k != "variable"},
            })

        if any(len(g_arr) < minimum for g_arr in arrays):
            comp_rows.append({
                "stratum": str(s_name),
                "test": test_name,
                "group_1": group_names[0],
                "group_2": group_names[1] if len(group_names) == 2 else None,
                "statistic": None,
                "df": None,
                "p_unadjusted": None,
                "p_holm": None,
                "mean_difference": None,
                "effect_size": None,
                "effect_type": None,
                "note": f"Insufficient observations (< {minimum}) in at least one group at this stratum",
            })
            continue

        try:
            if test_name == "ttest":
                t_val, df_val, p_val, diff, half, d_val = _scale_welch(arrays[0], arrays[1])
                comp_rows.append({
                    "stratum": str(s_name),
                    "test": "Welch t-test",
                    "group_1": group_names[0],
                    "group_2": group_names[1],
                    "statistic": t_val,
                    "df": df_val,
                    "p_unadjusted": p_val,
                    "p_holm": None,
                    "mean_difference": diff,
                    "ci_low": diff - half,
                    "ci_high": diff + half,
                    "effect_size": d_val,
                    "effect_type": "cohens_d_pooled",
                })
            elif test_name == "mannwhitney":
                if np.unique(np.concatenate(arrays)).size < 2:
                    raise ValueError("constant values")
                res = stats.mannwhitneyu(arrays[0], arrays[1], alternative="two-sided", method="auto")
                rb = 2 * float(res.statistic) / (len(arrays[0]) * len(arrays[1])) - 1
                comp_rows.append({
                    "stratum": str(s_name),
                    "test": "Mann–Whitney U",
                    "group_1": group_names[0],
                    "group_2": group_names[1],
                    "statistic": float(res.statistic),
                    "df": None,
                    "p_unadjusted": float(res.pvalue),
                    "p_holm": None,
                    "mean_difference": float(np.median(arrays[0]) - np.median(arrays[1])),
                    "effect_size": rb,
                    "effect_type": "rank_biserial",
                })
            elif test_name == "anova":
                f_val, df1, df2, p_val, eta = _scale_anova(arrays)
                comp_rows.append({
                    "stratum": str(s_name),
                    "test": "One-way ANOVA",
                    "statistic": f_val,
                    "df": f"{df1}, {df2}",
                    "p_unadjusted": p_val,
                    "p_holm": None,
                    "effect_size": eta,
                    "effect_type": "eta_squared",
                })
            else:
                if np.unique(np.concatenate(arrays)).size < 2:
                    raise ValueError("constant values")
                res = stats.kruskal(*arrays)
                n_tot, k_grp = sum(map(len, arrays)), len(arrays)
                eff = max(0.0, (float(res.statistic) - k_grp + 1) / (n_tot - k_grp)) if n_tot > k_grp else None
                comp_rows.append({
                    "stratum": str(s_name),
                    "test": "Kruskal–Wallis",
                    "statistic": float(res.statistic),
                    "df": k_grp - 1,
                    "p_unadjusted": float(res.pvalue),
                    "p_holm": None,
                    "effect_size": eff,
                    "effect_type": "eta_squared_H",
                })
        except ValueError:
            comp_rows.append({
                "stratum": str(s_name),
                "test": test_name,
                "group_1": group_names[0],
                "group_2": group_names[1] if len(group_names) == 2 else None,
                "statistic": None,
                "df": None,
                "p_unadjusted": None,
                "p_holm": None,
                "mean_difference": None,
                "effect_size": None,
                "effect_type": None,
                "note": "Zero variance or constant values at this stratum (e.g. normalized baseline)",
            })

    adjusted = _holm_adjust([r.get("p_unadjusted") for r in comp_rows])
    for r, p_adj in zip(comp_rows, adjusted):
        r["p_holm"] = p_adj
    return summary_rows, comp_rows


def _note_longitudinal_units(ds: Dataset, mask: np.ndarray, strata: np.ndarray, stratum_order: list[str], used_cols: set[str], warnings: list[str], x_name: str) -> None:
    for col in ds.df.columns:
        if col in used_cols or not _UNIT_COLUMN_RE.match(col.strip()):
            continue
        u_vals, v_u, _ = _categorical(ds, col)
        active = mask & v_u
        if int(active.sum()) < 3:
            continue
        # Check if duplicate subreplicates exist WITHIN a single stratum
        dup_within = False
        for s_name in stratum_order:
            sub_u = u_vals[active & (strata == s_name)]
            if len(sub_u) > len(set(sub_u)):
                dup_within = True
                break
        if dup_within:
            raise ValueError(
                f"Column '{col}' has multiple observations for the same unit within a single '{x_name}' stratum. "
                f"Pool technical subreplicates per ('{col}', '{x_name}') first via build_working_sheet(op='aggregate_units')."
            )
        n_units = len(set(u_vals[active]))
        if n_units < int(active.sum()):
            warnings.append(
                f"Longitudinal note: {int(active.sum())} observations come from {n_units} distinct '{col}' units tracked across '{x_name}'. "
                f"Groups are compared at each '{x_name}' with step-down Holm–Bonferroni multiplicity adjustment; cross-timepoint within-subject correlation is not modeled as a random effect."
            )


def _timecourse_compare(ds: Dataset, plan: dict, warnings: list[str]) -> dict:
    if plan.get("design") not in {"independent", "paired"}:
        raise ValueError(
            "Confirm the study design before timecourse comparison (design='independent' when groups contain distinct biological subjects, or design='paired' for repeated tracking)."
        )
    allowed, r_excl, excluded = _excluded_mask(ds, plan)
    x = _column(ds, plan.get("x"), "the timepoint or horizontal factor ('x')")
    y = _column(ds, plan.get("y"), "the numeric outcome ('y')")
    group = _column(ds, plan.get("group"), "group labels ('group')")
    if len({x, y, group}) != 3:
        raise ValueError("Timecourse comparison requires distinct columns for 'x' (timepoint), 'y' (numeric outcome), and 'group'.")
    subj_col = _column(ds, plan["subject"], "subject identifiers") if plan.get("subject") else None
    plan.update(x=x, y=y, group=group)
    if subj_col:
        plan["subject"] = subj_col

    strata, vx, rx = _categorical(ds, x)
    labels, vg, rg = _categorical(ds, group)
    values, vy, ry = _numeric(ds, y)
    mask = vx & vg & vy & allowed

    stratum_order = _sort_strata_naturally(list(dict.fromkeys(strata[vx & allowed])))
    group_names = list(dict.fromkeys(labels[vg & allowed]))
    if len(stratum_order) < 2:
        raise ValueError(f"timecourse_compare requires at least 2 timepoints/levels in '{x}'; {len(stratum_order)} found.")
    if len(group_names) < 2:
        raise ValueError(f"timecourse_compare requires at least 2 groups in '{group}'; {len(group_names)} found.")

    _note_longitudinal_units(ds, mask, strata, stratum_order, {x, y, group} | ({subj_col} if subj_col else set()), warnings, x)

    nonparametric = bool(plan.get("nonparametric", False))
    requested_test = plan.get("test")
    if requested_test is None:
        test_name = ("mannwhitney" if nonparametric else "ttest") if len(group_names) == 2 else ("kruskal" if nonparametric else "anova")
    else:
        if requested_test not in {"ttest", "mannwhitney", "anova", "kruskal"}:
            raise ValueError("timecourse_compare 'test' must be 'ttest', 'mannwhitney', 'anova', or 'kruskal'.")
        if requested_test in {"ttest", "mannwhitney"} and len(group_names) != 2:
            raise ValueError(f"{requested_test} requires exactly two groups; {len(group_names)} were found.")
        test_name = requested_test
    plan["test"] = test_name

    summary_rows, comp_rows = _per_stratum_tests(strata, stratum_order, labels, group_names, values, mask, test_name)
    valid_comps = [r for r in comp_rows if r.get("p_unadjusted") is not None]
    if not valid_comps:
        raise ValueError(
            f"No '{x}' timepoints had sufficient variance and sample size in each '{group}' group to run {test_name}."
        )

    warnings.append(
        f"Per-timepoint comparisons across {len(stratum_order)} '{x}' levels report both unadjusted p-values and step-down Holm–Bonferroni multiplicity-adjusted p-values (p_holm)."
    )
    parts = [
        f"{r['stratum']}: p = {r['p_unadjusted']:.4g} (Holm {r['p_holm']:.4g})"
        if r.get("p_unadjusted") is not None
        else f"{r['stratum']}: n/a ({r.get('note', 'constant')})"
        for r in comp_rows
    ]
    summary = f"Per-timepoint {valid_comps[0]['test']} of {y} by {group} across {len(stratum_order)} {x} levels: " + "; ".join(parts) + "."
    tables = [
        _table("Timepoint group summaries", summary_rows),
        _table("Timepoint comparisons", comp_rows),
    ]
    return _finish(ds, plan, "timecourse_compare", summary, tables, warnings, _account(ds, mask, [r_excl, rx, rg, ry], excluded_rows=excluded))


def _ols_sse_rank(X_mat: np.ndarray, y_vec: np.ndarray) -> tuple[float, int]:
    coef, _, rank, _ = np.linalg.lstsq(X_mat, y_vec, rcond=None)
    resid = y_vec - X_mat @ coef
    return float(np.sum(resid ** 2)), int(rank)


def _two_way_anova(ds: Dataset, plan: dict, warnings: list[str]) -> dict:
    if plan.get("design") not in {"independent", "paired"}:
        raise ValueError(
            "Confirm the study design before two-way ANOVA (design='independent' for separate biological units per group, or design='paired' when tracking longitudinal timepoints)."
        )
    allowed, r_excl, excluded = _excluded_mask(ds, plan)
    x = _column(ds, plan.get("x"), "second factor / timepoint ('x')")
    y = _column(ds, plan.get("y"), "the numeric outcome ('y')")
    group = _column(ds, plan.get("group"), "group factor ('group')")
    if len({x, y, group}) != 3:
        raise ValueError("Two-way ANOVA requires distinct columns for 'group', 'x' (second factor/timepoint), and 'y' (numeric outcome).")
    subj_col = _column(ds, plan["subject"], "subject identifiers") if plan.get("subject") else None
    plan.update(x=x, y=y, group=group)
    if subj_col:
        plan["subject"] = subj_col

    strata, vx, rx = _categorical(ds, x)
    labels, vg, rg = _categorical(ds, group)
    values, vy, ry = _numeric(ds, y)
    mask = vx & vg & vy & allowed

    stratum_order = _sort_strata_naturally(list(dict.fromkeys(strata[vx & allowed])))
    group_names = list(dict.fromkeys(labels[vg & allowed]))
    if len(group_names) < 2 or len(stratum_order) < 2:
        raise ValueError(
            f"Two-way ANOVA requires at least 2 levels in '{group}' (found {len(group_names)}) and at least 2 levels in '{x}' (found {len(stratum_order)})."
        )

    _note_longitudinal_units(ds, mask, strata, stratum_order, {x, y, group} | ({subj_col} if subj_col else set()), warnings, x)

    y_use = values[mask]
    g_use = labels[mask]
    x_use = strata[mask]
    n = len(y_use)
    if n < len(group_names) + len(stratum_order):
        raise ValueError("Two-way ANOVA requires replication beyond the number of factor levels.")

    scale = float(np.max(np.abs(y_use))) or 1.0
    y_s = y_use / scale
    ones = np.ones((n, 1), dtype=float)
    D_a = np.column_stack([(g_use == g_lvl).astype(float) for g_lvl in group_names[1:]])
    D_b = np.column_stack([(x_use == s_lvl).astype(float) for s_lvl in stratum_order[1:]])
    D_ab = np.column_stack([D_a[:, i] * D_b[:, j] for i in range(D_a.shape[1]) for j in range(D_b.shape[1])])

    sse_a, r_a = _ols_sse_rank(np.hstack([ones, D_a]), y_s)
    sse_b, r_b = _ols_sse_rank(np.hstack([ones, D_b]), y_s)
    sse_add, r_add = _ols_sse_rank(np.hstack([ones, D_a, D_b]), y_s)
    sse_full, r_full = _ols_sse_rank(np.hstack([ones, D_a, D_b, D_ab]), y_s)

    df_res = n - r_full
    additive_only = False
    if df_res < 1:
        df_res_add = n - r_add
        if df_res_add >= 1 and sse_add > 1e-30:
            additive_only = True
            df_res = df_res_add
            sse_resid = sse_add
        else:
            raise ValueError("Two-way ANOVA cannot estimate residual variance: within-cell residual degrees of freedom or variance is zero.")
    elif sse_full <= 1e-30:
        raise ValueError("Two-way ANOVA cannot estimate residual variance: within-cell residual degrees of freedom or variance is zero.")
    else:
        sse_resid = sse_full

    ms_res_s = sse_resid / df_res
    scale2 = scale ** 2
    anova_rows = []
    effects_spec = [
        (group, max(0.0, sse_b - sse_add), max(1, r_add - r_b)),
        (x, max(0.0, sse_a - sse_add), max(1, r_add - r_a)),
    ]
    df_int = r_full - r_add
    if not additive_only and df_int >= 1:
        effects_spec.append((f"{group} × {x}", max(0.0, sse_add - sse_full), df_int))

    summary_bits = []
    for source_lbl, ss_s, df_eff in effects_spec:
        ms_s = ss_s / df_eff
        f_val = ms_s / ms_res_s
        p_val = float(stats.f.sf(f_val, df_eff, df_res))
        p_eta2 = ss_s / (ss_s + sse_resid) if (ss_s + sse_resid) > 0 else 0.0
        anova_rows.append({
            "source": source_lbl,
            "ss": ss_s * scale2,
            "df": df_eff,
            "ms": ms_s * scale2,
            "F": f_val,
            "p": p_val,
            "partial_eta_squared": p_eta2,
        })
        summary_bits.append(f"{source_lbl}: F({df_eff}, {df_res}) = {f_val:.4g}, p = {p_val:.4g}")

    anova_rows.append({
        "source": "Residual",
        "ss": sse_resid * scale2,
        "df": df_res,
        "ms": ms_res_s * scale2,
        "F": None,
        "p": None,
        "partial_eta_squared": None,
    })

    simple_test = "ttest" if len(group_names) == 2 else "anova"
    cell_rows, comp_rows = _per_stratum_tests(strata, stratum_order, labels, group_names, values, mask, simple_test)
    if additive_only:
        warnings.append(
            f"Unreplicated two-way / block design (1 observation per '{group}' × '{x}' cell): fitted additive Type II main-effects ANOVA ({group} + {x}) without an interaction term."
        )
        model_lbl = f"{group} + {x}"
    else:
        warnings.append(
            f"Two-way factorial ANOVA uses Type II sum of squares across '{group}' and '{x}' with ordinary least-squares residuals, accompanied by Holm–Bonferroni adjusted simple-effect comparisons at each '{x}' level."
        )
        model_lbl = f"{group} × {x}"
    summary = f"Two-way ANOVA of {y} by {model_lbl} (n = {n}): " + "; ".join(summary_bits) + "."
    tables = [
        _table("Two-way ANOVA", anova_rows),
        _table("Timepoint group summaries", cell_rows),
        _table("Timepoint comparisons", comp_rows),
    ]
    return _finish(ds, plan, "two_way_anova", summary, tables, warnings, _account(ds, mask, [r_excl, rx, rg, ry], excluded_rows=excluded))


def _orthonormal_helmert(m: int) -> np.ndarray:
    """Return m × (m - 1) orthonormal Helmert contrast matrix for exact spherical Greenhouse–Geisser."""
    H = np.zeros((m, m - 1), dtype=float)
    for c in range(m - 1):
        H[:c + 1, c] = 1.0
        H[c + 1, c] = -float(c + 1)
        H[:, c] /= float(np.linalg.norm(H[:, c]))
    return H


def _gg_from_orthonormal_scores(Z: np.ndarray) -> float:
    """Compute exact Greenhouse–Geisser sphericity epsilon from N × d orthonormal contrast scores."""
    n_obs, d = Z.shape
    if d <= 1 or n_obs < 3:
        return 1.0
    S = np.atleast_2d(np.cov(Z, rowvar=False, ddof=1))
    tr_s = float(np.trace(S))
    sum_sq = float(np.sum(S * S))
    if sum_sq <= 1e-30:
        return 1.0
    return float(np.clip((tr_s * tr_s) / (d * sum_sq), 1.0 / d, 1.0))


def _rm_two_way(ds: Dataset, plan: dict, warnings: list[str]) -> dict:
    """Within-Subject (A × B crossover, e.g. Drug × CO2 HCVR) or Mixed Split-Plot Two-Way RM-ANOVA + MixedLM fallback."""
    if plan.get("design") not in {"paired", "independent"}:
        raise ValueError(
            "Confirm the study design before two-way repeated-measures analysis (design='paired' for within-subject tracking across levels)."
        )
    allowed, r_excl, excluded = _excluded_mask(ds, plan)
    x = _column(ds, plan.get("x"), "repeated factor / CO2 / timepoint ('x')")
    y = _column(ds, plan.get("y"), "the numeric outcome ('y')")
    group = _column(ds, plan.get("group"), "condition / drug / group factor ('group')")
    subj_raw = plan.get("subject") or plan.get("pool_by")
    if not subj_raw:
        # Auto-detect explicit subject/mouse column when uniquely present
        cand_subjs = [c for c in ds.df.columns if str(c) not in {x, y, group} and _UNIT_COLUMN_RE.match(str(c).strip())]
        if len(cand_subjs) == 1:
            subj_raw = str(cand_subjs[0])
    subj_col = _column(ds, subj_raw, "subject / animal identifier ('subject')")
    if len({x, y, group, subj_col}) != 4:
        raise ValueError("rm_two_way requires distinct columns for 'subject', 'group', 'x', and 'y'.")
    plan.update(x=x, y=y, group=group, subject=subj_col)

    subjs, vs, rs = _categorical(ds, subj_col)
    strata, vx, rx = _categorical(ds, x)
    labels, vg, rg = _categorical(ds, group)
    values, vy, ry = _numeric(ds, y)
    mask = vs & vx & vg & vy & allowed

    stratum_order = _sort_strata_naturally(list(dict.fromkeys(strata[vx & allowed])))
    group_names = list(dict.fromkeys(labels[vg & allowed]))
    J = len(group_names)
    K = len(stratum_order)
    if J < 2 or K < 2:
        raise ValueError(
            f"rm_two_way requires at least 2 levels in '{group}' (found {J}) and at least 2 levels in '{x}' (found {K})."
        )

    work_df = pd.DataFrame({
        "subj": subjs[mask],
        "grp": labels[mask],
        "x": strata[mask],
        "y": values[mask],
    })
    if work_df.empty:
        raise ValueError("No complete finite observations are available for rm_two_way.")

    # Pool technical duplicate epochs within identical (subj, grp, x) cells with explicit audit warning
    dup_cells = int(work_df.duplicated(subset=["subj", "grp", "x"]).sum())
    if dup_cells > 0:
        work_df = work_df.groupby(["subj", "grp", "x"], sort=False, as_index=False)["y"].mean()
        warnings.append(
            f"Averaged {dup_cells} technical duplicate row(s) within identical ({subj_col}, {group}, {x}) cells so each subject contributes at most one observation per cell."
        )

    # Determine whether subjects are crossed across `group` (Before vs After Drug on same mouse) or nested within `group` (WT vs KO mice)
    subj_grp_counts = work_df.groupby("subj")["grp"].nunique()
    is_within_both = bool((subj_grp_counts > 1).any())

    # Cell summaries across all valid observations
    cell_rows: list[dict] = []
    for s_lvl in stratum_order:
        for g_lvl in group_names:
            arr_sg = work_df.loc[(work_df["x"] == s_lvl) & (work_df["grp"] == g_lvl), "y"].to_numpy(dtype=float)
            if len(arr_sg):
                s_info = _summary(f"{g_lvl} @ {s_lvl}", arr_sg)
                s_info["stratum"] = s_lvl
                s_info["group"] = g_lvl
                cell_rows.append(s_info)

    anova_rows: list[dict] = []
    comp_rows: list[dict] = []
    summary_bits: list[str] = []

    if is_within_both:
        # Completely Within-Subject J × K Crossover (e.g. Before_Drug vs After_Drug across 0%, 3%, 5%, 7% CO2)
        all_subjs = list(dict.fromkeys(work_df["subj"].tolist()))
        complete_subjs: list[str] = []
        Y_list: list[np.ndarray] = []
        cell_lookup = {(r["subj"], r["grp"], r["x"]): float(r["y"]) for r in work_df.to_dict("records")}
        for s_id in all_subjs:
            mat = np.empty((J, K), dtype=float)
            ok = True
            for j_i, g_lvl in enumerate(group_names):
                for k_i, x_lvl in enumerate(stratum_order):
                    v_cell = cell_lookup.get((s_id, g_lvl, x_lvl))
                    if v_cell is None or not math.isfinite(v_cell):
                        ok = False
                        break
                    mat[j_i, k_i] = v_cell
                if not ok:
                    break
            if ok:
                complete_subjs.append(s_id)
                Y_list.append(mat)

        n_comp = len(complete_subjs)
        if n_comp < len(all_subjs):
            warnings.append(
                f"{len(all_subjs) - n_comp} of {len(all_subjs)} '{subj_col}' unit(s) lacked complete {J}×{K} crossover cells."
            )

        if n_comp >= 2:
            Y = np.stack(Y_list, axis=0)  # (N, J, K)
            grand = float(np.mean(Y))
            m_i = np.mean(Y, axis=(1, 2), keepdims=True)
            m_j = np.mean(Y, axis=(0, 2), keepdims=True)
            m_k = np.mean(Y, axis=(0, 1), keepdims=True)
            m_ij = np.mean(Y, axis=2, keepdims=True)
            m_ik = np.mean(Y, axis=1, keepdims=True)
            m_jk = np.mean(Y, axis=0, keepdims=True)

            ss_a = float(n_comp * K * np.sum((m_j - grand) ** 2))
            ss_sa = float(K * np.sum((m_ij - m_i - m_j + grand) ** 2))
            ss_b = float(n_comp * J * np.sum((m_k - grand) ** 2))
            ss_sb = float(J * np.sum((m_ik - m_i - m_k + grand) ** 2))
            ss_ab = float(n_comp * np.sum((m_jk - m_j - m_k + grand) ** 2))
            ss_sab = float(np.sum((Y - m_ij - m_ik - m_jk + m_i + m_j + m_k - grand) ** 2))

            df_a, df_sa = J - 1, (n_comp - 1) * (J - 1)
            df_b, df_sb = K - 1, (n_comp - 1) * (K - 1)
            df_ab, df_sab = (J - 1) * (K - 1), (n_comp - 1) * (J - 1) * (K - 1)

            CA = _orthonormal_helmert(J)
            CB = _orthonormal_helmert(K)
            eps_a = _gg_from_orthonormal_scores(np.mean(Y, axis=2) @ CA)
            eps_b = _gg_from_orthonormal_scores(np.mean(Y, axis=1) @ CB)
            Z_ab = np.vstack([(CA.T @ Y[i] @ CB).ravel() for i in range(n_comp)])
            eps_ab = _gg_from_orthonormal_scores(Z_ab)

            for lbl, ss_eff, df_eff, ss_err, df_err, eps in (
                (group, ss_a, df_a, ss_sa, df_sa, eps_a),
                (x, ss_b, df_b, ss_sb, df_sb, eps_b),
                (f"{group} × {x}", ss_ab, df_ab, ss_sab, df_sab, eps_ab),
            ):
                if ss_err <= 1e-30 or df_err < 1:
                    raise ValueError(f"Zero within-subject error variance for '{lbl}'; F-ratio is undefined.")
                ms_eff = ss_eff / df_eff
                ms_err = ss_err / df_err
                f_val = ms_eff / ms_err
                p_sph = float(stats.f.sf(f_val, df_eff, df_err))
                p_gg = float(stats.f.sf(f_val, eps * df_eff, eps * df_err))
                p_eta2 = ss_eff / (ss_eff + ss_err) if (ss_eff + ss_err) > 0 else 0.0
                anova_rows.append({
                    "source": lbl,
                    "design_stratum": "Within-Subjects",
                    "subjects": n_comp,
                    "ss": ss_eff,
                    "df": df_eff,
                    "df_error": df_err,
                    "ms": ms_eff,
                    "ms_error": ms_err,
                    "F": f_val,
                    "gg_epsilon": eps,
                    "df_gg": eps * df_eff,
                    "df_gg_error": eps * df_err,
                    "p_sphericity_assumed": p_sph,
                    "p": p_gg,
                    "partial_eta_squared": p_eta2,
                })
                summary_bits.append(f"{lbl}: F({eps * df_eff:.3g}, {eps * df_err:.3g}) = {f_val:.4g}, p = {p_gg:.4g}")

            warnings.append(
                f"Two-way within-subject Repeated-Measures ANOVA across '{group}' ({J} levels) × '{x}' ({K} levels) on N = {n_comp} complete '{subj_col}' subjects reports Greenhouse–Geisser sphericity-adjusted p-values alongside Holm–Bonferroni paired comparisons at each '{x}' level."
            )
            design_desc = f"Two-way within-subject RM-ANOVA (N = {n_comp} {subj_col})"
        else:
            # Unbalanced MixedLM random-intercept fallback
            from statsmodels.regression.mixed_linear_model import MixedLM
            if len(all_subjs) < 2:
                raise ValueError(f"rm_two_way requires at least 2 distinct '{subj_col}' subjects.")
            D_a = np.column_stack([(work_df["grp"].to_numpy() == g_lvl).astype(float) for g_lvl in group_names[1:]])
            D_b = np.column_stack([(work_df["x"].to_numpy() == s_lvl).astype(float) for s_lvl in stratum_order[1:]])
            D_ab = np.column_stack([D_a[:, i] * D_b[:, j] for i in range(D_a.shape[1]) for j in range(D_b.shape[1])])
            X_full = np.hstack([np.ones((len(work_df), 1)), D_a, D_b, D_ab])
            m_fit = MixedLM(work_df["y"].to_numpy(dtype=float), X_full, groups=work_df["subj"].to_numpy()).fit(reml=True, disp=False)
            idx_a_end = 1 + D_a.shape[1]
            idx_b_end = idx_a_end + D_b.shape[1]
            for lbl, slc in (
                (group, slice(1, idx_a_end)),
                (x, slice(idx_a_end, idx_b_end)),
                (f"{group} × {x}", slice(idx_b_end, X_full.shape[1])),
            ):
                R_mat = np.zeros((slc.stop - slc.start, X_full.shape[1]))
                for r_i, c_i in enumerate(range(slc.start, slc.stop)):
                    R_mat[r_i, c_i] = 1.0
                wt = m_fit.wald_test(R_mat, scalar=True)
                f_v = float(wt.statistic)
                df_n = int(slc.stop - slc.start)
                df_d = max(1, len(work_df) - X_full.shape[1])
                p_v = float(stats.f.sf(f_v, df_n, df_d))
                anova_rows.append({
                    "source": lbl,
                    "design_stratum": "Linear Mixed Model (REML)",
                    "subjects": len(all_subjs),
                    "df": df_n,
                    "df_error": df_d,
                    "F": f_v,
                    "p": p_v,
                })
                summary_bits.append(f"{lbl}: F({df_n}, {df_d}) = {f_v:.4g}, p = {p_v:.4g}")
            warnings.append(
                f"Incomplete {J}×{K} cells prevented balanced RM-ANOVA; fitted REML Linear Mixed-Effects Model with random '{subj_col}' intercepts across {len(all_subjs)} subjects."
            )
            design_desc = f"Linear Mixed-Effects 2-Way Model (N = {len(all_subjs)} {subj_col})"

        # Per-stratum paired comparisons across `group` at each `x` level
        nonparam = bool(plan.get("nonparametric", False))
        raw_ps: list[float | None] = []
        for s_lvl in stratum_order:
            sub_x = work_df[work_df["x"] == s_lvl]
            piv = sub_x.pivot(index="subj", columns="grp", values="y").reindex(columns=group_names).dropna()
            n_pair = len(piv)
            if n_pair < 2:
                raw_ps.append(None)
                comp_rows.append({"stratum": s_lvl, "test": "Paired comparison", "n_pairs": n_pair, "statistic": None, "p_unadjusted": None, "p_holm": None, "note": "fewer than 2 matched subjects"})
                continue
            if J == 2:
                d_vec = piv[group_names[1]].to_numpy(dtype=float) - piv[group_names[0]].to_numpy(dtype=float)
                if nonparam:
                    nz = d_vec[d_vec != 0.0]
                    if len(nz) >= 1:
                        w_res = stats.wilcoxon(nz, zero_method="wilcox", alternative="two-sided")
                        stat_v, p_u = float(w_res.statistic), float(w_res.pvalue)
                    else:
                        stat_v, p_u = 0.0, 1.0
                    t_lbl = "Wilcoxon signed-rank"
                else:
                    sd_d = float(np.std(d_vec, ddof=1))
                    md_d = float(np.mean(d_vec))
                    if sd_d > 0:
                        t_v = md_d / (sd_d / math.sqrt(n_pair))
                        stat_v, p_u = float(t_v), float(2.0 * stats.t.sf(abs(t_v), n_pair - 1))
                    else:
                        stat_v, p_u = None, (1.0 if md_d == 0.0 else 0.0)
                    t_lbl = "Paired t-test"
                raw_ps.append(p_u)
                comp_rows.append({
                    "stratum": s_lvl,
                    "test": t_lbl,
                    "n_pairs": n_pair,
                    "mean_difference": float(np.mean(d_vec)),
                    "statistic": stat_v,
                    "p_unadjusted": p_u,
                    "p_holm": None,
                })
            else:
                M_x = piv.to_numpy(dtype=float)
                gm_x = float(np.mean(M_x))
                sm_x = np.mean(M_x, axis=1, keepdims=True)
                cm_x = np.mean(M_x, axis=0, keepdims=True)
                ss_c = float(n_pair * np.sum((cm_x - gm_x) ** 2))
                ss_e = float(np.sum((M_x - sm_x - cm_x + gm_x) ** 2))
                if ss_e > 0:
                    f_x = (ss_c / (J - 1)) / (ss_e / ((n_pair - 1) * (J - 1)))
                    p_u = float(stats.f.sf(f_x, J - 1, (n_pair - 1) * (J - 1)))
                else:
                    f_x, p_u = None, None
                raw_ps.append(p_u)
                comp_rows.append({
                    "stratum": s_lvl,
                    "test": "One-way RM-ANOVA",
                    "n_pairs": n_pair,
                    "statistic": f_x,
                    "p_unadjusted": p_u,
                    "p_holm": None,
                })
        for r_item, p_adj in zip(comp_rows, _holm_adjust(raw_ps)):
            r_item["p_holm"] = p_adj

    else:
        # Mixed Split-Plot Design: Between-Subjects `group` (e.g. WT vs KO) × Within-Subjects `x` (0%, 3%, 5%, 7% CO2)
        piv_all = work_df.pivot(index=["grp", "subj"], columns="x", values="y").reindex(columns=stratum_order).dropna()
        grp_mats: list[np.ndarray] = []
        for g_lvl in group_names:
            if g_lvl in piv_all.index.get_level_values(0):
                gm = piv_all.loc[g_lvl].to_numpy(dtype=float)
                if gm.ndim == 1:
                    gm = gm.reshape(1, -1)
                grp_mats.append(gm)
            else:
                grp_mats.append(np.empty((0, K), dtype=float))

        n_per_grp = [len(gm) for gm in grp_mats]
        N_tot = sum(n_per_grp)
        if any(ng < 2 for ng in n_per_grp):
            raise ValueError(
                f"Mixed between × within RM-ANOVA requires at least 2 complete '{subj_col}' subjects in each '{group}' across all '{x}' levels (counts: {dict(zip(group_names, n_per_grp))})."
            )

        Y_all = np.vstack(grp_mats)
        g_idx_vec = np.concatenate([np.full(ng, j_i, dtype=int) for j_i, ng in enumerate(n_per_grp)])
        subj_means = np.mean(Y_all, axis=1)  # Between-subjects collapse

        # Between-Subjects Factor A (`group`): Type III unweighted / OLS F-test on subject means across K levels
        grand_unw = float(np.mean([np.mean(gm) for gm in grp_mats]))
        ss_between_err = float(K * sum(np.sum((np.mean(gm, axis=1) - np.mean(gm)) ** 2) for gm in grp_mats))
        ss_a = float(K * sum(len(gm) * ((np.mean(gm) - float(np.mean(Y_all))) ** 2) for gm in grp_mats))
        df_a = J - 1
        df_s_within_a = N_tot - J
        if ss_between_err <= 1e-30 or df_s_within_a < 1:
            raise ValueError(f"Zero between-subject residual variance across '{subj_col}'.")
        f_a = (ss_a / df_a) / (ss_between_err / df_s_within_a)
        p_a = float(stats.f.sf(f_a, df_a, df_s_within_a))

        # Within-Subjects Factor B (`x`) & A × B (`group × x`) using Type III harmonic-mean unweighted cell means (matches R car::Anova Type III)
        CB = _orthonormal_helmert(K)
        Z_all = Y_all @ CB  # N_tot × (K - 1)
        Z_grp_means = np.vstack([np.mean(gm @ CB, axis=0) for gm in grp_mats])  # J × (K - 1)
        Z_resid = np.vstack([(gm @ CB) - np.mean(gm @ CB, axis=0, keepdims=True) for gm in grp_mats])
        ss_within_err = float(np.sum(Z_resid ** 2))
        df_within_err = (N_tot - J) * (K - 1)
        if ss_within_err <= 1e-30 or df_within_err < 1:
            raise ValueError(f"Zero within-subject '{subj_col} × {x}' error variance.")

        n_harm = float(J) / sum(1.0 / ng for ng in n_per_grp)
        z_bar_unw = np.mean(Z_grp_means, axis=0)
        ss_b = float(n_harm * J * np.sum(z_bar_unw ** 2))
        # Exact Type III interaction SS across orthonormal contrasts
        X_g = np.column_stack([np.ones(N_tot)] + [(g_idx_vec == j_i).astype(float) - (1.0 if j_i == 0 else 0.0) for j_i in range(1, J)])
        # Fit OLS of Z_all on group indicators: SS_AB = sum(Z_all^2) - SS_within_err - sum_of_overall_intercept_contrast
        Z_centered_tot = Z_all - np.mean(Z_all, axis=0, keepdims=True)
        ss_tot_within = float(np.sum(Z_all ** 2))
        ss_ab = max(0.0, float(sum(len(gm) * np.sum((np.mean(gm @ CB, axis=0) - np.mean(Z_all, axis=0)) ** 2) for gm in grp_mats)))

        df_b = K - 1
        df_ab = (J - 1) * (K - 1)
        # Pooled covariance matrix across within-group residuals for Greenhouse-Geisser
        S_pool = (Z_resid.T @ Z_resid) / float(N_tot - J)
        tr_p = float(np.trace(S_pool))
        sq_p = float(np.sum(S_pool * S_pool))
        eps_w = float(np.clip((tr_p * tr_p) / ((K - 1) * sq_p), 1.0 / (K - 1), 1.0)) if (K > 2 and sq_p > 0) else 1.0

        anova_rows.append({
            "source": group,
            "design_stratum": "Between-Subjects",
            "subjects": N_tot,
            "ss": ss_a,
            "df": df_a,
            "df_error": df_s_within_a,
            "ms": ss_a / df_a,
            "ms_error": ss_between_err / df_s_within_a,
            "F": f_a,
            "gg_epsilon": 1.0,
            "df_gg": float(df_a),
            "df_gg_error": float(df_s_within_a),
            "p_sphericity_assumed": p_a,
            "p": p_a,
            "partial_eta_squared": ss_a / (ss_a + ss_between_err),
        })
        summary_bits.append(f"{group}: F({df_a}, {df_s_within_a}) = {f_a:.4g}, p = {p_a:.4g}")

        for lbl, ss_eff, df_eff in ((x, ss_b, df_b), (f"{group} × {x}", ss_ab, df_ab)):
            f_v = (ss_eff / df_eff) / (ss_within_err / df_within_err)
            p_sph = float(stats.f.sf(f_v, df_eff, df_within_err))
            p_gg = float(stats.f.sf(f_v, eps_w * df_eff, eps_w * df_within_err))
            anova_rows.append({
                "source": lbl,
                "design_stratum": "Within-Subjects",
                "subjects": N_tot,
                "ss": ss_eff,
                "df": df_eff,
                "df_error": df_within_err,
                "ms": ss_eff / df_eff,
                "ms_error": ss_within_err / df_within_err,
                "F": f_v,
                "gg_epsilon": eps_w,
                "df_gg": eps_w * df_eff,
                "df_gg_error": eps_w * df_within_err,
                "p_sphericity_assumed": p_sph,
                "p": p_gg,
                "partial_eta_squared": ss_eff / (ss_eff + ss_within_err),
            })
            summary_bits.append(f"{lbl}: F({eps_w * df_eff:.3g}, {eps_w * df_within_err:.3g}) = {f_v:.4g}, p = {p_gg:.4g}")

        simple_t = "ttest" if J == 2 else "anova"
        _, comp_rows = _per_stratum_tests(
            work_df["x"].to_numpy(dtype=object),
            stratum_order,
            work_df["grp"].to_numpy(dtype=object),
            group_names,
            work_df["y"].to_numpy(dtype=float),
            np.ones(len(work_df), dtype=bool),
            simple_t,
        )
        warnings.append(
            f"Mixed Split-Plot Two-Way RM-ANOVA treats '{group}' as Between-Subjects and '{x}' as Within-Subjects across N = {N_tot} '{subj_col}' units with Greenhouse–Geisser sphericity adjustment."
        )
        design_desc = f"Mixed two-way RM-ANOVA (N = {N_tot} {subj_col})"

    summary = f"{design_desc} of {y} by {group} × {x}: " + "; ".join(summary_bits) + "."
    tables = [
        _table("Two-way repeated-measures ANOVA", anova_rows),
        _table("Timepoint group summaries", cell_rows),
        _table("Timepoint comparisons", comp_rows),
    ]
    return _finish(ds, plan, "rm_two_way", summary, tables, warnings, _account(ds, mask, [r_excl, rs, rx, rg, ry], excluded_rows=excluded))


def _ap_waveform(ds: Dataset, plan: dict, warnings: list[str]) -> dict:
    """Extract source-preserving AP–AHP biophysical waveform features and group comparisons."""
    from .ap_ahp import analyze_waveform_collection
    allowed, r_excl, excluded = _excluded_mask(ds, plan)
    sub_df = ds.df.loc[allowed].reset_index(drop=True)
    if sub_df.empty:
        raise ValueError("No waveform rows remain after applying exclusions.")
    res = analyze_waveform_collection(sub_df, plan)
    warnings.extend(res["notes"])
    warnings.append(
        f"AP–AHP biophysical extraction uses unsmoothed raw voltage samples (dV/dt threshold = {res['dvdt_threshold_vs']:g} V/s; "
        "fAHP window 0.5–10 ms, mAHP window 10–150 ms, sAHP window 150–1000 ms post-peak)."
    )

    tables = [
        _table("AP-AHP trace metrics", res["metric_rows"]),
        _table("AP-AHP group summaries", res["summary_rows"]),
    ]
    if res["comparison_rows"]:
        tables.append(_table("AP-AHP parameter comparisons", res["comparison_rows"]))

    n_traces = len(res["metric_rows"])
    grps = res["groups"]
    mdf = res["metrics_df"]
    bits: list[str] = []
    for g in grps:
        sub_g = mdf[mdf["Group"] == g]
        amp = pd.to_numeric(sub_g["AP_Amplitude_mV"], errors="coerce").dropna()
        hw = pd.to_numeric(sub_g["HalfWidth_ms"], errors="coerce").dropna()
        mahp = pd.to_numeric(sub_g["mAHP_mV"], errors="coerce").dropna()
        if len(amp):
            g_str = f"{g} (n={len(amp)}): Amp = {float(amp.mean()):.3g} mV"
            if len(hw):
                g_str += f", APD50 = {float(hw.mean()):.3g} ms"
            if len(mahp):
                g_str += f", mAHP = {float(mahp.mean()):.3g} mV"
            bits.append(g_str)
    cmp_bits = [
        f"{c['parameter']} p = {c['p_unadjusted']:.4g} (Holm {c['p_holm']:.4g})"
        for c in res["comparison_rows"]
        if c["parameter"] in {"mAHP_mV", "fAHP_mV", "HalfWidth_ms", "AP_Amplitude_mV"}
    ][:3]
    summary = f"AP–AHP waveform analysis across {n_traces} trace(s) ({len(grps)} group(s)): " + "; ".join(bits or [f"{n_traces} trace(s) evaluated"])
    if cmp_bits:
        summary += " | " + "; ".join(cmp_bits)
    summary += "."
    return _finish(ds, plan, "ap_waveform", summary, tables, warnings, _account(ds, allowed, [r_excl], excluded_rows=excluded))


def _parse_survival_series(raw_series: pd.Series, event_col: str) -> tuple[np.ndarray, np.ndarray, list[str], str | None]:
    """Parse right-censored event indicator Series into {0, 1} with explicit coding provenance."""
    n_rows = len(raw_series)
    ev = np.zeros(n_rows, dtype=int)
    valid = np.zeros(n_rows, dtype=bool)
    reasons = [""] * n_rows

    parsed_nums: list[tuple[int, float]] = []
    text_tokens: list[tuple[int, str]] = []

    true_tokens = {"1", "true", "t", "yes", "y", "event", "dead", "deceased", "died", "relapse", "relapsed", "progressed", "failure"}
    false_tokens = {"0", "false", "f", "no", "n", "censored", "censor", "alive", "living", "surviving", "event-free"}

    for idx, val in enumerate(raw_series.tolist()):
        if _blank(val) or _is_missing_token(val):
            reasons[idx] = f"Missing event indicator in '{event_col}'"
            continue
        if isinstance(val, (bool, np.bool_)):
            ev[idx] = 1 if bool(val) else 0
            valid[idx] = True
            continue
        try:
            fv = float(val)
            if math.isfinite(fv) and abs(fv - round(fv)) < 1e-9:
                parsed_nums.append((idx, float(round(fv))))
                continue
        except (TypeError, ValueError):
            pass
        tok = str(val).strip().casefold()
        text_tokens.append((idx, tok))

    coding_note: str | None = None
    if parsed_nums and not text_tokens:
        uniq = sorted({int(v) for _, v in parsed_nums})
        if set(uniq).issubset({0, 1}):
            for idx, fv in parsed_nums:
                ev[idx] = int(fv)
                valid[idx] = True
        elif set(uniq) == {1, 2}:
            coding_note = (
                f"Event column '{event_col}' uses R survival 1/2 coding (1 = right-censored, 2 = event); "
                "mapped 2 → event (1) and 1 → censored (0)."
            )
            for idx, fv in parsed_nums:
                ev[idx] = 1 if int(fv) == 2 else 0
                valid[idx] = True
        else:
            raise ValueError(
                f"Survival event indicator '{event_col}' must encode binary censoring/event status "
                f"(0 = censored, 1 = event; or R 1 = censored, 2 = event), found values {uniq[:8]}."
            )
    else:
        for idx, fv in parsed_nums:
            iv = int(fv)
            if iv in (0, 1):
                ev[idx] = iv
                valid[idx] = True
            else:
                reasons[idx] = f"Unsupported event code {fv!r} in '{event_col}'"
        for idx, tok in text_tokens:
            if tok in true_tokens:
                ev[idx] = 1
                valid[idx] = True
            elif tok in false_tokens:
                ev[idx] = 0
                valid[idx] = True
            else:
                reasons[idx] = f"Unrecognized event status {tok!r} in '{event_col}'"
        if not valid.any():
            raise ValueError(
                f"Could not parse binary event/censoring status from '{event_col}'. "
                "Use 0/1 (0 = censored, 1 = event), 1/2, or explicit 'censored'/'event' labels."
            )

    return ev, valid, reasons, coding_note


def _parse_survival_events(ds: Dataset, event_col: str) -> tuple[np.ndarray, np.ndarray, list[str], str | None]:
    """Parse right-censored event indicator column into {0, 1} with explicit coding provenance."""
    return _parse_survival_series(ds.df[event_col], event_col)


def _km_loglog_ci(surv_prob: np.ndarray, surv_se: np.ndarray, alpha: float = 0.05) -> tuple[np.ndarray, np.ndarray]:
    """Compute R-compatible log(-log S(t)) 95% pointwise confidence bounds clipped to [0, 1]."""
    z = float(stats.norm.ppf(1.0 - alpha / 2.0))
    lo = np.full_like(surv_prob, np.nan, dtype=float)
    hi = np.full_like(surv_prob, np.nan, dtype=float)
    for i, (s, se) in enumerate(zip(surv_prob, surv_se)):
        if not math.isfinite(s):
            continue
        if s <= 0.0:
            lo[i], hi[i] = 0.0, 0.0
        elif s >= 1.0 or not math.isfinite(se) or se <= 0.0:
            lo[i], hi[i] = float(s), float(s)
        else:
            denom = s * abs(math.log(s))
            if denom <= 0:
                lo[i], hi[i] = float(s), float(s)
            else:
                theta = math.exp(z * se / denom)
                lo[i] = float(np.clip(s ** theta, 0.0, 1.0))
                hi[i] = float(np.clip(s ** (1.0 / theta), 0.0, 1.0))
    return lo, hi


def _survival(ds: Dataset, plan: dict, warnings: list[str]) -> dict:
    """Kaplan–Meier right-censored survival estimation, Mantel–Cox log-rank test, and Cox PH hazard ratio."""
    _require_independent(plan)
    allowed, r_excl, excluded = _excluded_mask(ds, plan)

    cols_hint = plan.get("columns")
    if not plan.get("x") and not plan.get("y") and isinstance(cols_hint, list) and len(cols_hint) >= 2:
        plan["x"], plan["y"] = cols_hint[0], cols_hint[1]

    time_col = _column(ds, plan.get("x"), "the survival follow-up time")
    event_col = _column(ds, plan.get("y"), "the binary event/censoring indicator")
    if time_col == event_col:
        raise ValueError("Choose distinct columns for survival time (x) and event/censoring indicator (y).")
    plan.update(x=time_col, y=event_col)

    times, vt, rt = _numeric(ds, time_col)
    neg_mask = vt & (times < 0)
    if neg_mask.any():
        for idx in np.flatnonzero(neg_mask):
            vt[idx] = False
            rt[idx] = f"Negative survival time ({times[idx]:g}) in '{time_col}'"

    events, ve, re_ev, coding_note = _parse_survival_events(ds, event_col)
    if coding_note:
        warnings.append(coding_note)

    group_spec = plan.get("group")
    if group_spec:
        group_col = _column(ds, group_spec, "the survival grouping factor")
        if group_col in {time_col, event_col}:
            raise ValueError("The survival grouping factor must be distinct from time and event columns.")
        plan["group"] = group_col
        g_labels, vg, rg = _categorical(ds, group_col)
        mask = vt & ve & vg & allowed
        reason_lists = [r_excl, rt, re_ev, rg]
        used_cols = {time_col, event_col, group_col}
    else:
        group_col = None
        g_labels = np.array(["All subjects"] * len(ds.df), dtype=object)
        mask = vt & ve & allowed
        reason_lists = [r_excl, rt, re_ev]
        used_cols = {time_col, event_col}

    _check_unpooled_replicates(ds, plan, mask, used_cols)
    n_total = int(mask.sum())
    if n_total < 3:
        raise ValueError(f"Survival analysis requires at least three complete (time, event) observations; {n_total} were found.")

    active_times = times[mask]
    active_events = events[mask]
    active_groups = g_labels[mask]
    total_events = int(active_events.sum())
    if total_events < 1:
        raise ValueError(f"Zero events were observed in '{event_col}' across the {n_total} active rows; log-rank and median survival are undefined.")

    if group_col:
        raw_order = list(dict.fromkeys(str(g) for g in active_groups))
        group_names = _sort_strata_naturally(raw_order)
        if len(group_names) < 2:
            raise ValueError(f"Survival comparison across '{group_col}' requires at least two observed groups; found {group_names}.")
        if len(group_names) > 12:
            raise ValueError(f"Grouping column '{group_col}' has {len(group_names)} levels; choose a categorical factor with 2–12 groups.")
    else:
        group_names = ["All subjects"]

    # Compute expected events per group under Mantel-Cox hypergeometric null
    expected_by_group: dict[str, float | None] = {g: None for g in group_names}
    if len(group_names) >= 2:
        uniq_event_times = np.sort(np.unique(active_times[active_events == 1]))
        exp_acc = {g: 0.0 for g in group_names}
        for t_ev in uniq_event_times:
            at_risk = active_times >= t_ev
            n_r = int(at_risk.sum())
            d_t = int(((active_times == t_ev) & (active_events == 1)).sum())
            if n_r > 0 and d_t > 0:
                for g in group_names:
                    n_rg = int((at_risk & (active_groups == g)).sum())
                    exp_acc[g] += d_t * (n_rg / n_r)
        expected_by_group = exp_acc

    km_summary_rows: list[dict] = []
    km_curve_rows: list[dict] = []
    t_horizon = float(np.max(active_times))

    for g in group_names:
        g_mask = active_groups == g
        gt = active_times[g_mask]
        ge = active_events[g_mask]
        n_g = int(len(gt))
        ev_g = int(ge.sum())
        cens_g = n_g - ev_g
        if n_g < 1:
            continue

        with pywarnings.catch_warnings():
            pywarnings.simplefilter("ignore", RuntimeWarning)
            sf = SurvfuncRight(gt, ge)
            med = float(sf.quantile(0.5))
            try:
                med_lo, med_hi = sf.quantile_ci(0.5)
            except Exception:
                med_lo, med_hi = np.nan, np.nan

        st = np.asarray(sf.surv_times, dtype=float)
        sp = np.asarray(sf.surv_prob, dtype=float)
        se = np.asarray(sf.surv_prob_se, dtype=float)
        nr = np.asarray(sf.n_risk, dtype=int)
        ne = np.asarray(sf.n_events, dtype=int)
        ci_lo, ci_hi = _km_loglog_ci(sp, se)

        # Restricted mean survival time (area under step KM curve up to observed group max follow-up)
        t_knots = np.concatenate(([0.0], st))
        s_prev = np.concatenate(([1.0], sp[:-1])) if len(sp) else np.array([1.0])
        rmst = float(np.sum(np.diff(t_knots) * s_prev[:len(st)])) if len(st) else float(np.max(gt))

        km_summary_rows.append({
            "group": g,
            "n": n_g,
            "events": ev_g,
            "censored": cens_g,
            "expected_events": expected_by_group.get(g),
            "median_survival": med if math.isfinite(med) else None,
            "ci_low": float(med_lo) if math.isfinite(med_lo) else None,
            "ci_high": float(med_hi) if math.isfinite(med_hi) else None,
            "restricted_mean_survival": rmst,
        })

        km_curve_rows.append({
            "group": g,
            "time": 0.0,
            "n_risk": n_g,
            "n_events": 0,
            "survival_prob": 1.0,
            "se": 0.0,
            "ci_low": 1.0,
            "ci_high": 1.0,
        })
        for idx_t in range(len(st)):
            km_curve_rows.append({
                "group": g,
                "time": float(st[idx_t]),
                "n_risk": int(nr[idx_t]),
                "n_events": int(ne[idx_t]),
                "survival_prob": float(sp[idx_t]),
                "se": float(se[idx_t]) if math.isfinite(se[idx_t]) else None,
                "ci_low": float(ci_lo[idx_t]) if math.isfinite(ci_lo[idx_t]) else None,
                "ci_high": float(ci_hi[idx_t]) if math.isfinite(ci_hi[idx_t]) else None,
            })

    tables = [_table("Kaplan–Meier group summaries", km_summary_rows)]

    if len(group_names) >= 2:
        chi2_stat, p_logrank = survdiff(active_times, active_events, active_groups)
        chi2_f = float(chi2_stat)
        p_f = float(p_logrank)
        df_lr = len(group_names) - 1

        lr_row: dict = {
            "test": "Mantel–Cox log-rank",
            "groups": len(group_names),
            "n": n_total,
            "events": total_events,
            "chi_squared": chi2_f,
            "df": df_lr,
            "p": p_f,
        }

        hr_summary_str = ""
        if len(group_names) == 2:
            # Fit Efron-tied univariate Cox proportional hazards matching R survival::coxph
            ref_grp, cmp_grp = group_names[0], group_names[1]
            x_ind = (active_groups == cmp_grp).astype(float)[:, None]
            try:
                with pywarnings.catch_warnings():
                    pywarnings.simplefilter("ignore")
                    cox_res = PHReg(active_times, x_ind, status=active_events, ties="efron").fit()
                beta = float(cox_res.params[0])
                se_b = float(cox_res.bse[0])
                p_cox = float(cox_res.pvalues[0])
                if math.isfinite(beta) and math.isfinite(se_b) and se_b > 0 and abs(beta) < 20:
                    hr = math.exp(beta)
                    hr_lo = math.exp(beta - 1.959963984540054 * se_b)
                    hr_hi = math.exp(beta + 1.959963984540054 * se_b)
                    lr_row.update({
                        "hr_comparison": f"{cmp_grp} vs {ref_grp}",
                        "hazard_ratio": hr,
                        "hr_ci_low": hr_lo,
                        "hr_ci_high": hr_hi,
                        "cox_wald_p": p_cox,
                    })
                    hr_summary_str = f"; Cox HR ({cmp_grp} vs {ref_grp}) = {hr:.4g}, 95% CI [{hr_lo:.4g}, {hr_hi:.4g}]"
            except Exception:
                pass

        tables.append(_table("Log-rank test", [lr_row]))
        warnings.append(
            "Kaplan–Meier survival curves and the Mantel–Cox log-rank test assume independent subjects and non-informative right censoring. "
            "Pointwise 95% survival bands use Greenwood standard errors on the log(-log) scale; median survival 95% intervals use the Brookmeyer–Crowley method."
        )
        summary = (
            f"Kaplan–Meier & Mantel–Cox log-rank test of {time_col} (event: {event_col}) across {group_col} "
            f"(n = {n_total}, events = {total_events}): chi-square({df_lr}) = {chi2_f:.4g}, p = {p_f:.4g}{hr_summary_str}."
        )
    else:
        row0 = km_summary_rows[0]
        med_txt = (
            f"{row0['median_survival']:.4g} (95% CI [{row0['ci_low']:.4g}, {row0['ci_high']:.4g}])"
            if row0.get("median_survival") is not None and row0.get("ci_low") is not None and row0.get("ci_high") is not None
            else f"{row0['median_survival']:.4g}" if row0.get("median_survival") is not None else "not reached"
        )
        warnings.append(
            "Kaplan–Meier survival estimation assumes independent subjects and non-informative right censoring (max observed follow-up "
            f"{t_horizon:.4g})."
        )
        summary = (
            f"Kaplan–Meier survival estimate of {time_col} (event: {event_col}): "
            f"n = {n_total} ({total_events} events, {n_total - total_events} right-censored); median survival = {med_txt}."
        )

    tables.append(_table("Kaplan–Meier curve coordinates", km_curve_rows[:600]))
    return _finish(ds, plan, "survival", summary, tables, warnings, _account(ds, mask, reason_lists, excluded_rows=excluded))


def _wilcoxon(ds: Dataset, plan: dict, warnings: list[str]) -> dict:
    """Paired two-condition Wilcoxon signed-rank test (wide 2-column or long subject+group+y)."""
    if plan.get("design") != "paired":
        raise ValueError("Confirm the paired design before a Wilcoxon signed-rank test (design='paired'). Each pair must represent the same independent experimental unit.")
    allowed, r_excl, excluded = _excluded_mask(ds, plan)
    pair_rows: list[dict] = []
    if plan.get("subject") and plan.get("group"):
        subject = _column(ds, plan.get("subject"), "subject identifiers")
        group = _column(ds, plan.get("group"), "the two measurement conditions")
        y = _column(ds, plan.get("y") or plan.get("x"), "the numeric outcome")
        if len({subject, group, y}) != 3:
            raise ValueError("Subject, group, and numeric outcome must be three different columns for long-format paired data.")
        plan.update(subject=subject, group=group, y=y)
        subjects, vs, rs = _categorical(ds, subject)
        groups, vg, rg = _categorical(ds, group)
        values, vy, ry = _numeric(ds, y)
        names = list(dict.fromkeys(groups[vg & allowed]))
        if len(names) != 2:
            raise ValueError(f"Long-format Wilcoxon signed-rank requires exactly two conditions; {len(names)} were found (use method='friedman' for 3+ matched conditions).")
        lookup: dict[tuple[str, str], int] = {}
        for i in np.flatnonzero(vs & vg & allowed):
            key = (subjects[i], groups[i])
            if key in lookup:
                raise ValueError(f"Subject '{subjects[i]}' has duplicate rows in condition '{groups[i]}' (source rows {ds.row_numbers[lookup[key]]} and {ds.row_numbers[i]}).")
            lookup[key] = i
        mask = np.zeros(len(ds.df), dtype=bool)
        unmatched_reason = [""] * len(ds.df)
        for subj in dict.fromkeys(subjects[vs & allowed]):
            ia, ib = lookup.get((subj, names[0])), lookup.get((subj, names[1]))
            if ia is not None and ib is not None and vy[ia] and vy[ib]:
                mask[[ia, ib]] = True
                pair_rows.append({"subject": subj, "x": values[ia], "y": values[ib], "x_row": ds.row_numbers[ia], "y_row": ds.row_numbers[ib]})
            else:
                for i in np.flatnonzero(vs & allowed & (subjects == subj)):
                    unmatched_reason[i] = f"No complete pair for subject '{subj}' across '{names[0]}' and '{names[1]}'"
        accounting = _account(ds, mask, [r_excl, rs, rg, ry, unmatched_reason], excluded_rows=excluded)
        a = np.asarray([r["x"] for r in pair_rows], dtype=float)
        b = np.asarray([r["y"] for r in pair_rows], dtype=float)
    else:
        cols = _wide_columns(ds, plan)
        if cols is not None:
            if len(cols) != 2:
                raise ValueError("A wide-format Wilcoxon signed-rank test requires exactly two numeric columns (use method='friedman' for 3+ columns).")
            x, y = cols
        else:
            x = _column(ds, plan.get("x"), "the first paired measurement")
            y = _column(ds, plan.get("y"), "the second paired measurement")
        if x == y:
            raise ValueError("Choose two different columns for paired measurements.")
        plan.update(x=x, y=y)
        values_x, vx, rx = _numeric(ds, x)
        values_y, vy, ry = _numeric(ds, y)
        mask = vx & vy & allowed
        accounting = _account(ds, mask, [r_excl, rx, ry], excluded_rows=excluded)
        a, b, names = values_x[mask], values_y[mask], [x, y]
        for i in np.flatnonzero(mask):
            pair_rows.append({"subject": str(ds.row_numbers[i]), "x": values_x[i], "y": values_y[i], "x_row": ds.row_numbers[i], "y_row": ds.row_numbers[i]})

    n = len(a)
    if n < 2:
        raise ValueError(f"A Wilcoxon signed-rank test needs at least two complete pairs; {n} were found.")
    diff = a - b
    nz = diff[diff != 0.0]
    if len(nz) == 0:
        raise ValueError("All paired differences are zero; the Wilcoxon signed-rank test is undefined.")
    w_res = stats.wilcoxon(a, b, zero_method="wilcox", correction=True, alternative="two-sided", method="auto")
    ranks = stats.rankdata(np.abs(nz))
    w_plus = float(np.sum(ranks[nz > 0.0]))
    w_minus = float(np.sum(ranks[nz < 0.0]))
    denom_rb = len(nz) * (len(nz) + 1) / 2.0
    rb = (w_plus - w_minus) / denom_rb if denom_rb > 0 else 0.0
    med_diff = float(np.median(diff))
    q25, q75 = [float(q) for q in np.percentile(diff, [25, 75])]
    accounting["pairs"] = n
    warnings.append(
        "Two-sided Wilcoxon signed-rank test omits exact zero paired differences from ranking ('wilcox' convention) "
        "and uses exact permutation p-values for small untied samples or continuity-corrected normal approximation otherwise."
    )
    tables = [
        _table("Paired condition summaries", [_summary(str(names[0]), a), _summary(str(names[1]), b)]),
        _table("Wilcoxon signed-rank test", [{
            "condition_1": names[0],
            "condition_2": names[1],
            "pairs": n,
            "nonzero_pairs": int(len(nz)),
            "W": float(w_res.statistic),
            "V_plus": w_plus,
            "p": float(w_res.pvalue),
            "median_difference": med_diff,
            "diff_q1": q25,
            "diff_q3": q75,
            "rank_biserial": rb,
        }]),
        _table("Paired observations", pair_rows),
    ]
    summary = (
        f"Wilcoxon signed-rank test on {n} complete pairs ({len(nz)} nonzero): W = {float(w_res.statistic):.4g} "
        f"(V+ = {w_plus:.4g}), p = {float(w_res.pvalue):.4g}; median paired difference ({names[0]} − {names[1]}) = {med_diff:.4g}, rank-biserial = {rb:.4g}."
    )
    return _finish(ds, plan, "wilcoxon", summary, tables, warnings, accounting)


def _extract_repeated_matrix(ds: Dataset, plan: dict, min_conditions: int = 2) -> tuple[list[str], list[str], np.ndarray, dict]:
    """Extract complete subject × condition matrix Y (n_subjects × K_conditions) from long or wide layout."""
    allowed, r_excl, excluded = _excluded_mask(ds, plan)
    cond_col_spec = plan.get("group") or plan.get("x")
    if plan.get("subject") and cond_col_spec and plan.get("y"):
        subject = _column(ds, plan.get("subject"), "subject identifiers")
        cond_col = _column(ds, cond_col_spec, "repeated measurement conditions")
        y = _column(ds, plan.get("y"), "the numeric outcome")
        if len({subject, cond_col, y}) != 3:
            raise ValueError("Subject, repeated condition, and numeric outcome must be three distinct columns.")
        plan["subject"] = subject
        plan["group"] = cond_col
        plan["y"] = y
        subjects, vs, rs = _categorical(ds, subject)
        conds, vc, rc = _categorical(ds, cond_col)
        values, vy, ry = _numeric(ds, y)
        raw_conds = list(dict.fromkeys(str(c) for c in conds[vc & allowed]))
        cond_names = _sort_strata_naturally(raw_conds)
        if len(cond_names) < min_conditions:
            raise ValueError(f"Repeated-measures analysis requires at least {min_conditions} conditions in '{cond_col}'; {len(cond_names)} were found.")
        if len(cond_names) > 16:
            raise ValueError(f"Repeated condition column '{cond_col}' has {len(cond_names)} levels; choose at most 16 conditions.")
        lookup: dict[tuple[str, str], int] = {}
        for i in np.flatnonzero(vs & vc & allowed):
            key = (str(subjects[i]), str(conds[i]))
            if key in lookup:
                raise ValueError(
                    f"Subject '{subjects[i]}' has duplicate rows in condition '{conds[i]}' "
                    f"(source rows {ds.row_numbers[lookup[key]]} and {ds.row_numbers[i]}). Pool technical subreplicates first."
                )
            lookup[key] = i
        mask = np.zeros(len(ds.df), dtype=bool)
        unmatched = [""] * len(ds.df)
        subj_list: list[str] = []
        mat_rows: list[list[float]] = []
        for subj in dict.fromkeys(str(s) for s in subjects[vs & allowed]):
            idxs = [lookup.get((subj, cn)) for cn in cond_names]
            if all(ix is not None and vy[ix] for ix in idxs):
                mask[idxs] = True
                subj_list.append(subj)
                mat_rows.append([float(values[ix]) for ix in idxs])
            else:
                for i in np.flatnonzero(vs & allowed & (subjects == subj)):
                    unmatched[i] = f"Incomplete repeated block for subject '{subj}' across all {len(cond_names)} '{cond_col}' conditions"
        accounting = _account(ds, mask, [r_excl, rs, rc, ry, unmatched], excluded_rows=excluded)
        accounting["complete_subjects"] = len(subj_list)
        Y = np.asarray(mat_rows, dtype=float) if mat_rows else np.empty((0, len(cond_names)), dtype=float)
        return cond_names, subj_list, Y, accounting

    # Wide K-column format
    cols = _wide_columns(ds, plan)
    if not cols:
        # Auto-select numeric non-identifier columns if columns not explicitly specified
        cand_cols = []
        for c in ds.df.columns:
            if _UNIT_COLUMN_RE.match(str(c).strip()) or str(c).strip().casefold() in {"id", "row", "replicate"}:
                continue
            try:
                _arr, v_c, _ = _numeric(ds, str(c))
                if int(v_c.sum()) >= 2:
                    cand_cols.append(str(c))
            except ValueError:
                continue
        cols = cand_cols
    if not cols or len(cols) < min_conditions:
        raise ValueError(
            f"Specify at least {min_conditions} matched numeric columns in 'columns', or specify 'subject', 'group', and 'y' for long-format repeated measures."
        )
    if len(cols) > 16:
        raise ValueError("Wide repeated-measures tables support at most 16 condition columns.")
    plan["columns"] = list(cols)
    arrs, masks_c, reasons_c = [], [], [r_excl]
    for c in cols:
        v_arr, v_m, v_r = _numeric(ds, c)
        arrs.append(v_arr)
        masks_c.append(v_m)
        reasons_c.append(v_r)
    mask = np.logical_and.reduce([allowed, *masks_c])
    accounting = _account(ds, mask, reasons_c, excluded_rows=excluded)
    active_idx = np.flatnonzero(mask)
    subj_list = [str(ds.row_numbers[i]) for i in active_idx]
    accounting["complete_subjects"] = len(subj_list)
    Y = np.column_stack([a[mask] for a in arrs]) if len(active_idx) else np.empty((0, len(cols)), dtype=float)
    return list(cols), subj_list, Y, accounting


def _rm_anova(ds: Dataset, plan: dict, warnings: list[str]) -> dict:
    """One-way Repeated-Measures ANOVA with Greenhouse–Geisser sphericity adjustment and Holm paired post-hoc tests."""
    if plan.get("design") != "paired":
        raise ValueError("Confirm the repeated-measures / within-subject design (design='paired') before running Repeated-Measures ANOVA.")
    cond_names, subj_list, Y, accounting = _extract_repeated_matrix(ds, plan, min_conditions=2)
    n, k = Y.shape
    if n < 2:
        raise ValueError(f"Repeated-Measures ANOVA requires at least 2 complete subjects across all {k} conditions; {n} were found.")

    grand = float(np.mean(Y))
    subj_means = np.mean(Y, axis=1)
    cond_means = np.mean(Y, axis=0)
    ss_cond = float(n * np.sum((cond_means - grand) ** 2))
    ss_subj = float(k * np.sum((subj_means - grand) ** 2))
    ss_tot = float(np.sum((Y - grand) ** 2))
    ss_err = max(0.0, ss_tot - ss_cond - ss_subj)
    df1 = k - 1
    df2 = (n - 1) * (k - 1)
    if ss_err <= 0.0 or df2 <= 0:
        raise ValueError("Residual subject × condition error variance is zero; Repeated-Measures ANOVA F-ratio is undefined.")
    ms_cond = ss_cond / df1
    ms_err = ss_err / df2
    f_stat = ms_cond / ms_err
    p_sph = float(stats.f.sf(f_stat, df1, df2))
    eta_p2 = ss_cond / (ss_cond + ss_err) if (ss_cond + ss_err) > 0 else 0.0

    # Exact Greenhouse-Geisser sphericity epsilon matching R anova.mlm(..., test="Spherical")
    if k == 2 or n < 3:
        eps_gg = 1.0
    else:
        S_cov = np.cov(Y, rowvar=False, ddof=1)
        C_mat = np.eye(k) - (1.0 / k) * np.ones((k, k))
        M = C_mat @ S_cov @ C_mat
        tr_M = float(np.trace(M))
        sum_sq_M = float(np.sum(M * M))
        eps_gg = float(np.clip((tr_M * tr_M) / ((k - 1) * sum_sq_M), 1.0 / (k - 1), 1.0)) if sum_sq_M > 0 else 1.0
    df1_gg = eps_gg * df1
    df2_gg = eps_gg * df2
    p_gg = float(stats.f.sf(f_stat, df1_gg, df2_gg))

    # Pairwise Holm-adjusted paired t-tests
    ph_rows: list[dict] = []
    raw_ps: list[float | None] = []
    for i in range(k):
        for j in range(i + 1, k):
            diff = Y[:, j] - Y[:, i]
            md = float(np.mean(diff))
            sd_d = float(np.std(diff, ddof=1))
            if sd_d > 0:
                se_d = sd_d / math.sqrt(n)
                t_ij = md / se_d
                p_ij = float(2.0 * stats.t.sf(abs(t_ij), n - 1))
                half_ij = float(stats.t.ppf(0.975, n - 1) * se_d)
                dz = md / sd_d
            else:
                t_ij, p_ij, half_ij, dz = None, (1.0 if md == 0.0 else 0.0), 0.0, None
            raw_ps.append(p_ij)
            ph_rows.append({
                "group_1": cond_names[i],
                "group_2": cond_names[j],
                "comparison": f"{cond_names[j]} − {cond_names[i]}",
                "method": "Paired t-test (Holm)",
                "difference": md,
                "statistic": t_ij,
                "df": n - 1,
                "ci_low": md - half_ij,
                "ci_high": md + half_ij,
                "cohens_dz": dz,
                "p_unadjusted": p_ij,
                "p_adjusted": None,
            })
    for r, padj in zip(ph_rows, _holm_adjust(raw_ps)):
        r["p_adjusted"] = padj

    cond_summaries = [_summary(str(cn), Y[:, idx]) for idx, cn in enumerate(cond_names)]
    rm_row = {
        "subjects": n,
        "conditions": k,
        "F": f_stat,
        "df_condition": df1,
        "df_error": df2,
        "p_sphericity_assumed": p_sph,
        "gg_epsilon": eps_gg,
        "df_gg_condition": df1_gg,
        "df_gg_error": df2_gg,
        "p": p_gg,
        "partial_eta_squared": eta_p2,
    }
    warnings.append(
        f"One-way Repeated-Measures ANOVA across {k} matched conditions ({n} complete subjects) reports both sphericity-assumed p = {p_sph:.4g} "
        f"and Greenhouse–Geisser sphericity-adjusted p = {p_gg:.4g} (ε = {eps_gg:.4g}), plus Holm-adjusted paired t-test post-hoc comparisons."
    )
    tables = [
        _table("Repeated condition summaries", cond_summaries),
        _table("Repeated-measures ANOVA", [rm_row]),
        _table("Post-hoc pairwise comparisons", ph_rows),
    ]
    summary = (
        f"Repeated-Measures ANOVA ({n} subjects × {k} conditions): F({df1}, {df2}) = {f_stat:.4g}, "
        f"Greenhouse–Geisser p = {p_gg:.4g} (ε = {eps_gg:.3g}; sphericity p = {p_sph:.4g}), partial η² = {eta_p2:.4g}."
    )
    return _finish(ds, plan, "rm_anova", summary, tables, warnings, accounting)


def _friedman(ds: Dataset, plan: dict, warnings: list[str]) -> dict:
    """Nonparametric Friedman test across K >= 3 matched conditions with Kendall's W and Holm Wilcoxon post-hoc tests."""
    if plan.get("design") != "paired":
        raise ValueError("Confirm the repeated-measures / matched-block design (design='paired') before running a Friedman test.")
    cond_names, _subj_list, Y, accounting = _extract_repeated_matrix(ds, plan, min_conditions=3)
    n, k = Y.shape
    if n < 2:
        raise ValueError(f"Friedman test requires at least 2 complete blocks across {k} conditions; {n} were found.")
    if all(np.ptp(Y[i, :]) == 0.0 for i in range(n)):
        raise ValueError("Every subject has identical values across all conditions; Friedman chi-square is undefined.")

    fr = stats.friedmanchisquare(*[Y[:, j] for j in range(k)])
    q_stat = float(fr.statistic)
    p_val = float(fr.pvalue)
    kendall_w = float(np.clip(q_stat / (n * (k - 1)), 0.0, 1.0))

    ph_rows: list[dict] = []
    raw_ps: list[float | None] = []
    for i in range(k):
        for j in range(i + 1, k):
            diff = Y[:, j] - Y[:, i]
            nz = diff[diff != 0.0]
            if len(nz) == 0:
                w_val, p_ij = 0.0, 1.0
            else:
                w_ij = stats.wilcoxon(Y[:, j], Y[:, i], zero_method="wilcox", correction=True, alternative="two-sided", method="auto")
                w_val, p_ij = float(w_ij.statistic), float(w_ij.pvalue)
            raw_ps.append(p_ij)
            ph_rows.append({
                "group_1": cond_names[i],
                "group_2": cond_names[j],
                "comparison": f"{cond_names[j]} − {cond_names[i]}",
                "method": "Wilcoxon signed-rank (Holm)",
                "difference": float(np.median(diff)),
                "statistic": w_val,
                "p_unadjusted": p_ij,
                "p_adjusted": None,
            })
    for r, padj in zip(ph_rows, _holm_adjust(raw_ps)):
        r["p_adjusted"] = padj

    cond_summaries = [_summary(str(cn), Y[:, idx]) for idx, cn in enumerate(cond_names)]
    warnings.append(
        f"Friedman's rank test across {k} matched conditions ({n} complete subjects) uses tie-corrected chi-square (df = {k - 1}) "
        "and step-down Holm–Bonferroni pairwise Wilcoxon signed-rank post-hoc comparisons."
    )
    tables = [
        _table("Repeated condition summaries", cond_summaries),
        _table("Friedman test", [{"subjects": n, "conditions": k, "Q": q_stat, "df": k - 1, "p": p_val, "kendalls_W": kendall_w}]),
        _table("Post-hoc pairwise comparisons", ph_rows),
    ]
    summary = f"Friedman test ({n} subjects × {k} conditions): Q({k - 1}) = {q_stat:.4g}, p = {p_val:.4g}; Kendall's W = {kendall_w:.4g}."
    return _finish(ds, plan, "friedman", summary, tables, warnings, accounting)


def _fisher_exact(ds: Dataset, plan: dict, warnings: list[str]) -> dict:
    """Two-sided Fisher's exact test on a 2×2 contingency table (raw rows or weighted cell counts)."""
    _require_independent(plan)
    allowed, r_excl, excluded = _excluded_mask(ds, plan)
    x = _column(ds, plan.get("x"), "the first binary categorical variable")
    y = _column(ds, plan.get("y"), "the second binary categorical variable")
    if x == y:
        raise ValueError("Choose two different categorical columns.")
    plan.update(x=x, y=y)
    a, va, ra = _categorical(ds, x)
    b, vb, rb = _categorical(ds, y)

    weight_col_spec = plan.get("count") or plan.get("weight")
    if weight_col_spec:
        count_col = _column(ds, weight_col_spec, "pre-aggregated cell counts")
        if count_col in {x, y}:
            raise ValueError("The count column must be distinct from both categorical columns.")
        plan["count"] = count_col
        plan.pop("weight", None)
        w_vals, vw, rw = _numeric(ds, count_col)
        mask = va & vb & vw & allowed
        if not mask.any():
            raise ValueError("No complete weighted categorical cells were found.")
        active_w = w_vals[mask]
        if np.any(active_w < 0) or not np.all(np.isclose(active_w, np.round(active_w), atol=1e-9)):
            raise ValueError(f"Count column '{count_col}' must contain nonnegative whole-number counts.")
        int_w = np.round(active_w).astype(int)
        counts = pd.crosstab(pd.Series(a[mask], name=x), pd.Series(b[mask], name=y), values=int_w, aggfunc="sum").fillna(0).astype(int)
        reason_lists = [r_excl, ra, rb, rw]
        n = int(counts.to_numpy().sum())
    else:
        mask = va & vb & allowed
        if not mask.any():
            raise ValueError("No complete categorical observations were found.")
        _check_unpooled_replicates(ds, plan, mask, {x, y})
        counts = pd.crosstab(pd.Series(a[mask], name=x), pd.Series(b[mask], name=y))
        reason_lists = [r_excl, ra, rb]
        n = int(mask.sum())

    if counts.shape != (2, 2):
        raise ValueError(
            f"Fisher's exact test requires a 2×2 contingency table, but ({x} × {y}) has shape {counts.shape[0]}×{counts.shape[1]}. "
            "Use method='chi2' for larger contingency tables."
        )
    if n <= 0:
        raise ValueError("Contingency table total count is zero.")

    mat = counts.to_numpy(dtype=int)
    odds_ratio, p_val = stats.fisher_exact(mat, alternative="two-sided")
    or_clean = float(odds_ratio) if math.isfinite(odds_ratio) else None
    observed_rows = [{x: str(idx), **{str(col): int(counts.loc[idx, col]) for col in counts.columns}} for idx in counts.index]
    warnings.append(
        "Two-sided Fisher's exact test conditions on the observed row and column marginals (hypergeometric distribution); "
        "exact p-values sum probabilities of all 2×2 tables with probability less than or equal to the observed table."
    )
    tables = [
        _table("Fisher's exact test", [{
            "row_levels": f"{counts.index[0]} vs {counts.index[1]}",
            "col_levels": f"{counts.columns[0]} vs {counts.columns[1]}",
            "n": n,
            "odds_ratio": or_clean,
            "p": float(p_val),
        }]),
        _table("Observed counts", observed_rows),
    ]
    or_txt = f"{or_clean:.4g}" if or_clean is not None else "infinite/0"
    summary = f"Fisher's exact test (2×2, n = {n}): two-sided p = {float(p_val):.4g}, sample odds ratio = {or_txt}."
    return _finish(ds, plan, "fisher_exact", summary, tables, warnings, _account(ds, mask, reason_lists, excluded_rows=excluded))


def _nonlinear_curve(ds: Dataset, plan: dict, curve_mode: str, warnings: list[str]) -> dict:
    """Fit 4PL Hill concentration–response ('hill') or Boltzmann voltage-dependence ('boltzmann') curves."""
    _require_independent(plan)
    allowed, r_excl, excluded = _excluded_mask(ds, plan)
    x_col = _column(ds, plan.get("x"), "concentration / dose (x)" if curve_mode == "hill" else "membrane voltage / stimulus (x)")
    y_col = _column(ds, plan.get("y"), "response outcome (y)")
    if x_col == y_col:
        raise ValueError("Choose distinct columns for predictor (x) and response (y).")
    plan.update(x=x_col, y=y_col)

    x_vals, vx, rx = _numeric(ds, x_col)
    y_vals, vy, ry = _numeric(ds, y_col)

    group_spec = plan.get("group")
    if group_spec:
        group_col = _column(ds, group_spec, "curve grouping factor")
        if group_col in {x_col, y_col}:
            raise ValueError("The grouping column must be distinct from x and y.")
        plan["group"] = group_col
        g_labels, vg, rg = _categorical(ds, group_col)
        mask = vx & vy & vg & allowed
        reason_lists = [r_excl, rx, ry, rg]
        used_cols = {x_col, y_col, group_col}
    else:
        group_col = None
        g_labels = np.array(["All observations"] * len(ds.df), dtype=object)
        mask = vx & vy & allowed
        reason_lists = [r_excl, rx, ry]
        used_cols = {x_col, y_col}

    x_is_log10 = bool(plan.get("x_is_log10", False))
    if curve_mode == "hill" and not x_is_log10:
        # Auto-detect already log10-transformed molar concentrations (e.g. -9, -8, -7, -6, -5)
        valid_x_preview = x_vals[mask]
        if len(valid_x_preview) >= 4 and float(np.min(valid_x_preview)) < 0.0 and float(np.max(valid_x_preview)) <= 2.0:
            x_is_log10 = True
            plan["x_is_log10"] = True
            warnings.append(
                f"Predictor '{x_col}' contains negative values spanning [{float(np.min(valid_x_preview)):g}, {float(np.max(valid_x_preview)):g}]; "
                "treated directly as log10(concentration) units."
            )
        else:
            neg_x = mask & (x_vals < 0.0)
            if neg_x.any():
                for idx in np.flatnonzero(neg_x):
                    mask[idx] = False
                    rx[idx] = f"Negative concentration ({x_vals[idx]:g}) in '{x_col}' (pass x_is_log10=True if '{x_col}' is already log10-scaled)"

    if not mask.any():
        raise ValueError("No complete finite (x, y) observations are available for curve fitting.")

    # Check longitudinal / sweep structure across x levels (allow 1 sweep per cell at each voltage/dose, block duplicate subreplicates)
    x_strata_str = np.asarray([f"{v:g}" if math.isfinite(v) else "" for v in x_vals], dtype=object)
    x_stratum_order = _sort_strata_naturally(list(dict.fromkeys(x_strata_str[mask])))
    _note_longitudinal_units(ds, mask, x_strata_str, x_stratum_order, used_cols, warnings, x_col)

    if group_col:
        raw_groups = list(dict.fromkeys(str(g) for g in g_labels[mask]))
        group_names = _sort_strata_naturally(raw_groups)
        if len(group_names) > 8:
            raise ValueError(f"Curve comparison supports at most 8 groups; '{group_col}' has {len(group_names)} levels.")
    else:
        group_names = ["All observations"]

    param_rows: list[dict] = []
    grid_rows: list[dict] = []
    separate_fits: list[dict] = []
    group_data_tuples: list[tuple[str, np.ndarray, np.ndarray, np.ndarray]] = []
    had_zero_dose = False

    for g_name in group_names:
        g_mask = mask & (g_labels == g_name) if group_col else mask
        gx = x_vals[g_mask]
        gy = y_vals[g_mask]
        if curve_mode == "hill":
            if x_is_log10:
                u_g = gx.copy()
                z_g = np.zeros(len(gx), dtype=bool)
            else:
                z_g = gx == 0.0
                if z_g.any():
                    had_zero_dose = True
                if int((~z_g).sum()) < 4:
                    raise ValueError(f"Group '{g_name}' needs at least 4 positive (> 0) concentration values to fit a 4PL curve.")
                u_g = np.where(z_g, 0.0, np.log10(np.where(z_g, 1.0, gx)))
        else:
            u_g = gx.copy()
            z_g = np.zeros(len(gx), dtype=bool)

        fit_g = fit_four_param_curve(u_g, gy, z_g, curve_mode)
        separate_fits.append(fit_g)
        group_data_tuples.append((g_name, u_g, gy, z_g))

        b_est, t_est, mid_est, s_est = [float(v) for v in fit_g["params"]]
        b_se, t_se, mid_se, s_se = [float(v) if math.isfinite(v) else None for v in fit_g["se"]]
        b_lo, t_lo, mid_lo, s_lo = [float(v) if math.isfinite(v) else None for v in fit_g["ci_low"]]
        b_hi, t_hi, mid_hi, s_hi = [float(v) if math.isfinite(v) else None for v in fit_g["ci_high"]]

        if curve_mode == "hill":
            pot_type = "EC50" if s_est >= 0.0 else "IC50"
            ec50 = 10.0 ** mid_est if abs(mid_est) < 300 else None
            ec50_lo = (10.0 ** mid_lo) if (mid_lo is not None and abs(mid_lo) < 300) else None
            ec50_hi = (10.0 ** mid_hi) if (mid_hi is not None and abs(mid_hi) < 300) else None
            param_rows.append({
                "group": g_name,
                "n": fit_g["n"],
                "potency_type": pot_type,
                "ec50": ec50,
                "ec50_ci_low": ec50_lo,
                "ec50_ci_high": ec50_hi,
                "log10_ec50": mid_est,
                "log10_ec50_se": mid_se,
                "hill_slope": s_est,
                "hill_se": s_se,
                "bottom": b_est,
                "bottom_se": b_se,
                "top": t_est,
                "top_se": t_se,
                "r_squared": fit_g["r_squared"],
                "residual_sd": fit_g["residual_sd"],
            })
        else:
            param_rows.append({
                "group": g_name,
                "n": fit_g["n"],
                "v_half": mid_est,
                "v_half_se": mid_se,
                "v_half_ci_low": mid_lo,
                "v_half_ci_high": mid_hi,
                "slope_k": s_est,
                "slope_k_se": s_se,
                "bottom": b_est,
                "bottom_se": b_se,
                "top": t_est,
                "top_se": t_se,
                "r_squared": fit_g["r_squared"],
                "residual_sd": fit_g["residual_sd"],
            })

        u_pos = u_g[~z_g]
        u_grid = np.linspace(float(np.min(u_pos)), float(np.max(u_pos)), 120)
        y_hat, ci_l, ci_h = predict_curve_grid(fit_g, u_grid, curve_mode)
        for idx_pt in range(0, len(u_grid), 3):
            uv = float(u_grid[idx_pt])
            xv = (uv if x_is_log10 else (10.0 ** uv)) if curve_mode == "hill" else uv
            grid_rows.append({
                "group": g_name,
                "x": xv,
                "y_fitted": float(y_hat[idx_pt]),
                "ci_low": float(ci_l[idx_pt]) if math.isfinite(ci_l[idx_pt]) else None,
                "ci_high": float(ci_h[idx_pt]) if math.isfinite(ci_h[idx_pt]) else None,
            })

    if had_zero_dose:
        warnings.append(
            f"Zero-concentration vehicle rows ({x_col} = 0) were retained and evaluated at the exact zero-dose horizontal asymptote of the 4PL curve."
        )

    tbl_title = "4PL dose-response parameters" if curve_mode == "hill" else "Boltzmann curve parameters"
    tables = [_table(tbl_title, param_rows)]

    cmp_info = compare_shared_midpoint(group_data_tuples, separate_fits, curve_mode) if len(group_names) >= 2 else None
    if cmp_info is not None:
        tables.append(_table("Curve midpoint comparison", [cmp_info]))

    tables.append(_table("Fitted curve coordinates", grid_rows[:600]))

    method_name = "dose_response" if curve_mode == "hill" else "boltzmann"
    if curve_mode == "hill":
        warnings.append(
            "4-parameter logistic (4PL Hill) nonlinear least squares estimates log10(EC50/IC50) by Gauss–Newton/TRF optimization; "
            "EC50 95% intervals are back-transformed from symmetric Student-t intervals on the log10 concentration scale."
        )
        bits = []
        for r in param_rows:
            ec_str = f"{r['ec50']:.4g}" if r["ec50"] is not None else "n/a"
            ci_str = f" (95% CI [{r['ec50_ci_low']:.4g}, {r['ec50_ci_high']:.4g}])" if (r["ec50_ci_low"] is not None and r["ec50_ci_high"] is not None) else ""
            lbl_prefix = f"{r['group']}: " if group_col else ""
            bits.append(f"{lbl_prefix}{r['potency_type']} = {ec_str}{ci_str}, Hill = {r['hill_slope']:.3g}, R² = {(r['r_squared'] or 0.0):.4g}")
        summary = f"4PL Hill dose–response fit of {y_col} vs {x_col}: " + "; ".join(bits)
        if cmp_info is not None:
            summary += f". Shared-midpoint F({cmp_info['df_between']}, {cmp_info['df_within']}) = {cmp_info['F']:.4g}, p = {cmp_info['p']:.4g}"
        summary += "."
    else:
        warnings.append(
            "4-parameter Boltzmann nonlinear least squares fits Y = Bottom + (Top − Bottom) / (1 + exp((V1/2 − V) / k)); "
            "95% intervals use asymptotic Student-t standard errors (df = n − 4)."
        )
        bits = []
        for r in param_rows:
            ci_str = f" (95% CI [{r['v_half_ci_low']:.4g}, {r['v_half_ci_high']:.4g}])" if (r["v_half_ci_low"] is not None and r["v_half_ci_high"] is not None) else ""
            lbl_prefix = f"{r['group']}: " if group_col else ""
            bits.append(f"{lbl_prefix}V1/2 = {r['v_half']:.4g}{ci_str}, k = {r['slope_k']:.3g}, R² = {(r['r_squared'] or 0.0):.4g}")
        summary = f"Boltzmann fit of {y_col} vs {x_col}: " + "; ".join(bits)
        if cmp_info is not None:
            summary += f". Shared-V1/2 F({cmp_info['df_between']}, {cmp_info['df_within']}) = {cmp_info['F']:.4g}, p = {cmp_info['p']:.4g}"
        summary += "."

    return _finish(ds, plan, method_name, summary, tables, warnings, _account(ds, mask, reason_lists, excluded_rows=excluded))


def analyze(dataset: Dataset, plan: dict) -> dict:
    """Execute one explicitly selected analysis; preserve source values and input plan."""
    if not isinstance(plan, dict):
        raise ValueError("The analysis plan must be a dictionary.")
    if not isinstance(dataset, Dataset) or not len(dataset.df):
        raise ValueError("Open a dataset containing observations before analysis.")
    plan = copy.deepcopy(plan)
    method = plan.get("method", "describe")
    if not isinstance(method, str) or method not in METHODS:
        raise ValueError(f"Unsupported statistical method '{method}'. Supported methods: {', '.join(sorted(METHODS))}.")
    plan["method"] = method
    plan["action"] = "analyze"
    if method == "survival":
        default_plot = "survival"
    elif method == "dose_response":
        default_plot = "dose_response"
    elif method == "boltzmann":
        default_plot = "boltzmann"
    elif method == "ap_waveform":
        default_plot = "ap_waveform"
    elif method in {"timecourse_compare", "two_way_anova", "rm_two_way"}:
        default_plot = "timecourse"
    elif plan.get("pool_by") and method in {"ttest", "anova", "mannwhitney", "kruskal"}:
        default_plot = "superplot"
    elif method in {"paired_t", "wilcoxon", "rm_anova", "friedman"}:
        default_plot = "paired"
    elif method in {"pearson", "spearman", "regression"}:
        default_plot = "scatter"
    elif method in {"chi2", "fisher_exact"}:
        default_plot = "heatmap"
    elif method in {"mannwhitney", "kruskal"}:
        default_plot = "box"
    else:
        default_plot = "distribution"
    plan.setdefault("plot", default_plot)
    warnings = list(getattr(dataset, "warnings", []))
    warnings.append("The software does not infer the experimental unit. Confirm the study design, unit of replication, missingness mechanism, and any planned multiple-comparison procedure.")
    if method == "describe":
        return _describe(dataset, plan, warnings)
    if method == "survival":
        return _survival(dataset, plan, warnings)
    if method == "dose_response":
        return _nonlinear_curve(dataset, plan, "hill", warnings)
    if method == "boltzmann":
        return _nonlinear_curve(dataset, plan, "boltzmann", warnings)
    if method == "ap_waveform":
        return _ap_waveform(dataset, plan, warnings)
    if method == "paired_t":
        return _paired(dataset, plan, warnings)
    if method == "wilcoxon":
        return _wilcoxon(dataset, plan, warnings)
    if method == "rm_anova":
        return _rm_anova(dataset, plan, warnings)
    if method == "friedman":
        return _friedman(dataset, plan, warnings)
    if method == "timecourse_compare":
        return _timecourse_compare(dataset, plan, warnings)
    if method == "two_way_anova":
        return _two_way_anova(dataset, plan, warnings)
    if method == "rm_two_way":
        return _rm_two_way(dataset, plan, warnings)
    if method == "batch_compare":
        return _batch_compare(dataset, plan, warnings)
    if method in {"ttest", "anova", "kruskal", "mannwhitney"}:
        return _group_test(dataset, plan, method, warnings)
    if method in {"pearson", "spearman", "regression"}:
        return _association(dataset, plan, method, warnings)
    if method == "fisher_exact":
        return _fisher_exact(dataset, plan, warnings)
    return _chi2(dataset, plan, warnings)
