"""Bundled R Repository Learning Set (32 canonical R datasets + Rscript ground truth).

Provides zero-network, <5 ms access to 32 real datasets exported from base R and
CRAN packages (`datasets`, `MASS`, `nlme`, `ggplot2`, `survival`), complete with exact R
ground-truth test statistics (`t.test`, `aov`, `kruskal.test`, `drop1`, `lm`,
`cor.test`, `p.adjust(..., 'holm')`, `survdiff`, `coxph`) and archetype routing hints for the LLM
figure & working-sheet planner.
"""
from __future__ import annotations

from functools import lru_cache
import io
import json
import lzma
from pathlib import Path
from typing import Any

import pandas as pd

BUNDLE_PATH = Path(__file__).resolve().parent / 'r_datasets_bundle.json.lzma'


@lru_cache(maxsize=1)
def load_r_bundle() -> dict[str, Any]:
    """Load and cache the compressed R learning-set bundle."""
    if not BUNDLE_PATH.is_file():
        raise FileNotFoundError(f'R learning-set bundle not found at {BUNDLE_PATH}')
    raw = lzma.decompress(BUNDLE_PATH.read_bytes()).decode('utf-8')
    return json.loads(raw)


def list_r_datasets() -> list[dict[str, Any]]:
    """Return lightweight catalog metadata for all bundled R datasets."""
    bundle = load_r_bundle()
    out: list[dict[str, Any]] = []
    for item in bundle.get('datasets', []):
        out.append({
            'id': item['id'],
            'package': item['package'],
            'name': item['name'],
            'r_ref': item['r_ref'],
            'archetype': item['archetype'],
            'title': item['title'],
            'rows': item['rows'],
            'cols': item['cols'],
            'columns': item['columns'],
            'sample_prompts': item.get('sample_prompts', []),
        })
    return out


def get_r_dataset_entry(dataset_id: str) -> dict[str, Any]:
    """Retrieve a single R dataset entry (including CSV payload & R ground truth) by id or r_ref."""
    key = (dataset_id or '').strip()
    if not key:
        raise KeyError('Specify a non-empty R dataset id.')
    bundle = load_r_bundle()
    key_low = key.casefold()
    for item in bundle.get('datasets', []):
        if item['id'].casefold() == key_low or item['r_ref'].casefold() == key_low or item['name'].casefold() == key_low:
            return item
    available = ', '.join(d['id'] for d in bundle.get('datasets', [])[:10])
    raise KeyError(f"Unknown R dataset {dataset_id!r}. Examples: {available}…")


def load_r_dataframe(dataset_id: str) -> pd.DataFrame:
    """Parse the exact R-exported CSV for `dataset_id` into a pandas DataFrame."""
    entry = get_r_dataset_entry(dataset_id)
    return pd.read_csv(io.StringIO(entry['csv']))


def match_learning_set_exemplars(overview: dict[str, Any], max_items: int = 2) -> list[dict[str, Any]]:
    """Return compact R learning-set exemplar recipes matching a spreadsheet's detected layout.

    Safe for LLM context: contains only public R dataset exemplars (zero user cell values).
    """
    if not BUNDLE_PATH.is_file() or not isinstance(overview, dict):
        return []
    layout = str(overview.get('detected_layout') or '')
    if not layout:
        return []
    bundle = load_r_bundle()
    matches: list[dict[str, Any]] = []
    for item in bundle.get('datasets', []):
        if item.get('expected_layout') == layout:
            matches.append({
                'r_ref': item['r_ref'],
                'archetype': item['archetype'],
                'layout': layout,
                'recommended_workflow': item.get('recommended_workflow', ''),
                'sample_prompt': (item.get('sample_prompts') or [''])[0],
            })
            if len(matches) >= max_items:
                break
    return matches
