"""Source-preserving Action Potential & Afterhyperpolarization (AP–AHP) waveform analyzer.

Operates on raw unsmoothed voltage-vs-time traces from spreadsheets (.xlsx/.csv),
Axon Text Files (.atf), or binary .abf recordings loaded via `abf_lite.py`.
Computes threshold (dV/dt criterion), peak, amplitude, half-width (APD50),
10–90% rise time, max upstroke/downstroke dV/dt, phase-plane loops, and
decomposed fast/medium/slow AHP (fAHP, mAHP + integrated area + 50% decay, sAHP).
"""
from __future__ import annotations

import math
import re
from typing import Any

import numpy as np
import pandas as pd
from scipy import stats

_TIME_HEADER_RE = re.compile(
    r'^(?:time(?:[_\s()-]*(?:ms|s|sec|seconds|msec|milliseconds))?|t[_\s-]*(?:ms|s))$',
    re.I,
)
_SECONDS_UNIT_RE = re.compile(r'(?:^|[_\s(-])(?:s|sec|seconds)(?:$|[_\s)-])', re.I)
_TRACE_GROUP_RE = re.compile(
    r'^\s*([A-Za-z][A-Za-z0-9_ +/]*?)(?:[_\-\s.#]+(?:cell|neuron|sweep|sw|trace|rec|mouse|n)?[_\-\s.#]*(\d+|[A-Fa-f])|(\d+))\s*$',
    re.I,
)


def is_waveform_trace_dataframe(df: pd.DataFrame) -> bool:
    """Return True if `df` looks like a high-resolution voltage-vs-time waveform table."""
    if df is None or len(df) < 50 or len(df.columns) < 2:
        return False
    c0 = str(df.columns[0]).strip()
    has_time_col = any(_TIME_HEADER_RE.match(str(c).strip()) for c in df.columns[:3])
    if not has_time_col:
        return False
    t_col = next(str(c) for c in df.columns[:3] if _TIME_HEADER_RE.match(str(c).strip()))
    t_vals = pd.to_numeric(df[t_col], errors='coerce').dropna().to_numpy(dtype=float)
    if len(t_vals) < 50:
        return False
    diffs = np.diff(t_vals[:min(len(t_vals), 500)])
    # Strictly monotonic positive uniform-ish sampling step with small dt (<= 2.0 ms or <= 0.002 s)
    if not np.all(diffs > 0):
        return False
    dt_med = float(np.median(diffs))
    if dt_med > 2.0:
        return False
    # Check at least one trace column spanning physiological mV range ([-110, +80] with excursion >= 25 mV)
    other_cols = [str(c) for c in df.columns if str(c) != t_col]
    for oc in other_cols[:12]:
        v = pd.to_numeric(df[oc], errors='coerce').dropna().to_numpy(dtype=float)
        if len(v) >= 50:
            vmin, vmax = float(np.min(v)), float(np.max(v))
            if -130.0 <= vmin <= -25.0 and -20.0 <= vmax <= 100.0 and (vmax - vmin) >= 30.0:
                return True
    return False


def _infer_trace_group(col_name: str) -> str:
    m = _TRACE_GROUP_RE.match(col_name.strip())
    if not m:
        return 'All_Traces'
    prefix = m.group(1).strip(' _-.')
    if prefix.lower() in {'sweep', 'sw', 'trace', 'cell', 'ch', 'vm', 'voltage', 'in', 'rec'}:
        return 'Sweeps'
    return prefix or 'Sweeps'


def extract_waveform_traces(
    df: pd.DataFrame,
    time_col: str | None = None,
    trace_cols: list[str] | None = None,
    group_col: str | None = None,
    subject_col: str | None = None,
    value_col: str | None = None,
) -> tuple[list[dict[str, Any]], list[str]]:
    """Extract ordered (trace_id, group, time_ms, voltage_mv) dicts from wide or long DataFrame."""
    notes: list[str] = []
    cols_str = [str(c) for c in df.columns]

    # Resolve time column
    if time_col and time_col in cols_str:
        t_col = time_col
    else:
        t_matches = [c for c in cols_str if _TIME_HEADER_RE.match(c.strip())]
        t_col = t_matches[0] if t_matches else cols_str[0]

    # Check if long-format (Group/Cell_ID/Time_ms/Voltage_mV)
    if value_col and value_col in cols_str and (subject_col or group_col):
        traces_out: list[dict[str, Any]] = []
        id_col = subject_col if (subject_col and subject_col in cols_str) else group_col
        assert id_col is not None
        t_raw = pd.to_numeric(df[t_col], errors='coerce')
        v_raw = pd.to_numeric(df[value_col], errors='coerce')
        valid = t_raw.notna() & v_raw.notna()
        sub_df = df.loc[valid].copy()
        sub_df['_t'] = t_raw.loc[valid].astype(float)
        sub_df['_v'] = v_raw.loc[valid].astype(float)
        scale_ms = 1000.0 if (_SECONDS_UNIT_RE.search(t_col) and not re.search(r'ms', t_col, re.I)) else 1.0
        for tid, chunk in sub_df.groupby(id_col, sort=False):
            chunk_s = chunk.sort_values('_t', kind='mergesort')
            t_arr = chunk_s['_t'].to_numpy(dtype=float) * scale_ms
            v_arr = chunk_s['_v'].to_numpy(dtype=float)
            if len(t_arr) < 20:
                continue
            grp = str(chunk_s[group_col].iloc[0]) if (group_col and group_col in chunk_s.columns) else _infer_trace_group(str(tid))
            traces_out.append({
                'trace_id': str(tid),
                'group': grp,
                'time_ms': t_arr,
                'voltage_mv': v_arr,
            })
        if traces_out:
            return traces_out, notes

    # Wide format: 1 time column + N numeric trace columns
    t_series = pd.to_numeric(df[t_col], errors='coerce')
    t_valid_mask = t_series.notna().to_numpy()
    t_vec = t_series.to_numpy(dtype=float)[t_valid_mask]
    if len(t_vec) < 20:
        raise ValueError(f"Waveform time column '{t_col}' requires at least 20 finite samples.")

    # Convert seconds -> ms when indicated by column name or sub-millisecond total span
    is_sec_name = bool(_SECONDS_UNIT_RE.search(t_col) and not re.search(r'ms', t_col, re.I))
    span_raw = float(t_vec[-1] - t_vec[0])
    dt_raw = float(np.median(np.diff(t_vec)))
    if is_sec_name or (0 < span_raw <= 5.0 and dt_raw <= 0.002):
        t_vec = t_vec * 1000.0
        notes.append(f"Converted waveform time column '{t_col}' from seconds to milliseconds (× 1000).")

    cand_cols = trace_cols if trace_cols else [c for c in cols_str if c != t_col]
    traces: list[dict[str, Any]] = []
    raw_groups: list[str] = []
    for c in cand_cols:
        if c not in df.columns:
            continue
        v_ser = pd.to_numeric(df[c], errors='coerce').to_numpy(dtype=float)[t_valid_mask]
        fin = np.isfinite(t_vec) & np.isfinite(v_ser)
        if int(fin.sum()) < 20:
            continue
        grp = _infer_trace_group(c)
        raw_groups.append(grp)
        traces.append({
            'trace_id': c,
            'group': grp,
            'time_ms': t_vec[fin],
            'voltage_mv': v_ser[fin],
        })

    if not traces:
        raise ValueError('No numeric voltage trace columns with >= 20 samples were found.')

    # If every column mapped to a distinct singleton group name, collapse into 'Sweeps' unless >=2 columns share a group
    grp_counts: dict[str, int] = {}
    for g in raw_groups:
        grp_counts[g] = grp_counts.get(g, 0) + 1
    if len(traces) > 1 and max(grp_counts.values()) == 1 and len(grp_counts) > 2:
        for tr in traces:
            tr['group'] = 'Sweeps'

    return traces, notes


def _interp_crossing_up(t: np.ndarray, y: np.ndarray, level: float, i_start: int, i_end: int) -> float | None:
    for idx in range(max(1, i_start + 1), min(len(y), i_end + 1)):
        y0, y1 = float(y[idx - 1]), float(y[idx])
        if y0 < level <= y1 and y1 > y0:
            frac = (level - y0) / (y1 - y0)
            return float(t[idx - 1] + frac * (t[idx] - t[idx - 1]))
    return None


def _interp_crossing_down(t: np.ndarray, y: np.ndarray, level: float, i_start: int, i_end: int) -> float | None:
    for idx in range(max(1, i_start + 1), min(len(y), i_end + 1)):
        y0, y1 = float(y[idx - 1]), float(y[idx])
        if y0 >= level > y1 and y0 > y1:
            frac = (y0 - level) / (y0 - y1)
            return float(t[idx - 1] + frac * (t[idx] - t[idx - 1]))
    return None


def analyze_single_trace_ap_ahp(
    time_ms: np.ndarray,
    voltage_mv: np.ndarray,
    *,
    dvdt_threshold_vs: float = 20.0,
    min_peak_mv: float = -15.0,
    fahp_window_ms: tuple[float, float] = (0.5, 10.0),
    mahp_window_ms: tuple[float, float] = (10.0, 150.0),
    sahp_window_ms: tuple[float, float] = (150.0, 1000.0),
) -> dict[str, Any]:
    """Measure primary AP + fAHP/mAHP/sAHP + phase-plane profile on one unsmoothed trace."""
    t = np.asarray(time_ms, dtype=float)
    v = np.asarray(voltage_mv, dtype=float)
    dt_vec = np.diff(t)
    if len(t) < 20 or np.any(dt_vec <= 0):
        raise ValueError('Waveform trace must have >= 20 strictly increasing time samples.')

    dt_ms = float(np.median(dt_vec))
    fs_hz = 1000.0 / dt_ms
    dvdt = np.gradient(v, t)  # mV / ms == V / s

    # Detect local voltage maxima crossing min_peak_mv with minimum 1.5 ms refractory spacing
    min_sep_samples = max(2, int(round(1.5 / dt_ms)))
    cand_peaks: list[int] = []
    for i in range(2, len(v) - 2):
        if v[i] >= min_peak_mv and v[i] >= v[i - 1] and v[i] > v[i + 1]:
            # Check pre-peak upstroke velocity in preceding 2.5 ms
            pre_lo = max(0, i - max(3, int(round(2.5 / dt_ms))))
            if float(np.max(dvdt[pre_lo:i + 1])) >= min(10.0, dvdt_threshold_vs * 0.5):
                if not cand_peaks or (i - cand_peaks[-1]) >= min_sep_samples:
                    cand_peaks.append(i)
                elif v[i] > v[cand_peaks[-1]]:
                    cand_peaks[-1] = i

    duration_s = float(t[-1] - t[0]) / 1000.0
    spike_count = len(cand_peaks)
    firing_rate_hz = (spike_count / duration_s) if duration_s > 0 else 0.0

    if spike_count == 0:
        # Subthreshold sweep: return resting voltage and explicit None spike metrics
        v_rest = float(np.median(v[:max(5, len(v) // 10)]))
        return {
            'has_spike': False,
            'Spike_Count': 0,
            'Firing_Rate_Hz': 0.0,
            'Sampling_Rate_Hz': round(fs_hz, 2),
            'V_rest_mV': v_rest,
            'V_thresh_mV': None,
            't_thresh_ms': None,
            'V_peak_mV': None,
            't_peak_ms': None,
            'AP_Amplitude_mV': None,
            'HalfWidth_ms': None,
            'RiseTime_10_90_ms': None,
            'Max_dVdt_Vs': float(np.max(dvdt)),
            'Min_dVdt_Vs': float(np.min(dvdt)),
            'fAHP_mV': None,
            'fAHP_Abs_mV': None,
            'fAHP_Latency_ms': None,
            'mAHP_mV': None,
            'mAHP_RelRest_mV': None,
            'mAHP_Latency_ms': None,
            'mAHP_Area_mVms': None,
            'AHP_HalfDecay_ms': None,
            'sAHP_mV': None,
            'sAHP_Area_mVms': None,
            'dvdt': dvdt,
        }

    p0 = cand_peaks[0]
    t_peak = float(t[p0])
    v_peak = float(v[p0])

    # Search 4.0 ms before primary peak for dV/dt threshold crossing
    lookback = max(3, int(round(4.0 / dt_ms)))
    i_up_start = max(0, p0 - lookback)
    eff_thresh = dvdt_threshold_vs
    if float(np.max(dvdt[i_up_start:p0 + 1])) < eff_thresh:
        eff_thresh = max(8.0, 0.25 * float(np.max(dvdt[i_up_start:p0 + 1])))

    i_thresh = i_up_start
    t_thresh = float(t[i_up_start])
    v_thresh = float(v[i_up_start])
    for idx in range(i_up_start + 1, p0 + 1):
        if dvdt[idx - 1] < eff_thresh <= dvdt[idx]:
            denom = float(dvdt[idx] - dvdt[idx - 1])
            frac = (eff_thresh - float(dvdt[idx - 1])) / denom if denom > 0 else 0.0
            t_thresh = float(t[idx - 1] + frac * (t[idx] - t[idx - 1]))
            v_thresh = float(v[idx - 1] + frac * (v[idx] - v[idx - 1]))
            i_thresh = idx
            break

    # Pre-spike baseline V_rest: [t_thresh - 5.0 ms, t_thresh - 0.8 ms] (or initial pre-spike samples)
    rest_mask = (t >= (t_thresh - 6.0)) & (t <= (t_thresh - 0.6))
    if int(rest_mask.sum()) >= 3:
        v_rest = float(np.median(v[rest_mask]))
    elif i_thresh >= 3:
        v_rest = float(np.median(v[:max(3, i_thresh - 1)]))
    else:
        v_rest = float(v[0])

    ap_amp = v_peak - v_thresh
    v_half = v_thresh + 0.5 * ap_amp

    # Post-spike bound before any 2nd spike upstroke (stop 1.0 ms prior to 2nd peak)
    if spike_count >= 2:
        p1 = cand_peaks[1]
        i_post_limit = max(p0 + 2, p1 - max(2, int(round(1.5 / dt_ms))))
    else:
        i_post_limit = len(v) - 1
    t_post_limit = float(t[i_post_limit])

    # APD50 Half-Width
    i_down_search = min(i_post_limit, p0 + max(5, int(round(15.0 / dt_ms))))
    t_up_50 = _interp_crossing_up(t, v, v_half, max(0, i_thresh - 3), p0)
    t_dn_50 = _interp_crossing_down(t, v, v_half, p0, i_down_search)
    half_width_ms = (t_dn_50 - t_up_50) if (t_up_50 is not None and t_dn_50 is not None and t_dn_50 > t_up_50) else None

    # 10-90% Rise Time
    t_10 = _interp_crossing_up(t, v, v_thresh + 0.1 * ap_amp, max(0, i_thresh - 3), p0)
    t_90 = _interp_crossing_up(t, v, v_thresh + 0.9 * ap_amp, max(0, i_thresh - 3), p0)
    rise_10_90 = (t_90 - t_10) if (t_10 is not None and t_90 is not None and t_90 > t_10) else None

    # Max upstroke and repolarization dV/dt within the primary spike complex
    max_dvdt = float(np.max(dvdt[i_up_start:p0 + 1]))
    min_dvdt = float(np.min(dvdt[p0:min(len(v), p0 + max(4, int(round(10.0 / dt_ms))))]))

    # fAHP: [t_peak + fahp_lo, min(t_post_limit, t_peak + fahp_hi)]
    f_lo = t_peak + fahp_window_ms[0]
    f_hi = min(t_post_limit, t_peak + fahp_window_ms[1])
    f_mask = (t >= f_lo) & (t <= f_hi)
    if int(f_mask.sum()) >= 2:
        f_idx_sub = int(np.argmin(v[f_mask]))
        f_abs = float(v[f_mask][f_idx_sub])
        f_t = float(t[f_mask][f_idx_sub])
        fahp_mv = f_abs - v_thresh
        fahp_lat = f_t - t_peak
    else:
        f_abs, fahp_mv, fahp_lat = None, None, None

    # mAHP: [t_peak + mahp_lo, min(t_post_limit, t_peak + mahp_hi)]
    m_lo = t_peak + mahp_window_ms[0]
    m_hi = min(t_post_limit, t_peak + mahp_window_ms[1])
    m_mask = (t >= m_lo) & (t <= m_hi)
    if int(m_mask.sum()) >= 3:
        t_m = t[m_mask]
        v_m = v[m_mask]
        m_sub = int(np.argmin(v_m))
        m_abs = float(v_m[m_sub])
        m_t = float(t_m[m_sub])
        mahp_mv = m_abs - v_thresh
        mahp_rel_rest = m_abs - v_rest
        mahp_lat = m_t - t_peak
        # Hyperpolarizing area below V_thresh (positive mV·ms magnitude for downward AHP deflection)
        hyper_deflection = np.maximum(0.0, v_thresh - v_m)
        _trapz = getattr(np, 'trapezoid', getattr(np, 'trapz', None))
        mahp_area = float(_trapz(hyper_deflection, t_m))

        # 50% AHP recovery time toward V_rest (or V_thresh if V_rest <= m_abs)
        v_rec_ref = v_rest if v_rest > (m_abs + 0.5) else v_thresh
        half_rec_target = m_abs + 0.5 * (v_rec_ref - m_abs)
        post_trough_mask = (t >= m_t) & (t <= t_post_limit)
        t_pt = t[post_trough_mask]
        v_pt = v[post_trough_mask]
        t_rec_50 = _interp_crossing_up(t_pt, v_pt, half_rec_target, 0, len(v_pt) - 1) if len(v_pt) >= 2 else None
        ahp_half_decay = (t_rec_50 - m_t) if (t_rec_50 is not None and t_rec_50 > m_t) else None
    else:
        mahp_mv, mahp_rel_rest, mahp_lat, mahp_area, ahp_half_decay = None, None, None, None, None

    # sAHP: measured [150, 1000] ms after the LAST spike in the sweep (captures post-burst sAHP too!)
    p_last = cand_peaks[-1]
    t_last_peak = float(t[p_last])
    s_lo = t_last_peak + sahp_window_ms[0]
    s_hi = t_last_peak + sahp_window_ms[1]
    s_mask = (t >= s_lo) & (t <= s_hi)
    if int(s_mask.sum()) >= 5:
        t_s = t[s_mask]
        v_s = v[s_mask]
        s_abs = float(np.min(v_s))
        sahp_mv = s_abs - v_rest
        _trapz = getattr(np, 'trapezoid', getattr(np, 'trapz', None))
        sahp_area = float(_trapz(np.maximum(0.0, v_rest - v_s), t_s))
    else:
        sahp_mv, sahp_area = None, None

    return {
        'has_spike': True,
        'Spike_Count': spike_count,
        'Firing_Rate_Hz': round(firing_rate_hz, 4),
        'Sampling_Rate_Hz': round(fs_hz, 2),
        'V_rest_mV': v_rest,
        'V_thresh_mV': v_thresh,
        't_thresh_ms': t_thresh,
        'V_peak_mV': v_peak,
        't_peak_ms': t_peak,
        'AP_Amplitude_mV': ap_amp,
        'HalfWidth_ms': half_width_ms,
        'RiseTime_10_90_ms': rise_10_90,
        'Max_dVdt_Vs': max_dvdt,
        'Min_dVdt_Vs': min_dvdt,
        'fAHP_mV': fahp_mv,
        'fAHP_Abs_mV': f_abs,
        'fAHP_Latency_ms': fahp_lat,
        'mAHP_mV': mahp_mv,
        'mAHP_RelRest_mV': mahp_rel_rest,
        'mAHP_Latency_ms': mahp_lat,
        'mAHP_Area_mVms': mahp_area,
        'AHP_HalfDecay_ms': ahp_half_decay,
        'sAHP_mV': sahp_mv,
        'sAHP_Area_mVms': sahp_area,
        'dvdt': dvdt,
    }


def analyze_waveform_collection(
    df: pd.DataFrame,
    plan: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Run full AP–AHP extraction, group summaries, and aligned ensemble curves on a waveform DataFrame."""
    cfg = dict(plan or {})
    traces, notes = extract_waveform_traces(
        df,
        time_col=cfg.get('x') or cfg.get('time_col'),
        trace_cols=cfg.get('columns'),
        group_col=cfg.get('group'),
        subject_col=cfg.get('subject'),
        value_col=cfg.get('y'),
    )
    dvdt_thr = float(cfg.get('dvdt_threshold', 20.0))
    min_pk = float(cfg.get('min_peak_mv', -15.0))

    metric_rows: list[dict[str, Any]] = []
    analyzed_traces: list[dict[str, Any]] = []
    max_post_ms = 25.0

    for tr in traces:
        res = analyze_single_trace_ap_ahp(
            tr['time_ms'],
            tr['voltage_mv'],
            dvdt_threshold_vs=dvdt_thr,
            min_peak_mv=min_pk,
        )
        row = {
            'Trace_ID': tr['trace_id'],
            'Group': tr['group'],
            'Spike_Count': res['Spike_Count'],
            'Firing_Rate_Hz': res['Firing_Rate_Hz'],
            'V_rest_mV': res['V_rest_mV'],
            'V_thresh_mV': res['V_thresh_mV'],
            'V_peak_mV': res['V_peak_mV'],
            'AP_Amplitude_mV': res['AP_Amplitude_mV'],
            'HalfWidth_ms': res['HalfWidth_ms'],
            'RiseTime_10_90_ms': res['RiseTime_10_90_ms'],
            'Max_dVdt_Vs': res['Max_dVdt_Vs'],
            'Min_dVdt_Vs': res['Min_dVdt_Vs'],
            'fAHP_mV': res['fAHP_mV'],
            'fAHP_Latency_ms': res['fAHP_Latency_ms'],
            'mAHP_mV': res['mAHP_mV'],
            'mAHP_RelRest_mV': res['mAHP_RelRest_mV'],
            'mAHP_Area_mVms': res['mAHP_Area_mVms'],
            'AHP_HalfDecay_ms': res['AHP_HalfDecay_ms'],
            'sAHP_mV': res['sAHP_mV'],
            'sAHP_Area_mVms': res['sAHP_Area_mVms'],
        }
        metric_rows.append(row)

        t_arr = tr['time_ms']
        v_arr = tr['voltage_mv']
        t_zero = res['t_thresh_ms'] if res['t_thresh_ms'] is not None else float(t_arr[0])
        rel_t = t_arr - float(t_zero)
        if res['has_spike']:
            max_post_ms = max(max_post_ms, min(160.0, float(rel_t[-1])))
        analyzed_traces.append({
            'trace_id': tr['trace_id'],
            'group': tr['group'],
            'has_spike': res['has_spike'],
            'rel_time_ms': rel_t,
            'voltage_mv': v_arr,
            'dvdt_vs': res['dvdt'],
            'metrics': row,
        })

    spiking = [tr for tr in analyzed_traces if tr['has_spike']]
    if not spiking:
        notes.append('No suprathreshold action potentials crossing min_peak_mv were detected; reporting passive trace velocities.')

    # Build aligned common time grid [-4 ms, +max_post_ms] for ensemble Mean ± SEM overlays
    grid_hi = min(150.0, max(20.0, max_post_ms))
    common_tau = np.linspace(-4.0, grid_hi, 600)
    groups_ordered = list(dict.fromkeys(tr['group'] for tr in analyzed_traces))

    ensemble_by_group: dict[str, dict[str, Any]] = {}
    for g in groups_ordered:
        g_traces = [tr for tr in spiking if tr['group'] == g] or [tr for tr in analyzed_traces if tr['group'] == g]
        interp_mat = []
        phase_loops = []
        for tr in g_traces:
            rt = tr['rel_time_ms']
            vv = tr['voltage_mv']
            dv = tr['dvdt_vs']
            # Mask outside trace support as NaN so shorter sweeps don't extrapolate flat tails
            y_i = np.interp(common_tau, rt, vv, left=np.nan, right=np.nan)
            interp_mat.append(y_i)
            # Phase-plane window [-3 ms, +12 ms] around spike threshold
            pp_mask = (rt >= -3.0) & (rt <= 12.0)
            if int(pp_mask.sum()) >= 5:
                phase_loops.append((vv[pp_mask], dv[pp_mask], tr['trace_id']))

        M = np.vstack(interp_mat) if interp_mat else np.empty((0, len(common_tau)))
        if len(M):
            n_fin = np.sum(np.isfinite(M), axis=0)
            sum_v = np.nansum(M, axis=0)
            mean_v = np.where(n_fin >= 1, sum_v / np.maximum(1, n_fin), np.nan)
            diff_sq = np.where(np.isfinite(M), (M - mean_v) ** 2, 0.0)
            sd_v = np.where(n_fin >= 2, np.sqrt(np.sum(diff_sq, axis=0) / np.maximum(1, n_fin - 1)), 0.0)
            sem_v = np.where(n_fin >= 2, sd_v / np.sqrt(np.maximum(1, n_fin)), 0.0)
        else:
            mean_v = np.zeros_like(common_tau)
            sd_v = np.zeros_like(common_tau)
            sem_v = np.zeros_like(common_tau)
        ensemble_by_group[g] = {
            'n_traces': len(g_traces),
            'tau_ms': common_tau,
            'mean_mv': mean_v,
            'sd_mv': sd_v,
            'sem_mv': sem_v,
            'individual_traces': [(tr['rel_time_ms'], tr['voltage_mv'], tr['trace_id']) for tr in g_traces],
            'phase_loops': phase_loops,
        }

    # Summarize biophysical metrics per group & run automatic group comparison on key AP–AHP features
    key_features = (
        'V_thresh_mV',
        'AP_Amplitude_mV',
        'HalfWidth_ms',
        'Max_dVdt_Vs',
        'Min_dVdt_Vs',
        'fAHP_mV',
        'mAHP_mV',
        'mAHP_Area_mVms',
        'sAHP_mV',
    )
    summary_rows: list[dict[str, Any]] = []
    comparison_rows: list[dict[str, Any]] = []
    mdf = pd.DataFrame(metric_rows)

    for feat in key_features:
        if feat not in mdf.columns:
            continue
        grp_arrays: list[tuple[str, np.ndarray]] = []
        for g in groups_ordered:
            vals = pd.to_numeric(mdf.loc[mdf['Group'] == g, feat], errors='coerce').dropna().to_numpy(dtype=float)
            if len(vals) == 0:
                continue
            grp_arrays.append((g, vals))
            sd_val = float(np.std(vals, ddof=1)) if len(vals) >= 2 else 0.0
            summary_rows.append({
                'parameter': feat,
                'group': g,
                'n': int(len(vals)),
                'mean': float(np.mean(vals)),
                'sd': sd_val,
                'sem': sd_val / math.sqrt(len(vals)) if len(vals) >= 2 else 0.0,
                'median': float(np.median(vals)),
            })
        if len(grp_arrays) == 2 and all(len(a) >= 2 for _, a in grp_arrays):
            (g1, a1), (g2, a2) = grp_arrays
            if np.std(a1, ddof=1) > 0 or np.std(a2, ddof=1) > 0:
                t_res = stats.ttest_ind(a1, a2, equal_var=False)
                comparison_rows.append({
                    'parameter': feat,
                    'test': 'Welch t-test',
                    'groups': f'{g2} vs {g1}',
                    'difference': float(np.mean(a2) - np.mean(a1)),
                    'statistic': float(t_res.statistic),
                    'p_unadjusted': float(t_res.pvalue),
                })
        elif len(grp_arrays) >= 3 and all(len(a) >= 2 for _, a in grp_arrays):
            f_res = stats.f_oneway(*(a for _, a in grp_arrays))
            if math.isfinite(float(f_res.pvalue)):
                comparison_rows.append({
                    'parameter': feat,
                    'test': 'One-way ANOVA',
                    'groups': ' vs '.join(g for g, _ in grp_arrays),
                    'difference': None,
                    'statistic': float(f_res.statistic),
                    'p_unadjusted': float(f_res.pvalue),
                })

    # Holm-adjust across reported AP–AHP parameter comparisons
    if comparison_rows:
        m_cmp = len(comparison_rows)
        indexed = sorted(enumerate(comparison_rows), key=lambda kv: kv[1]['p_unadjusted'])
        running = 0.0
        adj_map: dict[int, float] = {}
        for rank, (orig_i, item) in enumerate(indexed):
            running = max(running, min(1.0, item['p_unadjusted'] * (m_cmp - rank)))
            adj_map[orig_i] = running
        for orig_i, item in enumerate(comparison_rows):
            item['p_holm'] = adj_map[orig_i]

    return {
        'metrics_df': mdf,
        'metric_rows': metric_rows,
        'summary_rows': summary_rows,
        'comparison_rows': comparison_rows,
        'groups': groups_ordered,
        'ensemble_by_group': ensemble_by_group,
        'dvdt_threshold_vs': dvdt_thr,
        'notes': notes,
    }
