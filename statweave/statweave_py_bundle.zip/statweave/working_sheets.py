"""Audited, deterministic intermediate working sheets and multi-tab .xlsx export.

Preserves StatWeave's core data-integrity guarantee:
- Raw imported files in `project_dir/source/` remain 0444 read-only and untouched.
- Intermediate reshaped, constructed, normalized, or unit-pooled tables are stored
  separately in `project_dir/derived/working_sheets.xlsx`, exposed as first-class
  selectable tabs in `Dataset.sheets`, and recorded in the hash-chained audit log.
- Zero `eval()` or `exec()`: only closed, reproducible tabular transformations run.
"""
from __future__ import annotations

import io
import math
from pathlib import Path
import re
from typing import Any
import urllib.parse
import urllib.request

import numpy as np
import openpyxl
import pandas as pd

from .data import Dataset, list_sheets, load_dataset
from .engine import MISSING_TOKENS, _COUNT_COLUMN_RE, _parse_survival_series

MAX_WORKING_SHEETS = 24
MAX_CONSTRUCT_ROWS = 2_000
MAX_CONSTRUCT_COLS = 64
WORKING_WORKBOOK_REL = Path('derived') / 'working_sheets.xlsx'

SUPPORTED_OPS = frozenset({
    'construct',
    'melt_wide_to_long',
    'melt_plate_grid',
    'reshape_replicates',
    'derive_group',
    'assign_groups',
    'compute_column',
    'aggregate_units',
    'rename_or_select',
})

SUPPORTED_FORMULAS = frozenset({
    'diff',
    'sum',
    'ratio',
    'pct_change',
    'pct_of_col',
    'pct_of_group_mean',
    'pct_of_baseline_group_mean',
    'pct_of_timepoint_group_mean',
    'fold_of_group_mean',
    'pow2_neg_ddct',
    'ddct_fold_change',
    'mean_cols',
    'log10',
    'ln',
    'abs',
    'zscore',
    'linear_scale',
})

_REPLICATE_HEADER_RE = re.compile(
    r'^\s*([A-Za-z][A-Za-z0-9_ +/]*?)(?:[_\-\s.#]+(\d+|[A-Da-d])|(\d+))\s*$'
)
_TIME_COL_HINT_RE = re.compile(
    r'^(?:column\s*1|unnamed.*|time|timepoint|time_point|date|dates|day|days|week|weeks|hour|hours|min|minutes|sec|seconds|session|visit|trial|dose|stage|age|bin)$',
    re.I,
)


def _clean_stratum_value(val: Any, fallback: str = '') -> str:
    """Format dates/timestamps/numbers cleanly (e.g. '2026-05-01' without '00:00:00')."""
    if val is None:
        return fallback
    try:
        if bool(pd.isna(val)):
            return fallback
    except (TypeError, ValueError):
        pass
    if hasattr(val, 'strftime'):
        try:
            if getattr(val, 'hour', 0) == 0 and getattr(val, 'minute', 0) == 0 and getattr(val, 'second', 0) == 0:
                return val.strftime('%Y-%m-%d')
            return val.strftime('%Y-%m-%d %H:%M')
        except Exception:
            pass
    text = str(val).strip()
    if not text or text.casefold() in MISSING_TOKENS:
        return fallback
    text = re.sub(r'^(\d{4}-\d{2}-\d{2})\s+00:00:00(?:\.0+)?$', r'\1', text)
    if re.fullmatch(r'[-+]?\d+\.0+', text):
        text = text.split('.')[0]
    return text


def _normalize_prefix_label(prefix: str) -> str:
    p = prefix.strip(" _-#.")
    if len(p) <= 3:
        return p.upper()
    if p.islower() or p.isupper():
        return p.upper() if len(p) <= 4 else p.title()
    return p


def extract_replicate_prefix(label: str) -> str | None:
    """Extract base group prefix from a replicate header or subject ID (e.g. 'Wt-1' -> 'WT', 'Control_2' -> 'Control')."""
    m = _REPLICATE_HEADER_RE.match(str(label or '').strip())
    if not m:
        return None
    raw_prefix = (m.group(1) or '').strip()
    if not raw_prefix or _TIME_COL_HINT_RE.match(raw_prefix):
        return None
    return _normalize_prefix_label(raw_prefix)


def detect_replicate_structure(df: pd.DataFrame, row_numbers: list[int] | None = None) -> dict[str, Any]:
    """Inspect wide columns for replicate families (e.g. Wt-1..3 vs Ko-1..3) and optional leading timepoint/index column."""
    empty_res: dict[str, Any] = {
        'detected': False,
        'is_replicate_wide': False,
        'is_timecourse': False,
        'has_multiple_timepoints': False,
        'groups': {},
        'time_col': None,
        'time_labels': [],
        'replicate_cols': [],
        'suggested_ref_group': None,
    }
    if df is None or df.empty or len(df.columns) < 2:
        return empty_res

    cols = [str(c) for c in df.columns]
    numeric_set: set[str] = set()
    for c in cols:
        try:
            s = _numeric_series(df, c)
            if int(s.notna().sum()) >= 1:
                numeric_set.add(c)
        except ValueError:
            continue

    prefix_buckets: dict[str, list[str]] = {}
    prefix_display: dict[str, str] = {}
    for c in cols:
        if c not in numeric_set:
            continue
        pref = extract_replicate_prefix(c)
        if not pref:
            continue
        key = pref.casefold()
        prefix_buckets.setdefault(key, []).append(c)
        prefix_display.setdefault(key, pref)

    groups_map: dict[str, list[str]] = {
        prefix_display[k]: list(v)
        for k, v in prefix_buckets.items()
        if len(v) >= 2
    }
    replicate_cols = [c for g_cols in groups_map.values() for c in g_cols]
    if len(groups_map) < 1 or len(replicate_cols) < 3:
        return empty_res

    non_rep_cols = [c for c in cols if c not in replicate_cols]
    time_col: str | None = None
    if non_rep_cols:
        first_non_rep = non_rep_cols[0]
        if cols.index(first_non_rep) == 0 or _TIME_COL_HINT_RE.match(first_non_rep):
            time_col = first_non_rep

    rnums = list(row_numbers) if row_numbers is not None else list(range(2, len(df) + 2))
    time_labels: list[str] = []
    if time_col is not None:
        raw_t = df[time_col].tolist()
        for idx, val in enumerate(raw_t):
            r_lbl = f"A{rnums[idx]}" if idx < len(rnums) else f"T{idx + 1}"
            time_labels.append(_clean_stratum_value(val, fallback=r_lbl))
    elif len(df) >= 2:
        time_labels = [f"Row {r}" for r in rnums]

    # Decide control/reference group heuristically (WT / Control / Veh / Baseline first, else first family)
    group_names = list(groups_map.keys())
    control_group = group_names[0]
    for g_name in group_names:
        if re.search(r'^(?:wt|wild|ctrl|control|con|veh|vehicle|sham|base|baseline|ref|untreated|saline)$', g_name, re.I):
            control_group = g_name
            break

    is_tc = len(df) >= 2
    return {
        'detected': True,
        'is_replicate_wide': True,
        'groups': groups_map,
        'replicate_cols': replicate_cols,
        'time_col': time_col,
        'time_labels': time_labels[:24],
        'is_timecourse': is_tc,
        'has_multiple_timepoints': is_tc,
        'suggested_ref_group': control_group,
    }


_UNIT_COL_HINT_RE = re.compile(
    r'^(?:(?:animal|mouse|mice|rat|chick|tree|plant|donor|patient|subject|litter|participant|person|cage|run|plot)(?:[\s_-]*id)?|(?:cell|neuron|slice|recording|replicate)[\s_-]*id|id)$',
    re.I,
)
_ROW_INDEX_COL_RE = re.compile(r'^(?:index|row|row_id|obs|observation)$', re.I)
_DISCRETE_FACTOR_NAME_RE = re.compile(
    r'^(?:group|groups|diet|diets|supp|supplement|treat|treatment|arm|cond|condition|strain|genotype|sex|gender|species|'
    r'dose(?:s|[_\s-]*(?:um|nm|mm|mg|ng|ug|g|ml|kg|pct))?|(?:conc|concentration)(?:[_\s-]*(?:um|nm|mm|mg|ng|ug|m|pct))?|'
    r'time(?:point|s|[_\s-]*(?:point|min|mins|s|sec|ms|hr|hrs|h|d|days|wk|wks|mo))?|'
    r'(?:(?:training|study|postop|test)[_\s-]*)?(?:day|days|week|weeks|month|months|year|years|visit|session|trial)|'
    r'age|stage|phase|block|variety|var|loc|location|wool|tension|spray|state|type|drv|cyl|gear|am|vs|n|p|k|sweep|'
    r'(?:current[_\s-]*)?step(?:[_\s-]*pa)?|(?:command[_\s-]*|holding[_\s-]*)?voltage(?:[_\s-]*mv)?|'
    r'temp(?:erature)?(?:[_\s-]*[cfk])?)$',
    re.I,
)
_TIME_OR_DOSE_FACTOR_RE = re.compile(
    r'^(?:column\s*1|date|dates|'
    r'time(?:point|s|[_\s-]*(?:point|min|mins|s|sec|ms|hr|hrs|h|d|days|wk|wks|mo))?|'
    r'(?:(?:training|study|postop|test)[_\s-]*)?(?:day|days|week|weeks|month|months|year|years|visit|session|trial)|'
    r'age|dose(?:s|[_\s-]*(?:um|nm|mm|mg|ng|ug|g|ml|kg|pct))?|(?:conc|concentration)(?:[_\s-]*(?:um|nm|mm|mg|ng|ug|m|pct))?|'
    r'stage|phase|sweep|(?:current[_\s-]*)?step(?:[_\s-]*pa)?|(?:command[_\s-]*|holding[_\s-]*)?voltage(?:[_\s-]*mv)?|'
    r'temp(?:erature)?(?:[_\s-]*[cfk])?)$',
    re.I,
)
_SURVIVAL_TIME_COL_RE = re.compile(
    r'^(?:time|futime|surv[._\s-]*(?:time|days|months|weeks|years)|survival[._\s-]*(?:time|days|months|weeks|years)|'
    r'time[._\s-]*(?:days|months|weeks|years|hrs|hours)|time[._\s-]*to[._\s-]*\w+|'
    r'follow[._\s-]*up(?:[._\s-]*(?:time|days|months|weeks|years))?|'
    r'os[._\s-]*(?:time|months|days)|pfs[._\s-]*(?:time|months|days)|dfs[._\s-]*time|rfs[._\s-]*time|'
    r'days[._\s-]*to[._\s-]*(?:event|death|follow[._\s-]*up)|duration|stime|t_surv|months|days)$',
    re.I,
)
_SURVIVAL_EVENT_COL_RE = re.compile(
    r'^(?:status|event|events|cens|censor|censored|fustat|vital[._\s-]*status|dead|death|died|'
    r'(?:event|censor|censored|survival|death)[._\s-]*(?:status|ind|indicator|code|flag|event)|'
    r'\w+[._\s-]*(?:event|events|death|died|censor|censored|recurrence|relapse)|'
    r'os[._\s-]*(?:event|status)|pfs[._\s-]*(?:event|status)|recurrence|relapse|progression|cmv)$',
    re.I,
)
_SURVIVAL_GROUP_PREF_RE = re.compile(
    r'^(?:rx|trt|treat|treatment|arm|group|groups|cohort|regimen|sex|gender|x|celltype|genotype|strain|prior|resid\.ds|ph\.ecog|ecog\.ps)$',
    re.I,
)
_PLATE_ROW_LETTER_RE = re.compile(r'^[A-P]$', re.I)
_PLATE_COL_NUM_RE = re.compile(r'^(?:col(?:umn)?[_\s-]*)?0*([1-9]|1\d|2[0-4])$', re.I)


def detect_plate_structure(df: pd.DataFrame) -> dict[str, Any]:
    """Detect 24/48/96/384-well microplate reader matrix (rows A..H/P × numeric columns 1..12/24)."""
    empty: dict[str, Any] = {'detected': False, 'row_col': None, 'plate_cols': [], 'well_count': 0}
    if df is None or df.empty or not (3 <= len(df) <= 16) or not (5 <= len(df.columns) <= 25):
        return empty
    cols = [str(c) for c in df.columns]
    row_col = cols[0]
    row_vals = [str(v).strip().upper() for v in df[row_col].tolist() if v is not None and str(v).strip()]
    if len(row_vals) != len(df) or len(set(row_vals)) != len(row_vals):
        return empty
    if not all(_PLATE_ROW_LETTER_RE.match(rv) for rv in row_vals):
        return empty
    plate_cols: list[str] = []
    for c in cols[1:]:
        if not _PLATE_COL_NUM_RE.match(c.strip()):
            return empty
        try:
            s = _numeric_series(df, c)
            if int(s.notna().sum()) >= 1:
                plate_cols.append(c)
        except ValueError:
            return empty
    if len(plate_cols) < 4:
        return empty
    return {
        'detected': True,
        'row_col': row_col,
        'plate_cols': plate_cols,
        'row_letters': row_vals,
        'well_count': len(row_vals) * len(plate_cols),
    }


def detect_survival_structure(df: pd.DataFrame) -> dict[str, Any]:
    """Detect right-censored survival / time-to-event structure (non-negative follow-up time + binary censoring/event indicator)."""
    empty: dict[str, Any] = {
        'detected': False,
        'time_col': None,
        'event_col': None,
        'events': 0,
        'censored': 0,
        'group_cols': [],
    }
    if df is None or df.empty or len(df) < 4 or len(df.columns) < 2:
        return empty

    cols = [str(c) for c in df.columns]
    event_col: str | None = None
    ev_arr_best: np.ndarray | None = None
    ev_valid_best: np.ndarray | None = None

    for c in cols:
        if not _SURVIVAL_EVENT_COL_RE.match(c.strip()):
            continue
        try:
            ev_arr, ev_valid, _, _ = _parse_survival_series(df[c], c)
        except ValueError:
            continue
        n_v = int(ev_valid.sum())
        if n_v < max(4, int(0.6 * len(df))):
            continue
        n_ev = int(ev_arr[ev_valid].sum())
        if 1 <= n_ev <= n_v:
            # Check that distinct raw non-missing values are strictly binary (1 or 2 distinct status values)
            non_miss = [
                str(v).strip().casefold()
                for v in df[c].tolist()
                if v is not None and not (isinstance(v, float) and math.isnan(v))
                and str(v).strip() != '' and str(v).strip().casefold() not in MISSING_TOKENS
            ]
            if 1 <= len(set(non_miss)) <= 2:
                event_col = c
                ev_arr_best = ev_arr
                ev_valid_best = ev_valid
                break

    if event_col is None or ev_arr_best is None or ev_valid_best is None:
        return empty

    time_col: str | None = None
    for c in cols:
        if c == event_col or not _SURVIVAL_TIME_COL_RE.match(c.strip()):
            continue
        try:
            s_num = _numeric_series(df, c)
        except ValueError:
            continue
        valid_t = s_num.dropna()
        if len(valid_t) < max(4, int(0.6 * len(df))):
            continue
        arr_t = valid_t.to_numpy(dtype=float)
        if float(np.min(arr_t)) < 0.0 or len(np.unique(arr_t)) < 4:
            continue
        time_col = c
        break

    if time_col is None:
        return empty

    s_time = _numeric_series(df, time_col)
    active = s_time.notna().to_numpy(dtype=bool) & (s_time.fillna(-1.0).to_numpy(dtype=float) >= 0.0) & ev_valid_best
    if int(active.sum()) < 4 or int(ev_arr_best[active].sum()) < 1:
        return empty

    cand_groups: list[tuple[int, int, str]] = []
    for idx_c, c in enumerate(cols):
        if c in {time_col, event_col} or _UNIT_COL_HINT_RE.match(c) or _ROW_INDEX_COL_RE.match(c) or c.casefold() in {'inst', 'institution'}:
            continue
        cleaned = pd.Series([_clean_stratum_value(v) for v in df[c].tolist()], dtype=object)
        vc = cleaned[active & (cleaned != '')].value_counts()
        if 2 <= len(vc) <= 6 and int((vc >= 2).sum()) >= 2:
            # Skip float continuous covariates that happen to have few rows unless integer/string-like
            try:
                sn = _numeric_series(df, c).dropna()
                if len(sn) and not bool(np.all(np.isclose(sn.to_numpy(dtype=float), np.round(sn.to_numpy(dtype=float)), atol=1e-9))):
                    continue
            except ValueError:
                pass
            pref_rank = 0 if _SURVIVAL_GROUP_PREF_RE.match(c.strip()) else (1 if len(vc) == 2 else 2)
            cand_groups.append((pref_rank, idx_c, c))

    cand_groups.sort()
    n_act = int(active.sum())
    n_events = int(ev_arr_best[active].sum())
    return {
        'detected': True,
        'time_col': time_col,
        'event_col': event_col,
        'events': n_events,
        'censored': n_act - n_events,
        'group_cols': [c for _, _, c in cand_groups],
    }


def _crossed_factor_stats(df: pd.DataFrame, col_a: str, col_b: str) -> tuple[bool, int]:
    """Return (is_crossed, max_cell_n) for two candidate factor columns."""
    sub = df[[col_a, col_b]].dropna()
    if len(sub) < 4:
        return False, 0
    a_s = sub[col_a].map(lambda v: _clean_stratum_value(v))
    b_s = sub[col_b].map(lambda v: _clean_stratum_value(v))
    valid = (a_s != '') & (b_s != '')
    if int(valid.sum()) < 4:
        return False, 0
    a_s, b_s = a_s[valid], b_s[valid]
    if a_s.nunique() > 15 or b_s.nunique() > 15:
        return False, 0
    b_per_a = b_s.groupby(a_s).nunique()
    a_per_b = a_s.groupby(b_s).nunique()
    is_crossed = bool((b_per_a >= 2).any() and (a_per_b >= 2).any())
    if not is_crossed:
        return False, 0
    cell_counts = pd.crosstab(a_s, b_s).to_numpy()
    max_cell_n = int(cell_counts.max()) if cell_counts.size else 0
    return True, max_cell_n


def describe_spreadsheet_structure(dataset: Dataset | None) -> dict[str, Any]:
    """Produce a plain-language + structured Step 1 Spreadsheet Overview for UI inspection."""
    if dataset is None or not hasattr(dataset, 'df') or dataset.df is None:
        return {'available': False}
    df = dataset.df
    cols = [str(c) for c in df.columns]
    rnums = list(getattr(dataset, 'row_numbers', range(2, len(df) + 2)))
    rep = detect_replicate_structure(df, rnums)
    surv = detect_survival_structure(df) if not rep['detected'] else {
        'detected': False, 'time_col': None, 'event_col': None, 'events': 0, 'censored': 0, 'group_cols': [],
    }
    plate = detect_plate_structure(df) if (not rep['detected'] and not surv['detected']) else {
        'detected': False, 'row_col': None, 'plate_cols': [], 'well_count': 0,
    }

    col_rows: list[dict[str, Any]] = []
    raw_num_entries: list[tuple[str, np.ndarray, int, list[str]]] = []
    cat_cols: list[str] = []
    id_cols: list[str] = []
    unit_cols: list[str] = []
    candidate_factor_cols: list[str] = []

    # First pass: classify columns into numeric candidates, unit/row IDs, and text categories
    col_order_entries: list[tuple[str, str, Any]] = []
    for c in cols:
        raw = df[c]
        non_blank = [
            v for v in raw.tolist()
            if v is not None and not (isinstance(v, float) and math.isnan(v))
            and str(v).strip() != '' and str(v).strip().casefold() not in MISSING_TOKENS
        ]
        missing_n = len(df) - len(non_blank)
        num_ok = False
        try:
            s_num = _numeric_series(df, c)
            valid_num = s_num.dropna()
            if len(valid_num) >= max(1, math.ceil(0.6 * max(1, len(non_blank)))):
                num_ok = True
        except ValueError:
            valid_num = pd.Series([], dtype=float)

        if num_ok and not (c == rep.get('time_col') and not pd.api.types.is_numeric_dtype(raw)):
            arr = valid_num.to_numpy(dtype=float)
            levels = list(dict.fromkeys(_clean_stratum_value(v) for v in non_blank if _clean_stratum_value(v)))
            all_int_like = bool(len(arr) and np.all(np.isclose(arr, np.round(arr), atol=1e-9)))
            if (_UNIT_COL_HINT_RE.match(c) or _ROW_INDEX_COL_RE.match(c)) and all_int_like:
                cat_cols.append(c)
                is_unique_id = len(non_blank) >= 2 and len(levels) == len(non_blank)
                if is_unique_id or _ROW_INDEX_COL_RE.match(c):
                    id_cols.append(c)
                    role_lbl = 'row ID'
                else:
                    unit_cols.append(c)
                    role_lbl = 'subject / unit ID'
                col_order_entries.append((c, 'cat', (role_lbl, len(non_blank), missing_n, levels)))
            else:
                raw_num_entries.append((c, arr, missing_n, levels))
                col_order_entries.append((c, 'num_cand', (arr, missing_n, levels)))
        else:
            cat_cols.append(c)
            levels = list(dict.fromkeys(_clean_stratum_value(v) for v in non_blank if _clean_stratum_value(v)))
            is_unique_id = len(non_blank) >= 2 and len(levels) == len(non_blank)
            is_id_like_cat = bool(re.search(r'(?:^|[\s_-])id$', c.strip(), re.I)) or (
                len(levels) > 16 and len(levels) >= 0.5 * max(1, len(non_blank))
            )
            if is_unique_id:
                id_cols.append(c)
                role_lbl = 'row ID'
            elif _UNIT_COL_HINT_RE.match(c) and len(levels) >= 2:
                unit_cols.append(c)
                role_lbl = 'subject / unit ID'
            elif is_id_like_cat:
                id_cols.append(c)
                role_lbl = 'identifier'
            else:
                if len(levels) >= 2:
                    candidate_factor_cols.append(c)
                role_lbl = 'categorical'
            col_order_entries.append((c, 'cat', (role_lbl, len(non_blank), missing_n, levels)))

    # Decide which discrete numeric columns (e.g. Dose=0.5/1/2, Diet=1..4, Time=0..21, group=1/2) act as factors,
    # always preserving at least one continuous numeric outcome column when numeric columns exist!
    discrete_num_factors: set[str] = set()
    surv_protected = {surv.get('time_col'), surv.get('event_col')} - {None}
    if surv.get('detected'):
        for gc in surv.get('group_cols') or []:
            if any(c == gc for c, _, _, _ in raw_num_entries):
                discrete_num_factors.add(gc)
    elif not rep['detected'] and len(raw_num_entries) >= 2:
        non_factor_nums = [
            c for c, arr, _m, lv in raw_num_entries
            if c not in surv_protected and not (_DISCRETE_FACTOR_NAME_RE.match(c) and 2 <= len(lv) <= 15 and len(arr) >= 2 * len(lv))
        ]
        # Only promote discrete numeric columns to factors if >= 1 continuous outcome remains
        if len(non_factor_nums) >= 1:
            for c, arr, _m, lv in raw_num_entries:
                if c not in surv_protected and _DISCRETE_FACTOR_NAME_RE.match(c) and 2 <= len(lv) <= 15 and len(arr) >= 2 * len(lv):
                    discrete_num_factors.add(c)

    numeric_cols: list[str] = []
    for c, tag, payload in col_order_entries:
        if tag == 'num_cand':
            arr, missing_n, levels = payload
            if c in discrete_num_factors:
                cat_cols.append(c)
                candidate_factor_cols.append(c)
                col_rows.append({
                    'name': c,
                    'column': c,
                    'kind': 'discrete factor',
                    'type': 'discrete numeric factor',
                    'non_missing': int(len(arr)),
                    'missing': int(missing_n),
                    'missing_count': int(missing_n),
                    'distinct': len(levels),
                    'distinct_count': len(levels),
                    'levels': levels[:12],
                    'sample_levels': levels[:8],
                    'preview': ', '.join(levels[:6]) + (' …' if len(levels) > 6 else ''),
                })
            else:
                numeric_cols.append(c)
                col_rows.append({
                    'name': c,
                    'column': c,
                    'kind': 'numeric',
                    'type': 'numeric',
                    'non_missing': int(len(arr)),
                    'missing': int(missing_n),
                    'missing_count': int(missing_n),
                    'mean': round(float(np.mean(arr)), 4) if len(arr) else None,
                    'sd': round(float(np.std(arr, ddof=1)), 4) if len(arr) > 1 else None,
                    'median': round(float(np.median(arr)), 4) if len(arr) else None,
                    'min': round(float(np.min(arr)), 4) if len(arr) else None,
                    'max': round(float(np.max(arr)), 4) if len(arr) else None,
                    'preview': f"{np.min(arr):.3g} – {np.max(arr):.3g} (mean {np.mean(arr):.3g})",
                })
        else:
            role_lbl, non_b_len, missing_n, levels = payload
            col_rows.append({
                'name': c,
                'column': c,
                'kind': role_lbl,
                'type': 'categorical / label',
                'non_missing': int(non_b_len),
                'missing': int(missing_n),
                'missing_count': int(missing_n),
                'distinct': len(levels),
                'distinct_count': len(levels),
                'levels': levels[:12],
                'sample_levels': levels[:8],
                'preview': ', '.join(levels[:6]) + (' …' if len(levels) > 6 else ''),
            })

    # Find best crossed two-factor pair (preferring replicated cells & group × time/dose pairs)
    non_unit_factors = [c for c in candidate_factor_cols if not _UNIT_COL_HINT_RE.match(c)]
    best_pair: tuple[str, str] | None = None
    best_score: tuple[int, int, int] = (-1, -1, -1)
    best_max_cell_n = 0
    search_pool = non_unit_factors if len(non_unit_factors) >= 2 else candidate_factor_cols
    for i in range(len(search_pool)):
        for j in range(i + 1, len(search_pool)):
            ca, cb = search_pool[i], search_pool[j]
            if _UNIT_COL_HINT_RE.match(ca) or _UNIT_COL_HINT_RE.match(cb):
                continue
            ok_cross, max_cn = _crossed_factor_stats(df, ca, cb)
            if not ok_cross:
                continue
            has_replicates = 1 if max_cn >= 2 else 0
            has_time_axis = 1 if (bool(_TIME_OR_DOSE_FACTOR_RE.match(ca)) ^ bool(_TIME_OR_DOSE_FACTOR_RE.match(cb))) else 0
            score = (has_replicates, has_time_axis, max_cn)
            if score > best_score:
                best_score = score
                best_pair = (ca, cb)
                best_max_cell_n = max_cn

    factor_cols = list(best_pair) if best_pair else (non_unit_factors or candidate_factor_cols)

    # Detect pre-aggregated contingency count tables (RowFactor × ColFactor -> Count) and raw 2-factor categorical tables
    contingency_info: dict[str, Any] = {'detected': False}
    if best_pair and best_max_cell_n == 1 and len(numeric_cols) == 1 and _COUNT_COLUMN_RE.match(numeric_cols[0].strip()):
        c_s = _numeric_series(df, numeric_cols[0]).dropna()
        if len(c_s) >= 4 and bool((c_s >= 0).all()) and bool(np.all(np.isclose(c_s, np.round(c_s), atol=1e-9))) and float(c_s.sum()) > 0:
            contingency_info = {
                'detected': True,
                'x_col': best_pair[0],
                'y_col': best_pair[1],
                'count_col': numeric_cols[0],
                'total_n': int(np.round(c_s).sum()),
            }
    elif not numeric_cols and len(non_unit_factors) >= 2:
        fa, fb = non_unit_factors[0], non_unit_factors[1]
        na, nb = int(df[fa].dropna().nunique()), int(df[fb].dropna().nunique())
        if 2 <= na <= 14 and 2 <= nb <= 14:
            contingency_info = {
                'detected': True,
                'x_col': fa,
                'y_col': fb,
                'count_col': None,
                'total_n': int(df[[fa, fb]].dropna().shape[0]),
            }

    # Detect layout archetype
    if rep['detected'] and rep['is_timecourse']:
        layout = 'wide_replicate_timecourse'
        grp_desc = ', '.join(f"{g} ({', '.join(g_cols)})" for g, g_cols in rep['groups'].items())
        t_desc = f"'{rep['time_col']}' ({', '.join(rep['time_labels'][:6])})" if rep['time_col'] else f"{len(df)} row timepoints"
        headline = (
            f"Wide replicate timecourse table ({len(df)} timepoints × {len(rep['replicate_cols'])} replicate columns): "
            f"Time/Row index {t_desc}; Replicate groups: {grp_desc}."
        )
    elif rep['detected']:
        layout = 'wide_replicate_groups'
        grp_desc = ', '.join(f"{g} (n={len(g_cols)})" for g, g_cols in rep['groups'].items())
        headline = f"Wide replicate table across {grp_desc}."
    elif surv['detected']:
        layout = 'survival_time_to_event'
        grp_part = f"; candidate stratification factor(s): {', '.join(surv['group_cols'][:3])}" if surv['group_cols'] else ''
        headline = (
            f"Right-censored survival / time-to-event table ({len(df)} rows): follow-up '{surv['time_col']}', "
            f"event indicator '{surv['event_col']}' ({surv['events']} events, {surv['censored']} right-censored){grp_part}."
        )
    elif plate['detected']:
        layout = 'plate_grid'
        headline = (
            f"Microplate reader grid ({len(plate['row_letters'])} rows {plate['row_letters'][0]}–{plate['row_letters'][-1]} × "
            f"{len(plate['plate_cols'])} columns; {plate['well_count']} wells)."
        )
    elif contingency_info.get('detected') and contingency_info.get('count_col'):
        layout = 'contingency_counts'
        headline = (
            f"Pre-aggregated contingency count table ({len(df)} cells, total N = {contingency_info['total_n']}): "
            f"'{contingency_info['x_col']}' × '{contingency_info['y_col']}' weighted by '{contingency_info['count_col']}'."
        )
    elif contingency_info.get('detected'):
        layout = 'contingency_raw'
        headline = (
            f"Two-way categorical contingency table ({len(df)} observations): "
            f"'{contingency_info['x_col']}' × '{contingency_info['y_col']}'."
        )
    elif best_pair and len(numeric_cols) >= 1:
        layout = 'long_two_factor'
        unit_note = f" (tracked across '{unit_cols[0]}')" if unit_cols else ''
        headline = (
            f"Tidy multi-factor table ({len(df)} rows{unit_note}): crossed factors {', '.join(best_pair)} "
            f"and numeric outcome(s) {', '.join(numeric_cols[:4])}."
        )
    elif len(factor_cols) == 1 and len(numeric_cols) >= 1 and _TIME_OR_DOSE_FACTOR_RE.match(factor_cols[0]) and unit_cols:
        layout = 'long_single_timecourse'
        headline = (
            f"Longitudinal / dose-response table ({len(df)} rows): '{numeric_cols[0]}' across '{factor_cols[0]}' "
            f"tracked per '{unit_cols[0]}'."
        )
    elif len(factor_cols) >= 1 and len(numeric_cols) >= 1:
        layout = 'long_grouped'
        unit_note = f" (with subject/unit '{unit_cols[0]}')" if unit_cols else ''
        headline = (
            f"Grouped table ({len(df)} rows{unit_note}): grouping factor '{factor_cols[0]}' "
            f"with {len(numeric_cols)} numeric measure(s) ({', '.join(numeric_cols[:5])})."
        )
    elif len(numeric_cols) >= 2 and not factor_cols:
        layout = 'wide_numeric'
        idx_lbl = id_cols[0] if id_cols else (unit_cols[0] if unit_cols else '')
        id_note = f" (indexed by '{idx_lbl}')" if idx_lbl else ''
        headline = (
            f"Side-by-side numeric columns ({len(df)} rows × {len(numeric_cols)} columns{id_note}: {', '.join(numeric_cols[:6])})."
        )
    else:
        layout = 'general_table'
        headline = f"Spreadsheet with {len(df)} rows and {len(cols)} columns ({', '.join(cols[:6])})."

    return {
        'available': True,
        'active_sheet': getattr(dataset, 'sheet', None),
        'row_count': int(len(df)),
        'column_count': len(cols),
        'detected_layout': layout,
        'headline': headline,
        'replicate_structure': rep,
        'survival_structure': surv,
        'plate_structure': plate,
        'contingency_structure': contingency_info,
        'numeric_columns': numeric_cols,
        'categorical_columns': cat_cols,
        'factor_columns': factor_cols,
        'unit_columns': unit_cols,
        'id_columns': id_cols,
        'max_two_factor_cell_n': best_max_cell_n,
        'columns_overview': col_rows,
    }


def sanitize_sheet_title(raw: str | None, existing: list[str], default_prefix: str = 'Working') -> str:
    """Create a clean, unique Excel-compatible worksheet name (<= 31 chars)."""
    cleaned = re.sub(r'[:\\/?*\[\]\x00-\x1f]+', '_', (raw or '').strip())
    cleaned = re.sub(r'\s+', '_', cleaned).strip("'_ ")
    if not cleaned:
        idx = len(existing) + 1
        cleaned = f'{idx}_{default_prefix}'
    cleaned = cleaned[:28]
    candidate = cleaned
    suffix = 2
    existing_set = set(existing)
    while candidate in existing_set:
        tag = f'_{suffix}'
        candidate = f'{cleaned[:31 - len(tag)]}{tag}'
        suffix += 1
    return candidate


def _coerce_series_types(values: list[Any]) -> list[Any]:
    """Parse numeric strings cleanly into floats/ints while preserving text labels and missing tokens."""
    cleaned_raw: list[Any] = []
    non_missing_strs: list[str] = []
    for v in values:
        if v is None:
            cleaned_raw.append(None)
            continue
        if isinstance(v, (int, float)) and not isinstance(v, bool):
            cleaned_raw.append(float(v) if math.isfinite(float(v)) else None)
            continue
        s = str(v).strip()
        if not s or s.casefold() in MISSING_TOKENS:
            cleaned_raw.append(None)
        else:
            cleaned_raw.append(s)
            non_missing_strs.append(s)

    if not non_missing_strs:
        return cleaned_raw

    parsed_nums: list[float] = []
    all_numeric = True
    for s in non_missing_strs:
        s_norm = s.replace(',', '')
        try:
            f = float(s_norm)
            if not math.isfinite(f):
                all_numeric = False
                break
            parsed_nums.append(f)
        except ValueError:
            all_numeric = False
            break

    if not all_numeric:
        return cleaned_raw

    out: list[Any] = []
    for item in cleaned_raw:
        if item is None:
            out.append(np.nan)
        elif isinstance(item, (int, float)):
            out.append(float(item))
        else:
            f = float(str(item).replace(',', ''))
            out.append(int(f) if f.is_integer() and abs(f) < 10**12 else f)
    return out


def _numeric_series(df: pd.DataFrame, col: str) -> pd.Series:
    if col not in df.columns:
        raise ValueError(f"Column '{col}' is not in the active sheet ({', '.join(map(str, df.columns))}).")
    raw = df[col]
    if pd.api.types.is_numeric_dtype(raw):
        return pd.to_numeric(raw, errors='coerce').astype(float)
    cleaned = raw.map(
        lambda v: np.nan
        if (v is None or (isinstance(v, float) and math.isnan(v)) or str(v).strip().casefold() in MISSING_TOKENS or not str(v).strip())
        else str(v).strip().replace(',', '')
    )
    out = pd.to_numeric(cleaned, errors='coerce').astype(float)
    if int(out.notna().sum()) == 0:
        raise ValueError(f"Column '{col}' does not contain numeric values.")
    return out


def apply_working_sheet_op(
    current_dataset: Dataset | None,
    spec: dict[str, Any],
    existing_sheets: list[str] | None = None,
) -> tuple[str, pd.DataFrame, str]:
    """Execute one deterministic table-shaping step and return (sheet_name, new_df, summary_text)."""
    op = spec.get('op')
    if op not in SUPPORTED_OPS:
        raise ValueError(f'Unsupported working sheet operation: {op!r}.')

    existing = list(existing_sheets or (getattr(current_dataset, 'sheets', []) if current_dataset else []))
    sheet_name = sanitize_sheet_title(spec.get('sheet_name'), existing, default_prefix=op)

    if op == 'construct':
        cols_spec = spec.get('constructed_columns') or []
        if not isinstance(cols_spec, list) or not (1 <= len(cols_spec) <= MAX_CONSTRUCT_COLS):
            raise ValueError('Provide 1 to 64 columns in constructed_columns to build a working sheet.')
        col_dict: dict[str, list[Any]] = {}
        expected_len: int | None = None
        seen_names: set[str] = set()
        for idx, item in enumerate(cols_spec, 1):
            if not isinstance(item, dict):
                raise ValueError('Each constructed column must have a name and values list.')
            cname = str(item.get('name') or f'Column_{idx}').strip()[:120]
            if not cname or cname in seen_names:
                raise ValueError(f'Constructed column names must be non-empty and unique (duplicate or blank: {cname!r}).')
            vals = item.get('values')
            if not isinstance(vals, list) or not (2 <= len(vals) <= MAX_CONSTRUCT_ROWS):
                raise ValueError(f"Column '{cname}' must contain between 2 and {MAX_CONSTRUCT_ROWS} values.")
            if expected_len is None:
                expected_len = len(vals)
            elif len(vals) != expected_len:
                raise ValueError(
                    f"Constructed columns must have equal row counts: '{cname}' has {len(vals)} values, expected {expected_len}. "
                    "For unequal group sizes, build a tidy two-column table with 'Group' and 'Value' columns (or pad missing cells with '')."
                )
            seen_names.add(cname)
            col_dict[cname] = _coerce_series_types(vals)
        out_df = pd.DataFrame(col_dict)
        summary = f"Built intermediate working sheet '{sheet_name}' ({len(out_df)} rows × {len(out_df.columns)} columns: {', '.join(out_df.columns)})."
        return sheet_name, out_df, summary

    if current_dataset is None or not hasattr(current_dataset, 'df') or current_dataset.df is None:
        raise ValueError("No active data table is open yet. Use op='construct' to build a sheet from raw numbers first.")

    df = current_dataset.df.copy(deep=True)
    cols = [str(c) for c in df.columns]

    if op == 'melt_plate_grid':
        plate = detect_plate_structure(df)
        row_col = str(spec.get('group_col') or plate.get('row_col') or cols[0])
        if row_col not in cols:
            raise ValueError(f"Row-letter column '{row_col}' not found in active sheet.")
        val_cols = [str(c) for c in (spec.get('value_cols') or plate.get('plate_cols') or cols[1:]) if c != row_col]
        if len(val_cols) < 2:
            raise ValueError('melt_plate_grid requires at least 2 plate columns.')
        val_name = str(spec.get('value_name') or 'Value').strip() or 'Value'
        records_out: list[dict[str, Any]] = []
        for r_idx in range(len(df)):
            r_let = str(df[row_col].iloc[r_idx]).strip().upper()
            if not r_let:
                continue
            for c_name in val_cols:
                m_c = _PLATE_COL_NUM_RE.match(c_name.strip())
                col_num = int(m_c.group(1)) if m_c else c_name.strip()
                well_id = f"{r_let}{col_num:02d}" if isinstance(col_num, int) else f"{r_let}_{col_num}"
                raw_v = df[c_name].iloc[r_idx]
                coerced_v = _coerce_series_types([raw_v])[0]
                if coerced_v is not None and not (isinstance(coerced_v, float) and math.isnan(coerced_v)):
                    records_out.append({
                        'Well': well_id,
                        'Plate_Row': r_let,
                        'Plate_Col': col_num,
                        val_name: coerced_v,
                    })
        if len(records_out) < 2:
            raise ValueError('Plate grid reshaping produced fewer than 2 non-missing well values.')
        out_df = pd.DataFrame(records_out)
        summary = f"Reshaped microplate grid ({len(df)}×{len(val_cols)}) into tidy well sheet '{sheet_name}' ({len(out_df)} wells: Well, Plate_Row, Plate_Col, {val_name})."
        return sheet_name, out_df, summary

    if op == 'melt_wide_to_long':
        value_cols = [str(c) for c in (spec.get('value_cols') or spec.get('columns') or [])]
        id_cols = [str(c) for c in (spec.get('id_cols') or spec.get('id_vars') or [])]
        if not value_cols:
            # Default to all columns not in id_cols
            value_cols = [c for c in cols if c not in id_cols]
        missing_c = [c for c in (id_cols + value_cols) if c not in cols]
        if missing_c:
            raise ValueError(f"Columns not found in active sheet: {', '.join(missing_c)}. Available: {', '.join(cols)}.")
        if len(value_cols) < 2:
            raise ValueError('melt_wide_to_long requires at least 2 value_cols to stack into long format.')
        var_name = str(spec.get('var_name') or spec.get('group_name') or 'Group').strip() or 'Group'
        val_name = str(spec.get('value_name') or 'Value').strip() or 'Value'
        if var_name == val_name or var_name in id_cols or val_name in id_cols:
            raise ValueError('var_name, value_name, and id_cols must be distinct column names.')
        work = df.copy()
        if not id_cols:
            work.insert(0, 'Source_Row', list(current_dataset.row_numbers))
            eff_ids = ['Source_Row']
        else:
            eff_ids = id_cols
        melted = work.melt(id_vars=eff_ids, value_vars=value_cols, var_name=var_name, value_name=val_name)
        melted[val_name] = _coerce_series_types(melted[val_name].tolist())
        melted = melted.dropna(subset=[val_name]).reset_index(drop=True)
        if len(melted) < 2:
            raise ValueError('Reshaping produced fewer than 2 valid observations.')
        summary = (
            f"Reshaped {len(value_cols)} wide columns ({', '.join(value_cols)}) into tidy long sheet '{sheet_name}' "
            f"({len(melted)} rows; group column '{var_name}', outcome column '{val_name}')."
        )
        return sheet_name, melted, summary

    if op == 'reshape_replicates':
        rnums = list(map(int, current_dataset.row_numbers))
        rep = detect_replicate_structure(df, rnums)
        value_cols = [str(c) for c in (spec.get('value_cols') or [])]
        id_cols = [str(c) for c in (spec.get('id_cols') or ([spec['time_col']] if spec.get('time_col') else []))]
        if not value_cols:
            if rep['is_replicate_wide']:
                value_cols = list(rep['replicate_cols'])
            else:
                value_cols = [c for c in cols if c not in id_cols]
        if not id_cols and rep.get('time_col') and rep['time_col'] not in value_cols:
            id_cols = [rep['time_col']]

        missing_c = [c for c in (id_cols + value_cols) if c not in cols]
        if missing_c:
            raise ValueError(f"Columns not found in active sheet: {', '.join(missing_c)}. Available: {', '.join(cols)}.")
        if len(value_cols) < 2:
            raise ValueError('reshape_replicates requires at least 2 replicate columns.')

        # Map each replicate column to its biological group (explicit rename_columns map overrides prefix detection)
        explicit_map: dict[str, str] = {}
        for item in (spec.get('rename_columns') or []):
            if isinstance(item, dict) and item.get('old') and item.get('new'):
                explicit_map[str(item['old']).strip().casefold()] = str(item['new']).strip()

        col_to_group: dict[str, str] = {}
        for vc in value_cols:
            if vc.casefold() in explicit_map:
                col_to_group[vc] = explicit_map[vc.casefold()]
            else:
                pref = extract_replicate_prefix(vc)
                col_to_group[vc] = pref if pref else vc

        time_col_out = str(spec.get('var_name') or 'Timepoint').strip() or 'Timepoint'
        val_name = str(spec.get('value_name') or 'Value').strip() or 'Value'
        group_col_out = str(spec.get('group_col') or 'Group').strip() or 'Group'
        subj_col_out = 'Subject_ID'
        for reserved in (time_col_out, val_name, group_col_out):
            if reserved == subj_col_out:
                subj_col_out = 'Replicate_Subject'

        has_time = len(df) > 1 or bool(id_cols)
        time_vals: list[str] = []
        if id_cols:
            raw_t = df[id_cols[0]].tolist()
            for idx, v in enumerate(raw_t):
                fb = f"A{rnums[idx]}" if idx < len(rnums) else f"T{idx + 1}"
                time_vals.append(_clean_stratum_value(v, fallback=fb))
        else:
            time_vals = [f"A{r}" for r in rnums]

        records: list[dict[str, Any]] = []
        parsed_cols = {vc: _numeric_series(df, vc).tolist() for vc in value_cols}
        for row_idx in range(len(df)):
            t_lbl = time_vals[row_idx]
            for vc in value_cols:
                v_num = parsed_cols[vc][row_idx]
                if v_num is None or (isinstance(v_num, float) and math.isnan(v_num)):
                    continue
                rec: dict[str, Any] = {}
                if has_time:
                    rec[time_col_out] = t_lbl
                rec[group_col_out] = col_to_group[vc]
                rec[subj_col_out] = vc
                rec[val_name] = float(v_num)
                records.append(rec)

        if len(records) < 2:
            raise ValueError('Reshaping replicates produced fewer than 2 finite numeric observations.')
        out_df = pd.DataFrame(records)

        # Optional one-step control normalization inside reshape_replicates
        norm_formula = str(spec.get('formula') or '').strip()
        ref_grp_req = str(spec.get('ref_group') or '').strip()
        norm_desc = ''
        if norm_formula or ref_grp_req:
            eff_formula = norm_formula or 'pct_of_group_mean'
            avail_groups = list(dict.fromkeys(out_df[group_col_out].astype(str).tolist()))
            ref_grp = ref_grp_req
            if not ref_grp:
                ref_grp = rep.get('suggested_ref_group') if rep.get('suggested_ref_group') in avail_groups else avail_groups[0]
            else:
                matches = [g for g in avail_groups if g.casefold() == ref_grp.casefold()]
                if matches:
                    ref_grp = matches[0]
            if ref_grp in avail_groups:
                norm_col = str(spec.get('new_column') or f'Pct_of_{ref_grp}_Mean').strip()
                vals_s = out_df[val_name].astype(float)
                grp_s = out_df[group_col_out].astype(str)
                if eff_formula == 'pct_of_baseline_group_mean' and has_time:
                    first_tp = str(out_df[time_col_out].iloc[0])
                    base_vals = vals_s[(grp_s == ref_grp) & (out_df[time_col_out].astype(str) == first_tp)].dropna()
                    denom = float(base_vals.mean()) if len(base_vals) else float(vals_s[grp_s == ref_grp].mean())
                    if denom != 0 and math.isfinite(denom):
                        out_df[norm_col] = 100.0 * vals_s / denom
                        norm_desc = f" + '{norm_col}' (100 * {val_name} / {ref_grp} baseline {first_tp} mean [{denom:.4g}])"
                elif eff_formula == 'pct_of_timepoint_group_mean' and has_time:
                    tp_means = out_df.loc[grp_s == ref_grp].groupby(time_col_out)[val_name].mean().to_dict()
                    denoms = out_df[time_col_out].map(lambda t: tp_means.get(t, np.nan)).astype(float)
                    out_df[norm_col] = np.where((denoms != 0) & np.isfinite(denoms), 100.0 * vals_s / denoms, np.nan)
                    norm_desc = f" + '{norm_col}' (100 * {val_name} / timepoint-matched {ref_grp} mean)"
                else:
                    ref_mean = float(vals_s[grp_s == ref_grp].mean())
                    if ref_mean != 0 and math.isfinite(ref_mean):
                        mult = 1.0 if eff_formula == 'fold_of_group_mean' else 100.0
                        if eff_formula == 'fold_of_group_mean' and not spec.get('new_column'):
                            norm_col = f'Fold_of_{ref_grp}_Mean'
                        out_df[norm_col] = mult * vals_s / ref_mean
                        norm_desc = f" + '{norm_col}' ({'100 * ' if mult == 100.0 else ''}{val_name} / {ref_grp} mean [{ref_mean:.4g}])"

        grp_counts = out_df.groupby(group_col_out, sort=False)[subj_col_out].nunique().to_dict()
        grp_summary = ', '.join(f"{k} (N={v})" for k, v in grp_counts.items())
        tp_summary = f" across {out_df[time_col_out].nunique()} timepoints ({', '.join(map(str, pd.unique(out_df[time_col_out])[:6]))})" if has_time else ''
        summary = (
            f"Reshaped wide replicates into '{sheet_name}' ({len(out_df)} observations: {grp_summary}{tp_summary}{norm_desc})."
        )
        return sheet_name, out_df, summary

    if op == 'derive_group':
        src_col = str(spec.get('col_a') or spec.get('group_col') or '').strip()
        if not src_col or src_col not in cols:
            raise ValueError(f"derive_group requires col_a naming an existing label/subject column (available: {', '.join(cols)}).")
        new_col = str(spec.get('new_column') or 'Group').strip() or 'Group'
        explicit_map = {}
        for item in (spec.get('rename_columns') or []):
            if isinstance(item, dict) and item.get('old') and item.get('new'):
                explicit_map[str(item['old']).strip().casefold()] = str(item['new']).strip()
        out_df = df.copy()

        def _map_lbl(v: Any) -> str | None:
            s = _clean_stratum_value(v)
            if not s:
                return None
            if s.casefold() in explicit_map:
                return explicit_map[s.casefold()]
            for old_k, new_v in explicit_map.items():
                if s.casefold().startswith(old_k):
                    return new_v
            pref = extract_replicate_prefix(s)
            return pref if pref else s

        out_df[new_col] = [ _map_lbl(v) for v in df[src_col].tolist() ]
        distinct_g = list(dict.fromkeys(x for x in out_df[new_col].tolist() if x))
        summary = f"Derived group column '{new_col}' ({', '.join(distinct_g[:8])}) from '{src_col}' in working sheet '{sheet_name}'."
        return sheet_name, out_df, summary

    if op == 'assign_groups':
        new_col = str(spec.get('new_column') or 'Group').strip() or 'Group'
        ranges = spec.get('group_ranges') or []
        if not isinstance(ranges, list) or not ranges:
            raise ValueError('Provide group_ranges (1-based source row start_row/end_row and label) for assign_groups.')
        row_nums = list(map(int, current_dataset.row_numbers))
        row_to_label: dict[int, str] = {}
        for item in ranges:
            if not isinstance(item, dict):
                raise ValueError('Invalid group_ranges entry.')
            lbl = str(item.get('label') or '').strip()
            s_row = item.get('start_row')
            e_row = item.get('end_row')
            if not lbl or not isinstance(s_row, int) or not isinstance(e_row, int) or s_row > e_row:
                raise ValueError('Each group_ranges item requires a non-empty label and integer start_row <= end_row.')
            for r in range(s_row, e_row + 1):
                row_to_label[r] = lbl
        out_df = df.copy()
        out_df[new_col] = [row_to_label.get(r, None) for r in row_nums]
        assigned_n = int(out_df[new_col].notna().sum())
        if assigned_n == 0:
            raise ValueError(
                f"None of the specified row numbers matched the active sheet's row numbers ({row_nums[0]}..{row_nums[-1]})."
            )
        summary = f"Added group column '{new_col}' across {assigned_n} rows in working sheet '{sheet_name}'."
        return sheet_name, out_df, summary

    if op == 'compute_column':
        new_col = str(spec.get('new_column') or '').strip()
        formula = str(spec.get('formula') or '').strip()
        if not new_col:
            raise ValueError('Specify new_column for compute_column.')
        if formula not in SUPPORTED_FORMULAS:
            raise ValueError(f'Unsupported formula {formula!r}. Supported: {", ".join(sorted(SUPPORTED_FORMULAS))}.')
        out_df = df.copy()
        if formula == 'mean_cols':
            vcols = [str(c) for c in (spec.get('value_cols') or [])]
            if len(vcols) < 2:
                raise ValueError('mean_cols requires at least 2 columns in value_cols.')
            mat = pd.concat([_numeric_series(df, c) for c in vcols], axis=1)
            out_df[new_col] = mat.mean(axis=1, skipna=True)
            desc = f"row-wise mean of ({', '.join(vcols)})"
        else:
            col_a = str(spec.get('col_a') or '').strip()
            if not col_a:
                raise ValueError(f"Formula '{formula}' requires col_a.")
            sa = _numeric_series(df, col_a)
            if formula in {'diff', 'sum', 'ratio', 'pct_change', 'pct_of_col'}:
                col_b = str(spec.get('col_b') or '').strip()
                if not col_b:
                    raise ValueError(f"Formula '{formula}' requires col_b.")
                sb = _numeric_series(df, col_b)
                if formula == 'diff':
                    out_df[new_col] = sa - sb
                    desc = f"{col_a} - {col_b}"
                elif formula == 'sum':
                    out_df[new_col] = sa + sb
                    desc = f"{col_a} + {col_b}"
                elif formula == 'ratio':
                    out_df[new_col] = np.where(sb != 0, sa / sb, np.nan)
                    desc = f"{col_a} / {col_b}"
                elif formula == 'pct_change':
                    out_df[new_col] = np.where(sb != 0, 100.0 * (sa - sb) / sb, np.nan)
                    desc = f"100 * ({col_a} - {col_b}) / {col_b}"
                else:
                    out_df[new_col] = np.where(sb != 0, 100.0 * sa / sb, np.nan)
                    desc = f"100 * {col_a} / {col_b}"
            elif formula in {'pct_of_group_mean', 'fold_of_group_mean', 'pow2_neg_ddct', 'ddct_fold_change', 'pct_of_baseline_group_mean', 'pct_of_timepoint_group_mean'}:
                gcol = str(spec.get('group_col') or '').strip()
                ref_grp = str(spec.get('ref_group') or spec.get('control_group') or '').strip()
                if not gcol or gcol not in cols or not ref_grp:
                    raise ValueError(f"Formula '{formula}' requires group_col and ref_group.")
                gseries = df[gcol].astype(str).str.strip()
                avail_unique = list(dict.fromkeys(str(x).strip() for x in df[gcol].dropna().tolist()))
                ci_match = [g for g in avail_unique if g.casefold() == ref_grp.casefold()]
                if ci_match:
                    ref_grp = ci_match[0]
                if formula in {'pow2_neg_ddct', 'ddct_fold_change'}:
                    col_b_hk = str(spec.get('col_b') or '').strip()
                    if col_b_hk:
                        if col_b_hk not in cols:
                            raise ValueError(f"Housekeeping column '{col_b_hk}' not found in '{sheet_name}'.")
                        dct_s = sa - _numeric_series(df, col_b_hk)
                        dct_lbl = f"({col_a} - {col_b_hk})"
                    else:
                        dct_s = sa
                        dct_lbl = col_a
                    ref_dct = dct_s[gseries == ref_grp].dropna()
                    if len(ref_dct) == 0:
                        raise ValueError(f"Reference group {ref_grp!r} has no valid Ct values in '{gcol}'.")
                    ref_mean = float(ref_dct.mean())
                    if not math.isfinite(ref_mean):
                        raise ValueError(f"Reference group {ref_grp!r} mean is non-finite.")
                    out_df[new_col] = np.power(2.0, -(dct_s - ref_mean))
                    desc = f"2^(-({dct_lbl} - mean({dct_lbl} in {gcol}={ref_grp!r} [{ref_mean:.4g}])))"
                elif formula in {'pct_of_baseline_group_mean', 'pct_of_timepoint_group_mean'}:
                    ref_vals = sa[gseries == ref_grp].dropna()
                    if len(ref_vals) == 0:
                        raise ValueError(f"Reference group {ref_grp!r} has no numeric values in '{gcol}' (available: {', '.join(avail_unique)}).")
                    tcol = str(spec.get('col_b') or '').strip()
                    if not tcol:
                        cand_t = [c for c in cols if c not in {col_a, gcol} and _TIME_COL_HINT_RE.match(c)]
                        tcol = cand_t[0] if cand_t else ''
                    if not tcol or tcol not in cols:
                        raise ValueError(f"Formula '{formula}' requires col_b naming the Timepoint column.")
                    tseries = df[tcol].map(lambda v: _clean_stratum_value(v))
                    if formula == 'pct_of_baseline_group_mean':
                        first_t = next((t for t in tseries.tolist() if t), '')
                        base_v = sa[(gseries == ref_grp) & (tseries == first_t)].dropna()
                        denom = float(base_v.mean()) if len(base_v) else float(ref_vals.mean())
                        if denom == 0 or not math.isfinite(denom):
                            raise ValueError(f"Reference group {ref_grp!r} baseline mean is 0; cannot normalize by zero.")
                        out_df[new_col] = 100.0 * sa / denom
                        desc = f"100 * {col_a} / mean({col_a} in {gcol}={ref_grp!r} at {tcol}={first_t!r} [{denom:.4g}])"
                    else:
                        tp_means: dict[str, float] = {}
                        for t_lvl in dict.fromkeys(t for t in tseries.tolist() if t):
                            tv = sa[(gseries == ref_grp) & (tseries == t_lvl)].dropna()
                            if len(tv):
                                tp_means[t_lvl] = float(tv.mean())
                        denoms = tseries.map(lambda t: tp_means.get(t, np.nan)).astype(float)
                        out_df[new_col] = np.where((denoms != 0) & np.isfinite(denoms), 100.0 * sa / denoms, np.nan)
                        desc = f"100 * {col_a} / timepoint-matched {ref_grp} mean across {tcol}"
                else:
                    ref_vals = sa[gseries == ref_grp].dropna()
                    if len(ref_vals) == 0:
                        raise ValueError(f"Reference group {ref_grp!r} has no numeric values in '{gcol}' (available: {', '.join(avail_unique)}).")
                    ref_mean = float(ref_vals.mean())
                    if ref_mean == 0 or not math.isfinite(ref_mean):
                        raise ValueError(f"Reference group {ref_grp!r} mean is 0; cannot normalize by zero.")
                    mult = 100.0 if formula == 'pct_of_group_mean' else 1.0
                    out_df[new_col] = mult * sa / ref_mean
                    desc = f"{'100 * ' if mult == 100.0 else ''}{col_a} / mean({col_a} in {gcol}={ref_grp!r} [{ref_mean:.4g}])"
            elif formula == 'log10':
                if int((sa > 0).sum()) == 0:
                    raise ValueError(f"Column '{col_a}' has no positive values for log10.")
                out_df[new_col] = np.where(sa > 0, np.log10(np.where(sa > 0, sa, np.nan)), np.nan)
                desc = f"log10({col_a})"
            elif formula == 'ln':
                if int((sa > 0).sum()) == 0:
                    raise ValueError(f"Column '{col_a}' has no positive values for ln.")
                out_df[new_col] = np.where(sa > 0, np.log(np.where(sa > 0, sa, np.nan)), np.nan)
                desc = f"ln({col_a})"
            elif formula == 'abs':
                out_df[new_col] = sa.abs()
                desc = f"abs({col_a})"
            elif formula == 'zscore':
                sd = float(sa.std(ddof=1))
                if not math.isfinite(sd) or sd <= 0:
                    raise ValueError(f"Column '{col_a}' has zero variance; cannot compute z-score.")
                out_df[new_col] = (sa - float(sa.mean())) / sd
                desc = f"zscore({col_a})"
            elif formula == 'linear_scale':
                factor = float(spec.get('scale_factor') if spec.get('scale_factor') is not None else 1.0)
                offset = float(spec.get('offset') if spec.get('offset') is not None else 0.0)
                out_df[new_col] = sa * factor + offset
                desc = f"{col_a} * {factor:g} + {offset:g}"
            else:
                raise ValueError(f'Unsupported formula {formula!r}.')

        summary = f"Created working sheet '{sheet_name}' with derived column '{new_col}' = {desc}."
        return sheet_name, out_df, summary

    if op == 'aggregate_units':
        gcols = [str(c) for c in (spec.get('group_cols') or [])]
        if not gcols or any(c not in cols for c in gcols):
            raise ValueError(f"Specify valid group_cols (e.g. ['Animal_ID', 'Group']) from: {', '.join(cols)}.")
        agg_stat = str(spec.get('agg_stat') or 'mean').strip()
        if agg_stat not in {'mean', 'median', 'count'}:
            raise ValueError("agg_stat must be 'mean', 'median', or 'count'.")
        if agg_stat == 'count':
            cnt_name = str(spec.get('new_column') or spec.get('value_name') or 'Count').strip() or 'Count'
            work_cat = df[gcols].dropna().copy()
            for gc in gcols:
                work_cat[gc] = work_cat[gc].map(lambda v: _clean_stratum_value(v))
                work_cat = work_cat[work_cat[gc] != '']
            out_df = work_cat.groupby(gcols, sort=False).size().reset_index(name=cnt_name)
            summary = (
                f"Built frequency working sheet '{sheet_name}' ({len(out_df)} cells tabulated across "
                f"{', '.join(gcols)} into '{cnt_name}', N = {int(out_df[cnt_name].sum())})."
            )
            return sheet_name, out_df, summary
        vcols = [str(c) for c in (spec.get('value_cols') or [])]
        if not vcols:
            vcols = [c for c in cols if c not in gcols and pd.api.types.is_numeric_dtype(df[c])]
        if not vcols or any(c not in cols for c in vcols):
            raise ValueError('Specify one or more numeric value_cols to aggregate.')
        work = df[gcols].copy()
        for vc in vcols:
            work[vc] = _numeric_series(df, vc)
        grouped = work.groupby(gcols, sort=False, dropna=False)
        agg_df = (grouped[vcols].median() if agg_stat == 'median' else grouped[vcols].mean()).reset_index()
        counts = grouped.size().reset_index(name='N_Subreplicates')
        out_df = pd.merge(agg_df, counts, on=gcols, how='left')
        summary = (
            f"Built unit-summary working sheet '{sheet_name}' ({len(out_df)} units pooled by {', '.join(gcols)} "
            f"using {agg_stat} across {', '.join(vcols)})."
        )
        return sheet_name, out_df, summary

    if op == 'rename_or_select':
        out_df = df.copy()
        vcols = [str(c) for c in (spec.get('value_cols') or [])]
        if vcols:
            missing_c = [c for c in vcols if c not in cols]
            if missing_c:
                raise ValueError(f"Columns not found: {', '.join(missing_c)}.")
            out_df = out_df[vcols].copy()
        renames = spec.get('rename_columns') or []
        rmap: dict[str, str] = {}
        for item in renames:
            if isinstance(item, dict) and item.get('old') and item.get('new'):
                old_c = str(item['old']).strip()
                new_c = str(item['new']).strip()[:120]
                if old_c not in out_df.columns:
                    raise ValueError(f"Cannot rename unknown column '{old_c}'.")
                rmap[old_c] = new_c
        if rmap:
            out_df = out_df.rename(columns=rmap)
        if not out_df.columns.is_unique:
            raise ValueError('Renamed columns must remain unique.')
        summary = f"Prepared cleaned working sheet '{sheet_name}' ({len(out_df)} rows × {len(out_df.columns)} columns)."
        return sheet_name, out_df, summary

    raise ValueError(f'Unhandled working sheet operation: {op!r}.')


def save_working_sheet_to_workbook(workbook_path: Path, sheet_name: str, df: pd.DataFrame) -> None:
    """Create or update a named worksheet inside `project_dir/derived/working_sheets.xlsx` atomically."""
    workbook_path.parent.mkdir(parents=True, exist_ok=True)
    if workbook_path.is_file():
        wb = openpyxl.load_workbook(workbook_path)
    else:
        wb = openpyxl.Workbook()
        # Remove default empty 'Sheet' when creating fresh
        if wb.sheetnames == ['Sheet']:
            wb.remove(wb['Sheet'])

    if sheet_name in wb.sheetnames:
        idx = wb.sheetnames.index(sheet_name)
        wb.remove(wb[sheet_name])
        ws = wb.create_sheet(title=sheet_name, index=idx)
    else:
        ws = wb.create_sheet(title=sheet_name)

    ws.append([str(c) for c in df.columns])
    for row in df.itertuples(index=False, name=None):
        clean_row = []
        for val in row:
            if val is None or (isinstance(val, (float, np.floating)) and not math.isfinite(float(val))):
                clean_row.append(None)
            elif hasattr(val, 'item'):
                clean_row.append(val.item())
            else:
                clean_row.append(val)
        ws.append(clean_row)

    tmp = workbook_path.with_suffix('.xlsx.tmp')
    wb.save(tmp)
    tmp.replace(workbook_path)


def load_working_sheet_dataset(
    source_path: str | Path,
    source_hash: str,
    workbook_path: Path,
    sheet_name: str,
    combined_sheets: list[str],
    warnings: list[str] | None = None,
) -> Dataset:
    """Load a working sheet from `working_sheets.xlsx` while keeping immutable `source_path` & `source_hash`."""
    temp_ds = load_dataset(workbook_path, sheet=sheet_name, header_row=0)
    merged_warnings = list(warnings or [])
    note = f"Viewing intermediate working sheet '{sheet_name}' (raw source remains preserved and read-only)."
    if note not in merged_warnings:
        merged_warnings.insert(0, note)
    return Dataset(
        df=temp_ds.df,
        source_path=str(source_path),
        source_hash=source_hash,
        sheet=sheet_name,
        sheets=list(combined_sheets),
        header_row=0,
        row_numbers=temp_ds.row_numbers,
        warnings=merged_warnings,
    )


def build_multi_tab_export_xlsx(session: Any) -> bytes:
    """Export raw source sheet(s) + all intermediate working sheets + Stat_Results + Audit_Provenance as .xlsx."""
    wb = openpyxl.Workbook()
    wb.remove(wb.active)

    def _write_df(title: str, frame: pd.DataFrame) -> None:
        safe_t = sanitize_sheet_title(title, wb.sheetnames)
        ws = wb.create_sheet(title=safe_t)
        ws.append([str(c) for c in frame.columns])
        for row in frame.itertuples(index=False, name=None):
            out_r = []
            for v in row:
                if v is None or (isinstance(v, (float, np.floating)) and not math.isfinite(float(v))):
                    out_r.append(None)
                elif hasattr(v, 'item'):
                    out_r.append(v.item())
                else:
                    out_r.append(v)
            ws.append(out_r)

    ds = getattr(session, 'dataset', None)
    if ds is not None and getattr(ds, 'source_path', None):
        src_path = Path(ds.source_path)
        if src_path.is_file() and src_path.suffix.lower() in {'.xlsx', '.xlsm', '.xls', '.ods'}:
            native = list_sheets(src_path)
            if src_path.suffix.lower() in {'.xlsx', '.xlsm'}:
                from .scrubber import inspect_ooxml_workbook
                hidden = set(inspect_ooxml_workbook(src_path).get('hidden_sheets') or ())
                native = [s for s in native if s not in hidden]
            for sname in native[:16]:
                try:
                    nds = load_dataset(src_path, sheet=sname)
                    _write_df(sname, nds.df)
                except Exception:
                    continue
        elif src_path.is_file() and src_path.suffix.lower() in {'.csv', '.tsv', '.txt'}:
            try:
                nds = load_dataset(src_path)
                _write_df('0_Raw_Source', nds.df)
            except Exception:
                pass

    # Derived working sheets
    if getattr(session, 'project_dir', None):
        wpath = Path(session.project_dir) / WORKING_WORKBOOK_REL
        if wpath.is_file():
            for wname in list_sheets(wpath):
                try:
                    wds = load_dataset(wpath, sheet=wname)
                    _write_df(wname, wds.df)
                except Exception:
                    continue

    # Statistical results tab
    res = getattr(session, 'result', None)
    if isinstance(res, dict):
        ws_res = wb.create_sheet(title=sanitize_sheet_title('Stat_Results', wb.sheetnames))
        ws_res.append(['Method', str(res.get('method', ''))])
        ws_res.append(['Summary', str(res.get('summary', ''))])
        ws_res.append([])
        for tbl in res.get('tables') or []:
            if not isinstance(tbl, dict):
                continue
            ws_res.append([str(tbl.get('title', 'Table'))])
            tcols = [str(c) for c in (tbl.get('columns') or [])]
            if tcols:
                ws_res.append(tcols)
                for r in tbl.get('rows') or []:
                    if isinstance(r, dict):
                        ws_res.append([r.get(c) for c in tcols])
            ws_res.append([])
        if res.get('warnings'):
            ws_res.append(['Methodological Notes & Disclosures'])
            for w in res['warnings']:
                ws_res.append([str(w)])

    # Provenance tab
    ws_prov = wb.create_sheet(title=sanitize_sheet_title('Audit_Provenance', wb.sheetnames))
    ws_prov.append(['Step', 'Sheet Name', 'Operation', 'Summary'])
    for idx, entry in enumerate(session.context.get('working_sheets') or [], 1):
        if isinstance(entry, dict):
            ws_prov.append([
                idx,
                str(entry.get('sheet_name', '')),
                str(entry.get('op', '')),
                str(entry.get('summary', '')),
            ])
    if ds is not None:
        ws_prov.append([])
        ws_prov.append(['Source SHA-256', str(getattr(ds, 'source_hash', ''))])
        ws_prov.append(['Active Sheet', str(getattr(ds, 'sheet', ''))])

    if not wb.sheetnames:
        ws_empty = wb.create_sheet(title='Empty')
        ws_empty.append(['Note'])
        ws_empty.append(['No data loaded yet.'])

    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


_GSHEET_URL_RE = re.compile(
    r'^https://docs\.google\.com/spreadsheets/d/([A-Za-z0-9_-]{15,120})(?:/[^\s#?]*)?(?:\?([^\s#]*))?(?:#([^\s]*))?$'
)


def parse_google_sheets_url(url: str) -> tuple[str, str | None]:
    """Validate a `docs.google.com/spreadsheets/d/<ID>` link strictly (preventing SSRF) and extract (sheet_id, gid)."""
    cleaned = (url or '').strip()
    m = _GSHEET_URL_RE.match(cleaned)
    if not m:
        raise ValueError(
            'Enter a valid Google Sheets URL starting with https://docs.google.com/spreadsheets/d/<ID> '
            '(make sure sharing is set to "Anyone with the link can view").'
        )
    spreadsheet_id = m.group(1)
    gid: str | None = None
    for part in (m.group(2), m.group(3)):
        if part:
            qs = urllib.parse.parse_qs(part)
            if 'gid' in qs and qs['gid']:
                cand = qs['gid'][0].strip()
                if re.fullmatch(r'\d{1,15}', cand):
                    gid = cand
                    break
    return spreadsheet_id, gid


def fetch_google_sheet_xlsx(url: str, max_bytes: int = 16 * 1024 * 1024, timeout: float = 20.0) -> tuple[bytes, str | None]:
    """Download a shared Google Sheet strictly from `https://docs.google.com/spreadsheets/d/<ID>/export?format=xlsx`."""
    spreadsheet_id, gid = parse_google_sheets_url(url)
    export_url = f'https://docs.google.com/spreadsheets/d/{spreadsheet_id}/export?format=xlsx'
    req = urllib.request.Request(
        export_url,
        headers={
            'User-Agent': 'StatWeave-SheetImporter/1.0',
            'Accept': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        },
        method='GET',
    )

    class _StrictGoogleRedirectHandler(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, req_obj, fp, code, msg, headers, newurl):
            parsed = urllib.parse.urlsplit(newurl)
            if parsed.scheme != 'https' or not (
                parsed.hostname == 'docs.google.com'
                or (parsed.hostname and parsed.hostname.endswith('.googleusercontent.com'))
            ):
                raise ValueError(
                    'Google Sheet appears to require sign-in. In Google Sheets, click Share -> "Anyone with the link" (Viewer), '
                    'or copy and paste the cells directly.'
                )
            return super().redirect_request(req_obj, fp, code, msg, headers, newurl)

    opener = urllib.request.build_opener(_StrictGoogleRedirectHandler)
    try:
        with opener.open(req, timeout=timeout) as resp:
            ctype = (resp.headers.get('Content-Type') or '').lower()
            if 'text/html' in ctype:
                raise ValueError(
                    'This Google Sheet is private. In Google Sheets, click Share -> "Anyone with the link" (Viewer), '
                    'or copy and paste the cells directly into StatWeave.'
                )
            raw = resp.read(max_bytes + 1)
    except ValueError:
        raise
    except urllib.error.HTTPError as exc:
        if exc.code in {401, 403, 404}:
            raise ValueError(
                'Could not access that Google Sheet (HTTP '
                f'{exc.code}). Set Share -> "Anyone with the link" (Viewer), or paste the cells directly.'
            ) from None
        raise ValueError(f'Google Sheets download failed (HTTP {exc.code}).') from None
    except Exception as exc:
        raise ValueError(f'Could not reach Google Sheets ({type(exc).__name__}). Paste the cells or upload .xlsx instead.') from None

    if len(raw) > max_bytes:
        raise ValueError('The Google Sheet exceeds the maximum supported workbook upload size.')
    if not raw.startswith(b'PK\x03\x04'):
        raise ValueError(
            'Google Sheets did not return an .xlsx workbook (check that "Anyone with the link" viewing is enabled).'
        )
    return raw, gid
