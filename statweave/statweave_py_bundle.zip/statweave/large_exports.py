"""Compact reproducible exports for disk-backed queries, with explicit source inclusion."""
from datetime import datetime
from pathlib import Path
import csv
import json
import os
import shutil
import sys
import uuid
import zipfile

from .scrubber import escape_csv_rows, sanitize_source_filename


def export_large_bundle(session,request=None):
    from .session import clean,sha256,versions
    from .figures import make_figure,export_figure,figure_caption
    from .storage import require_space, MIB
    request=request or {};session._assert_integrity(full=True)
    if not session.result:raise ValueError('Run a large-table query before export.')
    if request.get('path') and not getattr(session,'allow_host_paths',True):
        raise ValueError('Custom host export paths are disabled in this session.')
    parent=Path(request.get('path') or session.project_dir/'exports').expanduser().resolve()
    source=Path(session.dataset.source_path);include=bool(request.get('include_source',False))
    if source.is_symlink():raise ValueError('Refusing to export a symlinked source file.')
    require_space(parent, 64 * MIB + (2 * source.stat().st_size if include else 0), 'export the figures and analysis record')
    parent.mkdir(parents=True,exist_ok=True)
    stem_name=f'large-table-{datetime.now():%Y%m%d-%H%M%S}-{uuid.uuid4().hex[:4]}'
    folder=parent/stem_name
    stage=parent/f'.{stem_name}.tmp'
    archive=folder.with_suffix('.zip')
    temp_archive=parent/f'.{stem_name}.zip.tmp'
    stage.mkdir(parents=True,exist_ok=False)
    style={**session.style,**request.get('style',{})}
    formats=['pdf','svg','png']
    if request.get('style',{}).get('format') in ('tif','tiff') or request.get('format') in ('tif','tiff'):formats.append('tiff')
    try:
        figure=make_figure(session.dataset,session.result,session.plan,style)
        for fmt in formats:export_figure(figure,stage/f'figure.{fmt}',dpi=style.get('dpi',600))
        caption=figure_caption(session.dataset,session.result,session.plan,style)
        (stage/'caption.txt').write_text(caption+'\n',encoding='utf-8')
        for index,table in enumerate(session.result.get('tables',[]),1):
            name=''.join(c.lower() if c.isalnum() else '-' for c in table['title']).strip('-')
            with (stage/f'{index}-{name}.csv').open('w',encoding='utf-8',newline='') as handle:
                writer=csv.DictWriter(handle,fieldnames=table['columns'],extrasaction='ignore');writer.writeheader()
                writer.writerows(escape_csv_rows(table['rows'],table['columns']))
        clean_source_name=sanitize_source_filename(source.name)['sanitized_name']
        source_reference=clean_source_name
        if include:
            (stage/'source').mkdir();shutil.copy2(source,stage/'source'/clean_source_name)
            source_reference=str(Path('source')/clean_source_name)
        specification={'app_version':versions()['StatWeave'],'environment':versions(),'input_type':'large_table',
            'source_reference':source_reference,'source_sha256':session.dataset.source_hash,'raw_source_included':include,
            'source_size_bytes':source.stat().st_size,'cache_identity_at_export':session.dataset.cache_identity(),
            'plan':session.plan,'style':style,'result':session.result,
            'source_policy':'Original remains preserved in its project; provide --source when reproducing elsewhere.' if not include else 'Exact original source is included in source/.',
            'result_policy':'Returned record/group/scatter limits are explicit in accounting; aggregates use all selected finite values.'}
        (stage/'analysis.json').write_text(json.dumps(clean(specification),indent=2,ensure_ascii=False),encoding='utf-8')
        (stage/'metadata.json').write_text(json.dumps(clean(session.dataset.metadata()),indent=2,ensure_ascii=False),encoding='utf-8')
        (stage/'processing-steps.json').write_text(json.dumps(clean(session.result.get('processing_steps',[])),indent=2),encoding='utf-8')
        (stage/'methods.txt').write_text(session.result['summary']+'\n\n'+caption+'\n\n'+specification['source_policy']+'\n',encoding='utf-8')
        (stage/'reproduce.py').write_text(REPRODUCE_LARGE,encoding='utf-8')
        code=stage/'reproduction-source/statweave';code.mkdir(parents=True)
        source_root=Path(__file__).parent
        if getattr(sys,'frozen',False):source_root=Path(sys._MEIPASS)/'reproduction-source/statweave'
        for name in ['__init__.py','scrubber.py','abf_lite.py','ap_ahp.py','data.py','curves.py','large_table.py','large_figures.py','figures.py']:
            shutil.copy2(source_root/name,code/name)
        pinned='\n'.join(f'{key}=={value}' for key,value in versions().items() if key in ('numpy','pandas','scipy','matplotlib','duckdb','defusedxml') and value!='not installed')
        (stage/'requirements.txt').write_text(pinned+'\n',encoding='utf-8')
        (stage/'START_HERE.txt').write_text('This export contains the exact query, returned results, numerical/figure source and pinned requirements.\n'
            'Install requirements in a Python environment, then run reproduce.py.\n'
            'If the original source is not included, supply: python reproduce.py --source /path/to/original.csv\n'
            'A new derived local DuckDB cache is built on first reproduction; the raw source is never modified.\n'
            'Large originals are excluded by default to avoid automatic multi-gigabyte copies. Ask export with source to include one.\n',encoding='utf-8')
        shutil.copy2(session.project_dir/'history.jsonl',stage/'history.jsonl')
        manifest={str(path.relative_to(stage)):sha256(path) for path in sorted(stage.rglob('*')) if path.is_file()}
        (stage/'SHA256.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
        with temp_archive.open('xb') as raw_zip:
            with zipfile.ZipFile(raw_zip,'w',compression=zipfile.ZIP_DEFLATED) as handle:
                for path in sorted(stage.rglob('*')):
                    if path.is_file():handle.write(path,str(Path(folder.name)/path.relative_to(stage)))
            raw_zip.flush();os.fsync(raw_zip.fileno())
        os.replace(stage,folder)
        os.replace(temp_archive,archive)
    except BaseException:
        shutil.rmtree(stage,ignore_errors=True)
        temp_archive.unlink(missing_ok=True)
        raise
    try:
        session._event('large_table_export',{'directory':str(folder),'formats':formats,'plan':session.plan,'style':style,
            'source_sha256':session.dataset.source_hash,'raw_source_included':include,'cache_identity':session.dataset.cache_identity()})
        session.save()
    except BaseException:
        shutil.rmtree(folder,ignore_errors=True)
        archive.unlink(missing_ok=True)
        raise
    return {'folder':str(folder),'archive':str(archive),'figure':str(folder/'figure.png'),
            'input_type':'large_table','raw_source_included':include}


REPRODUCE_LARGE='''"""Rebuild a derived cache and reproduce the saved query without an AI model."""
from pathlib import Path
import argparse,hashlib,json,sys
root=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'reproduction-source'))
from statweave.large_table import LargeTable
from statweave.figures import make_figure,export_figure
parser=argparse.ArgumentParser();parser.add_argument('--source');args=parser.parse_args()
spec=json.loads((root/'analysis.json').read_text())
source=Path(args.source or spec['source_reference']).expanduser()
if not source.is_absolute():source=root/source
h=hashlib.sha256()
with source.open('rb') as handle:
    for chunk in iter(lambda:handle.read(1024*1024),b''):h.update(chunk)
if h.hexdigest()!=spec['source_sha256']:
    raise ValueError('Original source changed')
cache=root/'reproduced-cache/data.duckdb'
data=LargeTable(source,cache,source_hash=spec['source_sha256'],create=not cache.exists())
result=data.execute_plan(spec['plan'])
(root/'reproduced-results.json').write_text(json.dumps(result,indent=2,ensure_ascii=False))
if result!=spec['result']:
    raise ValueError('Recomputed results differ from the recorded result; inspect reproduced-results.json before using the figure')
figure=make_figure(data,result,spec['plan'],spec['style'])
for extension in ['pdf','svg','png']:
    export_figure(figure,root/('reproduced-figure.'+extension),dpi=spec['style'].get('dpi',600))
print('Reproduced saved query and figure in',root)
'''
