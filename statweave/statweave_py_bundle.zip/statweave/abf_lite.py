"""Pure-Python, zero-C-extension ABF1/ABF2 (.abf) and Axon Text (.atf) reader.

Designed to run identically in local CPython, cloud FastAPI workers, and browser
Pyodide WebAssembly without requiring `neo` or `pyabf`. Raw samples are never
filtered, smoothed, or mutated; integer ADC counts are converted to float64
physical units using exact Axon header calibration factors.
"""
from __future__ import annotations

import io
import math
from pathlib import Path
import re
import struct
from typing import Any

import numpy as np
import pandas as pd

BLOCKSIZE = 512
MAX_CHANNELS = 64
MAX_SWEEPS = 10_000
MAX_TABLE_ROWS = 100_000
MAX_TOTAL_SAMPLES = 12_000_000

_ABF2_SECTION_NAMES = (
    'ProtocolSection',
    'ADCSection',
    'DACSection',
    'EpochSection',
    'ADCPerDACSection',
    'EpochPerDACSection',
    'UserListSection',
    'StatsRegionSection',
    'MathSection',
    'StringsSection',
    'DataSection',
    'TagSection',
    'ScopeSection',
    'DeltaSection',
    'VoiceTagSection',
    'SynchArraySection',
    'AnnotationSection',
    'StatsSection',
)

_ABF2_PROTOCOL_FIELDS = (
    ('nOperationMode', 'h'),
    ('fADCSequenceInterval', 'f'),
    ('bEnableFileCompression', 'b'),
    ('sUnused1', '3s'),
    ('uFileCompressionRatio', 'I'),
    ('fSynchTimeUnit', 'f'),
    ('fSecondsPerRun', 'f'),
    ('lNumSamplesPerEpisode', 'i'),
    ('lPreTriggerSamples', 'i'),
    ('lEpisodesPerRun', 'i'),
    ('lRunsPerTrial', 'i'),
    ('lNumberOfTrials', 'i'),
    ('nAveragingMode', 'h'),
    ('nUndoRunCount', 'h'),
    ('nFirstEpisodeInRun', 'h'),
    ('fTriggerThreshold', 'f'),
    ('nTriggerSource', 'h'),
    ('nTriggerAction', 'h'),
    ('nTriggerPolarity', 'h'),
    ('fScopeOutputInterval', 'f'),
    ('fEpisodeStartToStart', 'f'),
    ('fRunStartToStart', 'f'),
    ('lAverageCount', 'i'),
    ('fTrialStartToStart', 'f'),
    ('nAutoTriggerStrategy', 'h'),
    ('fFirstRunDelayS', 'f'),
    ('nChannelStatsStrategy', 'h'),
    ('lSamplesPerTrace', 'i'),
    ('lStartDisplayNum', 'i'),
    ('lFinishDisplayNum', 'i'),
    ('nShowPNRawData', 'h'),
    ('fStatisticsPeriod', 'f'),
    ('lStatisticsMeasurements', 'i'),
    ('nStatisticsSaveStrategy', 'h'),
    ('fADCRange', 'f'),
    ('fDACRange', 'f'),
    ('lADCResolution', 'i'),
    ('lDACResolution', 'i'),
)

_ABF2_ADC_FIELDS = (
    ('nADCNum', 'h'),
    ('nTelegraphEnable', 'h'),
    ('nTelegraphInstrument', 'h'),
    ('fTelegraphAdditGain', 'f'),
    ('fTelegraphFilter', 'f'),
    ('fTelegraphMembraneCap', 'f'),
    ('nTelegraphMode', 'h'),
    ('fTelegraphAccessResistance', 'f'),
    ('nADCPtoLChannelMap', 'h'),
    ('nADCSamplingSeq', 'h'),
    ('fADCProgrammableGain', 'f'),
    ('fADCDisplayAmplification', 'f'),
    ('fADCDisplayOffset', 'f'),
    ('fInstrumentScaleFactor', 'f'),
    ('fInstrumentOffset', 'f'),
    ('fSignalGain', 'f'),
    ('fSignalOffset', 'f'),
    ('fSignalLowpassFilter', 'f'),
    ('fSignalHighpassFilter', 'f'),
    ('nLowpassFilterType', 'b'),
    ('nHighpassFilterType', 'b'),
    ('fPostProcessLowpassFilter', 'f'),
    ('nPostProcessLowpassFilterType', 'c'),
    ('bEnabledDuringPN', 'b'),
    ('nStatsChannelPolarity', 'h'),
    ('lADCChannelNameIndex', 'i'),
    ('lADCUnitsIndex', 'i'),
)


def _decode_axon_text(raw: bytes) -> str:
    cleaned = raw.split(b'\x00', 1)[0].replace(b'\xb5', b'u').replace(b'\xb0', b'deg')
    return cleaned.decode('utf-8', errors='replace').strip()


def _unpack_struct_table(buf: bytes, offset: int, fields: tuple[tuple[str, str], ...]) -> dict[str, Any]:
    out: dict[str, Any] = {}
    pos = offset
    for key, fmt in fields:
        le_fmt = '<' + fmt
        sz = struct.calcsize(le_fmt)
        if pos + sz > len(buf):
            raise ValueError(f'Truncated ABF2 structure while reading {key}.')
        vals = struct.unpack_from(le_fmt, buf, pos)
        out[key] = vals[0] if len(vals) == 1 else vals
        pos += sz
    return out


def parse_abf_bytes(raw: bytes, source_name: str = 'recording.abf') -> dict[str, Any]:
    """Parse ABF1 ('ABF ') or ABF2 ('ABF2') bytes into calibrated float64 sweeps."""
    size = len(raw)
    if size < 512 or raw[:4] not in (b'ABF ', b'ABF2'):
        raise ValueError(f'{source_name!r} is not a complete ABF1 or ABF2 binary recording header (upload a valid .abf file or compile multi-file .abf cohorts in ClampFlow).')

    sig = raw[:4]
    warnings: list[str] = []

    if sig == b'ABF2':
        if size < 76 + 18 * 16:
            raise ValueError('Truncated ABF2 section directory.')
        ver_bytes = struct.unpack_from('<4b', raw, 4)
        abf_version = round(ver_bytes[3] + 0.1 * ver_bytes[2] + 0.01 * ver_bytes[1] + 0.001 * ver_bytes[0], 4)
        data_format = struct.unpack_from('<H', raw, 30)[0]

        sections: dict[str, tuple[int, int, int]] = {}
        for idx, sname in enumerate(_ABF2_SECTION_NAMES):
            blk, width, count = struct.unpack_from('<IIq', raw, 76 + idx * 16)
            if count < 0:
                raise ValueError(f'ABF2 section {sname} has a negative entry count.')
            if count and (not width or blk * BLOCKSIZE + width * count > size):
                raise ValueError(f'ABF2 section {sname} extends past end of file ({size} bytes).')
            sections[sname] = (int(blk), int(width), int(count))

        n_channels = sections['ADCSection'][2]
        if not 1 <= n_channels <= MAX_CHANNELS:
            raise ValueError(f'Unsupported ABF2 channel count: {n_channels}.')
        if sections['SynchArraySection'][2] > MAX_SWEEPS:
            raise ValueError(f'ABF2 sweep count ({sections["SynchArraySection"][2]}) exceeds browser/workbench limit ({MAX_SWEEPS}).')

        proto_blk, _, proto_cnt = sections['ProtocolSection']
        if proto_cnt < 1:
            raise ValueError('ABF2 ProtocolSection is missing.')
        proto = _unpack_struct_table(raw, proto_blk * BLOCKSIZE, _ABF2_PROTOCOL_FIELDS)
        if proto.get('bEnableFileCompression'):
            raise ValueError('Compressed ABF2 recordings are not supported; re-save uncompressed in Clampfit.')

        mode = int(proto['nOperationMode'])
        if mode not in (1, 2, 3, 5):
            raise ValueError(f'Unsupported ABF2 acquisition mode {mode}.')
        seq_interval_us = float(proto['fADCSequenceInterval'])
        if seq_interval_us <= 0:
            raise ValueError('Invalid ABF2 sampling interval.')
        sampling_rate_hz = 1.0e6 / seq_interval_us
        synch_time_unit = float(proto['fSynchTimeUnit'])
        adc_range = float(proto['fADCRange'])
        adc_resolution = int(proto['lADCResolution']) or 1

        # Parse StringsSection indexed strings
        str_blk, str_bytes, _ = sections['StringsSection']
        strings: list[bytes] = [b'']
        if str_blk and str_bytes:
            big = raw[str_blk * BLOCKSIZE: str_blk * BLOCKSIZE + str_bytes]
            anchor = big.rfind(b'\x00\x00')
            indexed = big[anchor:] if anchor >= 0 else big
            strings = indexed.split(b'\x00')[1:] if b'\x00' in indexed else [indexed]

        adc_blk, adc_width, _ = sections['ADCSection']
        channels: list[dict[str, Any]] = []
        for ch_idx in range(n_channels):
            adc = _unpack_struct_table(raw, adc_blk * BLOCKSIZE + ch_idx * adc_width, _ABF2_ADC_FIELDS)
            name_i = int(adc['lADCChannelNameIndex'])
            unit_i = int(adc['lADCUnitsIndex'])
            ch_name = _decode_axon_text(strings[name_i]) if 0 <= name_i < len(strings) else ''
            ch_unit = _decode_axon_text(strings[unit_i]) if 0 <= unit_i < len(strings) else ''
            if not ch_name:
                ch_name = f'Ch{ch_idx}'
            if data_format == 0:
                gain = adc_range
                for denom_key in ('fInstrumentScaleFactor', 'fSignalGain', 'fADCProgrammableGain'):
                    denom = float(adc[denom_key]) or 1.0
                    gain /= denom
                gain /= float(adc_resolution)
                if adc['nTelegraphEnable']:
                    tg = float(adc['fTelegraphAdditGain']) or 1.0
                    gain /= tg
                offset = float(adc['fInstrumentOffset']) - float(adc['fSignalOffset'])
            else:
                gain, offset = 1.0, 0.0
            channels.append({
                'index': ch_idx,
                'adc_num': int(adc['nADCNum']),
                'name': ch_name,
                'unit': ch_unit or 'mV',
                'sampling_rate_hz': sampling_rate_hz,
                'gain': gain,
                'offset': offset,
            })

        data_blk, _, total_samples = sections['DataSection']
        head_offset = data_blk * BLOCKSIZE
        sync_blk, _, n_episodes = sections['SynchArraySection']
        sync_offset = sync_blk * BLOCKSIZE

    else:
        # ABF1 ('ABF ')
        if size < 2048:
            raise ValueError('Truncated ABF1 header (< 2048 bytes).')
        abf_version = round(float(struct.unpack_from('<f', raw, 4)[0]), 4)
        mode = int(struct.unpack_from('<h', raw, 8)[0])
        if mode not in (1, 2, 3, 5):
            raise ValueError(f'Unsupported ABF1 acquisition mode {mode}.')
        total_samples = int(struct.unpack_from('<i', raw, 10)[0])
        pts_ignored = int(struct.unpack_from('<h', raw, 14)[0])
        data_ptr = int(struct.unpack_from('<i', raw, 40)[0])
        sync_ptr = int(struct.unpack_from('<i', raw, 92)[0])
        n_episodes = int(struct.unpack_from('<i', raw, 96)[0])
        data_format = int(struct.unpack_from('<h', raw, 100)[0])
        n_channels = int(struct.unpack_from('<h', raw, 120)[0])
        sample_interval_us = float(struct.unpack_from('<f', raw, 122)[0])
        synch_time_unit = float(struct.unpack_from('<f', raw, 130)[0])
        adc_range = float(struct.unpack_from('<f', raw, 244)[0])
        adc_resolution = int(struct.unpack_from('<i', raw, 252)[0]) or 1

        if not 1 <= n_channels <= MAX_CHANNELS:
            raise ValueError(f'Unsupported ABF1 channel count: {n_channels}.')
        if not 0 <= n_episodes <= MAX_SWEEPS:
            raise ValueError(f'Unsupported ABF1 sweep count: {n_episodes}.')
        if sample_interval_us <= 0:
            raise ValueError('Invalid ABF1 sample interval.')

        sampling_rate_hz = 1.0 / (sample_interval_us * n_channels * 1.0e-6)
        itemsize_v1 = 2 if data_format == 0 else 4
        head_offset = data_ptr * BLOCKSIZE + pts_ignored * itemsize_v1
        sync_offset = sync_ptr * BLOCKSIZE

        seq_raw = struct.unpack_from('<16h', raw, 410)
        seq_ids = [int(c) for c in seq_raw if int(c) >= 0][:n_channels]
        if len(seq_ids) != n_channels or len(set(seq_ids)) != len(seq_ids):
            seq_ids = list(range(n_channels))

        ch_names_raw = [raw[442 + 10 * i: 442 + 10 * (i + 1)] for i in range(16)]
        ch_units_raw = [raw[602 + 8 * i: 602 + 8 * (i + 1)] for i in range(16)]
        prog_gain = struct.unpack_from('<16f', raw, 730)
        inst_scale = struct.unpack_from('<16f', raw, 922)
        inst_offset = struct.unpack_from('<16f', raw, 986)
        sig_gain = struct.unpack_from('<16f', raw, 1050)
        sig_offset = struct.unpack_from('<16f', raw, 1114)
        if size >= 4576 + 64:
            tele_enable = struct.unpack_from('<16h', raw, 4512)
            tele_gain = struct.unpack_from('<16f', raw, 4576)
        else:
            tele_enable = (0,) * 16
            tele_gain = (1.0,) * 16

        channels = []
        for idx_pos, cid in enumerate(seq_ids):
            cname = _decode_axon_text(ch_names_raw[cid]) or f'Ch{cid}'
            cunit = _decode_axon_text(ch_units_raw[cid]) or 'mV'
            if data_format == 0:
                gain = adc_range
                gain /= (float(inst_scale[cid]) or 1.0)
                gain /= (float(sig_gain[cid]) or 1.0)
                gain /= (float(prog_gain[cid]) or 1.0)
                gain /= float(adc_resolution)
                if int(tele_enable[cid]) == 1:
                    gain /= (float(tele_gain[cid]) or 1.0)
                offset = float(inst_offset[cid]) - float(sig_offset[cid])
            else:
                gain, offset = 1.0, 0.0
            channels.append({
                'index': idx_pos,
                'adc_num': cid,
                'name': cname,
                'unit': cunit,
                'sampling_rate_hz': sampling_rate_hz,
                'gain': gain,
                'offset': offset,
            })

    if data_format == 0:
        sig_dtype = np.dtype('<i2')
    elif data_format == 1:
        sig_dtype = np.dtype('<f4')
    else:
        raise ValueError(f'Unsupported ABF data format code: {data_format}.')

    if total_samples <= 0 or total_samples > MAX_TOTAL_SAMPLES:
        raise ValueError(f'ABF sample count ({total_samples}) is empty or exceeds workbench safety bound ({MAX_TOTAL_SAMPLES}).')

    if n_episodes > 0:
        if sync_offset < 0 or sync_offset + n_episodes * 8 > size:
            raise ValueError('ABF SynchArray extends beyond file bounds.')
        ep_arr = np.frombuffer(raw, dtype=[('offset', '<i4'), ('len', '<i4')], count=n_episodes, offset=sync_offset)
        ep_specs = [(int(ep_arr[i]['offset']), int(ep_arr[i]['len'])) for i in range(n_episodes)]
    else:
        ep_specs = [(0, int(total_samples))]

    sweeps: list[dict[str, Any]] = []
    pos = 0
    for sw_idx, (sw_off, sw_len_raw) in enumerate(ep_specs):
        sw_len = float(sw_len_raw)
        if synch_time_unit != 0.0 and mode == 1:
            sw_len = sw_len / synch_time_unit
        sw_len_int = int(round(sw_len))
        if sw_len_int < 0:
            raise ValueError(f'Negative sweep sample length in sweep {sw_idx + 1}.')
        n_frames = sw_len_int // n_channels
        byte_start = head_offset + pos * sig_dtype.itemsize
        byte_end = byte_start + n_frames * n_channels * sig_dtype.itemsize
        if byte_end > size:
            raise ValueError('ABF data block extends beyond file size; file may be truncated.')
        t_start_s = (float(sw_off) / sampling_rate_hz) if synch_time_unit == 0.0 else (float(sw_off) * synch_time_unit * 1e-6)
        raw_chunk = np.frombuffer(raw, dtype=sig_dtype, count=n_frames * n_channels, offset=byte_start).reshape((n_frames, n_channels))
        sweeps.append({
            'sweep_number': sw_idx + 1,
            'n_samples': n_frames,
            'start_s': t_start_s,
            'duration_s': n_frames / sampling_rate_hz,
            'raw_matrix': raw_chunk,
        })
        pos += sw_len_int

    return {
        'abf_version': abf_version,
        'mode': mode,
        'sampling_rate_hz': sampling_rate_hz,
        'channels': channels,
        'sweeps': sweeps,
        'warnings': warnings,
    }


def _clean_sheet_title(text: str, used: set[str]) -> str:
    base = re.sub(r'[^A-Za-z0-9_.-]+', '_', text.strip()).strip('_')[:28] or 'Channel'
    cand = base
    k = 2
    while cand in used:
        suffix = f'_{k}'
        cand = f'{base[:31 - len(suffix)]}{suffix}'
        k += 1
    used.add(cand)
    return cand


def abf_bytes_to_sheets(raw: bytes, source_name: str = 'recording.abf') -> tuple[dict[str, pd.DataFrame], list[str]]:
    """Convert binary .abf bytes into source-preserving channel sweep DataFrames (Time_ms + Sweep_1..K)."""
    parsed = parse_abf_bytes(raw, source_name=source_name)
    fs = float(parsed['sampling_rate_hz'])
    dt_ms = 1000.0 / fs
    sweeps = parsed['sweeps']
    channels = parsed['channels']
    notes = list(parsed['warnings'])

    # Prioritize voltage channels ('mV', 'V') first so default sheet is membrane potential Vm
    ordered_channels = sorted(
        channels,
        key=lambda c: (0 if str(c['unit']).lower() in {'mv', 'v'} else 1, int(c['index'])),
    )

    sheets: dict[str, pd.DataFrame] = {}
    used_names: set[str] = set()
    max_len = max((sw['n_samples'] for sw in sweeps), default=0)
    capped_len = min(max_len, MAX_TABLE_ROWS)
    if max_len > MAX_TABLE_ROWS:
        notes.append(
            f"Recording contains {max_len:,} samples per sweep at {fs:g} Hz; tabular view displays the first "
            f"{MAX_TABLE_ROWS:,} un-decimated samples ({MAX_TABLE_ROWS * dt_ms / 1000.0:.3g} s) to preserve exact raw sample fidelity."
        )

    time_ms = np.arange(capped_len, dtype=np.float64) * dt_ms
    for ch in ordered_channels:
        c_idx = int(ch['index'])
        gain = float(ch['gain'])
        offset = float(ch['offset'])
        unit = str(ch['unit'])
        cols: dict[str, Any] = {'Time_ms': time_ms}
        for sw in sweeps:
            n_sw = min(int(sw['n_samples']), capped_len)
            vals = sw['raw_matrix'][:n_sw, c_idx].astype(np.float64) * gain + offset
            if n_sw < capped_len:
                padded = np.full(capped_len, np.nan, dtype=np.float64)
                padded[:n_sw] = vals
                vals = padded
            col_name = f"Sweep_{sw['sweep_number']}" if len(sweeps) > 1 else f"{ch['name']}_{unit}"
            cols[col_name] = vals
        stitle = _clean_sheet_title(f"{ch['name']}_{unit}", used_names)
        sheets[stitle] = pd.DataFrame(cols)

    meta_rows = [
        {
            'Channel_Index': ch['index'],
            'ADC_Number': ch['adc_num'],
            'Channel_Name': ch['name'],
            'Unit': ch['unit'],
            'Sampling_Rate_Hz': fs,
            'Sweep_Count': len(sweeps),
            'Sweep_Samples': max_len,
            'Sweep_Duration_ms': round(max_len * dt_ms, 4),
            'ABF_Version': parsed['abf_version'],
        }
        for ch in ordered_channels
    ]
    sheets[_clean_sheet_title('ABF_Metadata', used_names)] = pd.DataFrame(meta_rows)
    return sheets, notes


def parse_atf_text(text: str, source_name: str = 'recording.atf') -> tuple[dict[str, pd.DataFrame], list[str]]:
    """Parse Clampfit / pCLAMP Axon Text File (.atf) into a clean waveform DataFrame."""
    lines = [ln.rstrip('\r\n') for ln in text.splitlines() if ln.strip()]
    if len(lines) < 3 or not lines[0].lstrip().startswith('ATF'):
        raise ValueError(f'{source_name!r} does not have a valid Axon Text File (ATF 1.0) header.')
    parts_1 = lines[1].strip().split()
    if len(parts_1) < 2:
        raise ValueError(f'{source_name!r} has a malformed ATF header count line.')
    n_opt_headers = int(parts_1[0])
    header_idx = 2 + n_opt_headers
    if header_idx >= len(lines):
        raise ValueError(f'{source_name!r} ended before the column header line.')

    notes: list[str] = []
    for opt_ln in lines[2:header_idx]:
        cleaned_opt = opt_ln.strip().strip('"')
        if cleaned_opt:
            notes.append(f'ATF metadata: {cleaned_opt[:140]}')

    table_txt = '\n'.join(lines[header_idx:])
    df = pd.read_csv(io.StringIO(table_txt), sep='\t', dtype=object)
    clean_cols: list[str] = []
    seen: dict[str, int] = {}
    for idx, raw_c in enumerate(df.columns):
        c = str(raw_c).strip().strip('"').strip()
        if not c:
            c = f'Column_{idx + 1}'
        # Normalize Time (s) / Time (ms) cleanly
        if re.match(r'^time\s*\(\s*s(?:ec)?\s*\)$', c, re.I):
            c = 'Time_s'
        elif re.match(r'^time\s*\(\s*ms\s*\)$', c, re.I):
            c = 'Time_ms'
        else:
            c = re.sub(r'\s+', '_', c).replace('#', '')
        cnt = seen.get(c, 0) + 1
        seen[c] = cnt
        clean_cols.append(c if cnt == 1 else f'{c}_{cnt}')
    df.columns = clean_cols

    # Convert numeric columns to float64 where all non-blank tokens parse cleanly
    for col in df.columns:
        num = pd.to_numeric(df[col], errors='coerce')
        if int(num.notna().sum()) > 0:
            df[col] = num

    if 'Time_s' in df.columns and 'Time_ms' not in df.columns:
        t_s = pd.to_numeric(df['Time_s'], errors='coerce')
        if t_s.notna().all():
            df.insert(0, 'Time_ms', t_s * 1000.0)
            df = df.drop(columns=['Time_s'])
            notes.append("Converted ATF 'Time (s)' column to 'Time_ms' (× 1000).")

    return {'ATF_Waveforms': df}, notes
