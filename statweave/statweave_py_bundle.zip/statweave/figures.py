"""Deterministic, data-faithful publication figures.

The figure layer does not select tests, remove outliers, alter source data, or
infer independent experimental units.  Captions are exported separately so the
figure's requested physical dimensions do not change with prose length.
"""
from __future__ import annotations

from pathlib import Path
from functools import wraps
from threading import RLock
import math
import textwrap
import hashlib

import matplotlib as mpl
from matplotlib.figure import Figure
from matplotlib.backends.backend_agg import FigureCanvasAgg
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.ticker import MaxNLocator
import numpy as np
import pandas as pd
from scipy import stats
from statsmodels.duration.survfunc import SurvfuncRight
from . import __version__
try:
    from .engine import MISSING_TOKENS, _sort_strata_naturally, _parse_survival_series, _km_loglog_ci
except ImportError:
    MISSING_TOKENS = frozenset({
        '', 'na', 'n/a', 'nan', 'null', 'none', 'nil', 'missing', 'nd', 'n.d.',
        'not determined', 'undetermined', 'not available', '-', '--', '—', '.',
    })

    def _sort_strata_naturally(levels: list[str]) -> list[str]:
        if len(levels) < 2:
            return list(levels)
        parsed: list[tuple[float, int, str]] = []
        for idx, lv in enumerate(levels):
            try:
                fv = float(str(lv).strip())
                if not math.isfinite(fv):
                    return list(levels)
                parsed.append((fv, idx, lv))
            except (TypeError, ValueError):
                return list(levels)
        return [item[2] for item in sorted(parsed, key=lambda t: (t[0], t[1]))]

# Matplotlib and its font cache are process-global, including the Qt preview.
# The desktop canvas uses this same reentrant lock before any rendering.
FIGURE_LOCK = RLock()


def _serialized_render(function):
    @wraps(function)
    def locked(*args, **kwargs):
        with FIGURE_LOCK:
            return function(*args, **kwargs)
    return locked


PRESETS = {
    'journal_single': {'width_mm': 89.0, 'height_mm': 75.0, 'font_size': 8.5},
    'journal_double': {'width_mm': 178.0, 'height_mm': 110.0, 'font_size': 9.0},
    'slide_16_9': {'width_mm': 220.0, 'height_mm': 135.0, 'font_size': 12.0},
    'poster': {'width_mm': 260.0, 'height_mm': 170.0, 'font_size': 14.0},
}

STYLE_KEYS = {
    'title', 'xlabel', 'ylabel', 'width_mm', 'height_mm', 'font_size',
    'palette', 'show_points', 'ci', 'format', 'dpi',
    'preset', 'error_bar', 'p_display', 'group_order', 'y_zero', 'ylim',
}
DEFAULT_STYLE = {
    'width_mm': 178.0, 'height_mm': 110.0, 'font_size': 9.0,
    'palette': 'teal', 'show_points': True, 'ci': True, 'dpi': 600,
    'error_bar': 'ci', 'p_display': 'none', 'y_zero': False,
}
PALETTES = {
    'teal': ['#1F6F5F', '#656B70', '#A7A7A0', '#30363A'],
    'blue': ['#306A97', '#656B70', '#A7A7A0', '#30363A'],
    'mono': ['#222222', '#666666', '#AAAAAA', '#444444'],
    'okabe_ito': ['#0072B2', '#D55E00', '#009E73', '#CC79A7', '#E69F00', '#56B4E9', '#000000'],
    'slate_coral': ['#2B4C7E', '#D95F43', '#4B8F8C', '#7A6C9D', '#C99A2E', '#56636A'],
    'viridis_cat': ['#440154', '#31688E', '#35B779', '#B5DE2B', '#21918C', '#482878'],
}
PLOT_TYPES = {
    'distribution', 'scatter', 'paired', 'line', 'timecourse', 'spaghetti',
    'grouped_bar', 'grouped_box', 'heatmap', 'survival',
    'box', 'violin', 'histogram', 'ecdf', 'bar', 'superplot',
}
ERROR_BAR_MODES = {'ci', 'sd', 'sem', 'iqr', 'none'}
P_DISPLAY_MODES = {'none', 'exact', 'stars_and_p'}
_SUPERPLOT_MARKERS = ('o', 's', '^', 'D', 'v', 'P', 'X', 'h')

RC = {
    'font.family': 'DejaVu Sans', 'font.size': 9,
    'text.color': '#111111', 'axes.labelcolor': '#303030',
    'axes.edgecolor': '#404040', 'axes.linewidth': 0.7,
    'xtick.color': '#404040', 'ytick.color': '#404040',
    'xtick.major.width': 0.6, 'ytick.major.width': 0.6,
    'xtick.major.size': 3, 'ytick.major.size': 3,
    'axes.spines.top': False, 'axes.spines.right': False,
    'axes.grid': False, 'figure.facecolor': 'white',
    'axes.facecolor': 'white', 'savefig.facecolor': 'white',
    'pdf.fonttype': 42, 'ps.fonttype': 42, 'svg.fonttype': 'none',
    'svg.hashsalt': 'StatWeave-v0.1',
}


def _style(plan, supplied=None):
    merged = dict(DEFAULT_STYLE)
    for incoming in (plan.get('style') or {}, supplied or {}):
        unknown = set(incoming) - STYLE_KEYS
        if unknown:
            raise ValueError('Unsupported figure setting: ' + ', '.join(sorted(unknown)))
        if incoming.get('preset') is not None:
            preset_name = incoming['preset']
            if not isinstance(preset_name, str) or preset_name not in PRESETS:
                raise ValueError('Unsupported figure preset. Choose journal_single, journal_double, slide_16_9, or poster.')
            for p_key, p_val in PRESETS[preset_name].items():
                if p_key not in incoming:
                    merged[p_key] = p_val
        merged.update(incoming)
        if 'error_bar' in incoming and incoming['error_bar'] is not None:
            eb = incoming['error_bar']
            if not isinstance(eb, str) or eb not in ERROR_BAR_MODES:
                raise ValueError('Choose error_bar from ci, sd, sem, iqr, or none.')
            if 'ci' not in incoming:
                merged['ci'] = (eb == 'ci')
        elif 'ci' in incoming:
            if not isinstance(incoming['ci'], bool):
                raise ValueError('ci must be true or false.')
            merged['error_bar'] = 'ci' if incoming['ci'] else 'none'

    for key in ('width_mm', 'height_mm', 'font_size', 'dpi'):
        try:
            merged[key] = float(merged[key])
        except (ValueError, TypeError):
            raise ValueError(f'{key} must be a number.') from None
        if not math.isfinite(merged[key]):
            raise ValueError(f'{key} must be finite.')
    if not 60 <= merged['width_mm'] <= 450 or not 40 <= merged['height_mm'] <= 450:
        raise ValueError('Figure width must be 60–450 mm and height 40–450 mm.')
    if not 8 <= merged['font_size'] <= 24:
        raise ValueError('Publication text must be 8–24 pt; increase the figure size for crowded labels.')
    if not 72 <= merged['dpi'] <= 1200:
        raise ValueError('Figure resolution must be 72–1200 dpi.')
    if merged['palette'] not in PALETTES:
        raise ValueError('Choose palette from: ' + ', '.join(sorted(PALETTES)) + '.')
    for key in ('show_points', 'ci', 'y_zero'):
        if not isinstance(merged[key], bool):
            raise ValueError(f'{key} must be true or false.')
    if merged.get('error_bar') not in ERROR_BAR_MODES:
        raise ValueError('Choose error_bar from ci, sd, sem, iqr, or none.')
    if merged.get('p_display') not in P_DISPLAY_MODES:
        raise ValueError('Choose p_display from none, exact, or stars_and_p.')
    if merged.get('group_order') is not None:
        go = merged['group_order']
        if not isinstance(go, (list, tuple)) or not go or len(go) > 18 or any(not isinstance(item, str) or not item.strip() for item in go):
            raise ValueError('group_order must be a non-empty list of group label strings (at most 18).')
        merged['group_order'] = [item.strip() for item in go]
    if merged.get('ylim') is not None:
        ylim = merged['ylim']
        if (
            not isinstance(ylim, (list, tuple))
            or len(ylim) != 2
            or any(isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(float(v)) for v in ylim)
            or float(ylim[0]) >= float(ylim[1])
        ):
            raise ValueError('ylim must be [ymin, ymax] with two finite numbers where ymin < ymax.')
        merged['ylim'] = [float(ylim[0]), float(ylim[1])]
    for key in ('title', 'xlabel', 'ylabel'):
        if key in merged and (not isinstance(merged[key], str) or len(merged[key]) > 600):
            raise ValueError(f'{key} must be text with at most 600 characters.')
    return merged


def _numbers(series):
    """Finite numeric values, treating standard missing tokens as NaN without modifying source."""
    def _clean(val):
        if val is None or isinstance(val, bool):
            return np.nan
        if isinstance(val, str):
            text = val.strip()
            if not text or text.casefold() in MISSING_TOKENS:
                return np.nan
        return val
    cleaned = series.map(_clean)
    return pd.to_numeric(cleaned, errors='coerce').replace([np.inf, -np.inf], np.nan)


def _categories(series):
    # Match engine category identity exactly, including blank-cell handling.
    # Excel may contain a mix of numeric, date, and text category cells.
    def convert(value):
        if value is None or (isinstance(value, str) and not value.strip()):
            return None
        try:
            if bool(pd.isna(value)):
                return None
        except (ValueError, TypeError):
            pass
        if isinstance(value, (float, np.floating)) and not np.isfinite(value):
            return None
        if hasattr(value, 'strftime'):
            try:
                if getattr(value, 'hour', 0) == 0 and getattr(value, 'minute', 0) == 0 and getattr(value, 'second', 0) == 0:
                    return value.strftime('%Y-%m-%d')
                return value.strftime('%Y-%m-%d %H:%M')
            except Exception:
                pass
        s = str(value).strip() if isinstance(value, str) else str(value)
        if len(s) >= 19 and s[10:] in (' 00:00:00', ' 00:00:00.0'):
            return s[:10]
        return s
    return series.map(convert)


def _selected_frame(dataset, result):
    frame = dataset.df.copy(deep=True)
    source_rows = getattr(dataset, 'row_numbers', list(range(2, len(frame) + 2)))
    # Describe has variable-specific missingness; only mask explicitly excluded rows.
    if result.get('method') == 'describe':
        excluded = {
            int(item['row']) for item in result.get('row_accounting', {}).get('excluded_rows', [])
            if isinstance(item, dict) and 'row' in item
        }
        if not excluded:
            excluded = {
                int(item['row']) for item in (result.get('plan') or {}).get('excluded_rows', [])
                if isinstance(item, dict) and 'row' in item
            }
        if excluded:
            frame = frame.loc[[int(row) not in excluded for row in source_rows]].copy()
    else:
        omitted = {
            int(item['row']) for item in result.get('row_accounting', {}).get('omitted_rows', [])
            if isinstance(item, dict) and 'row' in item
        }
        frame = frame.loc[[int(row) not in omitted for row in source_rows]].copy()
    return frame


def _column(frame, name):
    if not name or name not in frame.columns:
        raise ValueError(f'Choose an existing column; {name!r} was not found.')
    return name


def _numeric_columns(frame, plan):
    requested = plan.get('columns')
    if requested:
        return [_column(frame, name) for name in requested]
    if plan.get('y'):
        name = _column(frame, plan['y'])
        return [name] if _numbers(frame[name]).notna().any() else []
    excluded = {plan.get('subject'), plan.get('group'), plan.get('pool_by'), plan.get('count')}
    return [c for c in frame.columns if c not in excluded and _numbers(frame[c]).notna().any()]


def _apply_group_order(labels: list[str], group_order: list[str] | None) -> list[str]:
    if not group_order:
        return labels
    missing = [g for g in group_order if g not in labels]
    if missing:
        raise ValueError(f'Group(s) {missing} in group_order were not found in available groups {labels}.')
    seen = set(group_order)
    return list(group_order) + [g for g in labels if g not in seen]


def _groups(frame, plan, group_order: list[str] | None = None):
    """Return (labels, arrays, outcome label), preserving input or explicit category order."""
    y, group = plan.get('y'), plan.get('group')
    pool_by = plan.get('pool_by')
    pool_stat = plan.get('pool_stat', 'mean')
    if y and group:
        _column(frame, y); _column(frame, group)
        values = _numbers(frame[y])
        categories = _categories(frame[group])
        if pool_by:
            _column(frame, pool_by)
            units = _categories(frame[pool_by])
            good = values.notna() & categories.notna() & units.notna()
            work = pd.DataFrame({'y': values[good], 'group': categories[good], 'unit': units[good]})
            labels = _apply_group_order([str(v) for v in pd.unique(work['group'])], group_order)
            arrays = []
            for label in labels:
                sub = work.loc[work['group'] == label]
                unit_order = list(pd.unique(sub['unit']))
                agg = [
                    float(np.median(sub.loc[sub['unit'] == u, 'y'])) if pool_stat == 'median'
                    else float(np.mean(sub.loc[sub['unit'] == u, 'y']))
                    for u in unit_order
                ]
                arrays.append(np.asarray(agg, dtype=float))
            return labels, arrays, str(y)
        good = values.notna() & categories.notna()
        labels = _apply_group_order([str(v) for v in pd.unique(categories.loc[categories.notna()])], group_order)
        arrays = [values.loc[good & (categories == label)].to_numpy(dtype=float) for label in labels]
        return labels, arrays, str(y)
    columns = plan.get('columns')
    if not columns and plan.get('method') in ('ttest', 'paired_t', 'mannwhitney') and plan.get('x') and y:
        columns = [plan['x'], y]
    columns = columns or _numeric_columns(frame, plan)
    labels, arrays = [], []
    for name in columns:
        _column(frame, name)
        values = _numbers(frame[name]).dropna().to_numpy(dtype=float)
        if len(values):
            labels.append(str(name)); arrays.append(values)
    labels_ordered = _apply_group_order(labels, group_order)
    if labels_ordered != labels:
        by_label = dict(zip(labels, arrays))
        arrays = [by_label[label] for label in labels_ordered]
        labels = labels_ordered
    return labels, arrays, str(y or 'Value')


def _safe_label(text, width=22):
    return '\n'.join('\n'.join(textwrap.wrap(line, width=width, break_long_words=True, break_on_hyphens=False)) for line in str(text).split('\n'))


def _axes_style(ax, size):
    ax.tick_params(labelsize=max(8.0, size - 0.3))
    ax.xaxis.label.set_size(size)
    ax.yaxis.label.set_size(size)
    ax.title.set_size(size + 1.2)
    ax.title.set_weight('semibold')
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    if not isinstance(ax.yaxis.get_major_locator(), mpl.ticker.FixedLocator):
        ax.yaxis.set_major_locator(MaxNLocator(nbins=5))
    ax.margins(y=0.16)


def _apply_y_bounds(ax, style):
    if style.get('y_zero'):
        ymin, ymax = ax.get_ylim()
        ax.set_ylim(min(0.0, ymin), max(0.0, ymax))
    if style.get('ylim') is not None:
        ax.set_ylim(style['ylim'][0], style['ylim'][1])


def _mean_ci(values):
    mean = float(np.mean(values))
    if len(values) < 2:
        return mean, None
    se = float(stats.sem(values))
    error = float(stats.t.ppf(0.975, len(values) - 1) * se)
    return mean, error


def _summary_interval(values: np.ndarray, mode: str, allow_inferential: bool):
    """Return (center, yerr, description_tag) for a group's values."""
    if not len(values):
        return None, None, 'none'
    if mode == 'iqr':
        med = float(np.median(values))
        if len(values) < 2:
            return med, None, 'iqr'
        q25, q75 = np.percentile(values, [25, 75])
        return med, np.array([[max(0.0, med - float(q25))], [max(0.0, float(q75) - med)]]), 'iqr'
    mean = float(np.mean(values))
    if mode == 'sd':
        if len(values) < 2:
            return mean, None, 'sd'
        return mean, float(np.std(values, ddof=1)), 'sd'
    if mode == 'sem' and allow_inferential:
        if len(values) < 2:
            return mean, None, 'sem'
        return mean, float(stats.sem(values)), 'sem'
    if mode == 'ci' and allow_inferential:
        _, err = _mean_ci(values)
        return mean, err, 'ci'
    return mean, None, 'none'


def _format_p_label(p: float, mode: str, prefix: str = 'p') -> str:
    if p < 1e-4:
        p_text = f'{prefix} < 0.0001'
    elif p < 0.01:
        p_text = f'{prefix} = {p:.4f}'
    else:
        p_text = f'{prefix} = {p:.3g}'
    if mode == 'stars_and_p':
        stars = '****' if p < 1e-4 else '***' if p < 1e-3 else '**' if p < 1e-2 else '*' if p < 0.05 else 'ns'
        return f'{stars} ({p_text})'
    return p_text


def _extract_result_p(result: dict, variable: str | None = None) -> tuple[float | None, str]:
    tables = result.get('tables') or []
    method = result.get('method')
    if method == 'batch_compare' and variable:
        for tbl in tables:
            if tbl.get('title') == 'Batch comparisons':
                for row in tbl.get('rows') or []:
                    if row.get('variable') == variable:
                        p_holm = row.get('p_holm')
                        if isinstance(p_holm, (int, float)) and math.isfinite(p_holm):
                            return float(p_holm), 'Holm p'
                        p_raw = row.get('p_unadjusted')
                        if isinstance(p_raw, (int, float)) and math.isfinite(p_raw):
                            return float(p_raw), 'p'
    for tbl in tables:
        for row in tbl.get('rows') or []:
            if isinstance(row, dict) and 'p' in row and isinstance(row['p'], (int, float)) and math.isfinite(row['p']):
                prefix = 'Omnibus p' if method in {'anova', 'kruskal'} else 'p'
                return float(row['p']), prefix
    return None, 'p'


def _draw_p_bracket(ax, n_groups: int, result: dict, style: dict, variable: str | None = None):
    mode = style.get('p_display', 'none')
    if mode == 'none' or n_groups < 2:
        return
    p_val, prefix = _extract_result_p(result, variable=variable)
    if p_val is None:
        return
    ymin, ymax = ax.get_ylim()
    span = max(abs(ymax - ymin), 1e-9)
    y_base = ymax + 0.02 * span
    h = 0.035 * span
    x0, x1 = 0.0, float(n_groups - 1)
    if n_groups == 2:
        ax.plot([x0, x0, x1, x1], [y_base, y_base + h, y_base + h, y_base], color='#222222', lw=0.85, zorder=6)
    else:
        ax.plot([x0, x1], [y_base + h, y_base + h], color='#222222', lw=0.85, zorder=6)
    label = _format_p_label(p_val, mode, prefix=prefix)
    ax.text((x0 + x1) / 2.0, y_base + h + 0.015 * span, label,
            ha='center', va='bottom', fontsize=max(8.0, style['font_size'] - 0.5), color='#111111', zorder=6)
    if style.get('ylim') is None:
        ax.set_ylim(ymin, y_base + h + 0.16 * span)


def _point_offsets(count, variable, group):
    """Reproducible display offsets, independent of measured values.

    A display-only namespace separates these permutations from any data-generation
    random stream. Balanced offsets keep each group centered. Column and group
    names distinguish layouts without incorporating measurements or source hashes.
    This separates points visually; it is not a collision-free beeswarm.
    """
    if count < 0:
        raise ValueError('The number of displayed observations cannot be negative.')
    if count <= 1:
        return np.zeros(count, dtype=float)
    key = 'StatWeave display-only point offsets v1\x00' + str(variable) + '\x00' + str(group)
    seed = int.from_bytes(hashlib.sha256(key.encode('utf-8')).digest()[:16], 'big')
    display_rng = np.random.default_rng(seed)
    return display_rng.permutation(np.linspace(-0.16, 0.16, count))


def _interval_footer(used_tag: str, show_points: bool, design: str, pooled: bool = False) -> str:
    unit_word = 'unit summaries' if pooled else 'individual observations'
    if used_tag == 'ci':
        return f'Mean and 95% t confidence interval; {unit_word} shown' if show_points else 'Mean and 95% t confidence interval'
    if used_tag == 'sem':
        return f'Mean ± 1 SEM; {unit_word} shown' if show_points else 'Mean ± 1 SEM'
    if used_tag == 'sd':
        return f'Mean ± 1 SD; {unit_word} shown' if show_points else 'Mean ± 1 SD'
    if used_tag == 'iqr':
        return f'Median and interquartile range (Q1–Q3); {unit_word} shown' if show_points else 'Median and interquartile range (Q1–Q3)'
    if design != 'independent':
        return f'Mean and {unit_word}; independence not established'
    return f'Mean and {unit_word}'


def _distribution(ax, frame, plan, style, colors, plot, result=None, variable=None):
    labels, arrays, ylabel = _groups(frame, plan, group_order=style.get('group_order'))
    if not arrays or not any(len(values) for values in arrays):
        raise ValueError('No finite numeric values are available for this figure.')
    if len(arrays) > 12:
        raise ValueError('This figure has more than 12 groups. Select fewer columns or use separate figures to keep labels readable.')
    method = (result or {}).get('method', plan.get('method', 'describe'))
    allow_inferential = plan.get('design') == 'independent' and method not in {'mannwhitney', 'kruskal'}
    eb_mode = style.get('error_bar', 'ci' if style.get('ci', True) else 'none')
    used_tag = 'none'
    for index, (label, values) in enumerate(zip(labels, arrays)):
        color = colors[index % len(colors)]
        if not len(values):
            continue  # Keep its labeled n=0 group visible, with no invented mark.
        if plot == 'box':
            ax.boxplot([values], positions=[index], widths=0.48, patch_artist=True,
                       showfliers=not style['show_points'],
                       boxprops={'facecolor': color, 'alpha': 0.14, 'edgecolor': color, 'linewidth': 0.8},
                       medianprops={'color': '#111111', 'linewidth': 1.2},
                       whiskerprops={'color': color, 'linewidth': 0.8},
                       capprops={'color': color, 'linewidth': 0.8},
                       flierprops={'marker': 'o', 'markersize': 3, 'markerfacecolor': color, 'markeredgecolor': 'none'})
        if plot == 'violin' and len(values) > 1 and float(np.std(values)) > 0:
            violin = ax.violinplot([values], positions=[index], widths=0.65, showextrema=False)
            for body in violin['bodies']:
                body.set_facecolor(color); body.set_alpha(0.17); body.set_edgecolor(color); body.set_linewidth(0.7)
        if plot == 'violin':
            median = float(np.median(values))
            ax.plot([index - .10, index + .10], [median, median], color='#111111', lw=1.4, zorder=5)
        center, error, tag = _summary_interval(values, eb_mode, allow_inferential)
        if tag != 'none':
            used_tag = tag
        if plot == 'bar':
            bar_height = center if center is not None else float(np.mean(values))
            ax.bar(index, bar_height, width=0.56, color=color, alpha=0.18, edgecolor=color, linewidth=0.8)
        if style['show_points']:
            jitter = _point_offsets(len(values), ylabel, label)
            ax.scatter(index + jitter, values, s=16, color=color, alpha=0.66, edgecolors='none', zorder=3)
        if plot not in ('box', 'violin') and center is not None:
            if error is not None:
                ax.errorbar(index, center, yerr=error, fmt='_', markersize=15, markeredgewidth=1.7,
                            color='#111111', elinewidth=1.0, capsize=3, capthick=0.8, zorder=5)
            else:
                ax.plot([index - .12, index + .12], [center, center], color='#111111', lw=1.8, zorder=5)
    n_symbol = 'N' if plan.get('pool_by') else 'n'
    ax.set_xticks(range(len(labels)), [_safe_label(f'{label}\n({n_symbol} = {len(vals)})', 20) for label, vals in zip(labels, arrays)])
    ax.set_xlim(-0.6, len(labels) - 0.4)
    if plot == 'bar':
        ymin, ymax = ax.get_ylim()
        ax.set_ylim(min(0, ymin), max(0, ymax))
    _apply_y_bounds(ax, style)
    if result is not None:
        _draw_p_bracket(ax, len(labels), result, style, variable=variable or plan.get('y'))
    ax.set_ylabel(style.get('ylabel', _safe_label(ylabel, 34)))
    ax.set_xlabel(style.get('xlabel', _safe_label(str(plan.get('group') or ''), 50)))
    ax.set_title(_safe_label(style.get('title') or f'{ylabel} by {plan.get("group") or "column"}', 65), loc='left', pad=12)
    if plot == 'box':
        return 'Median, quartiles, 1.5×IQR whiskers; all observations retained'
    if plot == 'violin':
        return 'Kernel density and median; all observations retained'
    return _interval_footer(used_tag, style['show_points'], str(plan.get('design') or 'unknown'), pooled=bool(plan.get('pool_by')))


def _superplot(ax, frame, plan, style, colors, result=None, variable=None):
    y, group, unit_col = plan.get('y'), plan.get('group'), plan.get('pool_by')
    if not (y and group and unit_col):
        raise ValueError("Superplots require a numeric outcome ('y'), group column ('group'), and biological/cluster unit column ('pool_by').")
    for name in (y, group, unit_col):
        _column(frame, name)
    values = _numbers(frame[y])
    categories = _categories(frame[group])
    units = _categories(frame[unit_col])
    good = values.notna() & categories.notna() & units.notna()
    work = pd.DataFrame({'y': values[good], 'group': categories[good], 'unit': units[good]})
    if work.empty:
        raise ValueError('No complete observations with finite values, group, and unit ID are available for this superplot.')
    labels = _apply_group_order([str(v) for v in pd.unique(work['group'])], style.get('group_order'))
    if len(labels) > 12:
        raise ValueError('Superplots support at most 12 groups per panel.')
    pool_stat = plan.get('pool_stat', 'mean')
    method = (result or {}).get('method', plan.get('method', 'describe'))
    allow_inferential = plan.get('design') == 'independent' and method not in {'mannwhitney', 'kruskal'}
    eb_mode = style.get('error_bar', 'ci' if style.get('ci', True) else 'none')
    used_tag = 'none'
    tick_labels = []

    for index, label in enumerate(labels):
        color = colors[index % len(colors)]
        sub = work.loc[work['group'] == label]
        unit_names = list(pd.unique(sub['unit']))
        unit_summaries = []
        raw_count = len(sub)
        if style['show_points'] and raw_count:
            all_jitter = _point_offsets(raw_count, f'{y}::raw', label)
            cursor = 0
            for u_idx, u_name in enumerate(unit_names):
                u_vals = sub.loc[sub['unit'] == u_name, 'y'].to_numpy(dtype=float)
                u_jit = all_jitter[cursor:cursor + len(u_vals)]
                cursor += len(u_vals)
                marker = _SUPERPLOT_MARKERS[u_idx % len(_SUPERPLOT_MARKERS)]
                ax.scatter(index + u_jit, u_vals, s=16, marker=marker, color=color, alpha=0.32, edgecolors='none', zorder=2)
                u_stat = float(np.median(u_vals)) if pool_stat == 'median' else float(np.mean(u_vals))
                unit_summaries.append((u_idx, u_stat))
        else:
            for u_idx, u_name in enumerate(unit_names):
                u_vals = sub.loc[sub['unit'] == u_name, 'y'].to_numpy(dtype=float)
                u_stat = float(np.median(u_vals)) if pool_stat == 'median' else float(np.mean(u_vals))
                unit_summaries.append((u_idx, u_stat))

        unit_arr = np.asarray([val for _, val in unit_summaries], dtype=float)
        if len(unit_arr):
            u_offsets = np.linspace(-0.09, 0.09, len(unit_arr)) if len(unit_arr) > 1 else np.zeros(1)
            for (u_idx, u_val), dx in zip(unit_summaries, u_offsets):
                marker = _SUPERPLOT_MARKERS[u_idx % len(_SUPERPLOT_MARKERS)]
                ax.scatter([index + dx], [u_val], s=50, marker=marker, facecolor=color,
                           edgecolor='#111111', linewidth=0.9, alpha=0.94, zorder=4)
            center, error, tag = _summary_interval(unit_arr, eb_mode, allow_inferential)
            if tag != 'none':
                used_tag = tag
            if center is not None:
                if error is not None:
                    ax.errorbar(index, center, yerr=error, fmt='_', markersize=16, markeredgewidth=1.8,
                                color='#111111', elinewidth=1.1, capsize=3.5, capthick=0.9, zorder=5)
                else:
                    ax.plot([index - .13, index + .13], [center, center], color='#111111', lw=1.9, zorder=5)
        tick_labels.append(_safe_label(f'{label}\n(N = {len(unit_arr)}, n = {raw_count})', 22))

    ax.set_xticks(range(len(labels)), tick_labels)
    ax.set_xlim(-0.6, len(labels) - 0.4)
    _apply_y_bounds(ax, style)
    if result is not None:
        _draw_p_bracket(ax, len(labels), result, style, variable=variable or y)
    ax.set_ylabel(style.get('ylabel', _safe_label(str(y), 34)))
    ax.set_xlabel(style.get('xlabel', _safe_label(str(group), 50)))
    ax.set_title(_safe_label(style.get('title') or f'{y} by {group} ({unit_col} superplot)', 65), loc='left', pad=12)
    base = _interval_footer(used_tag, True, str(plan.get('design') or 'unknown'), pooled=True)
    return f'Superplot: translucent markers = raw observations (n), bold outlined markers = {unit_col} {pool_stat}s (N); {base}'


def _paired(ax, frame, plan, style, colors, result=None):
    subject, group, y = plan.get('subject'), plan.get('group'), plan.get('y')
    if subject and group and y:
        for name in (subject, group, y): _column(frame, name)
        work = frame[[subject, group, y]].copy()
        work[y] = _numbers(work[y])
        work[subject] = _categories(work[subject])
        work[group] = _categories(work[group])
        work = work.dropna(subset=[subject, group, y])
        if work.duplicated([subject, group]).any():
            raise ValueError('Paired figure needs one value per subject per condition; duplicate pairs must be resolved explicitly.')
        labels = _apply_group_order([str(v) for v in pd.unique(work[group])], style.get('group_order'))
        if len(labels) != 2:
            raise ValueError('Paired figures currently require exactly two conditions.')
        table = work.pivot(index=subject, columns=group, values=y).reindex(columns=labels).dropna()
        a, b = table[labels[0]].to_numpy(), table[labels[1]].to_numpy()
        ylabel = y
    else:
        columns = plan.get('columns') or [plan.get('x'), y]
        if len(columns) != 2 or not all(columns):
            raise ValueError('Choose two paired numeric columns, or identify subject, group, and outcome columns.')
        for name in columns: _column(frame, name)
        columns = _apply_group_order([str(c) for c in columns], style.get('group_order'))
        work = frame[columns].apply(_numbers).dropna()
        a, b = work[columns[0]].to_numpy(), work[columns[1]].to_numpy()
        labels, ylabel = columns, 'Value'
    if not len(a):
        raise ValueError('No complete observation pairs are available.')
    for before, after in zip(a, b):
        ax.plot([0, 1], [before, after], color='#8D8D88', alpha=0.56, lw=0.75, zorder=1)
    ax.scatter(np.zeros(len(a)), a, color=colors[0], s=21, edgecolors='white', linewidths=.35, zorder=3)
    ax.scatter(np.ones(len(b)), b, color=colors[1 % len(colors)], s=21, edgecolors='white', linewidths=.35, zorder=3)
    ax.set_xticks([0, 1], [_safe_label(str(label), 26) for label in labels])
    ax.set_xlim(-0.35, 1.35)
    _apply_y_bounds(ax, style)
    if result is not None:
        _draw_p_bracket(ax, 2, result, style)
    ax.set_ylabel(style.get('ylabel', _safe_label(ylabel, 35)))
    ax.set_xlabel(style.get('xlabel', ''))
    ax.set_title(_safe_label(style.get('title') or f'Paired observations · {len(a)} complete pairs', 62), loc='left', pad=12)
    return 'Lines connect the same unit; complete pairs only; no observations pruned'


def _scatter(ax, frame, result, plan, style, colors, line=False):
    x, y = _column(frame, plan.get('x')), _column(frame, plan.get('y'))
    values = pd.DataFrame({'x': _numbers(frame[x]), 'y': _numbers(frame[y])}).dropna()
    if not len(values): raise ValueError('No complete finite x/y observations are available.')
    if line:
        if values['x'].duplicated().any():
            raise ValueError('Several observations share x-values. Use a scatter figure; connecting these rows would imply an unsupported order.')
        values = values.sort_values('x', kind='stable')
        ax.plot(values.x, values.y, color=colors[0], marker='o', markersize=4, lw=1.3)
    else:
        ax.scatter(values.x, values.y, s=21, color=colors[0], edgecolor='white', linewidth=.35, alpha=.78)
        if result.get('method') == 'regression' and len(values) >= 3 and values.x.nunique() > 1:
            # Same one-predictor OLS estimator as the analysis engine; never fit
            # a line simply because a correlation happened to be requested.
            fit = stats.linregress(values.x, values.y)
            grid = np.linspace(values.x.min(), values.x.max(), 100)
            ax.plot(grid, fit.intercept + fit.slope * grid, color='#111111', lw=1.25)
            if style['ci'] and plan.get('design') == 'independent' and values.y.nunique() > 1:
                residual = values.y - (fit.intercept + fit.slope * values.x)
                sigma = math.sqrt(float(np.sum(residual**2)) / (len(values) - 2))
                sx = float(np.sum((values.x - values.x.mean())**2))
                half = stats.t.ppf(.975, len(values) - 2) * sigma * np.sqrt(1 / len(values) + (grid - values.x.mean())**2 / sx)
                center = fit.intercept + fit.slope * grid
                ax.fill_between(grid, center - half, center + half, color=colors[0], alpha=.12, linewidth=0)
    _apply_y_bounds(ax, style)
    ax.set_xlabel(style.get('xlabel', _safe_label(x, 50)))
    ax.set_ylabel(style.get('ylabel', _safe_label(y, 35)))
    ax.set_title(_safe_label(style.get('title') or f'{y} versus {x}', 62), loc='left', pad=12)
    return f'n = {len(values)} complete observations' + ('; ordinary least-squares fit' if result.get('method') == 'regression' and not line else '')


def _hist_or_ecdf(ax, frame, plan, style, colors, plot):
    labels, arrays, ylabel = _groups(frame, plan, group_order=style.get('group_order'))
    if not arrays: raise ValueError('No finite numeric values are available for this figure.')
    if len(arrays) > 6:
        raise ValueError('Select at most six distributions per figure to keep them readable.')
    all_values = np.concatenate(arrays)
    edges = np.histogram_bin_edges(all_values, bins='auto')
    if len(edges) > 101: edges = np.linspace(float(all_values.min()), float(all_values.max()), 101)
    for i, (label, values) in enumerate(zip(labels, arrays)):
        color = colors[i % len(colors)]
        if plot == 'ecdf':
            ordered = np.sort(values)
            ax.step(ordered, np.arange(1, len(values) + 1) / len(values), where='post', color=color,
                    lw=1.5, linestyle=['-', '--', ':', '-.'][i % 4], label=f'{label} (n = {len(values)})')
        else:
            ax.hist(values, bins=edges, histtype='step', color=color, lw=1.5,
                    linestyle=['-', '--', ':', '-.'][i % 4], label=f'{label} (n = {len(values)})')
    if len(arrays) > 1:
        ax.legend(frameon=False, fontsize=max(8, style['font_size'] - .3), loc='upper right')
    ax.set_xlabel(style.get('xlabel', _safe_label(ylabel, 50)))
    ax.set_ylabel(style.get('ylabel', 'Cumulative proportion' if plot == 'ecdf' else 'Count'))
    if plot == 'ecdf': ax.set_ylim(0, 1.06)
    else: ax.set_ylim(bottom=0)
    _apply_y_bounds(ax, style)
    ax.set_title(_safe_label(style.get('title') or f'{ylabel} distribution', 62), loc='left', pad=12)
    return 'Empirical cumulative distributions; no smoothing or exclusions' if plot == 'ecdf' else 'Shared data-derived bin boundaries; no observations pruned'


def _heatmap(ax, fig, frame, result, plan, style):
    is_mono = style.get('palette') == 'mono'
    if result.get('method') == 'chi2':
        x, y = _column(frame, plan.get('x')), _column(frame, plan.get('y'))
        if plan.get('count'):
            c_col = _column(frame, plan['count'])
            matrix = pd.crosstab(_categories(frame[x]), _categories(frame[y]), values=_numbers(frame[c_col]), aggfunc='sum', dropna=True).fillna(0.0)
        else:
            matrix = pd.crosstab(_categories(frame[x]), _categories(frame[y]), dropna=True)
        cmap = LinearSegmentedColormap.from_list('statweave_counts', ['#F7F7F7', '#222222'] if is_mono else ['#F3F5F2', '#1F6F5F'])
        low, high = 0, None
        footer, unit = 'Observed counts; missing required categories excluded as reported', 'Observed count'
    else:
        columns = plan.get('columns') or [c for c in frame if _numbers(frame[c]).notna().any() and c not in {plan.get('subject'), plan.get('group'), plan.get('pool_by')}]
        if len(columns) < 2: raise ValueError('A correlation heatmap needs at least two numeric columns.')
        matrix = frame[columns].apply(_numbers).corr(min_periods=2)
        cmap = LinearSegmentedColormap.from_list('statweave_corr', ['#555555', '#FAFAF8', '#111111'] if is_mono else ['#4E6482', '#FAFAF8', '#1F6F5F'])
        low, high = -1, 1
        footer, unit = 'Pearson correlation; pairwise complete observations; descriptive, no significance tests', 'Pearson r'
    if max(matrix.shape) > 14:
        raise ValueError('This matrix has more than 14 rows or columns. Select a smaller set to keep its labels readable.')
    cmap = cmap.with_extremes(bad='#D8D8D4')
    image = ax.imshow(np.ma.masked_invalid(matrix.to_numpy(dtype=float)), cmap=cmap, vmin=low, vmax=high, aspect='auto')
    ax.set_xticks(range(len(matrix.columns)), [_safe_label(c, 16) for c in matrix.columns], rotation=35, ha='right', rotation_mode='anchor')
    ax.set_yticks(range(len(matrix.index)), [_safe_label(c, 18) for c in matrix.index])
    ax.set_xlabel(style.get('xlabel', str(plan.get('y') or '')))
    ax.set_ylabel(style.get('ylabel', str(plan.get('x') or '')))
    ax.set_title(_safe_label(style.get('title') or ('Observed category counts' if result.get('method') == 'chi2' else 'Pairwise correlations'), 62), loc='left', pad=12)
    if max(matrix.shape) <= 7:
        mat_max = float(np.nanmax(matrix.to_numpy(dtype=float))) if matrix.size else 0.0
        for row in range(len(matrix.index)):
            for col in range(len(matrix.columns)):
                value = matrix.iloc[row, col]
                label = '—' if pd.isna(value) else (f'{value:.0f}' if result.get('method') == 'chi2' else f'{value:.2f}')
                light = pd.notna(value) and (abs(value) > .60 if result.get('method') != 'chi2' else (mat_max > 0 and value > mat_max * .60))
                ax.text(col, row, label, ha='center', va='center', fontsize=max(8, style['font_size'] - .2), color='white' if light else '#111111')
    colorbar = fig.colorbar(image, ax=ax, shrink=.82, pad=.03, fraction=.05)
    colorbar.set_label(unit, fontsize=style['font_size'])
    colorbar.ax.tick_params(labelsize=max(8, style['font_size'] - .3))
    return footer


def _categorical(ax, frame, plan, style, colors):
    name = plan.get('y') or plan.get('group') or str(frame.columns[0])
    _column(frame, name)
    counts = _categories(frame[name]).dropna().value_counts(sort=False)
    if len(counts) > 18:
        raise ValueError('This column has more than 18 categories. Select a different variable or use a results table.')
    ax.barh(np.arange(len(counts)), counts.to_numpy(), color=colors[0], alpha=.85, height=.6)
    ax.set_yticks(np.arange(len(counts)), [_safe_label(v, 25) for v in counts.index])
    ax.invert_yaxis(); ax.set_xlim(left=0)
    ax.xaxis.set_major_locator(MaxNLocator(nbins=5, integer=True))
    ax.set_xlabel(style.get('xlabel', 'Count'))
    ax.set_ylabel(style.get('ylabel', _safe_label(name, 30)))
    ax.set_title(_safe_label(style.get('title') or f'{name} counts', 62), loc='left', pad=12)
    return f'n = {int(counts.sum())} nonmissing observations; original category order'


def _extract_stratum_p_map(result: dict | None) -> dict[str, float]:
    if not isinstance(result, dict):
        return {}
    out: dict[str, float] = {}
    for tbl in result.get('tables') or []:
        if tbl.get('title') in {'Timepoint comparisons', 'Per-timepoint comparisons'}:
            for row in tbl.get('rows') or []:
                if not isinstance(row, dict) or not row.get('stratum'):
                    continue
                p_val = row.get('p_holm') if isinstance(row.get('p_holm'), (int, float)) else row.get('p_unadjusted')
                if isinstance(p_val, (int, float)) and math.isfinite(float(p_val)):
                    out[str(row['stratum'])] = float(p_val)
    return out


def _extract_two_way_summary(result: dict | None) -> str:
    if not isinstance(result, dict) or result.get('method') != 'two_way_anova':
        return ''
    bits = []
    for tbl in result.get('tables') or []:
        if tbl.get('title') == 'Two-way ANOVA':
            for row in tbl.get('rows') or []:
                if isinstance(row, dict) and row.get('source') != 'Residual' and isinstance(row.get('p'), (int, float)):
                    p_v = float(row['p'])
                    ptxt = '<0.0001' if p_v < 1e-4 else f'{p_v:.3g}'
                    src = str(row.get('source', ''))
                    if '×' in src:
                        src = 'Int'
                    elif len(src) > 10:
                        src = src[:9] + '…'
                    bits.append(f'{src} p={ptxt}')
    return ' · '.join(bits)


def _short_sig_label(p: float, mode: str, compact: bool = False) -> str:
    stars = '****' if p < 1e-4 else '***' if p < 1e-3 else '**' if p < 1e-2 else '*' if p < 0.05 else 'ns'
    if mode == 'stars_and_p':
        if compact:
            return stars
        p_txt = '<0.0001' if p < 1e-4 else f'{p:.3g}'
        return f'{stars}\n({p_txt})' if stars != 'ns' else 'ns'
    return 'p < 0.0001' if p < 1e-4 else f'p = {p:.3g}'


def _draw_stratum_p_annotations(ax, x_levels: list[str], result: dict | None, style: dict, cluster_half_width: float = 0.0) -> None:
    mode = style.get('p_display', 'none')
    if mode == 'none' or not result:
        return
    p_map = _extract_stratum_p_map(result)
    tw_text = _extract_two_way_summary(result)
    if not p_map and not tw_text:
        return
    ymin, ymax = ax.get_ylim()
    span = max(abs(ymax - ymin), 1e-9)
    y_annot = ymax + 0.04 * span
    compact = len(x_levels) > 4
    drew_any = False
    for xi, x_lbl in enumerate(x_levels):
        if x_lbl not in p_map:
            continue
        p_val = p_map[x_lbl]
        lbl = _short_sig_label(p_val, mode, compact=compact)
        if cluster_half_width > 0.04:
            x0, x1 = xi - cluster_half_width, xi + cluster_half_width
            bh = 0.025 * span
            ax.plot([x0, x0, x1, x1], [y_annot, y_annot + bh, y_annot + bh, y_annot], color='#222222', lw=0.75, zorder=6)
            ax.text(xi, y_annot + bh + 0.012 * span, lbl, ha='center', va='bottom',
                    fontsize=max(8.0, style['font_size'] - 0.6), color='#111111', zorder=6)
        else:
            ax.text(xi, y_annot, lbl, ha='center', va='bottom',
                    fontsize=max(8.0, style['font_size'] - 0.5), fontweight='semibold' if '*' in lbl else 'normal',
                    color='#111111', zorder=6)
        drew_any = True

    top_bump = (0.24 if (drew_any and tw_text) else 0.18 if (drew_any or tw_text) else 0.0) * span
    if style.get('ylim') is None and top_bump > 0:
        ax.set_ylim(ymin, ymax + top_bump)
    if tw_text:
        new_ymin, new_ymax = ax.get_ylim()
        ax.text(0.01, 0.97, tw_text, transform=ax.transAxes, ha='left', va='top',
                fontsize=max(8.0, style['font_size'] - 0.7), color='#222222', zorder=6)


def _timecourse(ax, frame, result, plan, style, colors):
    x_name = plan.get('x')
    y_name = plan.get('y')
    group_name = plan.get('group')
    if not x_name:
        # Fallback to first column if not specified
        x_name = str(frame.columns[0])
    _column(frame, x_name)

    method = (result or {}).get('method', plan.get('method', 'describe'))
    eb_req = style.get('error_bar', 'ci' if style.get('ci', True) else 'none')
    allow_inf = plan.get('design') in {'independent', 'paired'} and method not in {'mannwhitney', 'kruskal'}
    # In exploratory descriptive mode, show descriptive ±1 SD if inferential CI/SEM isn't active yet
    eff_eb = ('sd' if (not allow_inf and eb_req in {'ci', 'sem'}) else eb_req)

    # Support wide columns if y is omitted
    if not y_name:
        wide_cols = _numeric_columns(frame, plan)
        wide_cols = [c for c in wide_cols if c != x_name]
        if not wide_cols:
            raise ValueError('Choose a numeric outcome column (y) or wide numeric columns for this timecourse figure.')
        x_cats = _categories(frame[x_name])
        x_levels = [str(v) for v in pd.unique(x_cats.dropna())]
        if not x_levels:
            raise ValueError('No nonmissing timepoint/x labels are available.')
        for c_idx, col_c in enumerate(wide_cols[:12]):
            c_vals = _numbers(frame[col_c])
            xs_idx, ys_val = [], []
            for xi, x_lbl in enumerate(x_levels):
                sub_v = c_vals[x_cats == x_lbl].dropna()
                if len(sub_v):
                    xs_idx.append(xi)
                    ys_val.append(float(sub_v.mean()))
            if xs_idx:
                col_color = colors[c_idx % len(colors)]
                marker = _SUPERPLOT_MARKERS[c_idx % len(_SUPERPLOT_MARKERS)]
                ax.plot(xs_idx, ys_val, color=col_color, marker=marker, markersize=4.5, lw=1.5, label=_safe_label(col_c, 16))
        ax.set_xticks(range(len(x_levels)), [_safe_label(t, 14) for t in x_levels],
                      rotation=25 if len(x_levels) > 5 else 0,
                      ha='right' if len(x_levels) > 5 else 'center')
        ax.set_xlim(-0.4, len(x_levels) - 0.6)
        _apply_y_bounds(ax, style)
        if len(wide_cols) <= 8:
            ax.legend(frameon=False, fontsize=max(8.0, style['font_size'] - 0.6), loc='best', ncol=2 if len(wide_cols) > 4 else 1)
        ax.set_xlabel(style.get('xlabel', _safe_label(x_name, 45)))
        ax.set_ylabel(style.get('ylabel', 'Value'))
        ax.set_title(_safe_label(style.get('title') or f'Trajectories across {x_name}', 62), loc='left', pad=12)
        return f'Observed column trajectories across {len(x_levels)} {x_name} levels'

    _column(frame, y_name)
    x_cats = _categories(frame[x_name])
    y_vals = _numbers(frame[y_name])
    if group_name:
        _column(frame, group_name)
        g_cats = _categories(frame[group_name])
        good = x_cats.notna() & y_vals.notna() & g_cats.notna()
        work = pd.DataFrame({'x': x_cats[good], 'y': y_vals[good], 'g': g_cats[good]})
        group_levels = _apply_group_order([str(v) for v in pd.unique(work['g'])], style.get('group_order'))
    else:
        good = x_cats.notna() & y_vals.notna()
        work = pd.DataFrame({'x': x_cats[good], 'y': y_vals[good], 'g': y_name})
        group_levels = [str(y_name)]

    if work.empty:
        raise ValueError('No complete observations with finite outcome and timepoint values are available.')
    if len(group_levels) > 10:
        raise ValueError('Select at most 10 groups for a timecourse figure.')

    x_levels = _sort_strata_naturally([str(v) for v in pd.unique(work['x'])])
    n_g = len(group_levels)
    offsets = np.linspace(-0.05 * min(n_g - 1, 3), 0.05 * min(n_g - 1, 3), n_g) if n_g > 1 else np.zeros(1)
    used_tag = 'none'

    for gi, (g_lbl, dx) in enumerate(zip(group_levels, offsets)):
        color = colors[gi % len(colors)]
        marker = _SUPERPLOT_MARKERS[gi % len(_SUPERPLOT_MARKERS)]
        g_sub = work.loc[work['g'] == g_lbl]
        xs_plot, centers, err_low, err_high = [], [], [], []
        has_err = False
        for xi, x_lbl in enumerate(x_levels):
            arr = g_sub.loc[g_sub['x'] == x_lbl, 'y'].to_numpy(dtype=float)
            if not len(arr):
                continue
            if style['show_points']:
                p_jit = _point_offsets(len(arr), f'{y_name}::{x_lbl}', g_lbl) * 0.38
                ax.scatter(xi + dx + p_jit, arr, s=15, marker=marker, color=color, alpha=0.38, edgecolors='none', zorder=2)
            c_val, e_val, tag = _summary_interval(arr, eff_eb, True if eff_eb in {'sd', 'iqr'} else allow_inf)
            if tag != 'none':
                used_tag = tag
            xs_plot.append(xi + dx)
            centers.append(c_val)
            if e_val is None:
                err_low.append(0.0); err_high.append(0.0)
            elif isinstance(e_val, np.ndarray):
                err_low.append(float(e_val[0, 0])); err_high.append(float(e_val[1, 0]))
                has_err = True
            else:
                err_low.append(float(e_val)); err_high.append(float(e_val))
                has_err = True
        if xs_plot:
            ax.plot(xs_plot, centers, color=color, marker=marker, markersize=5.2, lw=1.75,
                    label=_safe_label(g_lbl, 20), zorder=4)
            if has_err:
                ax.errorbar(xs_plot, centers, yerr=np.array([err_low, err_high]), fmt='none',
                            ecolor=color, elinewidth=1.05, capsize=3.0, capthick=0.85, alpha=0.88, zorder=4)

    rot = 25 if (len(x_levels) > 5 or any(len(str(t)) > 10 for t in x_levels)) else 0
    ax.set_xticks(range(len(x_levels)), [_safe_label(t, 14) for t in x_levels],
                  rotation=rot, ha='right' if rot else 'center', rotation_mode='anchor' if rot else None)
    ax.set_xlim(-0.45, len(x_levels) - 0.55)
    _apply_y_bounds(ax, style)
    if group_name and len(group_levels) > 1:
        ymin, ymax = ax.get_ylim()
        span = max(abs(ymax - ymin), 1e-9)
        if style.get('ylim') is None:
            ax.set_ylim(ymin, ymax + 0.14 * span)
    _draw_stratum_p_annotations(ax, x_levels, result, style, cluster_half_width=0.0)
    if group_name and len(group_levels) >= 1:
        ax.legend(frameon=False, fontsize=max(8.0, style['font_size'] - 0.5), loc='upper right' if not _extract_two_way_summary(result) else 'lower right')
    ax.set_xlabel(style.get('xlabel', _safe_label(x_name, 45)))
    ax.set_ylabel(style.get('ylabel', _safe_label(y_name, 34)))
    default_title = f'{y_name} over {x_name}' + (f' by {group_name}' if group_name else '')
    ax.set_title(_safe_label(style.get('title') or default_title, 62), loc='left', pad=12)
    return _interval_footer(used_tag, style['show_points'], str(plan.get('design') or 'unknown'))


def _spaghetti(ax, frame, result, plan, style, colors):
    x_name = plan.get('x') or str(frame.columns[0])
    _column(frame, x_name)
    y_name = plan.get('y')
    group_name = plan.get('group')
    subj_name = plan.get('subject') or plan.get('pool_by')
    if not subj_name:
        for cand in frame.columns:
            if str(cand) not in {x_name, y_name, group_name} and str(cand).lower() in {'subject_id', 'subject', 'animal_id', 'mouse_id', 'cell_id', 'replicate'}:
                subj_name = str(cand)
                break

    x_cats = _categories(frame[x_name])
    x_levels = _sort_strata_naturally([str(v) for v in pd.unique(x_cats.dropna())])
    if not x_levels:
        raise ValueError('No nonmissing x/timepoint values are available for spaghetti trajectories.')

    if not y_name:
        # Wide format: each numeric column is an individual trajectory; group by prefix if available
        from .working_sheets import extract_replicate_prefix
        wide_cols = [c for c in _numeric_columns(frame, plan) if c != x_name]
        if not wide_cols:
            raise ValueError('No numeric replicate columns found for spaghetti plot.')
        prefixes = [extract_replicate_prefix(c) or c for c in wide_cols]
        grp_order = list(dict.fromkeys(prefixes))
        seen_legend = set()
        for col_c, g_lbl in zip(wide_cols, prefixes):
            gi = grp_order.index(g_lbl)
            color = colors[gi % len(colors)]
            c_vals = _numbers(frame[col_c])
            xs_i, ys_i = [], []
            for xi, x_lbl in enumerate(x_levels):
                sub_v = c_vals[x_cats == x_lbl].dropna()
                if len(sub_v):
                    xs_i.append(xi); ys_i.append(float(sub_v.iloc[0]))
            if xs_i:
                lbl = _safe_label(g_lbl, 18) if g_lbl not in seen_legend else None
                seen_legend.add(g_lbl)
                ax.plot(xs_i, ys_i, color=color, marker='o', markersize=3.6, lw=1.1, alpha=0.65, label=lbl)
        if len(grp_order) <= 8:
            ax.legend(frameon=False, fontsize=max(8.0, style['font_size'] - 0.5), loc='best')
        rot = 25 if len(x_levels) > 5 else 0
        ax.set_xticks(range(len(x_levels)), [_safe_label(t, 14) for t in x_levels],
                      rotation=rot, ha='right' if rot else 'center', rotation_mode='anchor' if rot else None)
        ax.set_xlim(-0.4, len(x_levels) - 0.6)
        _apply_y_bounds(ax, style)
        ax.set_xlabel(style.get('xlabel', _safe_label(x_name, 45)))
        ax.set_ylabel(style.get('ylabel', 'Value'))
        ax.set_title(_safe_label(style.get('title') or f'Individual trajectories across {x_name}', 62), loc='left', pad=12)
        return f'Individual replicate trajectories ({len(wide_cols)} series) across {len(x_levels)} {x_name} levels'

    _column(frame, y_name)
    if not subj_name or subj_name not in frame.columns:
        return _timecourse(ax, frame, result, plan, style, colors)

    y_vals = _numbers(frame[y_name])
    s_cats = _categories(frame[subj_name])
    g_cats = _categories(frame[group_name]) if (group_name and group_name in frame.columns) else pd.Series([y_name] * len(frame), index=frame.index)
    good = x_cats.notna() & y_vals.notna() & s_cats.notna() & g_cats.notna()
    work = pd.DataFrame({'x': x_cats[good], 'y': y_vals[good], 's': s_cats[good], 'g': g_cats[good]})
    if work.empty:
        raise ValueError('No complete subject trajectory observations are available.')

    x_levels = _sort_strata_naturally([str(v) for v in pd.unique(work['x'])])
    group_levels = _apply_group_order([str(v) for v in pd.unique(work['g'])], style.get('group_order'))
    for gi, g_lbl in enumerate(group_levels):
        color = colors[gi % len(colors)]
        marker = _SUPERPLOT_MARKERS[gi % len(_SUPERPLOT_MARKERS)]
        g_sub = work.loc[work['g'] == g_lbl]
        for s_id in pd.unique(g_sub['s']):
            s_sub = g_sub.loc[g_sub['s'] == s_id]
            xs_s, ys_s = [], []
            for xi, x_lbl in enumerate(x_levels):
                vals = s_sub.loc[s_sub['x'] == x_lbl, 'y'].to_numpy(dtype=float)
                if len(vals):
                    xs_s.append(xi); ys_s.append(float(np.mean(vals)))
            if xs_s:
                ax.plot(xs_s, ys_s, color=color, marker=marker, markersize=3.2, lw=0.95, alpha=0.38, zorder=2)
        # Bold group mean overlay
        xs_m, ys_m = [], []
        for xi, x_lbl in enumerate(x_levels):
            vals = g_sub.loc[g_sub['x'] == x_lbl, 'y'].to_numpy(dtype=float)
            if len(vals):
                xs_m.append(xi); ys_m.append(float(np.mean(vals)))
        if xs_m:
            n_subj = int(g_sub['s'].nunique())
            ax.plot(xs_m, ys_m, color=color, marker=marker, markersize=5.4, lw=2.1,
                    label=_safe_label(f'{g_lbl} (N={n_subj})', 22), zorder=5)

    rot = 25 if (len(x_levels) > 5 or any(len(str(t)) > 10 for t in x_levels)) else 0
    ax.set_xticks(range(len(x_levels)), [_safe_label(t, 14) for t in x_levels],
                  rotation=rot, ha='right' if rot else 'center', rotation_mode='anchor' if rot else None)
    ax.set_xlim(-0.45, len(x_levels) - 0.55)
    _apply_y_bounds(ax, style)
    ymin, ymax = ax.get_ylim()
    span = max(abs(ymax - ymin), 1e-9)
    if style.get('ylim') is None:
        ax.set_ylim(ymin, ymax + 0.14 * span)
    _draw_stratum_p_annotations(ax, x_levels, result, style, cluster_half_width=0.0)
    ax.legend(frameon=False, fontsize=max(8.0, style['font_size'] - 0.5), loc='upper right')
    ax.set_xlabel(style.get('xlabel', _safe_label(x_name, 45)))
    ax.set_ylabel(style.get('ylabel', _safe_label(y_name, 34)))
    ax.set_title(_safe_label(style.get('title') or f'Individual {subj_name} & group trajectories across {x_name}', 62), loc='left', pad=12)
    return f'Thin lines = individual {subj_name} trajectories; bold lines = group means; no observations pruned'


def _grouped_two_way(ax, frame, result, plan, style, colors, kind: str = 'bar'):
    x_name, y_name, group_name = plan.get('x'), plan.get('y'), plan.get('group')
    if not (x_name and y_name and group_name):
        # Graceful fallback to single-factor distribution if x or group is missing
        return _distribution(ax, frame, plan, style, colors, 'bar' if kind == 'bar' else 'box', result=result)
    for col_req in (x_name, y_name, group_name):
        _column(frame, col_req)

    x_cats = _categories(frame[x_name])
    y_vals = _numbers(frame[y_name])
    g_cats = _categories(frame[group_name])
    good = x_cats.notna() & y_vals.notna() & g_cats.notna()
    work = pd.DataFrame({'x': x_cats[good], 'y': y_vals[good], 'g': g_cats[good]})
    if work.empty:
        raise ValueError('No complete observations are available for this grouped two-factor figure.')

    x_levels = _sort_strata_naturally([str(v) for v in pd.unique(work['x'])])
    group_levels = _apply_group_order([str(v) for v in pd.unique(work['g'])], style.get('group_order'))
    if len(x_levels) > 16 or len(group_levels) > 6:
        raise ValueError('Grouped two-factor figures support at most 16 x-levels and 6 groups.')

    method = (result or {}).get('method', plan.get('method', 'describe'))
    eb_req = style.get('error_bar', 'ci' if style.get('ci', True) else 'none')
    allow_inf = plan.get('design') in {'independent', 'paired'} and method not in {'mannwhitney', 'kruskal'}
    eff_eb = ('sd' if (not allow_inf and eb_req in {'ci', 'sem'}) else eb_req)

    n_g = len(group_levels)
    total_w = min(0.76, 0.24 * n_g + 0.16)
    slot_w = total_w / n_g
    dx_list = [(-total_w / 2.0) + slot_w * (gi + 0.5) for gi in range(n_g)]
    used_tag = 'none'

    for gi, (g_lbl, dx) in enumerate(zip(group_levels, dx_list)):
        color = colors[gi % len(colors)]
        g_sub = work.loc[work['g'] == g_lbl]
        labeled = False
        for xi, x_lbl in enumerate(x_levels):
            arr = g_sub.loc[g_sub['x'] == x_lbl, 'y'].to_numpy(dtype=float)
            if not len(arr):
                continue
            pos = xi + dx
            lbl_arg = _safe_label(g_lbl, 20) if not labeled else None
            labeled = True
            if kind == 'box':
                bp = ax.boxplot(
                    [arr], positions=[pos], widths=slot_w * 0.82, patch_artist=True,
                    showfliers=not style['show_points'],
                    boxprops={'facecolor': color, 'alpha': 0.22, 'edgecolor': color, 'linewidth': 0.85},
                    medianprops={'color': '#111111', 'linewidth': 1.25},
                    whiskerprops={'color': color, 'linewidth': 0.8},
                    capprops={'color': color, 'linewidth': 0.8},
                )
                if lbl_arg and bp['boxes']:
                    bp['boxes'][0].set_label(lbl_arg)
            else:
                c_val, e_val, tag = _summary_interval(arr, eff_eb, True if eff_eb in {'sd', 'iqr'} else allow_inf)
                if tag != 'none':
                    used_tag = tag
                bh = c_val if c_val is not None else float(np.mean(arr))
                ax.bar(pos, bh, width=slot_w * 0.84, color=color, alpha=0.25, edgecolor=color, linewidth=0.85, label=lbl_arg)
                if e_val is not None:
                    ax.errorbar(pos, bh, yerr=e_val, fmt='none', ecolor='#111111', elinewidth=0.95, capsize=2.5, capthick=0.8, zorder=5)
            if style['show_points']:
                jit = _point_offsets(len(arr), f'{y_name}::{x_lbl}', g_lbl) * (slot_w * 1.4)
                ax.scatter(pos + jit, arr, s=14, color=color, alpha=0.72, edgecolors='white', linewidths=0.25, zorder=4)

    rot = 35 if len(x_levels) > 7 else (25 if (len(x_levels) > 5 or any(len(str(t)) > 10 for t in x_levels)) else 0)
    ax.set_xticks(range(len(x_levels)), [_safe_label(t, 14) for t in x_levels],
                  rotation=rot, ha='right' if rot else 'center', rotation_mode='anchor' if rot else None)
    ax.set_xlim(-0.6, len(x_levels) - 0.4)
    if kind == 'bar':
        ymin, ymax = ax.get_ylim()
        ax.set_ylim(min(0.0, ymin), max(0.0, ymax))
    _apply_y_bounds(ax, style)
    ymin, ymax = ax.get_ylim()
    span = max(abs(ymax - ymin), 1e-9)
    if style.get('ylim') is None:
        ax.set_ylim(ymin, ymax + 0.15 * span)
    _draw_stratum_p_annotations(ax, x_levels, result, style, cluster_half_width=abs(dx_list[-1]) if len(dx_list) > 1 else 0.0)
    ax.legend(frameon=False, fontsize=max(8.0, style['font_size'] - 0.5), loc='upper right')
    ax.set_xlabel(style.get('xlabel', _safe_label(x_name, 45)))
    ax.set_ylabel(style.get('ylabel', _safe_label(y_name, 34)))
    ax.set_title(_safe_label(style.get('title') or f'{y_name} by {group_name} across {x_name}', 62), loc='left', pad=12)
    if kind == 'box':
        return f'Grouped quartiles and 1.5×IQR whiskers across {x_name}; all observations retained'
    return _interval_footer(used_tag, style['show_points'], str(plan.get('design') or 'unknown'))


def _survival_curve(ax, frame, result, plan, style, colors):
    import warnings as pywarnings
    cols_hint = plan.get('columns')
    x_spec = plan.get('x') or (cols_hint[0] if isinstance(cols_hint, list) and len(cols_hint) >= 2 else None)
    y_spec = plan.get('y') or (cols_hint[1] if isinstance(cols_hint, list) and len(cols_hint) >= 2 else None)
    time_col = _column(frame, x_spec)
    event_col = _column(frame, y_spec)
    if time_col == event_col:
        raise ValueError('Choose distinct columns for survival time (x) and event/censoring indicator (y).')

    times = _numbers(frame[time_col])
    ev_arr, ev_valid, _, _ = _parse_survival_series(frame[event_col], event_col)
    valid_mask = times.notna().to_numpy(dtype=bool) & (times.fillna(-1.0).to_numpy(dtype=float) >= 0.0) & ev_valid

    group_col = _column(frame, plan['group']) if plan.get('group') else None
    if group_col:
        g_cats = _categories(frame[group_col])
        valid_mask = valid_mask & g_cats.notna().to_numpy(dtype=bool)
        raw_levels = [str(v) for v in pd.unique(g_cats[valid_mask])]
        group_levels = _apply_group_order(_sort_strata_naturally(raw_levels), style.get('group_order'))
    else:
        g_cats = None
        group_levels = ['All subjects']

    if not valid_mask.any() or not group_levels:
        raise ValueError('No complete non-negative (time, event) observations are available for this survival curve.')
    if len(group_levels) > 8:
        raise ValueError('Kaplan–Meier figures support at most 8 survival curves per panel.')

    method = (result or {}).get('method', plan.get('method', 'describe'))
    eb_req = style.get('error_bar', 'ci' if style.get('ci', True) else 'none')
    show_ci_band = (eb_req == 'ci') and bool(style.get('ci', True)) and (plan.get('design') == 'independent')
    show_censors = bool(style.get('show_points', True))

    times_np = times.to_numpy(dtype=float)
    crossed_median = False
    total_censored = 0

    for gi, g_lbl in enumerate(group_levels):
        sub = (valid_mask & (g_cats == g_lbl).to_numpy(dtype=bool)) if group_col else valid_mask
        gt = times_np[sub]
        ge = ev_arr[sub]
        if not len(gt):
            continue
        color = colors[gi % len(colors)]
        ls = ['-', '--', '-.', ':'][gi % 4] if style.get('palette') == 'mono' else '-'

        with pywarnings.catch_warnings():
            pywarnings.simplefilter('ignore', RuntimeWarning)
            sf = SurvfuncRight(gt, ge)
        st = np.asarray(sf.surv_times, dtype=float)
        sp = np.asarray(sf.surv_prob, dtype=float)
        se = np.asarray(sf.surv_prob_se, dtype=float)
        ci_lo, ci_hi = _km_loglog_ci(sp, se)

        t_step = np.concatenate(([0.0], st))
        s_step = np.concatenate(([1.0], sp))
        lo_step = np.concatenate(([1.0], np.where(np.isfinite(ci_lo), ci_lo, sp)))
        hi_step = np.concatenate(([1.0], np.where(np.isfinite(ci_hi), ci_hi, sp)))
        t_max_g = float(np.max(gt))
        if t_step[-1] < t_max_g:
            t_step = np.append(t_step, t_max_g)
            s_step = np.append(s_step, s_step[-1])
            lo_step = np.append(lo_step, lo_step[-1])
            hi_step = np.append(hi_step, hi_step[-1])

        if np.min(s_step) <= 0.5:
            crossed_median = True

        n_g = int(len(gt))
        ev_g = int(ge.sum())
        cens_g = n_g - ev_g
        total_censored += cens_g
        lbl = (
            f'{_safe_label(g_lbl, 15)} (n={n_g}, d={ev_g})'
            if group_col
            else f'Cohort (n={n_g}, d={ev_g})'
        )
        ax.step(t_step, s_step, where='post', color=color, lw=1.6, linestyle=ls, label=lbl, zorder=3)
        if show_ci_band and ev_g >= 1:
            ax.fill_between(t_step, lo_step, hi_step, step='post', color=color, alpha=0.14, linewidth=0, zorder=1)
        if show_censors and cens_g >= 1:
            cens_t = np.unique(gt[ge == 0])
            idx_c = np.searchsorted(st, cens_t, side='right') - 1
            s_cens = np.where(idx_c < 0, 1.0, sp[np.clip(idx_c, 0, max(0, len(sp) - 1))])
            ax.plot(cens_t, s_cens, linestyle='none', marker='+', markersize=5.8, markeredgewidth=1.0, color=color, alpha=0.92, zorder=4)

    if crossed_median:
        ax.axhline(0.5, color='#888884', lw=0.7, linestyle=':', alpha=0.75, zorder=1)

    t_max_all = float(np.max(times_np[valid_mask]))
    ax.set_xlim(0.0, t_max_all * 1.04 if t_max_all > 0 else 1.0)
    ax.set_ylim(-0.03, 1.05)
    _apply_y_bounds(ax, style)

    p_mode = style.get('p_display', 'none')
    if p_mode != 'none' and isinstance(result, dict) and result.get('method') == 'survival':
        lr_row = None
        for tbl in result.get('tables') or []:
            if tbl.get('title') == 'Log-rank test' and tbl.get('rows'):
                lr_row = tbl['rows'][0]
                break
        if isinstance(lr_row, dict) and isinstance(lr_row.get('p'), (int, float)) and math.isfinite(float(lr_row['p'])):
            pv = float(lr_row['p'])
            p_str = '< 0.0001' if pv < 1e-4 else f'= {pv:.3g}'
            if p_mode == 'stars_and_p':
                stars = '****' if pv < 1e-4 else '***' if pv < 1e-3 else '**' if pv < 1e-2 else '*' if pv < 0.05 else 'ns'
                line1 = f'Log-rank {stars} (p {p_str})'
            else:
                line1 = f'Log-rank p {p_str}'
            lines = [line1]
            if isinstance(lr_row.get('hazard_ratio'), (int, float)) and math.isfinite(float(lr_row['hazard_ratio'])):
                hr = float(lr_row['hazard_ratio'])
                lo = lr_row.get('hr_ci_low')
                hi = lr_row.get('hr_ci_high')
                if isinstance(lo, (int, float)) and isinstance(hi, (int, float)):
                    lines.append(f'HR = {hr:.2f} [{float(lo):.2f}, {float(hi):.2f}]')
                else:
                    lines.append(f'HR = {hr:.2f}')
            ax.text(
                0.03, 0.05, '\n'.join(lines), transform=ax.transAxes,
                ha='left', va='bottom', fontsize=max(8.0, style['font_size'] - 0.6), color='#111111',
                bbox={'facecolor': 'white', 'alpha': 0.82, 'edgecolor': 'none', 'pad': 1.5}, zorder=5,
            )

    ax.legend(frameon=False, fontsize=max(8.0, style['font_size'] - 0.6), loc='upper right')
    ax.set_xlabel(style.get('xlabel', _safe_label(time_col, 45)))
    ax.set_ylabel(style.get('ylabel', 'Survival probability'))
    default_title = f'Kaplan–Meier survival by {group_col}' if group_col else f'Kaplan–Meier survival ({time_col})'
    ax.set_title(_safe_label(style.get('title') or default_title, 62), loc='left', pad=12)

    parts = ['Kaplan–Meier product-limit survival']
    if show_ci_band:
        parts.append('Greenwood log(-log) 95% CI')
    if show_censors and total_censored > 0:
        parts.append(f'+ marks right-censored observations ({total_censored})')
    return '; '.join(parts)


def _default_plot_for(method: str, plan: dict) -> str:
    if method == 'survival':
        return 'survival'
    if method in {'timecourse_compare', 'two_way_anova'}:
        return 'timecourse'
    if plan.get('pool_by') and method in {'ttest', 'anova', 'mannwhitney', 'kruskal', 'batch_compare'}:
        return 'superplot'
    if method == 'paired_t':
        return 'paired'
    if method in ('pearson', 'spearman', 'regression'):
        return 'scatter'
    if method == 'chi2':
        return 'heatmap'
    if method in ('mannwhitney', 'kruskal') or (method == 'batch_compare' and plan.get('test') in {'mannwhitney', 'kruskal'}):
        return 'box'
    return 'distribution'


@_serialized_render
def make_figure(dataset, result: dict, plan: dict, style: dict | None = None) -> Figure:
    if result.get('method') == 'study_execution':
        from .study_figures import make_figure as make_study_figure
        return make_study_figure(dataset, result, plan, style)
    if getattr(dataset, 'kind', None) == 'large_table':
        from .large_figures import make_large_figure
        return make_large_figure(dataset, result, plan, style)
    if getattr(dataset, 'kind', None) == 'recording':
        if result.get('method') == 'action_potentials':
            from .ap_figures import make_ap_figure
            return make_ap_figure(dataset, result, plan, style)
        if result.get('method') == 'spikes':
            from .spike_figures import make_spike_figure
            return make_spike_figure(dataset, result, plan, style)
        from .trace_figures import make_trace_figure
        return make_trace_figure(dataset, plan, style)
    """Create a fixed-size Matplotlib figure without modifying source data."""
    settings = _style(plan, style)
    frame = _selected_frame(dataset, result)
    if frame.empty or not len(frame.columns):
        raise ValueError('There are no usable observations to plot.')
    method = result.get('method', plan.get('method', 'describe'))
    plot = plan.get('plot') or _default_plot_for(method, plan)
    if plot not in PLOT_TYPES:
        raise ValueError(f'Unsupported figure type: {plot}.')
    colors = PALETTES[settings['palette']]
    theme = dict(RC, **{'font.size': settings['font_size']})
    with mpl.rc_context(theme):
        fig = Figure(figsize=(settings['width_mm'] / 25.4, settings['height_mm'] / 25.4), dpi=150, layout='constrained')
        fig.get_layout_engine().set(w_pad=.10, h_pad=.10, wspace=.12, hspace=.12)

        if method == 'batch_compare':
            batch_cols = _numeric_columns(frame, plan)
            if len(batch_cols) < 2:
                raise ValueError('batch_compare requires at least two numeric outcome columns.')
            if len(batch_cols) > 12:
                raise ValueError('batch_compare supports at most 12 outcome panels per figure.')
            if plot not in {'distribution', 'box', 'violin', 'bar', 'superplot'}:
                raise ValueError('batch_compare figures support distribution, superplot, box, violin, or bar panels.')
            ncols = 2 if len(batch_cols) <= 4 else 3 if len(batch_cols) <= 9 else 4
            nrows = math.ceil(len(batch_cols) / ncols)
            axes = fig.subplots(nrows, ncols, squeeze=False).ravel()
            sub_method = plan.get('test') or ('mannwhitney' if plan.get('nonparametric') else 'ttest')
            for i, name in enumerate(batch_cols):
                subplan = dict(plan, method=sub_method, y=name, columns=[name])
                substyle = {k: v for k, v in settings.items() if k not in {'title', 'ylabel'}}
                if plot == 'superplot':
                    _superplot(axes[i], frame, subplan, substyle, colors, result=result, variable=name)
                else:
                    _distribution(axes[i], frame, subplan, substyle, colors, plot, result=result, variable=name)
                axes[i].set_title(_safe_label(name, 26), loc='left', pad=8)
                _axes_style(axes[i], settings['font_size'])
            for ax in axes[len(batch_cols):]:
                ax.remove()
            if settings.get('title'):
                fig.suptitle(_safe_label(settings['title'], 70), fontsize=settings['font_size'] + 1.2, fontweight='semibold')
            footer = f'Multi-endpoint comparison across {len(batch_cols)} measures in original units; Holm–Bonferroni adjusted p-values used when displayed'
        else:
            multi_columns = _numeric_columns(frame, plan) if method == 'describe' and not plan.get('group') and plot in {'distribution', 'histogram', 'ecdf', 'box', 'violin'} else []
            if len(multi_columns) > 1:
                if len(multi_columns) > 6:
                    raise ValueError('More than six numeric columns are available. Name the columns you want in this figure, or request a correlation heatmap.')
                ncols = 2 if len(multi_columns) <= 4 else 3
                nrows = math.ceil(len(multi_columns) / ncols)
                axes = fig.subplots(nrows, ncols, squeeze=False).ravel()
                for i, name in enumerate(multi_columns):
                    subplan = dict(plan, y=name, columns=[name])
                    substyle = {k: v for k, v in settings.items() if k != 'title'}
                    if plot in {'histogram', 'ecdf'}:
                        _hist_or_ecdf(axes[i], frame, subplan, substyle, colors, plot)
                    else:
                        _distribution(axes[i], frame, subplan, substyle, colors, plot, result=result, variable=name)
                    axes[i].set_title(_safe_label(name, 28), loc='left', pad=9)
                    _axes_style(axes[i], settings['font_size'])
                for ax in axes[len(multi_columns):]:
                    ax.remove()
                if settings.get('title'):
                    fig.suptitle(_safe_label(settings['title'], 70), fontsize=settings['font_size'] + 1.2, fontweight='semibold')
                footer = 'Separate scales and original units by column; all finite observations shown'
            else:
                ax = fig.subplots()
                if plot == 'survival':
                    footer = _survival_curve(ax, frame, result, plan, settings, colors)
                elif plot == 'timecourse':
                    footer = _timecourse(ax, frame, result, plan, settings, colors)
                elif plot == 'spaghetti':
                    footer = _spaghetti(ax, frame, result, plan, settings, colors)
                elif plot == 'grouped_bar':
                    footer = _grouped_two_way(ax, frame, result, plan, settings, colors, kind='bar')
                elif plot == 'grouped_box':
                    footer = _grouped_two_way(ax, frame, result, plan, settings, colors, kind='box')
                elif plot == 'line' and (
                    plan.get('group')
                    or (plan.get('x') in frame.columns and _numbers(frame[plan['x']]).dropna().empty)
                ):
                    footer = _timecourse(ax, frame, result, plan, settings, colors)
                elif plot in {'scatter', 'line'}:
                    footer = _scatter(ax, frame, result, plan, settings, colors, line=plot == 'line')
                elif plot == 'paired':
                    footer = _paired(ax, frame, plan, settings, colors, result=result)
                elif plot == 'heatmap':
                    footer = _heatmap(ax, fig, frame, result, plan, settings)
                elif plot in {'histogram', 'ecdf'}:
                    footer = _hist_or_ecdf(ax, frame, plan, settings, colors, plot)
                elif plot == 'superplot':
                    footer = _superplot(ax, frame, plan, settings, colors, result=result)
                elif not _numeric_columns(frame, plan):
                    footer = _categorical(ax, frame, plan, settings, colors)
                else:
                    footer = _distribution(ax, frame, plan, settings, colors, plot, result=result)
                if plot != 'heatmap':
                    _axes_style(ax, settings['font_size'])

        # Extra metadata is deliberately outside the plotting area. Long
        # captions belong in the companion caption.txt, not tiny figure text.
        fig._statweave_style = settings
        fig._statweave_footer = footer
        fig._statweave_caption = figure_caption(dataset, result, plan, settings)
        FigureCanvasAgg(fig).draw()
        _assert_not_clipped(fig)
        return fig


def _assert_not_clipped(fig):
    """Refuse exports where titles, suptitles, legends, or axis labels leave the fixed-size page."""
    renderer = fig.canvas.get_renderer()
    bounds = fig.bbox
    extra_texts = []
    if getattr(fig, '_suptitle', None) is not None:
        extra_texts.append(fig._suptitle)
    for legend in list(getattr(fig, 'legends', [])):
        if legend is not None and legend.get_visible():
            extra_texts.extend(legend.get_texts())
    for ax in fig.axes:
        xmin, xmax = sorted(ax.get_xlim())
        ymin, ymax = sorted(ax.get_ylim())
        xtexts = [text for text in ax.get_xticklabels() if xmin <= text.get_position()[0] <= xmax]
        ytexts = [text for text in ax.get_yticklabels() if ymin <= text.get_position()[1] <= ymax]
        legend = ax.get_legend()
        leg_texts = list(legend.get_texts()) if legend is not None and legend.get_visible() else []
        texts = [ax.title, ax._left_title, ax._right_title, ax.xaxis.label, ax.yaxis.label, *xtexts, *ytexts, *leg_texts]
        for text in texts:
            if text is None or not text.get_visible() or not text.get_text():
                continue
            box = text.get_window_extent(renderer)
            if box.x0 < bounds.x0 - 1 or box.y0 < bounds.y0 - 1 or box.x1 > bounds.x1 + 1 or box.y1 > bounds.y1 + 1:
                raise ValueError('A figure label extends outside the page. Increase width/height or shorten the label before exporting.')
    for text in extra_texts:
        if text is None or not text.get_visible() or not text.get_text():
            continue
        box = text.get_window_extent(renderer)
        if box.x0 < bounds.x0 - 1 or box.y0 < bounds.y0 - 1 or box.x1 > bounds.x1 + 1 or box.y1 > bounds.y1 + 1:
            raise ValueError('A figure title or legend extends outside the page. Increase width/height or shorten the label before exporting.')


@_serialized_render
def export_figure(fig: Figure, path, dpi=600) -> str:
    """Export editable vector or high-resolution raster at exact page size."""
    target = Path(path).expanduser().resolve()
    suffix = target.suffix.lower()
    if suffix not in {'.pdf', '.svg', '.png', '.tif', '.tiff'}:
        raise ValueError('Export figures as PDF, SVG, PNG, or TIFF.')
    try: dpi = int(dpi)
    except (ValueError, TypeError): raise ValueError('Resolution must be a number from 72 to 1200 dpi.') from None
    if not 72 <= dpi <= 1200: raise ValueError('Resolution must be 72–1200 dpi.')
    target.parent.mkdir(parents=True, exist_ok=True)
    with mpl.rc_context(RC):
        if hasattr(fig.canvas, 'get_renderer'):
            fig.canvas.draw()
            _assert_not_clipped(fig)
        metadata = {'Creator': f'StatWeave {__version__}'} if suffix == '.pdf' else {'Creator': f'StatWeave {__version__}', 'Date': None} if suffix == '.svg' else None
        fig.savefig(str(target), dpi=dpi, facecolor='white', edgecolor='white',
                    bbox_inches=None, metadata=metadata)
    return str(target)


def figure_caption(dataset, result: dict, plan: dict, style: dict | None = None) -> str:
    if result.get('method') == 'study_execution':
        from .study_figures import figure_caption as study_caption
        return study_caption(dataset, result, plan, style)
    if getattr(dataset, 'kind', None) == 'large_table':
        from .large_figures import large_caption
        return large_caption(dataset, result, plan, style)
    if getattr(dataset, 'kind', None) == 'recording':
        if result.get('method') == 'action_potentials':
            from .ap_figures import ap_caption
            return ap_caption(dataset, result, plan, style)
        if result.get('method') == 'spikes':
            from .spike_figures import spike_caption
            return spike_caption(dataset, result, plan, style)
        from .trace_figures import trace_caption
        return trace_caption(dataset, plan, style)
    """Explain observations, summary, intervals, and source-row accounting."""
    settings = _style(plan, style)
    accounting = result.get('row_accounting') or {}
    total = accounting.get('total', len(dataset.df))
    used = accounting.get('used', total)
    omitted = accounting.get('omitted', total - used)
    method = result.get('method', plan.get('method', 'describe'))
    plot = plan.get('plot') or _default_plot_for(method, plan)
    eb_mode = settings.get('error_bar', 'ci' if settings.get('ci', True) else 'none')
    allow_inferential = plan.get('design') == 'independent' and method not in {'mannwhitney', 'kruskal'}

    if plot == 'paired':
        body = 'Paired observations; lines connect measurements from the same unit. Only complete pairs are displayed.'
    elif plot == 'survival':
        body = f'Kaplan–Meier product-limit survival curves of {plan.get("x", "follow-up time")} (event indicator: {plan.get("y", "status")})'
        body += f' stratified by {plan["group"]}.' if plan.get('group') else '.'
        if eb_mode == 'ci' and settings.get('ci', True) and plan.get('design') == 'independent':
            body += ' Shaded step bands show pointwise 95% Greenwood confidence intervals on the log(-log) scale.'
        if settings.get('show_points', True):
            body += ' Plus (+) tick marks denote right-censored observations.'
    elif plot == 'superplot':
        pool_col = plan.get('pool_by', 'unit')
        pool_stat = plan.get('pool_stat', 'mean')
        body = f'Superplot stratified by {pool_col}: translucent background symbols show individual observations (n), and bold outlined symbols show {pool_col}-level {pool_stat}s (N).'
        if eb_mode == 'ci' and allow_inferential:
            body += f' Error bars show two-sided 95% Student t confidence intervals computed across {pool_col} units (N), not pooled technical observations.'
        elif eb_mode == 'sem' and allow_inferential:
            body += f' Error bars show ±1 SEM computed across {pool_col} units (N).'
        elif eb_mode == 'sd':
            body += f' Error bars show ±1 SD across {pool_col} units (N).'
        elif eb_mode == 'iqr':
            body += f' Marks and bars show the median and interquartile range (Q1–Q3) across {pool_col} units (N).'
    elif plot == 'scatter':
        body = f'{plan.get("y", "Outcome")} plotted against {plan.get("x", "predictor")}; each point is one complete observation.'
        if method == 'regression':
            body += ' The line is a one-predictor ordinary least-squares fit.'
            if settings['ci'] and plan.get('design') == 'independent':
                body += ' Shading is the pointwise 95% t confidence interval for the fitted mean (not a prediction interval).'
    elif plot == 'timecourse' or (plot == 'line' and (plan.get('group') or (plan.get('x') in dataset.df.columns and _numbers(dataset.df[plan['x']]).dropna().empty))):
        body = f'Group trajectories of {plan.get("y", "outcome")} across {plan.get("x", "timepoint")}.'
        if eb_mode == 'iqr':
            body += ' Connected symbols show group medians and error bars span interquartile ranges (Q1–Q3).'
        elif eb_mode == 'ci' and allow_inferential:
            body += ' Connected symbols show group means with two-sided 95% Student t confidence intervals.'
        elif eb_mode == 'sem' and allow_inferential:
            body += ' Connected symbols show group means ± 1 SEM.'
        elif eb_mode == 'sd':
            body += ' Connected symbols show group means ± 1 SD.'
        else:
            body += ' Connected symbols show group arithmetic means.'
        if settings['show_points']:
            body += ' Translucent symbols show individual observations at each stratum.'
    elif plot == 'spaghetti':
        subj = plan.get('subject') or plan.get('pool_by') or 'subject'
        body = f'Individual longitudinal trajectories ({subj}) across {plan.get("x", "timepoint")}, overlaid with bold group mean trajectories.'
    elif plot == 'grouped_bar':
        body = f'Dodged group bars of {plan.get("y", "outcome")} stratified by {plan.get("x", "stratum")} and {plan.get("group", "group")}.'
    elif plot == 'grouped_box':
        body = f'Dodged quartile box plots of {plan.get("y", "outcome")} stratified by {plan.get("x", "stratum")} and {plan.get("group", "group")}; whiskers extend within 1.5 IQR.'
    elif plot == 'line':
        body = 'Observed values connected in numeric x order; no smoothing or interpolation beyond straight segments.'
    elif plot == 'heatmap':
        body = 'Cells show observed contingency counts.' if method == 'chi2' else 'Cells show descriptive Pearson correlations using pairwise complete numeric observations. Pair-specific sample sizes may differ; no significance tests are implied.'
    elif plot == 'histogram':
        body = 'Histograms use shared, data-derived bin boundaries; vertical values are observation counts.'
    elif plot == 'ecdf':
        body = 'Empirical cumulative distributions show the proportion of observations at or below each value.'
    elif plot == 'box':
        body = 'Boxes show the first and third quartiles, with the median inside; whiskers extend to the last observed value within 1.5 interquartile ranges. Values beyond the whiskers are retained.'
    elif plot == 'violin':
        body = 'Violins show Gaussian-kernel density estimates for groups with at least two nonconstant values; black marks show medians. Individual observations are retained.'
    else:
        if eb_mode == 'iqr':
            body = 'Black horizontal marks show medians; error bars span the interquartile range (Q1–Q3).'
        else:
            body = 'Black horizontal marks show arithmetic means.'
            if eb_mode == 'ci' and allow_inferential:
                body += ' Error bars show two-sided 95% Student t confidence intervals of each group mean, when n ≥ 2; these are not confidence intervals of between-group differences.'
            elif eb_mode == 'sem' and allow_inferential:
                body += ' Error bars show ±1 standard error of the mean (SEM) for each group when n ≥ 2.'
            elif eb_mode == 'sd':
                body += ' Error bars show ±1 sample standard deviation (SD) for each group when n ≥ 2.'
            else:
                body += ' No inferential confidence intervals are shown because independence has not been established, the method is rank based, or intervals were disabled.'

    if plot != 'superplot':
        if settings['show_points'] and plot in {'distribution', 'box', 'violin', 'bar'}:
            body += ' Each dot is an individual observation (or pooled unit summary when pool_by is active). Horizontal offsets are assigned independently of measured values to separate dots; they have no quantitative meaning.'
        elif not settings['show_points'] and plot in {'distribution', 'box', 'violin', 'bar'}:
            body += ' Individual-point display was explicitly disabled; source observations remain in the saved project.'
    if settings.get('p_display', 'none') != 'none':
        if method == 'batch_compare':
            body += ' Displayed comparison brackets report Holm–Bonferroni multiplicity-adjusted p-values across the batch of endpoints.'
        elif method in {'timecourse_compare', 'two_way_anova'}:
            body += ' Per-stratum markers report Holm–Bonferroni multiplicity-adjusted p-values across strata.'
            if method == 'two_way_anova':
                body += ' Overall Group, Stratum, and Interaction effects come from the two-way OLS ANOVA.'
        else:
            body += ' Displayed bracket p-value comes directly from the executed statistical test.'
    if method == 'describe':
        body += ' Nonmissing finite values are used separately for each variable; n labels are variable/group-specific and do not establish independent experimental units.'
    body += f' Source rows: {total} total, {used} contributing, {omitted} not contributing to this analysis.'
    if omitted:
        body += ' Reasons and source row identifiers are listed in the analysis record; no automatic outlier removal is performed.'
    else:
        body += ' No source rows were removed from the analysis.'
    if plan.get('pool_by'):
        body += f' Biological/cluster unit column: {plan["pool_by"]} ({plan.get("pool_stat", "mean")}).'
    elif plan.get('subject'):
        body += f' Unit identifier: {plan["subject"]}.'
    body += f' Figure: {settings["width_mm"]:g} × {settings["height_mm"]:g} mm.'
    return body
