"""Deterministic, data-faithful publication figures.

The figure layer does not select tests, remove outliers, alter source data, or
infer independent experimental units.  Captions are exported separately so the
figure's requested physical dimensions do not change with prose length.
"""
from __future__ import annotations

from pathlib import Path
from functools import wraps
from threading import RLock
import math
import textwrap
import hashlib

import matplotlib as mpl
from matplotlib.figure import Figure
from matplotlib.backends.backend_agg import FigureCanvasAgg
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.ticker import MaxNLocator
import numpy as np
import pandas as pd
from scipy import stats
from statsmodels.duration.survfunc import SurvfuncRight
from . import __version__
from .curves import fit_four_param_curve, predict_curve_grid
try:
    from .engine import MISSING_TOKENS, _sort_strata_naturally, _parse_survival_series, _km_loglog_ci
except ImportError:
    MISSING_TOKENS = frozenset({
        '', 'na', 'n/a', 'nan', 'null', 'none', 'nil', 'missing', 'nd', 'n.d.',
        'not determined', 'undetermined', 'not available', '-', '--', '—', '.',
    })

    def _sort_strata_naturally(levels: list[str]) -> list[str]:
        if len(levels) < 2:
            return list(levels)
        parsed: list[tuple[float, int, str]] = []
        for idx, lv in enumerate(levels):
            try:
                fv = float(str(lv).strip())
                if not math.isfinite(fv):
                    return list(levels)
                parsed.append((fv, idx, lv))
            except (TypeError, ValueError):
                return list(levels)
        return [item[2] for item in sorted(parsed, key=lambda t: (t[0], t[1]))]

# Matplotlib and its font cache are process-global, including the Qt preview.
# The desktop canvas uses this same reentrant lock before any rendering.
FIGURE_LOCK = RLock()


def _serialized_render(function):
    @wraps(function)
    def locked(*args, **kwargs):
        with FIGURE_LOCK:
            return function(*args, **kwargs)
    return locked


PRESETS = {
    'journal_single': {'width_mm': 89.0, 'height_mm': 75.0, 'font_size': 8.5},
    'journal_double': {'width_mm': 178.0, 'height_mm': 110.0, 'font_size': 9.0},
    'nature_1col': {
        'width_mm': 89.0, 'height_mm': 78.0, 'font_size': 8.5,
        'palette': 'npg', 'font_family': 'sans', 'frame_style': 'open_l', 'cap_size': 0.0,
    },
    'nejm_clinical': {
        'width_mm': 132.0, 'height_mm': 95.0, 'font_size': 9.0,
        'palette': 'nejm', 'font_family': 'serif', 'frame_style': 'box', 'grid': 'y',
    },
    'prism_classic': {
        'width_mm': 122.0, 'height_mm': 95.0, 'font_size': 10.0,
        'palette': 'prism_bold', 'fill_style': 'hollow', 'point_style': 'open_circle',
        'line_width': 1.8, 'cap_size': 4.0,
    },
    'square_panel': {'width_mm': 108.0, 'height_mm': 108.0, 'font_size': 9.5},
    'slide_16_9': {'width_mm': 220.0, 'height_mm': 135.0, 'font_size': 12.0},
    'slide_dark': {
        'width_mm': 220.0, 'height_mm': 135.0, 'font_size': 12.0,
        'theme_bg': 'dark', 'palette': 'okabe_ito', 'line_width': 1.85,
    },
    'poster': {'width_mm': 260.0, 'height_mm': 170.0, 'font_size': 14.0},
}

STYLE_KEYS = {
    'title', 'xlabel', 'ylabel', 'width_mm', 'height_mm', 'font_size',
    'palette', 'show_points', 'ci', 'format', 'dpi',
    'preset', 'error_bar', 'p_display', 'group_order', 'y_zero', 'ylim',
    'fill_style', 'point_style', 'point_size', 'point_alpha', 'jitter_width',
    'frame_style', 'grid', 'font_family', 'theme_bg', 'legend_loc',
    'yscale', 'xscale', 'hline', 'xtick_angle', 'cap_size', 'line_width',
}
DEFAULT_STYLE = {
    'width_mm': 178.0, 'height_mm': 110.0, 'font_size': 9.0,
    'palette': 'teal', 'show_points': True, 'ci': True, 'dpi': 600,
    'error_bar': 'ci', 'p_display': 'none', 'y_zero': False,
    'fill_style': 'tinted', 'point_style': 'circle', 'point_size': 4.0,
    'point_alpha': 0.66, 'jitter_width': 0.16, 'frame_style': 'open_l',
    'grid': 'none', 'font_family': 'sans', 'theme_bg': 'white',
    'legend_loc': 'auto', 'yscale': 'linear', 'xscale': 'linear',
    'cap_size': 3.0, 'line_width': 1.5,
}
PALETTES = {
    'teal': ['#1F6F5F', '#656B70', '#A7A7A0', '#30363A', '#4B8F8C', '#7A8B82'],
    'blue': ['#306A97', '#656B70', '#A7A7A0', '#30363A', '#5690BA', '#8295A6'],
    'mono': ['#222222', '#666666', '#999999', '#444444', '#777777', '#BBBBBB'],
    'okabe_ito': ['#0072B2', '#D55E00', '#009E73', '#CC79A7', '#E69F00', '#56B4E9', '#000000'],
    'slate_coral': ['#2B4C7E', '#D95F43', '#4B8F8C', '#7A6C9D', '#C99A2E', '#56636A'],
    'viridis_cat': ['#440154', '#31688E', '#35B779', '#B5DE2B', '#21918C', '#482878'],
    'npg': ['#E64B35', '#4DBBD5', '#00A087', '#3C5488', '#F39B7F', '#8491B4', '#91D1C2', '#DC0000'],
    'nejm': ['#BC3C29', '#0072B5', '#E18727', '#20854E', '#7876B1', '#6F99AD', '#EE4C97', '#8C564B'],
    'lancet': ['#00468B', '#ED0000', '#42B540', '#0099B4', '#925E9F', '#FDAF91', '#AD002A', '#ADB6B6'],
    'jama': ['#374E55', '#DF8F44', '#00A1D5', '#B24745', '#79AF97', '#6A6599', '#80796B'],
    'aaas': ['#3B4992', '#EE0000', '#008B45', '#631879', '#008280', '#BB0021', '#5F559B', '#A20056'],
    'prism_bold': ['#111111', '#D62728', '#1F77B4', '#2CA02C', '#9467BD', '#FF7F0E', '#17BECF'],
    'pastel_soft': ['#4E79A7', '#F28E2B', '#E15759', '#76B7B2', '#59A14F', '#EDC948', '#B07AA1'],
    'tol_muted': ['#332288', '#88CCEE', '#44AA99', '#117733', '#999933', '#DDCC77', '#CC6677', '#882255', '#AA4499'],
}
PLOT_TYPES = {
    'distribution', 'scatter', 'paired', 'line', 'timecourse', 'spaghetti',
    'grouped_bar', 'grouped_box', 'grouped_violin', 'heatmap', 'survival',
    'dose_response', 'boltzmann', 'box', 'violin', 'raincloud',
    'histogram', 'ecdf', 'bar', 'superplot',
}
ERROR_BAR_MODES = {'ci', 'sd', 'sem', 'iqr', 'none'}
P_DISPLAY_MODES = {'none', 'exact', 'stars_only', 'stars_and_p'}
FILL_STYLE_MODES = {'tinted', 'solid', 'hollow', 'hatched'}
POINT_STYLE_MODES = {'circle', 'open_circle', 'by_group_shape', 'diamond', 'square', 'triangle'}
FRAME_STYLE_MODES = {'open_l', 'box', 'minimal'}
GRID_MODES = {'none', 'y', 'xy'}
FONT_FAMILY_MAP = {'sans': 'DejaVu Sans', 'serif': 'DejaVu Serif', 'mono': 'DejaVu Sans Mono'}
THEME_BG_MODES = {'white', 'transparent', 'paper', 'dark'}
LEGEND_LOC_MODES = {'auto', 'upper right', 'upper left', 'lower right', 'lower left', 'outside_top', 'none'}
AXIS_SCALE_MODES = {'linear', 'log10'}
_HATCH_PATTERNS = ('///', '\\\\\\', 'xxx', '...', '+++', '---')
_SUPERPLOT_MARKERS = ('o', 's', '^', 'D', 'v', 'P', 'X', 'h')

RC = {
    'font.family': 'DejaVu Sans', 'font.size': 9,
    'text.color': '#111111', 'axes.labelcolor': '#303030',
    'axes.edgecolor': '#404040', 'axes.linewidth': 0.7,
    'xtick.color': '#404040', 'ytick.color': '#404040',
    'xtick.major.width': 0.6, 'ytick.major.width': 0.6,
    'xtick.major.size': 3, 'ytick.major.size': 3,
    'axes.spines.top': False, 'axes.spines.right': False,
    'axes.grid': False, 'figure.facecolor': 'white',
    'axes.facecolor': 'white', 'savefig.facecolor': 'white',
    'pdf.fonttype': 42, 'ps.fonttype': 42, 'svg.fonttype': 'none',
    'svg.hashsalt': 'StatWeave-v0.1',
}


def _style(plan, supplied=None):
    merged = dict(DEFAULT_STYLE)
    for incoming in (plan.get('style') or {}, supplied or {}):
        unknown = set(incoming) - STYLE_KEYS
        if unknown:
            raise ValueError('Unsupported figure setting: ' + ', '.join(sorted(unknown)))
        if incoming.get('preset') is not None:
            preset_name = incoming['preset']
            if not isinstance(preset_name, str) or preset_name not in PRESETS:
                raise ValueError('Unsupported figure preset. Choose from: ' + ', '.join(sorted(PRESETS)) + '.')
            for p_key, p_val in PRESETS[preset_name].items():
                if p_key not in incoming:
                    merged[p_key] = p_val
        merged.update(incoming)
        if 'error_bar' in incoming and incoming['error_bar'] is not None:
            eb = incoming['error_bar']
            if not isinstance(eb, str) or eb not in ERROR_BAR_MODES:
                raise ValueError('Choose error_bar from ci, sd, sem, iqr, or none.')
            if 'ci' not in incoming:
                merged['ci'] = (eb == 'ci')
        elif 'ci' in incoming:
            if not isinstance(incoming['ci'], bool):
                raise ValueError('ci must be true or false.')
            merged['error_bar'] = 'ci' if incoming['ci'] else 'none'

    for key in ('width_mm', 'height_mm', 'font_size', 'dpi'):
        try:
            merged[key] = float(merged[key])
        except (ValueError, TypeError):
            raise ValueError(f'{key} must be a number.') from None
        if not math.isfinite(merged[key]):
            raise ValueError(f'{key} must be finite.')
    if not 60 <= merged['width_mm'] <= 450 or not 40 <= merged['height_mm'] <= 450:
        raise ValueError('Figure width must be 60–450 mm and height 40–450 mm.')
    if not 8 <= merged['font_size'] <= 24:
        raise ValueError('Publication text must be 8–24 pt; increase the figure size for crowded labels.')
    if not 72 <= merged['dpi'] <= 1200:
        raise ValueError('Figure resolution must be 72–1200 dpi.')
    if merged['palette'] not in PALETTES:
        raise ValueError('Choose palette from: ' + ', '.join(sorted(PALETTES)) + '.')
    for key in ('show_points', 'ci', 'y_zero'):
        if not isinstance(merged[key], bool):
            raise ValueError(f'{key} must be true or false.')
    if merged.get('error_bar') not in ERROR_BAR_MODES:
        raise ValueError('Choose error_bar from ci, sd, sem, iqr, or none.')
    if merged.get('p_display') not in P_DISPLAY_MODES:
        raise ValueError('Choose p_display from none, exact, stars_only, or stars_and_p.')
    if merged.get('fill_style') not in FILL_STYLE_MODES:
        raise ValueError('Choose fill_style from tinted, solid, hollow, or hatched.')
    if merged.get('point_style') not in POINT_STYLE_MODES:
        raise ValueError('Choose point_style from circle, open_circle, by_group_shape, diamond, square, or triangle.')
    if merged.get('frame_style') not in FRAME_STYLE_MODES:
        raise ValueError('Choose frame_style from open_l, box, or minimal.')
    if merged.get('grid') not in GRID_MODES:
        raise ValueError('Choose grid from none, y, or xy.')
    if merged.get('font_family') not in FONT_FAMILY_MAP:
        raise ValueError('Choose font_family from sans, serif, or mono.')
    if merged.get('theme_bg') not in THEME_BG_MODES:
        raise ValueError('Choose theme_bg from white, transparent, paper, or dark.')
    if merged.get('legend_loc') not in LEGEND_LOC_MODES:
        raise ValueError('Choose legend_loc from auto, upper right, upper left, lower right, lower left, outside_top, or none.')
    for sc_key in ('yscale', 'xscale'):
        if merged.get(sc_key) not in AXIS_SCALE_MODES:
            raise ValueError(f'Choose {sc_key} from linear or log10.')
    for f_key, lo_b, hi_b in (
        ('point_size', 2.0, 14.0),
        ('point_alpha', 0.15, 1.0),
        ('jitter_width', 0.0, 0.32),
        ('cap_size', 0.0, 10.0),
        ('line_width', 0.5, 3.5),
    ):
        val_f = merged.get(f_key)
        if isinstance(val_f, bool) or not isinstance(val_f, (int, float)) or not math.isfinite(float(val_f)) or not (lo_b <= float(val_f) <= hi_b):
            raise ValueError(f'{f_key} must be a finite number between {lo_b} and {hi_b}.')
        merged[f_key] = float(val_f)
    if merged.get('hline') is not None:
        hv = merged['hline']
        if isinstance(hv, bool) or not isinstance(hv, (int, float)) or not math.isfinite(float(hv)):
            raise ValueError('hline must be a finite number.')
        merged['hline'] = float(hv)
    if merged.get('xtick_angle') is not None:
        xa = merged['xtick_angle']
        if isinstance(xa, bool) or not isinstance(xa, (int, float)) or not (0.0 <= float(xa) <= 90.0):
            raise ValueError('xtick_angle must be between 0 and 90 degrees.')
        merged['xtick_angle'] = float(xa)
    if merged.get('group_order') is not None:
        go = merged['group_order']
        if not isinstance(go, (list, tuple)) or not go or len(go) > 18 or any(not isinstance(item, str) or not item.strip() for item in go):
            raise ValueError('group_order must be a non-empty list of group label strings (at most 18).')
        merged['group_order'] = [item.strip() for item in go]
    if merged.get('ylim') is not None:
        ylim = merged['ylim']
        if (
            not isinstance(ylim, (list, tuple))
            or len(ylim) != 2
            or any(isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(float(v)) for v in ylim)
            or float(ylim[0]) >= float(ylim[1])
        ):
            raise ValueError('ylim must be [ymin, ymax] with two finite numbers where ymin < ymax.')
        merged['ylim'] = [float(ylim[0]), float(ylim[1])]
    for key in ('title', 'xlabel', 'ylabel'):
        if key in merged and (not isinstance(merged[key], str) or len(merged[key]) > 600):
            raise ValueError(f'{key} must be text with at most 600 characters.')
    return merged


def _numbers(series):
    """Finite numeric values, treating standard missing tokens as NaN without modifying source."""
    def _clean(val):
        if val is None or isinstance(val, bool):
            return np.nan
        if isinstance(val, str):
            text = val.strip()
            if not text or text.casefold() in MISSING_TOKENS:
                return np.nan
        return val
    cleaned = series.map(_clean)
    return pd.to_numeric(cleaned, errors='coerce').replace([np.inf, -np.inf], np.nan)


def _categories(series):
    # Match engine category identity exactly, including blank-cell handling.
    # Excel may contain a mix of numeric, date, and text category cells.
    def convert(value):
        if value is None or (isinstance(value, str) and not value.strip()):
            return None
        try:
            if bool(pd.isna(value)):
                return None
        except (ValueError, TypeError):
            pass
        if isinstance(value, (float, np.floating)) and not np.isfinite(value):
            return None
        if hasattr(value, 'strftime'):
            try:
                if getattr(value, 'hour', 0) == 0 and getattr(value, 'minute', 0) == 0 and getattr(value, 'second', 0) == 0:
                    return value.strftime('%Y-%m-%d')
                return value.strftime('%Y-%m-%d %H:%M')
            except Exception:
                pass
        s = str(value).strip() if isinstance(value, str) else str(value)
        if len(s) >= 19 and s[10:] in (' 00:00:00', ' 00:00:00.0'):
            return s[:10]
        return s
    return series.map(convert)


def _selected_frame(dataset, result):
    frame = dataset.df.copy(deep=True)
    source_rows = getattr(dataset, 'row_numbers', list(range(2, len(frame) + 2)))
    # Describe has variable-specific missingness; only mask explicitly excluded rows.
    if result.get('method') == 'describe':
        excluded = {
            int(item['row']) for item in result.get('row_accounting', {}).get('excluded_rows', [])
            if isinstance(item, dict) and 'row' in item
        }
        if not excluded:
            excluded = {
                int(item['row']) for item in (result.get('plan') or {}).get('excluded_rows', [])
                if isinstance(item, dict) and 'row' in item
            }
        if excluded:
            frame = frame.loc[[int(row) not in excluded for row in source_rows]].copy()
    else:
        omitted = {
            int(item['row']) for item in result.get('row_accounting', {}).get('omitted_rows', [])
            if isinstance(item, dict) and 'row' in item
        }
        frame = frame.loc[[int(row) not in omitted for row in source_rows]].copy()
    return frame


def _column(frame, name):
    if not name or name not in frame.columns:
        raise ValueError(f'Choose an existing column; {name!r} was not found.')
    return name


def _numeric_columns(frame, plan):
    requested = plan.get('columns')
    if requested:
        return [_column(frame, name) for name in requested]
    if plan.get('y'):
        name = _column(frame, plan['y'])
        return [name] if _numbers(frame[name]).notna().any() else []
    excluded = {plan.get('subject'), plan.get('group'), plan.get('pool_by'), plan.get('count')}
    return [c for c in frame.columns if c not in excluded and _numbers(frame[c]).notna().any()]


def _apply_group_order(labels: list[str], group_order: list[str] | None) -> list[str]:
    if not group_order:
        return labels
    missing = [g for g in group_order if g not in labels]
    if missing:
        raise ValueError(f'Group(s) {missing} in group_order were not found in available groups {labels}.')
    seen = set(group_order)
    return list(group_order) + [g for g in labels if g not in seen]


def _groups(frame, plan, group_order: list[str] | None = None):
    """Return (labels, arrays, outcome label), preserving input or explicit category order."""
    y, group = plan.get('y'), plan.get('group')
    pool_by = plan.get('pool_by')
    pool_stat = plan.get('pool_stat', 'mean')
    if y and group:
        _column(frame, y); _column(frame, group)
        values = _numbers(frame[y])
        categories = _categories(frame[group])
        if pool_by:
            _column(frame, pool_by)
            units = _categories(frame[pool_by])
            good = values.notna() & categories.notna() & units.notna()
            work = pd.DataFrame({'y': values[good], 'group': categories[good], 'unit': units[good]})
            labels = _apply_group_order([str(v) for v in pd.unique(work['group'])], group_order)
            arrays = []
            for label in labels:
                sub = work.loc[work['group'] == label]
                unit_order = list(pd.unique(sub['unit']))
                agg = [
                    float(np.median(sub.loc[sub['unit'] == u, 'y'])) if pool_stat == 'median'
                    else float(np.mean(sub.loc[sub['unit'] == u, 'y']))
                    for u in unit_order
                ]
                arrays.append(np.asarray(agg, dtype=float))
            return labels, arrays, str(y)
        good = values.notna() & categories.notna()
        labels = _apply_group_order([str(v) for v in pd.unique(categories.loc[categories.notna()])], group_order)
        arrays = [values.loc[good & (categories == label)].to_numpy(dtype=float) for label in labels]
        return labels, arrays, str(y)
    columns = plan.get('columns')
    if not columns and plan.get('method') in ('ttest', 'paired_t', 'mannwhitney') and plan.get('x') and y:
        columns = [plan['x'], y]
    columns = columns or _numeric_columns(frame, plan)
    labels, arrays = [], []
    for name in columns:
        _column(frame, name)
        values = _numbers(frame[name]).dropna().to_numpy(dtype=float)
        if len(values):
            labels.append(str(name)); arrays.append(values)
    labels_ordered = _apply_group_order(labels, group_order)
    if labels_ordered != labels:
        by_label = dict(zip(labels, arrays))
        arrays = [by_label[label] for label in labels_ordered]
        labels = labels_ordered
    return labels, arrays, str(y or 'Value')


def _safe_label(text, width=22):
    return '\n'.join('\n'.join(textwrap.wrap(line, width=width, break_long_words=True, break_on_hyphens=False)) for line in str(text).split('\n'))


def _theme_spec(style: dict | None) -> dict[str, str]:
    bg = (style or {}).get('theme_bg', 'white')
    if bg == 'dark':
        return {
            'bg_mode': 'dark',
            'fig_fc': '#0F172A',
            'ax_fc': '#0F172A',
            'fg': '#F8FAFC',
            'label_fg': '#E2E8F0',
            'spine_fg': '#94A3B8',
            'grid_fg': '#334155',
            'muted_line': '#94A3B8',
            'hollow_fc': '#0F172A',
            'point_edge': '#0F172A',
        }
    if bg == 'paper':
        return {
            'bg_mode': 'paper',
            'fig_fc': '#FAF8F5',
            'ax_fc': '#FAF8F5',
            'fg': '#18181B',
            'label_fg': '#27272A',
            'spine_fg': '#3F3F46',
            'grid_fg': '#E2DDD3',
            'muted_line': '#857F77',
            'hollow_fc': '#FAF8F5',
            'point_edge': '#FAF8F5',
        }
    if bg == 'transparent':
        return {
            'bg_mode': 'transparent',
            'fig_fc': 'none',
            'ax_fc': 'none',
            'fg': '#111111',
            'label_fg': '#303030',
            'spine_fg': '#404040',
            'grid_fg': '#CBD5E1',
            'muted_line': '#8D8D88',
            'hollow_fc': '#FFFFFF',
            'point_edge': '#FFFFFF',
        }
    return {
        'bg_mode': 'white',
        'fig_fc': '#FFFFFF',
        'ax_fc': '#FFFFFF',
        'fg': '#111111',
        'label_fg': '#303030',
        'spine_fg': '#404040',
        'grid_fg': '#E2E8F0',
        'muted_line': '#8D8D88',
        'hollow_fc': '#FFFFFF',
        'point_edge': '#FFFFFF',
    }


def figure_savefig_kwargs(fig: Figure) -> dict[str, object]:
    """Return facecolor/edgecolor/transparent kwargs honoring the figure's `theme_bg` setting."""
    st = getattr(fig, '_statweave_style', None) or {}
    t = _theme_spec(st)
    if t['bg_mode'] == 'transparent':
        return {'transparent': True, 'facecolor': 'none', 'edgecolor': 'none'}
    return {'facecolor': t['fig_fc'], 'edgecolor': t['fig_fc']}


def _resolve_palette_colors(style: dict) -> list[str]:
    base = list(PALETTES[style['palette']])
    if style.get('theme_bg') == 'dark':
        dark_swaps = {
            '#111111': '#38BDF8',
            '#222222': '#E2E8F0',
            '#000000': '#FACC15',
            '#30363A': '#94A3B8',
            '#444444': '#CBD5E1',
            '#440154': '#A78BFA',
        }
        return [dark_swaps.get(c.upper(), dark_swaps.get(c, c)) for c in base]
    return base


def _marker_for_point(style: dict, group_idx: int = 0) -> str:
    ps = style.get('point_style', 'circle')
    if ps == 'by_group_shape':
        return _SUPERPLOT_MARKERS[group_idx % len(_SUPERPLOT_MARKERS)]
    return {
        'circle': 'o',
        'open_circle': 'o',
        'diamond': 'D',
        'square': 's',
        'triangle': '^',
    }.get(ps, 'o')


def _scatter_points(ax, xs, ys, color: str, style: dict, group_idx: int = 0, size_scale: float = 1.0, alpha_override: float | None = None, zorder: int = 3):
    marker = _marker_for_point(style, group_idx)
    pt_size = float(style.get('point_size', 4.0)) * size_scale
    s_area = max(4.0, pt_size * pt_size)
    alpha = float(alpha_override if alpha_override is not None else style.get('point_alpha', 0.66))
    t = _theme_spec(style)
    if style.get('point_style') == 'open_circle':
        ax.scatter(xs, ys, s=s_area, marker=marker, facecolors=t['hollow_fc'], edgecolors=color,
                   linewidths=max(0.85, float(style.get('line_width', 1.5)) * 0.65), alpha=min(1.0, alpha + 0.18), zorder=zorder)
    elif style.get('fill_style') == 'solid':
        ax.scatter(xs, ys, s=s_area, marker=marker, color=color, alpha=min(1.0, alpha + 0.15),
                   edgecolors=t['point_edge'], linewidths=0.45, zorder=zorder)
    else:
        ax.scatter(xs, ys, s=s_area, marker=marker, color=color, alpha=alpha, edgecolors='none', zorder=zorder)


def _patch_style(color: str, style: dict, group_idx: int = 0, base_alpha: float = 0.18) -> dict[str, object]:
    fs = style.get('fill_style', 'tinted')
    t = _theme_spec(style)
    lw_scale = float(style.get('line_width', 1.5)) / 1.5
    if fs == 'solid':
        return {'facecolor': color, 'alpha': 0.76, 'edgecolor': t['fg'], 'linewidth': 0.85 * lw_scale, 'hatch': None}
    if fs == 'hollow':
        return {'facecolor': t['hollow_fc'], 'alpha': 1.0, 'edgecolor': color, 'linewidth': max(1.15, 1.15 * lw_scale), 'hatch': None}
    if fs == 'hatched':
        return {
            'facecolor': t['hollow_fc'],
            'alpha': 1.0,
            'edgecolor': color,
            'linewidth': max(0.95, 0.95 * lw_scale),
            'hatch': _HATCH_PATTERNS[group_idx % len(_HATCH_PATTERNS)],
        }
    return {'facecolor': color, 'alpha': base_alpha, 'edgecolor': color, 'linewidth': 0.85 * lw_scale, 'hatch': None}


def _apply_legend(ax, style: dict, default_loc: str = 'upper right', ncol: int = 1) -> None:
    loc_pref = style.get('legend_loc', 'auto')
    if loc_pref == 'none':
        leg = ax.get_legend()
        if leg is not None:
            leg.remove()
        return
    handles, labels = ax.get_legend_handles_labels()
    if not handles:
        return
    t = _theme_spec(style)
    fsize = max(8.0, float(style['font_size']) - 0.5)
    if loc_pref == 'outside_top':
        leg = ax.legend(
            frameon=False,
            fontsize=fsize,
            loc='lower left',
            bbox_to_anchor=(0.0, 1.01),
            ncol=max(ncol, min(len(labels), 4)),
            borderaxespad=0.2,
        )
    else:
        eff_loc = default_loc if loc_pref == 'auto' else loc_pref
        leg = ax.legend(frameon=False, fontsize=fsize, loc=eff_loc, ncol=ncol)
    if leg is not None:
        for txt in leg.get_texts():
            txt.set_color(t['fg'])


def _axes_style(ax, size, style: dict | None = None):
    st = style or DEFAULT_STYLE
    t = _theme_spec(st)
    lw_scale = float(st.get('line_width', 1.5)) / 1.5
    spine_lw = max(0.55, 0.72 * lw_scale)
    ax.set_facecolor(t['ax_fc'])

    if ax.get_yscale() == 'linear' and not isinstance(ax.yaxis.get_major_locator(), mpl.ticker.FixedLocator):
        ax.yaxis.set_major_locator(MaxNLocator(nbins=5))

    ax.tick_params(
        axis='both',
        labelsize=max(8.0, size - 0.3),
        color=t['spine_fg'],
        labelcolor=t['label_fg'],
        width=max(0.5, 0.6 * lw_scale),
    )
    if st.get('xtick_angle') is not None:
        ang = float(st['xtick_angle'])
        for lbl in ax.get_xticklabels():
            lbl.set_rotation(ang)
            lbl.set_ha('right' if ang >= 20 else 'center')
    elif float(st.get('width_mm', 178.0)) <= 125.0 and isinstance(ax.xaxis.get_major_locator(), mpl.ticker.FixedLocator):
        xt_lbls = ax.get_xticklabels()
        if len(xt_lbls) >= 5 and all(lbl.get_rotation() == 0 for lbl in xt_lbls):
            for lbl in xt_lbls:
                lbl.set_rotation(28)
                lbl.set_ha('right')

    ax.xaxis.label.set_size(size)
    ax.yaxis.label.set_size(size)
    ax.xaxis.label.set_color(t['label_fg'])
    ax.yaxis.label.set_color(t['label_fg'])

    n_panels = len(ax.figure.axes) if ax.figure is not None else 1
    panel_w_mm = float(st.get('width_mm', 178.0)) / max(1, min(3, n_panels))
    max_title_chars = max(18, min(64, int((panel_w_mm - 24.0) / (0.215 * (size + 1.2)))))
    for t_obj in (ax.title, ax._left_title, ax._right_title):
        if t_obj is None:
            continue
        t_obj.set_size(size + 1.2)
        t_obj.set_weight('semibold')
        t_obj.set_color(t['fg'])
        cur_txt = t_obj.get_text()
        if cur_txt and any(len(ln) > max_title_chars for ln in cur_txt.split('\n')):
            t_obj.set_text(_safe_label(cur_txt.replace('\n', ' '), max_title_chars))

    frame = st.get('frame_style', 'open_l')
    for sp_name, sp in ax.spines.items():
        sp.set_edgecolor(t['spine_fg'])
        sp.set_linewidth(spine_lw)
        if frame == 'box':
            sp.set_visible(True)
        elif frame == 'minimal':
            sp.set_visible(sp_name == 'bottom')
        else:
            sp.set_visible(sp_name in {'left', 'bottom'})

    grid_mode = st.get('grid', 'none')
    if grid_mode == 'y' or (frame == 'minimal' and grid_mode == 'none'):
        ax.yaxis.grid(True, color=t['grid_fg'], linestyle='--', linewidth=0.6, alpha=0.85)
        ax.set_axisbelow(True)
    elif grid_mode == 'xy':
        ax.grid(True, color=t['grid_fg'], linestyle='--', linewidth=0.6, alpha=0.85)
        ax.set_axisbelow(True)

    ax.margins(y=0.16)


def _apply_y_bounds(ax, style, plotted_values: np.ndarray | None = None):
    t = _theme_spec(style)
    if style.get('hline') is not None:
        hv = float(style['hline'])
        if not (style.get('yscale') == 'log10' and hv <= 0):
            ax.axhline(hv, color=t['muted_line'], lw=0.95, linestyle='--', alpha=0.85, zorder=1)
    if style.get('xscale') == 'log10':
        xmin_c, xmax_c = ax.get_xlim()
        if xmin_c <= 0 and xmax_c <= 0:
            raise ValueError('Log10 x-axis requires positive x values (> 0).')
        ax.set_xscale('log')
    if style.get('yscale') == 'log10':
        if plotted_values is not None and len(plotted_values) and float(np.nanmin(plotted_values)) <= 0:
            raise ValueError('Log10 y-axis requires strictly positive outcome values (> 0).')
        ymin_c, ymax_c = ax.get_ylim()
        if ymax_c <= 0:
            raise ValueError('Log10 y-axis requires strictly positive outcome values (> 0).')
        if ymin_c <= 0 and plotted_values is not None and len(plotted_values):
            pos_min = float(np.nanmin(plotted_values[plotted_values > 0]))
            ax.set_ylim(bottom=pos_min * 0.8)
        ax.set_yscale('log')
    elif style.get('y_zero'):
        ymin, ymax = ax.get_ylim()
        ax.set_ylim(min(0.0, ymin), max(0.0, ymax))
    if style.get('ylim') is not None:
        if style.get('yscale') == 'log10' and style['ylim'][0] <= 0:
            raise ValueError('Log10 y-axis requires ylim[0] > 0.')
        ax.set_ylim(style['ylim'][0], style['ylim'][1])


def _mean_ci(values):
    mean = float(np.mean(values))
    if len(values) < 2:
        return mean, None
    se = float(stats.sem(values))
    error = float(stats.t.ppf(0.975, len(values) - 1) * se)
    return mean, error


def _summary_interval(values: np.ndarray, mode: str, allow_inferential: bool):
    """Return (center, yerr, description_tag) for a group's values."""
    if not len(values):
        return None, None, 'none'
    if mode == 'iqr':
        med = float(np.median(values))
        if len(values) < 2:
            return med, None, 'iqr'
        q25, q75 = np.percentile(values, [25, 75])
        return med, np.array([[max(0.0, med - float(q25))], [max(0.0, float(q75) - med)]]), 'iqr'
    mean = float(np.mean(values))
    if mode == 'sd':
        if len(values) < 2:
            return mean, None, 'sd'
        return mean, float(np.std(values, ddof=1)), 'sd'
    if mode == 'sem' and allow_inferential:
        if len(values) < 2:
            return mean, None, 'sem'
        return mean, float(stats.sem(values)), 'sem'
    if mode == 'ci' and allow_inferential:
        _, err = _mean_ci(values)
        return mean, err, 'ci'
    return mean, None, 'none'


def _format_p_label(p: float, mode: str, prefix: str = 'p') -> str:
    stars = '****' if p < 1e-4 else '***' if p < 1e-3 else '**' if p < 1e-2 else '*' if p < 0.05 else 'ns'
    if mode == 'stars_only':
        return stars
    if p < 1e-4:
        p_text = f'{prefix} < 0.0001'
    elif p < 0.01:
        p_text = f'{prefix} = {p:.4f}'
    else:
        p_text = f'{prefix} = {p:.3g}'
    if mode == 'stars_and_p':
        return f'{stars} ({p_text})'
    return p_text


def _extract_result_p(result: dict, variable: str | None = None) -> tuple[float | None, str]:
    tables = result.get('tables') or []
    method = result.get('method')
    if method == 'batch_compare' and variable:
        for tbl in tables:
            if tbl.get('title') == 'Batch comparisons':
                for row in tbl.get('rows') or []:
                    if row.get('variable') == variable:
                        p_holm = row.get('p_holm')
                        if isinstance(p_holm, (int, float)) and math.isfinite(p_holm):
                            return float(p_holm), 'Holm p'
                        p_raw = row.get('p_unadjusted')
                        if isinstance(p_raw, (int, float)) and math.isfinite(p_raw):
                            return float(p_raw), 'p'
    for tbl in tables:
        for row in tbl.get('rows') or []:
            if isinstance(row, dict) and 'p' in row and isinstance(row['p'], (int, float)) and math.isfinite(row['p']):
                prefix = 'Omnibus p' if method in {'anova', 'kruskal'} else 'p'
                return float(row['p']), prefix
    return None, 'p'


def _extract_posthoc_pairs(result: dict | None, labels: list[str] | None) -> list[tuple[int, int, float]]:
    if not isinstance(result, dict) or not labels or len(labels) < 2:
        return []
    idx_map = {str(lbl): i for i, lbl in enumerate(labels)}
    idx_cf = {str(lbl).casefold(): i for i, lbl in enumerate(labels)}
    pairs: list[tuple[int, int, float]] = []
    for tbl in result.get('tables') or []:
        if tbl.get('title') == 'Post-hoc pairwise comparisons':
            for row in tbl.get('rows') or []:
                if not isinstance(row, dict):
                    continue
                g1 = str(row.get('group_1') or '')
                g2 = str(row.get('group_2') or '')
                p_adj = row.get('p_adjusted')
                if not isinstance(p_adj, (int, float)) or not math.isfinite(float(p_adj)):
                    continue
                i1 = idx_map.get(g1, idx_cf.get(g1.casefold()))
                i2 = idx_map.get(g2, idx_cf.get(g2.casefold()))
                if i1 is None or i2 is None or i1 == i2:
                    continue
                lo_i, hi_i = (i1, i2) if i1 < i2 else (i2, i1)
                pairs.append((lo_i, hi_i, float(p_adj)))
    return pairs


def _draw_p_bracket(ax, n_groups: int, result: dict, style: dict, variable: str | None = None, labels: list[str] | None = None):
    mode = style.get('p_display', 'none')
    if mode == 'none' or n_groups < 2:
        return

    ph_pairs = _extract_posthoc_pairs(result, labels) if n_groups >= 2 else []
    if ph_pairs:
        # Show all pairs when <= 3 total comparisons (e.g. 3 groups or Dunnett <=3 arms);
        # when > 3 comparisons, display significant pairs (p_adj < 0.05) up to 6 brackets to prevent clutter.
        if len(ph_pairs) <= 3:
            chosen = list(ph_pairs)
        else:
            sig_only = [item for item in ph_pairs if item[2] < 0.05]
            sig_only.sort(key=lambda item: (item[2], item[1] - item[0]))
            chosen = sig_only[:6]

        if chosen:
            # Greedy tier assignment sorted by span width so short brackets sit below wider brackets without colliding
            chosen.sort(key=lambda item: (item[1] - item[0], item[0]))
            tiers: list[list[tuple[int, int, float]]] = []
            for i0, i1, pv in chosen:
                placed = False
                for tier in tiers:
                    # Require strict gap so text labels on adjacent brackets never collide on narrow columns
                    if all(i1 < a0 or i0 > a1 for (a0, a1, _ap) in tier):
                        tier.append((i0, i1, pv))
                        placed = True
                        break
                if not placed:
                    tiers.append([(i0, i1, pv)])

            ymin, ymax = ax.get_ylim()
            span = max(abs(ymax - ymin), 1e-9)
            n_t = len(tiers)
            step_h = (0.125 if n_t <= 3 else 0.10) * span
            leg_h = 0.026 * span
            y_cur = ymax + 0.03 * span
            compact_lbl = (n_t >= 3) or (n_groups >= 5)
            fsize = max(8.0, style['font_size'] - (0.8 if compact_lbl else 0.5))

            for tier in tiers:
                for i0, i1, pv in tier:
                    x0 = float(i0) + 0.03
                    x1 = float(i1) - 0.03
                    ax.plot([x0, x0, x1, x1], [y_cur, y_cur + leg_h, y_cur + leg_h, y_cur],
                            color='#222222', lw=0.82, zorder=6)
                    if mode == 'stars_and_p':
                        stars = '****' if pv < 1e-4 else '***' if pv < 1e-3 else '**' if pv < 1e-2 else '*' if pv < 0.05 else 'ns'
                        if compact_lbl:
                            lbl = stars
                        else:
                            ptxt = '<0.0001' if pv < 1e-4 else f'{pv:.3g}'
                            lbl = f'{stars} (p={ptxt})' if stars != 'ns' else f'ns (p={ptxt})'
                    else:
                        lbl = 'p < 0.0001' if pv < 1e-4 else f'p = {pv:.3g}'
                    ax.text((x0 + x1) / 2.0, y_cur + leg_h + 0.01 * span, lbl,
                            ha='center', va='bottom', fontsize=fsize, color='#111111', zorder=6)
                y_cur += step_h

            if style.get('ylim') is None:
                ax.set_ylim(ymin, y_cur + 0.08 * span)
            return

    p_val, prefix = _extract_result_p(result, variable=variable)
    if p_val is None:
        return
    t = _theme_spec(style)
    ymin, ymax = ax.get_ylim()
    x0, x1 = 0.0, float(n_groups - 1)
    label = _format_p_label(p_val, mode, prefix=prefix)
    if ax.get_yscale() == 'log' and ymin > 0 and ymax > 0:
        y_base = ymax * 1.08
        y_top = ymax * 1.18
        y_txt = ymax * 1.23
        if n_groups == 2:
            ax.plot([x0, x0, x1, x1], [y_base, y_top, y_top, y_base], color=t['fg'], lw=0.85, zorder=6)
        else:
            ax.plot([x0, x1], [y_top, y_top], color=t['fg'], lw=0.85, zorder=6)
        ax.text((x0 + x1) / 2.0, y_txt, label, ha='center', va='bottom',
                fontsize=max(8.0, style['font_size'] - 0.5), color=t['fg'], zorder=6)
        if style.get('ylim') is None:
            ax.set_ylim(ymin, ymax * 1.85)
        return
    span = max(abs(ymax - ymin), 1e-9)
    y_base = ymax + 0.02 * span
    h = 0.035 * span
    if n_groups == 2:
        ax.plot([x0, x0, x1, x1], [y_base, y_base + h, y_base + h, y_base], color=t['fg'], lw=0.85, zorder=6)
    else:
        ax.plot([x0, x1], [y_base + h, y_base + h], color=t['fg'], lw=0.85, zorder=6)
    ax.text((x0 + x1) / 2.0, y_base + h + 0.015 * span, label,
            ha='center', va='bottom', fontsize=max(8.0, style['font_size'] - 0.5), color=t['fg'], zorder=6)
    if style.get('ylim') is None:
        ax.set_ylim(ymin, y_base + h + 0.16 * span)


def _point_offsets(count, variable, group, half_width: float = 0.16):
    """Reproducible display offsets, independent of measured values."""
    if count < 0:
        raise ValueError('The number of displayed observations cannot be negative.')
    if count <= 1 or half_width <= 0.0:
        return np.zeros(count, dtype=float)
    key = 'StatWeave display-only point offsets v1\x00' + str(variable) + '\x00' + str(group)
    seed = int.from_bytes(hashlib.sha256(key.encode('utf-8')).digest()[:16], 'big')
    display_rng = np.random.default_rng(seed)
    return display_rng.permutation(np.linspace(-half_width, half_width, count))


def _interval_footer(used_tag: str, show_points: bool, design: str, pooled: bool = False) -> str:
    unit_word = 'unit summaries' if pooled else 'individual observations'
    if used_tag == 'ci':
        return f'Mean and 95% t confidence interval; {unit_word} shown' if show_points else 'Mean and 95% t confidence interval'
    if used_tag == 'sem':
        return f'Mean ± 1 SEM; {unit_word} shown' if show_points else 'Mean ± 1 SEM'
    if used_tag == 'sd':
        return f'Mean ± 1 SD; {unit_word} shown' if show_points else 'Mean ± 1 SD'
    if used_tag == 'iqr':
        return f'Median and interquartile range (Q1–Q3); {unit_word} shown' if show_points else 'Median and interquartile range (Q1–Q3)'
    if design != 'independent':
        return f'Mean and {unit_word}; independence not established'
    return f'Mean and {unit_word}'


def _distribution(ax, frame, plan, style, colors, plot, result=None, variable=None):
    labels, arrays, ylabel = _groups(frame, plan, group_order=style.get('group_order'))
    if not arrays or not any(len(values) for values in arrays):
        raise ValueError('No finite numeric values are available for this figure.')
    if len(arrays) > 12:
        raise ValueError('This figure has more than 12 groups. Select fewer columns or use separate figures to keep labels readable.')
    if style.get('yscale') == 'log10':
        all_v = np.concatenate([v for v in arrays if len(v)])
        if len(all_v) and float(np.nanmin(all_v)) <= 0:
            raise ValueError('Log10 y-axis requires strictly positive outcome values (> 0).')
    method = (result or {}).get('method', plan.get('method', 'describe'))
    allow_inferential = plan.get('design') == 'independent' and method not in {'mannwhitney', 'kruskal'}
    eb_mode = style.get('error_bar', 'ci' if style.get('ci', True) else 'none')
    t = _theme_spec(style)
    cap_sz = float(style.get('cap_size', 3.0))
    lw_scale = float(style.get('line_width', 1.5)) / 1.5
    jit_w = float(style.get('jitter_width', 0.16))
    used_tag = 'none'

    for index, (label, values) in enumerate(zip(labels, arrays)):
        color = colors[index % len(colors)]
        if not len(values):
            continue
        pfill = _patch_style(color, style, group_idx=index, base_alpha=0.18 if plot == 'bar' else 0.16)
        if plot == 'raincloud':
            if len(values) > 1 and float(np.std(values)) > 0:
                vp = ax.violinplot([values], positions=[index + 0.04], widths=0.58, showextrema=False)
                for body in vp['bodies']:
                    verts = body.get_paths()[0].vertices
                    verts[:, 0] = np.maximum(verts[:, 0], index + 0.04)
                    body.set_facecolor(pfill['facecolor'])
                    body.set_alpha(0.32 if style.get('fill_style') == 'tinted' else pfill['alpha'])
                    body.set_edgecolor(pfill['edgecolor'])
                    body.set_linewidth(pfill['linewidth'])
                    if pfill['hatch']:
                        body.set_hatch(pfill['hatch'])
            ax.boxplot(
                [values], positions=[index], widths=0.11, patch_artist=True, showfliers=False,
                boxprops={'facecolor': t['hollow_fc'], 'alpha': 0.95, 'edgecolor': t['fg'], 'linewidth': 0.85 * lw_scale},
                medianprops={'color': t['fg'], 'linewidth': 1.5 * lw_scale},
                whiskerprops={'color': t['fg'], 'linewidth': 0.8 * lw_scale},
                capprops={'color': t['fg'], 'linewidth': 0.8 * lw_scale},
            )
            if style['show_points']:
                jitter = _point_offsets(len(values), ylabel, label, half_width=min(0.11, jit_w * 0.65))
                _scatter_points(ax, index - 0.16 + jitter, values, color, style, group_idx=index, zorder=3)
            continue

        if plot == 'box':
            bp = ax.boxplot(
                [values], positions=[index], widths=0.48, patch_artist=True,
                showfliers=not style['show_points'],
                boxprops={'facecolor': pfill['facecolor'], 'alpha': pfill['alpha'], 'edgecolor': pfill['edgecolor'], 'linewidth': pfill['linewidth']},
                medianprops={'color': t['fg'], 'linewidth': 1.25 * lw_scale},
                whiskerprops={'color': pfill['edgecolor'], 'linewidth': 0.85 * lw_scale},
                capprops={'color': pfill['edgecolor'], 'linewidth': 0.85 * lw_scale},
                flierprops={'marker': 'o', 'markersize': 3, 'markerfacecolor': color, 'markeredgecolor': 'none'},
            )
            if pfill['hatch'] and bp['boxes']:
                bp['boxes'][0].set_hatch(pfill['hatch'])
        if plot == 'violin' and len(values) > 1 and float(np.std(values)) > 0:
            violin = ax.violinplot([values], positions=[index], widths=0.65, showextrema=False)
            for body in violin['bodies']:
                body.set_facecolor(pfill['facecolor'])
                body.set_alpha(pfill['alpha'])
                body.set_edgecolor(pfill['edgecolor'])
                body.set_linewidth(pfill['linewidth'])
                if pfill['hatch']:
                    body.set_hatch(pfill['hatch'])
        if plot == 'violin':
            median = float(np.median(values))
            ax.plot([index - .10, index + .10], [median, median], color=t['fg'], lw=1.4 * lw_scale, zorder=5)
        center, error, tag = _summary_interval(values, eb_mode, allow_inferential)
        if tag != 'none':
            used_tag = tag
        if plot == 'bar':
            bar_height = center if center is not None else float(np.mean(values))
            bars = ax.bar(index, bar_height, width=0.56, color=pfill['facecolor'], alpha=pfill['alpha'],
                          edgecolor=pfill['edgecolor'], linewidth=pfill['linewidth'])
            if pfill['hatch'] and bars:
                bars[0].set_hatch(pfill['hatch'])
        if style['show_points']:
            jitter = _point_offsets(len(values), ylabel, label, half_width=jit_w)
            _scatter_points(ax, index + jitter, values, color, style, group_idx=index, zorder=3)
        if plot not in ('box', 'violin') and center is not None:
            if error is not None:
                ax.errorbar(index, center, yerr=error, fmt='_', markersize=15, markeredgewidth=1.7 * lw_scale,
                            color=t['fg'], elinewidth=1.0 * lw_scale, capsize=cap_sz, capthick=0.8 * lw_scale if cap_sz > 0 else 0.0, zorder=5)
            else:
                ax.plot([index - .12, index + .12], [center, center], color=t['fg'], lw=1.8 * lw_scale, zorder=5)

    n_symbol = 'N' if plan.get('pool_by') else 'n'
    ax.set_xticks(range(len(labels)), [_safe_label(f'{label}\n({n_symbol} = {len(vals)})', 20) for label, vals in zip(labels, arrays)])
    ax.set_xlim(-0.6, len(labels) - 0.4)
    all_cat_vals = np.concatenate([v for v in arrays if len(v)]) if any(len(v) for v in arrays) else None
    if plot == 'bar' and style.get('yscale') != 'log10':
        ymin, ymax = ax.get_ylim()
        ax.set_ylim(min(0, ymin), max(0, ymax))
    _apply_y_bounds(ax, style, plotted_values=all_cat_vals)
    if result is not None:
        _draw_p_bracket(ax, len(labels), result, style, variable=variable or plan.get('y'), labels=labels)
    ax.set_ylabel(style.get('ylabel', _safe_label(ylabel, 34)))
    ax.set_xlabel(style.get('xlabel', _safe_label(str(plan.get('group') or ''), 50)))
    ax.set_title(_safe_label(style.get('title') or f'{ylabel} by {plan.get("group") or "column"}', 65), loc='left', pad=12)
    if plot == 'raincloud':
        return 'Half-violin density, median/quartile box, and jittered observations; all observations retained'
    if plot == 'box':
        return 'Median, quartiles, 1.5×IQR whiskers; all observations retained'
    if plot == 'violin':
        return 'Kernel density and median; all observations retained'
    return _interval_footer(used_tag, style['show_points'], str(plan.get('design') or 'unknown'), pooled=bool(plan.get('pool_by')))


def _superplot(ax, frame, plan, style, colors, result=None, variable=None):
    y, group, unit_col = plan.get('y'), plan.get('group'), plan.get('pool_by')
    if not (y and group and unit_col):
        raise ValueError("Superplots require a numeric outcome ('y'), group column ('group'), and biological/cluster unit column ('pool_by').")
    for name in (y, group, unit_col):
        _column(frame, name)
    values = _numbers(frame[y])
    categories = _categories(frame[group])
    units = _categories(frame[unit_col])
    good = values.notna() & categories.notna() & units.notna()
    work = pd.DataFrame({'y': values[good], 'group': categories[good], 'unit': units[good]})
    if work.empty:
        raise ValueError('No complete observations with finite values, group, and unit ID are available for this superplot.')
    labels = _apply_group_order([str(v) for v in pd.unique(work['group'])], style.get('group_order'))
    if len(labels) > 12:
        raise ValueError('Superplots support at most 12 groups per panel.')
    pool_stat = plan.get('pool_stat', 'mean')
    method = (result or {}).get('method', plan.get('method', 'describe'))
    allow_inferential = plan.get('design') == 'independent' and method not in {'mannwhitney', 'kruskal'}
    eb_mode = style.get('error_bar', 'ci' if style.get('ci', True) else 'none')
    used_tag = 'none'
    tick_labels = []

    t = _theme_spec(style)
    cap_sz = float(style.get('cap_size', 3.0)) + 0.5 if float(style.get('cap_size', 3.0)) > 0 else 0.0
    lw_scale = float(style.get('line_width', 1.5)) / 1.5
    jit_w = float(style.get('jitter_width', 0.16))
    pt_scale = float(style.get('point_size', 4.0)) / 4.0

    for index, label in enumerate(labels):
        color = colors[index % len(colors)]
        sub = work.loc[work['group'] == label]
        unit_names = list(pd.unique(sub['unit']))
        unit_summaries = []
        raw_count = len(sub)
        if style['show_points'] and raw_count:
            all_jitter = _point_offsets(raw_count, f'{y}::raw', label, half_width=jit_w)
            cursor = 0
            for u_idx, u_name in enumerate(unit_names):
                u_vals = sub.loc[sub['unit'] == u_name, 'y'].to_numpy(dtype=float)
                u_jit = all_jitter[cursor:cursor + len(u_vals)]
                cursor += len(u_vals)
                marker = _SUPERPLOT_MARKERS[u_idx % len(_SUPERPLOT_MARKERS)]
                ax.scatter(index + u_jit, u_vals, s=max(6.0, 16.0 * pt_scale * pt_scale), marker=marker, color=color, alpha=0.32, edgecolors='none', zorder=2)
                u_stat = float(np.median(u_vals)) if pool_stat == 'median' else float(np.mean(u_vals))
                unit_summaries.append((u_idx, u_stat))
        else:
            for u_idx, u_name in enumerate(unit_names):
                u_vals = sub.loc[sub['unit'] == u_name, 'y'].to_numpy(dtype=float)
                u_stat = float(np.median(u_vals)) if pool_stat == 'median' else float(np.mean(u_vals))
                unit_summaries.append((u_idx, u_stat))

        unit_arr = np.asarray([val for _, val in unit_summaries], dtype=float)
        if len(unit_arr):
            u_offsets = np.linspace(-0.09, 0.09, len(unit_arr)) if len(unit_arr) > 1 else np.zeros(1)
            for (u_idx, u_val), dx in zip(unit_summaries, u_offsets):
                marker = _SUPERPLOT_MARKERS[u_idx % len(_SUPERPLOT_MARKERS)]
                u_fc = t['hollow_fc'] if style.get('point_style') == 'open_circle' else color
                u_ec = color if style.get('point_style') == 'open_circle' else t['fg']
                ax.scatter([index + dx], [u_val], s=max(22.0, 50.0 * pt_scale * pt_scale), marker=marker, facecolor=u_fc,
                           edgecolor=u_ec, linewidth=0.95 * lw_scale, alpha=0.94, zorder=4)
            center, error, tag = _summary_interval(unit_arr, eb_mode, allow_inferential)
            if tag != 'none':
                used_tag = tag
            if center is not None:
                if error is not None:
                    ax.errorbar(index, center, yerr=error, fmt='_', markersize=16, markeredgewidth=1.8 * lw_scale,
                                color=t['fg'], elinewidth=1.1 * lw_scale, capsize=cap_sz, capthick=0.9 * lw_scale if cap_sz > 0 else 0.0, zorder=5)
                else:
                    ax.plot([index - .13, index + .13], [center, center], color=t['fg'], lw=1.9 * lw_scale, zorder=5)
        tick_labels.append(_safe_label(f'{label}\n(N = {len(unit_arr)}, n = {raw_count})', 22))

    ax.set_xticks(range(len(labels)), tick_labels)
    ax.set_xlim(-0.6, len(labels) - 0.4)
    _apply_y_bounds(ax, style, plotted_values=work['y'].to_numpy(dtype=float))
    if result is not None:
        _draw_p_bracket(ax, len(labels), result, style, variable=variable or y, labels=labels)
    ax.set_ylabel(style.get('ylabel', _safe_label(str(y), 34)))
    ax.set_xlabel(style.get('xlabel', _safe_label(str(group), 50)))
    ax.set_title(_safe_label(style.get('title') or f'{y} by {group} ({unit_col} superplot)', 65), loc='left', pad=12)
    base = _interval_footer(used_tag, True, str(plan.get('design') or 'unknown'), pooled=True)
    return f'Superplot: translucent markers = raw observations (n), bold outlined markers = {unit_col} {pool_stat}s (N); {base}'


def _paired(ax, frame, plan, style, colors, result=None):
    subject = plan.get('subject')
    cond_col = plan.get('group') or (plan.get('x') if subject else None)
    y = plan.get('y')
    if subject and cond_col and y:
        for name in (subject, cond_col, y):
            _column(frame, name)
        work = frame[[subject, cond_col, y]].copy()
        work[y] = _numbers(work[y])
        work[subject] = _categories(work[subject])
        work[cond_col] = _categories(work[cond_col])
        work = work.dropna(subset=[subject, cond_col, y])
        if work.duplicated([subject, cond_col]).any():
            raise ValueError('Paired figure needs one value per subject per condition; duplicate pairs must be resolved explicitly.')
        raw_labels = _sort_strata_naturally([str(v) for v in pd.unique(work[cond_col])])
        labels = _apply_group_order(raw_labels, style.get('group_order'))
        if len(labels) < 2 or len(labels) > 12:
            raise ValueError('Paired figures require between 2 and 12 matched conditions.')
        table = work.pivot(index=subject, columns=cond_col, values=y).reindex(columns=labels).dropna()
        Y_mat = table.to_numpy(dtype=float)
        ylabel = y
    else:
        columns = plan.get('columns') or ([plan.get('x'), y] if (plan.get('x') and y) else None)
        if not columns:
            columns = _numeric_columns(frame, plan)
        if not columns or len(columns) < 2 or len(columns) > 12 or not all(columns):
            raise ValueError('Choose two to twelve paired numeric columns, or identify subject, group, and outcome columns.')
        for name in columns:
            _column(frame, name)
        columns = _apply_group_order([str(c) for c in columns], style.get('group_order'))
        work = frame[columns].apply(_numbers).dropna()
        Y_mat = work.to_numpy(dtype=float)
        labels, ylabel = columns, 'Value'
    n_subj = Y_mat.shape[0]
    k_cond = len(labels)
    if n_subj == 0:
        raise ValueError('No complete matched observations are available.')

    t = _theme_spec(style)
    lw_scale = float(style.get('line_width', 1.5)) / 1.5
    xs = np.arange(k_cond, dtype=float)
    for r_idx in range(n_subj):
        ax.plot(xs, Y_mat[r_idx, :], color=t['muted_line'], alpha=0.58, lw=0.8 * lw_scale, zorder=1)
    for j in range(k_cond):
        col_j = Y_mat[:, j]
        c_j = colors[j % len(colors)]
        _scatter_points(ax, np.full(n_subj, float(j)), col_j, c_j, style, group_idx=j, size_scale=1.12, zorder=3)
        if k_cond >= 3:
            method_cur = (result or {}).get('method', plan.get('method', 'describe'))
            center_j = float(np.median(col_j)) if method_cur in {'wilcoxon', 'friedman'} else float(np.mean(col_j))
            ax.plot([j - 0.14, j + 0.14], [center_j, center_j], color=t['fg'], lw=2.0 * lw_scale, zorder=5)

    rot = 25 if (k_cond > 4 or any(len(str(lbl)) > 12 for lbl in labels)) else 0
    ax.set_xticks(range(k_cond), [_safe_label(str(label), 24) for label in labels],
                  rotation=rot, ha='right' if rot else 'center', rotation_mode='anchor' if rot else None)
    ax.set_xlim(-0.36, k_cond - 0.64)
    _apply_y_bounds(ax, style, plotted_values=Y_mat.ravel())
    if result is not None:
        _draw_p_bracket(ax, k_cond, result, style, labels=labels)
    ax.set_ylabel(style.get('ylabel', _safe_label(ylabel, 35)))
    ax.set_xlabel(style.get('xlabel', ''))
    unit_lbl = 'complete pairs' if k_cond == 2 else f'complete subjects across {k_cond} conditions'
    ax.set_title(_safe_label(style.get('title') or f'Matched observations · {n_subj} {unit_lbl}', 62), loc='left', pad=12)
    return 'Lines connect the same unit across matched conditions; complete blocks only; no observations pruned'


def _scatter(ax, frame, result, plan, style, colors, line=False):
    x, y = _column(frame, plan.get('x')), _column(frame, plan.get('y'))
    values = pd.DataFrame({'x': _numbers(frame[x]), 'y': _numbers(frame[y])}).dropna()
    if not len(values): raise ValueError('No complete finite x/y observations are available.')
    t = _theme_spec(style)
    lw_v = float(style.get('line_width', 1.5))
    if style.get('xscale') == 'log10' and float(values['x'].min()) <= 0:
        raise ValueError('Log10 x-axis requires strictly positive x values (> 0).')
    if style.get('yscale') == 'log10' and float(values['y'].min()) <= 0:
        raise ValueError('Log10 y-axis requires strictly positive y values (> 0).')
    if line:
        if values['x'].duplicated().any():
            raise ValueError('Several observations share x-values. Use a scatter figure; connecting these rows would imply an unsupported order.')
        values = values.sort_values('x', kind='stable')
        ax.plot(values.x, values.y, color=colors[0], marker=_marker_for_point(style, 0),
                markersize=max(2.5, float(style.get('point_size', 4.0))), lw=lw_v)
    else:
        _scatter_points(ax, values.x, values.y, colors[0], style, group_idx=0, size_scale=1.12, zorder=3)
        if result.get('method') == 'regression' and len(values) >= 3 and values.x.nunique() > 1:
            fit = stats.linregress(values.x, values.y)
            grid = np.linspace(values.x.min(), values.x.max(), 100)
            ax.plot(grid, fit.intercept + fit.slope * grid, color=t['fg'], lw=lw_v * 0.9)
            if style['ci'] and plan.get('design') == 'independent' and values.y.nunique() > 1:
                residual = values.y - (fit.intercept + fit.slope * values.x)
                sigma = math.sqrt(float(np.sum(residual**2)) / (len(values) - 2))
                sx = float(np.sum((values.x - values.x.mean())**2))
                half = stats.t.ppf(.975, len(values) - 2) * sigma * np.sqrt(1 / len(values) + (grid - values.x.mean())**2 / sx)
                center = fit.intercept + fit.slope * grid
                ax.fill_between(grid, center - half, center + half, color=colors[0], alpha=.14, linewidth=0)
    _apply_y_bounds(ax, style, plotted_values=values['y'].to_numpy(dtype=float))
    ax.set_xlabel(style.get('xlabel', _safe_label(x, 50)))
    ax.set_ylabel(style.get('ylabel', _safe_label(y, 35)))
    ax.set_title(_safe_label(style.get('title') or f'{y} versus {x}', 62), loc='left', pad=12)
    return f'n = {len(values)} complete observations' + ('; ordinary least-squares fit' if result.get('method') == 'regression' and not line else '')


def _hist_or_ecdf(ax, frame, plan, style, colors, plot):
    labels, arrays, ylabel = _groups(frame, plan, group_order=style.get('group_order'))
    if not arrays: raise ValueError('No finite numeric values are available for this figure.')
    if len(arrays) > 6:
        raise ValueError('Select at most six distributions per figure to keep them readable.')
    all_values = np.concatenate(arrays)
    edges = np.histogram_bin_edges(all_values, bins='auto')
    if len(edges) > 101: edges = np.linspace(float(all_values.min()), float(all_values.max()), 101)
    lw_v = float(style.get('line_width', 1.5))
    for i, (label, values) in enumerate(zip(labels, arrays)):
        color = colors[i % len(colors)]
        if plot == 'ecdf':
            ordered = np.sort(values)
            ax.step(ordered, np.arange(1, len(values) + 1) / len(values), where='post', color=color,
                    lw=lw_v, linestyle=['-', '--', ':', '-.'][i % 4], label=f'{label} (n = {len(values)})')
        else:
            htype = 'stepfilled' if style.get('fill_style') == 'solid' else 'step'
            ax.hist(values, bins=edges, histtype=htype, color=color, lw=lw_v,
                    alpha=0.45 if htype == 'stepfilled' else 1.0,
                    linestyle=['-', '--', ':', '-.'][i % 4], label=f'{label} (n = {len(values)})')
    if len(arrays) > 1:
        _apply_legend(ax, style, default_loc='upper right')
    ax.set_xlabel(style.get('xlabel', _safe_label(ylabel, 50)))
    ax.set_ylabel(style.get('ylabel', 'Cumulative proportion' if plot == 'ecdf' else 'Count'))
    if plot == 'ecdf': ax.set_ylim(0, 1.06)
    elif style.get('yscale') != 'log10': ax.set_ylim(bottom=0)
    _apply_y_bounds(ax, style)
    ax.set_title(_safe_label(style.get('title') or f'{ylabel} distribution', 62), loc='left', pad=12)
    return 'Empirical cumulative distributions; no smoothing or exclusions' if plot == 'ecdf' else 'Shared data-derived bin boundaries; no observations pruned'


def _heatmap(ax, fig, frame, result, plan, style):
    is_mono = style.get('palette') == 'mono'
    method_cur = result.get('method')
    is_counts = method_cur in {'chi2', 'fisher_exact'} or (
        bool(plan.get('x') and plan.get('y'))
        and plan.get('x') in frame.columns
        and plan.get('y') in frame.columns
        and (not _numbers(frame[plan['x']]).notna().any() or not _numbers(frame[plan['y']]).notna().any())
    )
    if is_counts:
        x, y = _column(frame, plan.get('x')), _column(frame, plan.get('y'))
        if plan.get('count'):
            c_col = _column(frame, plan['count'])
            matrix = pd.crosstab(_categories(frame[x]), _categories(frame[y]), values=_numbers(frame[c_col]), aggfunc='sum', dropna=True).fillna(0.0)
        else:
            matrix = pd.crosstab(_categories(frame[x]), _categories(frame[y]), dropna=True)
        cmap = LinearSegmentedColormap.from_list('statweave_counts', ['#F7F7F7', '#222222'] if is_mono else ['#F3F5F2', '#1F6F5F'])
        low, high = 0, None
        footer, unit = 'Observed counts; missing required categories excluded as reported', 'Observed count'
    else:
        columns = plan.get('columns') or [c for c in frame if _numbers(frame[c]).notna().any() and c not in {plan.get('subject'), plan.get('group'), plan.get('pool_by')}]
        if len(columns) < 2: raise ValueError('A correlation heatmap needs at least two numeric columns.')
        matrix = frame[columns].apply(_numbers).corr(min_periods=2)
        cmap = LinearSegmentedColormap.from_list('statweave_corr', ['#555555', '#FAFAF8', '#111111'] if is_mono else ['#4E6482', '#FAFAF8', '#1F6F5F'])
        low, high = -1, 1
        footer, unit = 'Pearson correlation; pairwise complete observations; descriptive, no significance tests', 'Pearson r'
    if max(matrix.shape) > 14:
        raise ValueError('This matrix has more than 14 rows or columns. Select a smaller set to keep its labels readable.')
    cmap = cmap.with_extremes(bad='#D8D8D4')
    image = ax.imshow(np.ma.masked_invalid(matrix.to_numpy(dtype=float)), cmap=cmap, vmin=low, vmax=high, aspect='auto')
    ax.set_xticks(range(len(matrix.columns)), [_safe_label(c, 16) for c in matrix.columns], rotation=35, ha='right', rotation_mode='anchor')
    ax.set_yticks(range(len(matrix.index)), [_safe_label(c, 18) for c in matrix.index])
    ax.set_xlabel(style.get('xlabel', str(plan.get('y') or '')))
    ax.set_ylabel(style.get('ylabel', str(plan.get('x') or '')))
    default_t = 'Observed category counts' if is_counts else 'Pairwise correlations'
    if is_counts and style.get('p_display', 'none') != 'none' and method_cur in {'chi2', 'fisher_exact'}:
        p_v, _pf = _extract_result_p(result)
        if p_v is not None:
            lbl_p = _format_p_label(p_v, style['p_display'], prefix='Fisher p' if method_cur == 'fisher_exact' else 'χ² p')
            default_t = f'Observed counts · {lbl_p}'
    ax.set_title(_safe_label(style.get('title') or default_t, 62), loc='left', pad=12)
    if max(matrix.shape) <= 7:
        mat_max = float(np.nanmax(matrix.to_numpy(dtype=float))) if matrix.size else 0.0
        for row in range(len(matrix.index)):
            for col in range(len(matrix.columns)):
                value = matrix.iloc[row, col]
                label = '—' if pd.isna(value) else (f'{value:.0f}' if is_counts else f'{value:.2f}')
                light = pd.notna(value) and (abs(value) > .60 if not is_counts else (mat_max > 0 and value > mat_max * .60))
                ax.text(col, row, label, ha='center', va='center', fontsize=max(8, style['font_size'] - .2), color='white' if light else '#111111')
    colorbar = fig.colorbar(image, ax=ax, shrink=.82, pad=.03, fraction=.05)
    colorbar.set_label(unit, fontsize=style['font_size'])
    colorbar.ax.tick_params(labelsize=max(8, style['font_size'] - .3))
    return footer


def _categorical(ax, frame, plan, style, colors):
    name = plan.get('y') or plan.get('group') or str(frame.columns[0])
    _column(frame, name)
    counts = _categories(frame[name]).dropna().value_counts(sort=False)
    if len(counts) > 18:
        raise ValueError('This column has more than 18 categories. Select a different variable or use a results table.')
    ax.barh(np.arange(len(counts)), counts.to_numpy(), color=colors[0], alpha=.85, height=.6)
    ax.set_yticks(np.arange(len(counts)), [_safe_label(v, 25) for v in counts.index])
    ax.invert_yaxis(); ax.set_xlim(left=0)
    ax.xaxis.set_major_locator(MaxNLocator(nbins=5, integer=True))
    ax.set_xlabel(style.get('xlabel', 'Count'))
    ax.set_ylabel(style.get('ylabel', _safe_label(name, 30)))
    ax.set_title(_safe_label(style.get('title') or f'{name} counts', 62), loc='left', pad=12)
    return f'n = {int(counts.sum())} nonmissing observations; original category order'


def _extract_stratum_p_map(result: dict | None) -> dict[str, float]:
    if not isinstance(result, dict):
        return {}
    out: dict[str, float] = {}
    for tbl in result.get('tables') or []:
        if tbl.get('title') in {'Timepoint comparisons', 'Per-timepoint comparisons'}:
            for row in tbl.get('rows') or []:
                if not isinstance(row, dict) or not row.get('stratum'):
                    continue
                p_val = row.get('p_holm') if isinstance(row.get('p_holm'), (int, float)) else row.get('p_unadjusted')
                if isinstance(p_val, (int, float)) and math.isfinite(float(p_val)):
                    out[str(row['stratum'])] = float(p_val)
    return out


def _extract_two_way_summary(result: dict | None) -> str:
    if not isinstance(result, dict) or result.get('method') != 'two_way_anova':
        return ''
    bits = []
    for tbl in result.get('tables') or []:
        if tbl.get('title') == 'Two-way ANOVA':
            for row in tbl.get('rows') or []:
                if isinstance(row, dict) and row.get('source') != 'Residual' and isinstance(row.get('p'), (int, float)):
                    p_v = float(row['p'])
                    ptxt = '<0.0001' if p_v < 1e-4 else f'{p_v:.3g}'
                    src = str(row.get('source', ''))
                    if '×' in src:
                        src = 'Int'
                    elif len(src) > 10:
                        src = src[:9] + '…'
                    bits.append(f'{src} p={ptxt}')
    return ' · '.join(bits)


def _short_sig_label(p: float, mode: str, compact: bool = False) -> str:
    stars = '****' if p < 1e-4 else '***' if p < 1e-3 else '**' if p < 1e-2 else '*' if p < 0.05 else 'ns'
    if mode == 'stars_only':
        return stars
    if mode == 'stars_and_p':
        if compact:
            return stars
        p_txt = '<0.0001' if p < 1e-4 else f'{p:.3g}'
        return f'{stars}\n({p_txt})' if stars != 'ns' else 'ns'
    return 'p < 0.0001' if p < 1e-4 else f'p = {p:.3g}'


def _draw_stratum_p_annotations(ax, x_levels: list[str], result: dict | None, style: dict, cluster_half_width: float = 0.0) -> None:
    mode = style.get('p_display', 'none')
    if mode == 'none' or not result:
        return
    p_map = _extract_stratum_p_map(result)
    tw_text = _extract_two_way_summary(result)
    if not p_map and not tw_text:
        return
    t = _theme_spec(style)
    ymin, ymax = ax.get_ylim()
    is_log = ax.get_yscale() == 'log' and ymin > 0 and ymax > 0
    span = max(abs(ymax - ymin), 1e-9)
    y_annot = (ymax * 1.08) if is_log else (ymax + 0.04 * span)
    compact = len(x_levels) > 4
    drew_any = False
    for xi, x_lbl in enumerate(x_levels):
        if x_lbl not in p_map:
            continue
        p_val = p_map[x_lbl]
        lbl = _short_sig_label(p_val, mode, compact=compact)
        if cluster_half_width > 0.04:
            x0, x1 = xi - cluster_half_width, xi + cluster_half_width
            y_top_b = (y_annot * 1.08) if is_log else (y_annot + 0.025 * span)
            y_txt_b = (y_top_b * 1.05) if is_log else (y_top_b + 0.012 * span)
            ax.plot([x0, x0, x1, x1], [y_annot, y_top_b, y_top_b, y_annot], color=t['fg'], lw=0.75, zorder=6)
            ax.text(xi, y_txt_b, lbl, ha='center', va='bottom',
                    fontsize=max(8.0, style['font_size'] - 0.6), color=t['fg'], zorder=6)
        else:
            ax.text(xi, y_annot, lbl, ha='center', va='bottom',
                    fontsize=max(8.0, style['font_size'] - 0.5), fontweight='semibold' if '*' in lbl else 'normal',
                    color=t['fg'], zorder=6)
        drew_any = True

    if style.get('ylim') is None:
        if is_log and (drew_any or tw_text):
            ax.set_ylim(ymin, ymax * (1.75 if (drew_any and tw_text) else 1.5))
        else:
            top_bump = (0.24 if (drew_any and tw_text) else 0.18 if (drew_any or tw_text) else 0.0) * span
            if top_bump > 0:
                ax.set_ylim(ymin, ymax + top_bump)
    if tw_text:
        ax.text(0.01, 0.97, tw_text, transform=ax.transAxes, ha='left', va='top',
                fontsize=max(8.0, style['font_size'] - 0.7), color=t['fg'], zorder=6)


def _timecourse(ax, frame, result, plan, style, colors):
    x_name = plan.get('x')
    y_name = plan.get('y')
    group_name = plan.get('group')
    if not x_name:
        # Fallback to first column if not specified
        x_name = str(frame.columns[0])
    _column(frame, x_name)

    method = (result or {}).get('method', plan.get('method', 'describe'))
    eb_req = style.get('error_bar', 'ci' if style.get('ci', True) else 'none')
    allow_inf = plan.get('design') in {'independent', 'paired'} and method not in {'mannwhitney', 'kruskal'}
    # In exploratory descriptive mode, show descriptive ±1 SD if inferential CI/SEM isn't active yet
    eff_eb = ('sd' if (not allow_inf and eb_req in {'ci', 'sem'}) else eb_req)

    # Support wide columns if y is omitted
    if not y_name:
        wide_cols = _numeric_columns(frame, plan)
        wide_cols = [c for c in wide_cols if c != x_name]
        if not wide_cols:
            raise ValueError('Choose a numeric outcome column (y) or wide numeric columns for this timecourse figure.')
        x_cats = _categories(frame[x_name])
        x_levels = [str(v) for v in pd.unique(x_cats.dropna())]
        if not x_levels:
            raise ValueError('No nonmissing timepoint/x labels are available.')
        for c_idx, col_c in enumerate(wide_cols[:12]):
            c_vals = _numbers(frame[col_c])
            xs_idx, ys_val = [], []
            for xi, x_lbl in enumerate(x_levels):
                sub_v = c_vals[x_cats == x_lbl].dropna()
                if len(sub_v):
                    xs_idx.append(xi)
                    ys_val.append(float(sub_v.mean()))
            if xs_idx:
                col_color = colors[c_idx % len(colors)]
                marker = _SUPERPLOT_MARKERS[c_idx % len(_SUPERPLOT_MARKERS)]
                ax.plot(xs_idx, ys_val, color=col_color, marker=marker, markersize=4.5, lw=1.5, label=_safe_label(col_c, 16))
        ax.set_xticks(range(len(x_levels)), [_safe_label(t, 14) for t in x_levels],
                      rotation=25 if len(x_levels) > 5 else 0,
                      ha='right' if len(x_levels) > 5 else 'center')
        ax.set_xlim(-0.4, len(x_levels) - 0.6)
        _apply_y_bounds(ax, style)
        if len(wide_cols) <= 8:
            ax.legend(frameon=False, fontsize=max(8.0, style['font_size'] - 0.6), loc='best', ncol=2 if len(wide_cols) > 4 else 1)
        ax.set_xlabel(style.get('xlabel', _safe_label(x_name, 45)))
        ax.set_ylabel(style.get('ylabel', 'Value'))
        ax.set_title(_safe_label(style.get('title') or f'Trajectories across {x_name}', 62), loc='left', pad=12)
        return f'Observed column trajectories across {len(x_levels)} {x_name} levels'

    _column(frame, y_name)
    x_cats = _categories(frame[x_name])
    y_vals = _numbers(frame[y_name])
    if group_name:
        _column(frame, group_name)
        g_cats = _categories(frame[group_name])
        good = x_cats.notna() & y_vals.notna() & g_cats.notna()
        work = pd.DataFrame({'x': x_cats[good], 'y': y_vals[good], 'g': g_cats[good]})
        group_levels = _apply_group_order([str(v) for v in pd.unique(work['g'])], style.get('group_order'))
    else:
        good = x_cats.notna() & y_vals.notna()
        work = pd.DataFrame({'x': x_cats[good], 'y': y_vals[good], 'g': y_name})
        group_levels = [str(y_name)]

    if work.empty:
        raise ValueError('No complete observations with finite outcome and timepoint values are available.')
    if len(group_levels) > 10:
        raise ValueError('Select at most 10 groups for a timecourse figure.')

    x_levels = _sort_strata_naturally([str(v) for v in pd.unique(work['x'])])
    n_g = len(group_levels)
    offsets = np.linspace(-0.05 * min(n_g - 1, 3), 0.05 * min(n_g - 1, 3), n_g) if n_g > 1 else np.zeros(1)
    lw_v = float(style.get('line_width', 1.5))
    cap_sz = float(style.get('cap_size', 3.0))
    t = _theme_spec(style)
    used_tag = 'none'

    for gi, (g_lbl, dx) in enumerate(zip(group_levels, offsets)):
        color = colors[gi % len(colors)]
        marker = _SUPERPLOT_MARKERS[gi % len(_SUPERPLOT_MARKERS)] if style.get('point_style') in {'circle', 'by_group_shape', 'open_circle'} else _marker_for_point(style, gi)
        mfc = t['hollow_fc'] if style.get('point_style') == 'open_circle' else color
        g_sub = work.loc[work['g'] == g_lbl]
        xs_plot, centers, err_low, err_high = [], [], [], []
        has_err = False
        for xi, x_lbl in enumerate(x_levels):
            arr = g_sub.loc[g_sub['x'] == x_lbl, 'y'].to_numpy(dtype=float)
            if not len(arr):
                continue
            if style['show_points']:
                p_jit = _point_offsets(len(arr), f'{y_name}::{x_lbl}', g_lbl, half_width=float(style.get('jitter_width', 0.16))) * 0.38
                _scatter_points(ax, xi + dx + p_jit, arr, color, style, group_idx=gi, size_scale=0.92, alpha_override=0.38, zorder=2)
            c_val, e_val, tag = _summary_interval(arr, eff_eb, True if eff_eb in {'sd', 'iqr'} else allow_inf)
            if tag != 'none':
                used_tag = tag
            xs_plot.append(xi + dx)
            centers.append(c_val)
            if e_val is None:
                err_low.append(0.0); err_high.append(0.0)
            elif isinstance(e_val, np.ndarray):
                err_low.append(float(e_val[0, 0])); err_high.append(float(e_val[1, 0]))
                has_err = True
            else:
                err_low.append(float(e_val)); err_high.append(float(e_val))
                has_err = True
        if xs_plot:
            ax.plot(xs_plot, centers, color=color, marker=marker, markerfacecolor=mfc, markeredgecolor=color,
                    markersize=max(3.5, float(style.get('point_size', 4.0)) * 1.25), lw=lw_v * 1.15,
                    label=_safe_label(g_lbl, 20), zorder=4)
            if has_err:
                ax.errorbar(xs_plot, centers, yerr=np.array([err_low, err_high]), fmt='none',
                            ecolor=color, elinewidth=max(0.75, lw_v * 0.7), capsize=cap_sz, capthick=0.85 if cap_sz > 0 else 0.0, alpha=0.88, zorder=4)

    rot = 25 if (len(x_levels) > 5 or any(len(str(t_x)) > 10 for t_x in x_levels)) else 0
    ax.set_xticks(range(len(x_levels)), [_safe_label(t_x, 14) for t_x in x_levels],
                  rotation=rot, ha='right' if rot else 'center', rotation_mode='anchor' if rot else None)
    ax.set_xlim(-0.45, len(x_levels) - 0.55)
    _apply_y_bounds(ax, style, plotted_values=work['y'].to_numpy(dtype=float))
    if group_name and len(group_levels) > 1 and ax.get_yscale() != 'log':
        ymin, ymax = ax.get_ylim()
        span = max(abs(ymax - ymin), 1e-9)
        if style.get('ylim') is None:
            ax.set_ylim(ymin, ymax + 0.14 * span)
    _draw_stratum_p_annotations(ax, x_levels, result, style, cluster_half_width=0.0)
    if group_name and len(group_levels) >= 1:
        _apply_legend(ax, style, default_loc='upper right' if not _extract_two_way_summary(result) else 'lower right')
    ax.set_xlabel(style.get('xlabel', _safe_label(x_name, 45)))
    ax.set_ylabel(style.get('ylabel', _safe_label(y_name, 34)))
    default_title = f'{y_name} over {x_name}' + (f' by {group_name}' if group_name else '')
    ax.set_title(_safe_label(style.get('title') or default_title, 62), loc='left', pad=12)
    return _interval_footer(used_tag, style['show_points'], str(plan.get('design') or 'unknown'))


def _spaghetti(ax, frame, result, plan, style, colors):
    x_name = plan.get('x') or str(frame.columns[0])
    _column(frame, x_name)
    y_name = plan.get('y')
    group_name = plan.get('group')
    subj_name = plan.get('subject') or plan.get('pool_by')
    if not subj_name:
        for cand in frame.columns:
            if str(cand) not in {x_name, y_name, group_name} and str(cand).lower() in {'subject_id', 'subject', 'animal_id', 'mouse_id', 'cell_id', 'replicate'}:
                subj_name = str(cand)
                break

    x_cats = _categories(frame[x_name])
    x_levels = _sort_strata_naturally([str(v) for v in pd.unique(x_cats.dropna())])
    if not x_levels:
        raise ValueError('No nonmissing x/timepoint values are available for spaghetti trajectories.')

    if not y_name:
        # Wide format: each numeric column is an individual trajectory; group by prefix if available
        from .working_sheets import extract_replicate_prefix
        wide_cols = [c for c in _numeric_columns(frame, plan) if c != x_name]
        if not wide_cols:
            raise ValueError('No numeric replicate columns found for spaghetti plot.')
        prefixes = [extract_replicate_prefix(c) or c for c in wide_cols]
        grp_order = list(dict.fromkeys(prefixes))
        seen_legend = set()
        for col_c, g_lbl in zip(wide_cols, prefixes):
            gi = grp_order.index(g_lbl)
            color = colors[gi % len(colors)]
            c_vals = _numbers(frame[col_c])
            xs_i, ys_i = [], []
            for xi, x_lbl in enumerate(x_levels):
                sub_v = c_vals[x_cats == x_lbl].dropna()
                if len(sub_v):
                    xs_i.append(xi); ys_i.append(float(sub_v.iloc[0]))
            if xs_i:
                lbl = _safe_label(g_lbl, 18) if g_lbl not in seen_legend else None
                seen_legend.add(g_lbl)
                ax.plot(xs_i, ys_i, color=color, marker='o', markersize=3.6, lw=1.1, alpha=0.65, label=lbl)
        if len(grp_order) <= 8:
            ax.legend(frameon=False, fontsize=max(8.0, style['font_size'] - 0.5), loc='best')
        rot = 25 if len(x_levels) > 5 else 0
        ax.set_xticks(range(len(x_levels)), [_safe_label(t, 14) for t in x_levels],
                      rotation=rot, ha='right' if rot else 'center', rotation_mode='anchor' if rot else None)
        ax.set_xlim(-0.4, len(x_levels) - 0.6)
        _apply_y_bounds(ax, style)
        ax.set_xlabel(style.get('xlabel', _safe_label(x_name, 45)))
        ax.set_ylabel(style.get('ylabel', 'Value'))
        ax.set_title(_safe_label(style.get('title') or f'Individual trajectories across {x_name}', 62), loc='left', pad=12)
        return f'Individual replicate trajectories ({len(wide_cols)} series) across {len(x_levels)} {x_name} levels'

    _column(frame, y_name)
    if not subj_name or subj_name not in frame.columns:
        return _timecourse(ax, frame, result, plan, style, colors)

    y_vals = _numbers(frame[y_name])
    s_cats = _categories(frame[subj_name])
    g_cats = _categories(frame[group_name]) if (group_name and group_name in frame.columns) else pd.Series([y_name] * len(frame), index=frame.index)
    good = x_cats.notna() & y_vals.notna() & s_cats.notna() & g_cats.notna()
    work = pd.DataFrame({'x': x_cats[good], 'y': y_vals[good], 's': s_cats[good], 'g': g_cats[good]})
    if work.empty:
        raise ValueError('No complete subject trajectory observations are available.')

    x_levels = _sort_strata_naturally([str(v) for v in pd.unique(work['x'])])
    group_levels = _apply_group_order([str(v) for v in pd.unique(work['g'])], style.get('group_order'))
    for gi, g_lbl in enumerate(group_levels):
        color = colors[gi % len(colors)]
        marker = _SUPERPLOT_MARKERS[gi % len(_SUPERPLOT_MARKERS)]
        g_sub = work.loc[work['g'] == g_lbl]
        for s_id in pd.unique(g_sub['s']):
            s_sub = g_sub.loc[g_sub['s'] == s_id]
            xs_s, ys_s = [], []
            for xi, x_lbl in enumerate(x_levels):
                vals = s_sub.loc[s_sub['x'] == x_lbl, 'y'].to_numpy(dtype=float)
                if len(vals):
                    xs_s.append(xi); ys_s.append(float(np.mean(vals)))
            if xs_s:
                ax.plot(xs_s, ys_s, color=color, marker=marker, markersize=3.2, lw=0.95, alpha=0.38, zorder=2)
        # Bold group mean overlay
        xs_m, ys_m = [], []
        for xi, x_lbl in enumerate(x_levels):
            vals = g_sub.loc[g_sub['x'] == x_lbl, 'y'].to_numpy(dtype=float)
            if len(vals):
                xs_m.append(xi); ys_m.append(float(np.mean(vals)))
        if xs_m:
            n_subj = int(g_sub['s'].nunique())
            ax.plot(xs_m, ys_m, color=color, marker=marker, markersize=5.4, lw=2.1,
                    label=_safe_label(f'{g_lbl} (N={n_subj})', 22), zorder=5)

    rot = 25 if (len(x_levels) > 5 or any(len(str(t)) > 10 for t in x_levels)) else 0
    ax.set_xticks(range(len(x_levels)), [_safe_label(t, 14) for t in x_levels],
                  rotation=rot, ha='right' if rot else 'center', rotation_mode='anchor' if rot else None)
    ax.set_xlim(-0.45, len(x_levels) - 0.55)
    _apply_y_bounds(ax, style, plotted_values=work['y'].to_numpy(dtype=float))
    if ax.get_yscale() != 'log':
        ymin, ymax = ax.get_ylim()
        span = max(abs(ymax - ymin), 1e-9)
        if style.get('ylim') is None:
            ax.set_ylim(ymin, ymax + 0.14 * span)
    _draw_stratum_p_annotations(ax, x_levels, result, style, cluster_half_width=0.0)
    _apply_legend(ax, style, default_loc='upper right')
    ax.set_xlabel(style.get('xlabel', _safe_label(x_name, 45)))
    ax.set_ylabel(style.get('ylabel', _safe_label(y_name, 34)))
    ax.set_title(_safe_label(style.get('title') or f'Individual {subj_name} & group trajectories across {x_name}', 62), loc='left', pad=12)
    return f'Thin lines = individual {subj_name} trajectories; bold lines = group means; no observations pruned'


def _grouped_two_way(ax, frame, result, plan, style, colors, kind: str = 'bar'):
    x_name, y_name, group_name = plan.get('x'), plan.get('y'), plan.get('group')
    if not (x_name and y_name and group_name):
        fallback_kind = 'bar' if kind == 'bar' else ('violin' if kind == 'violin' else 'box')
        return _distribution(ax, frame, plan, style, colors, fallback_kind, result=result)
    for col_req in (x_name, y_name, group_name):
        _column(frame, col_req)

    x_cats = _categories(frame[x_name])
    y_vals = _numbers(frame[y_name])
    g_cats = _categories(frame[group_name])
    good = x_cats.notna() & y_vals.notna() & g_cats.notna()
    work = pd.DataFrame({'x': x_cats[good], 'y': y_vals[good], 'g': g_cats[good]})
    if work.empty:
        raise ValueError('No complete observations are available for this grouped two-factor figure.')

    x_levels = _sort_strata_naturally([str(v) for v in pd.unique(work['x'])])
    group_levels = _apply_group_order([str(v) for v in pd.unique(work['g'])], style.get('group_order'))
    if len(x_levels) > 16 or len(group_levels) > 8:
        raise ValueError('Grouped two-factor figures support at most 16 x-levels and 8 groups.')

    method = (result or {}).get('method', plan.get('method', 'describe'))
    eb_req = style.get('error_bar', 'ci' if style.get('ci', True) else 'none')
    allow_inf = plan.get('design') in {'independent', 'paired'} and method not in {'mannwhitney', 'kruskal'}
    eff_eb = ('sd' if (not allow_inf and eb_req in {'ci', 'sem'}) else eb_req)

    n_g = len(group_levels)
    total_w = min(0.78, 0.24 * n_g + 0.16)
    slot_w = total_w / n_g
    dx_list = [(-total_w / 2.0) + slot_w * (gi + 0.5) for gi in range(n_g)]
    t = _theme_spec(style)
    cap_sz = float(style.get('cap_size', 3.0)) * 0.85
    lw_scale = float(style.get('line_width', 1.5)) / 1.5
    used_tag = 'none'

    for gi, (g_lbl, dx) in enumerate(zip(group_levels, dx_list)):
        color = colors[gi % len(colors)]
        pfill = _patch_style(color, style, group_idx=gi, base_alpha=0.25 if kind == 'bar' else 0.22)
        g_sub = work.loc[work['g'] == g_lbl]
        labeled = False
        for xi, x_lbl in enumerate(x_levels):
            arr = g_sub.loc[g_sub['x'] == x_lbl, 'y'].to_numpy(dtype=float)
            if not len(arr):
                continue
            pos = xi + dx
            lbl_arg = _safe_label(g_lbl, 20) if not labeled else None
            labeled = True
            if kind == 'box':
                bp = ax.boxplot(
                    [arr], positions=[pos], widths=slot_w * 0.82, patch_artist=True,
                    showfliers=not style['show_points'],
                    boxprops={'facecolor': pfill['facecolor'], 'alpha': pfill['alpha'], 'edgecolor': pfill['edgecolor'], 'linewidth': pfill['linewidth']},
                    medianprops={'color': t['fg'], 'linewidth': 1.25 * lw_scale},
                    whiskerprops={'color': pfill['edgecolor'], 'linewidth': 0.8 * lw_scale},
                    capprops={'color': pfill['edgecolor'], 'linewidth': 0.8 * lw_scale},
                )
                if pfill['hatch'] and bp['boxes']:
                    bp['boxes'][0].set_hatch(pfill['hatch'])
                if lbl_arg and bp['boxes']:
                    bp['boxes'][0].set_label(lbl_arg)
            elif kind == 'violin':
                if len(arr) > 1 and float(np.std(arr)) > 0:
                    vp = ax.violinplot([arr], positions=[pos], widths=slot_w * 0.86, showextrema=False)
                    for body in vp['bodies']:
                        body.set_facecolor(pfill['facecolor'])
                        body.set_alpha(pfill['alpha'])
                        body.set_edgecolor(pfill['edgecolor'])
                        body.set_linewidth(pfill['linewidth'])
                        if pfill['hatch']:
                            body.set_hatch(pfill['hatch'])
                med_v = float(np.median(arr))
                ax.plot([pos - slot_w * 0.25, pos + slot_w * 0.25], [med_v, med_v], color=t['fg'], lw=1.25 * lw_scale, zorder=5)
                if lbl_arg:
                    ax.plot([], [], color=color, lw=3.0, label=lbl_arg)
            else:
                c_val, e_val, tag = _summary_interval(arr, eff_eb, True if eff_eb in {'sd', 'iqr'} else allow_inf)
                if tag != 'none':
                    used_tag = tag
                bh = c_val if c_val is not None else float(np.mean(arr))
                bars = ax.bar(pos, bh, width=slot_w * 0.84, color=pfill['facecolor'], alpha=pfill['alpha'],
                              edgecolor=pfill['edgecolor'], linewidth=pfill['linewidth'], label=lbl_arg)
                if pfill['hatch'] and bars:
                    bars[0].set_hatch(pfill['hatch'])
                if e_val is not None:
                    ax.errorbar(pos, bh, yerr=e_val, fmt='none', ecolor=t['fg'], elinewidth=0.95 * lw_scale,
                                capsize=cap_sz, capthick=0.8 * lw_scale if cap_sz > 0 else 0.0, zorder=5)
            if style['show_points']:
                jit = _point_offsets(len(arr), f'{y_name}::{x_lbl}', g_lbl, half_width=float(style.get('jitter_width', 0.16))) * (slot_w * 1.4)
                _scatter_points(ax, pos + jit, arr, color, style, group_idx=gi, size_scale=0.88, zorder=4)

    rot = 35 if len(x_levels) > 7 else (25 if (len(x_levels) > 5 or any(len(str(t_x)) > 10 for t_x in x_levels)) else 0)
    ax.set_xticks(range(len(x_levels)), [_safe_label(t_x, 14) for t_x in x_levels],
                  rotation=rot, ha='right' if rot else 'center', rotation_mode='anchor' if rot else None)
    ax.set_xlim(-0.6, len(x_levels) - 0.4)
    if kind == 'bar' and style.get('yscale') != 'log10':
        ymin, ymax = ax.get_ylim()
        ax.set_ylim(min(0.0, ymin), max(0.0, ymax))
    _apply_y_bounds(ax, style, plotted_values=work['y'].to_numpy(dtype=float))
    if ax.get_yscale() != 'log':
        ymin, ymax = ax.get_ylim()
        span = max(abs(ymax - ymin), 1e-9)
        if style.get('ylim') is None:
            ax.set_ylim(ymin, ymax + 0.15 * span)
    _draw_stratum_p_annotations(ax, x_levels, result, style, cluster_half_width=abs(dx_list[-1]) if len(dx_list) > 1 else 0.0)
    _apply_legend(ax, style, default_loc='upper right')
    ax.set_xlabel(style.get('xlabel', _safe_label(x_name, 45)))
    ax.set_ylabel(style.get('ylabel', _safe_label(y_name, 34)))
    ax.set_title(_safe_label(style.get('title') or f'{y_name} by {group_name} across {x_name}', 62), loc='left', pad=12)
    if kind == 'violin':
        return f'Dodged kernel density violins and medians across {x_name}; all observations retained'
    if kind == 'box':
        return f'Grouped quartiles and 1.5×IQR whiskers across {x_name}; all observations retained'
    return _interval_footer(used_tag, style['show_points'], str(plan.get('design') or 'unknown'))


def _survival_curve(ax, frame, result, plan, style, colors):
    import warnings as pywarnings
    cols_hint = plan.get('columns')
    x_spec = plan.get('x') or (cols_hint[0] if isinstance(cols_hint, list) and len(cols_hint) >= 2 else None)
    y_spec = plan.get('y') or (cols_hint[1] if isinstance(cols_hint, list) and len(cols_hint) >= 2 else None)
    time_col = _column(frame, x_spec)
    event_col = _column(frame, y_spec)
    if time_col == event_col:
        raise ValueError('Choose distinct columns for survival time (x) and event/censoring indicator (y).')

    times = _numbers(frame[time_col])
    ev_arr, ev_valid, _, _ = _parse_survival_series(frame[event_col], event_col)
    valid_mask = times.notna().to_numpy(dtype=bool) & (times.fillna(-1.0).to_numpy(dtype=float) >= 0.0) & ev_valid

    group_col = _column(frame, plan['group']) if plan.get('group') else None
    if group_col:
        g_cats = _categories(frame[group_col])
        valid_mask = valid_mask & g_cats.notna().to_numpy(dtype=bool)
        raw_levels = [str(v) for v in pd.unique(g_cats[valid_mask])]
        group_levels = _apply_group_order(_sort_strata_naturally(raw_levels), style.get('group_order'))
    else:
        g_cats = None
        group_levels = ['All subjects']

    if not valid_mask.any() or not group_levels:
        raise ValueError('No complete non-negative (time, event) observations are available for this survival curve.')
    if len(group_levels) > 8:
        raise ValueError('Kaplan–Meier figures support at most 8 survival curves per panel.')

    method = (result or {}).get('method', plan.get('method', 'describe'))
    eb_req = style.get('error_bar', 'ci' if style.get('ci', True) else 'none')
    show_ci_band = (eb_req == 'ci') and bool(style.get('ci', True)) and (plan.get('design') == 'independent')
    show_censors = bool(style.get('show_points', True))

    times_np = times.to_numpy(dtype=float)
    crossed_median = False
    total_censored = 0

    for gi, g_lbl in enumerate(group_levels):
        sub = (valid_mask & (g_cats == g_lbl).to_numpy(dtype=bool)) if group_col else valid_mask
        gt = times_np[sub]
        ge = ev_arr[sub]
        if not len(gt):
            continue
        color = colors[gi % len(colors)]
        ls = ['-', '--', '-.', ':'][gi % 4] if style.get('palette') == 'mono' else '-'

        with pywarnings.catch_warnings():
            pywarnings.simplefilter('ignore', RuntimeWarning)
            sf = SurvfuncRight(gt, ge)
        st = np.asarray(sf.surv_times, dtype=float)
        sp = np.asarray(sf.surv_prob, dtype=float)
        se = np.asarray(sf.surv_prob_se, dtype=float)
        ci_lo, ci_hi = _km_loglog_ci(sp, se)

        t_step = np.concatenate(([0.0], st))
        s_step = np.concatenate(([1.0], sp))
        lo_step = np.concatenate(([1.0], np.where(np.isfinite(ci_lo), ci_lo, sp)))
        hi_step = np.concatenate(([1.0], np.where(np.isfinite(ci_hi), ci_hi, sp)))
        t_max_g = float(np.max(gt))
        if t_step[-1] < t_max_g:
            t_step = np.append(t_step, t_max_g)
            s_step = np.append(s_step, s_step[-1])
            lo_step = np.append(lo_step, lo_step[-1])
            hi_step = np.append(hi_step, hi_step[-1])

        if np.min(s_step) <= 0.5:
            crossed_median = True

        n_g = int(len(gt))
        ev_g = int(ge.sum())
        cens_g = n_g - ev_g
        total_censored += cens_g
        lbl = (
            f'{_safe_label(g_lbl, 15)} (n={n_g}, d={ev_g})'
            if group_col
            else f'Cohort (n={n_g}, d={ev_g})'
        )
        ax.step(t_step, s_step, where='post', color=color, lw=1.6, linestyle=ls, label=lbl, zorder=3)
        if show_ci_band and ev_g >= 1:
            ax.fill_between(t_step, lo_step, hi_step, step='post', color=color, alpha=0.14, linewidth=0, zorder=1)
        if show_censors and cens_g >= 1:
            cens_t = np.unique(gt[ge == 0])
            idx_c = np.searchsorted(st, cens_t, side='right') - 1
            s_cens = np.where(idx_c < 0, 1.0, sp[np.clip(idx_c, 0, max(0, len(sp) - 1))])
            ax.plot(cens_t, s_cens, linestyle='none', marker='+', markersize=5.8, markeredgewidth=1.0, color=color, alpha=0.92, zorder=4)

    t = _theme_spec(style)
    lw_v = float(style.get('line_width', 1.5))
    if crossed_median:
        ax.axhline(0.5, color=t['muted_line'], lw=0.75, linestyle=':', alpha=0.78, zorder=1)

    t_max_all = float(np.max(times_np[valid_mask]))
    ax.set_xlim(0.0, t_max_all * 1.04 if t_max_all > 0 else 1.0)
    ax.set_ylim(-0.03, 1.05)
    _apply_y_bounds(ax, style)

    p_mode = style.get('p_display', 'none')
    if p_mode != 'none' and isinstance(result, dict) and result.get('method') == 'survival':
        lr_row = None
        for tbl in result.get('tables') or []:
            if tbl.get('title') == 'Log-rank test' and tbl.get('rows'):
                lr_row = tbl['rows'][0]
                break
        if isinstance(lr_row, dict) and isinstance(lr_row.get('p'), (int, float)) and math.isfinite(float(lr_row['p'])):
            pv = float(lr_row['p'])
            p_str = '< 0.0001' if pv < 1e-4 else f'= {pv:.3g}'
            stars = '****' if pv < 1e-4 else '***' if pv < 1e-3 else '**' if pv < 1e-2 else '*' if pv < 0.05 else 'ns'
            if p_mode == 'stars_only':
                line1 = f'Log-rank {stars}'
            elif p_mode == 'stars_and_p':
                line1 = f'Log-rank {stars} (p {p_str})'
            else:
                line1 = f'Log-rank p {p_str}'
            lines = [line1]
            if p_mode != 'stars_only' and isinstance(lr_row.get('hazard_ratio'), (int, float)) and math.isfinite(float(lr_row['hazard_ratio'])):
                hr = float(lr_row['hazard_ratio'])
                lo = lr_row.get('hr_ci_low')
                hi = lr_row.get('hr_ci_high')
                if isinstance(lo, (int, float)) and isinstance(hi, (int, float)):
                    lines.append(f'HR = {hr:.2f} [{float(lo):.2f}, {float(hi):.2f}]')
                else:
                    lines.append(f'HR = {hr:.2f}')
            box_fc = '#1E293B' if t['bg_mode'] == 'dark' else (t['hollow_fc'] if t['bg_mode'] != 'transparent' else '#FFFFFF')
            ax.text(
                0.03, 0.05, '\n'.join(lines), transform=ax.transAxes,
                ha='left', va='bottom', fontsize=max(8.0, style['font_size'] - 0.6), color=t['fg'],
                bbox={'facecolor': box_fc, 'alpha': 0.84, 'edgecolor': 'none', 'pad': 1.5}, zorder=5,
            )

    _apply_legend(ax, style, default_loc='upper right')
    ax.set_xlabel(style.get('xlabel', _safe_label(time_col, 45)))
    ax.set_ylabel(style.get('ylabel', 'Survival probability'))
    default_title = f'Kaplan–Meier survival by {group_col}' if group_col else f'Kaplan–Meier survival ({time_col})'
    ax.set_title(_safe_label(style.get('title') or default_title, 62), loc='left', pad=12)

    parts = ['Kaplan–Meier product-limit survival']
    if show_ci_band:
        parts.append('Greenwood log(-log) 95% CI')
    if show_censors and total_censored > 0:
        parts.append(f'+ marks right-censored observations ({total_censored})')
    return '; '.join(parts)


def _nonlinear_curve_plot(ax, frame, result, plan, style, colors, curve_mode: str):
    cols_hint = plan.get('columns')
    x_spec = plan.get('x') or (cols_hint[0] if isinstance(cols_hint, list) and len(cols_hint) >= 2 else None)
    y_spec = plan.get('y') or (cols_hint[1] if isinstance(cols_hint, list) and len(cols_hint) >= 2 else None)
    x_col = _column(frame, x_spec)
    y_col = _column(frame, y_spec)
    if x_col == y_col:
        raise ValueError('Choose distinct columns for predictor (x) and response (y).')

    xs_s = _numbers(frame[x_col])
    ys_s = _numbers(frame[y_col])
    valid_m = xs_s.notna().to_numpy(dtype=bool) & ys_s.notna().to_numpy(dtype=bool)

    x_is_log10 = bool(plan.get('x_is_log10', False))
    if curve_mode == 'hill' and not x_is_log10:
        preview_x = xs_s[valid_m].to_numpy(dtype=float)
        if len(preview_x) >= 4 and float(np.min(preview_x)) < 0.0 and float(np.max(preview_x)) <= 2.0:
            x_is_log10 = True
        else:
            valid_m = valid_m & (xs_s.fillna(-1.0).to_numpy(dtype=float) >= 0.0)

    group_col = _column(frame, plan['group']) if plan.get('group') else None
    if group_col:
        g_cats = _categories(frame[group_col])
        valid_m = valid_m & g_cats.notna().to_numpy(dtype=bool)
        raw_lv = _sort_strata_naturally([str(v) for v in pd.unique(g_cats[valid_m])])
        group_levels = _apply_group_order(raw_lv, style.get('group_order'))
    else:
        g_cats = None
        group_levels = ['All observations']

    if not valid_m.any() or not group_levels:
        raise ValueError('No complete finite observations are available for this nonlinear curve.')
    if len(group_levels) > 8:
        raise ValueError('Nonlinear curve plots support at most 8 groups per panel.')

    xs_np = xs_s.to_numpy(dtype=float)
    ys_np = ys_s.to_numpy(dtype=float)
    eb_req = style.get('error_bar', 'ci' if style.get('ci', True) else 'none')
    allow_inf = plan.get('design') == 'independent'
    eff_eb = ('sd' if (not allow_inf and eb_req in {'ci', 'sem'}) else eb_req)
    show_ribbon = bool(style.get('ci', True)) and allow_inf

    use_log_scale = (curve_mode == 'hill') and (not x_is_log10)
    pos_all = xs_np[valid_m & (xs_np > 0.0)] if use_log_scale else np.array([])
    zero_plot_x = (float(np.min(pos_all)) / 5.0) if (use_log_scale and len(pos_all) > 0) else 0.0

    for gi, g_lbl in enumerate(group_levels):
        sub_m = (valid_m & (g_cats == g_lbl).to_numpy(dtype=bool)) if group_col else valid_m
        gx = xs_np[sub_m]
        gy = ys_np[sub_m]
        if not len(gx):
            continue
        color = colors[gi % len(colors)]
        marker = _SUPERPLOT_MARKERS[gi % len(_SUPERPLOT_MARKERS)]

        # Plot raw observations (translucent) and stratum mean ± error bar
        x_disp = np.where(gx == 0.0, zero_plot_x, gx) if use_log_scale else gx
        if style.get('show_points', True):
            ax.scatter(x_disp, gy, s=16, marker=marker, color=color, alpha=0.45, edgecolors='none', zorder=2)

        uniq_x = np.unique(gx)
        m_xs, m_ys, e_lo, e_hi = [], [], [], []
        has_eb = False
        for ux in uniq_x:
            arr_y = gy[gx == ux]
            c_v, e_v, _tag = _summary_interval(arr_y, eff_eb, True if eff_eb in {'sd', 'iqr'} else allow_inf)
            m_xs.append(zero_plot_x if (use_log_scale and ux == 0.0) else float(ux))
            m_ys.append(float(c_v))
            if e_v is None:
                e_lo.append(0.0); e_hi.append(0.0)
            elif isinstance(e_v, np.ndarray):
                e_lo.append(float(e_v[0, 0])); e_hi.append(float(e_v[1, 0]))
                has_eb = True
            else:
                e_lo.append(float(e_v)); e_hi.append(float(e_v))
                has_eb = True

        # Fit curve if >=5 points across >=4 levels
        fitted_ok = False
        lbl_str = f'{_safe_label(g_lbl, 16)} (n={len(gx)})' if group_col else f'Observed (n={len(gx)})'
        try:
            if curve_mode == 'hill':
                z_g = np.zeros(len(gx), dtype=bool) if x_is_log10 else (gx == 0.0)
                u_g = gx.copy() if x_is_log10 else np.where(z_g, 0.0, np.log10(np.where(z_g, 1.0, gx)))
            else:
                z_g = np.zeros(len(gx), dtype=bool)
                u_g = gx.copy()
            fit_g = fit_four_param_curve(u_g, gy, z_g, curve_mode)
            u_pos = u_g[~z_g]
            u_grid = np.linspace(float(np.min(u_pos)), float(np.max(u_pos)), 200)
            y_hat, ci_l, ci_h = predict_curve_grid(fit_g, u_grid, curve_mode)
            x_grid = (u_grid if x_is_log10 else (10.0 ** u_grid)) if curve_mode == 'hill' else u_grid

            mid_val = float(fit_g['params'][2])
            s_val = float(fit_g['params'][3])
            if curve_mode == 'hill':
                pot_lbl = 'EC50' if s_val >= 0.0 else 'IC50'
                ec_disp = (10.0 ** mid_val) if not x_is_log10 else mid_val
                lbl_str = (
                    f'{_safe_label(g_lbl, 14)} ({pot_lbl}={ec_disp:.3g})'
                    if group_col
                    else f'4PL fit ({pot_lbl}={ec_disp:.3g}, Hill={s_val:.2g})'
                )
            else:
                lbl_str = (
                    f'{_safe_label(g_lbl, 14)} (V1/2={mid_val:.3g})'
                    if group_col
                    else f'Boltzmann (V1/2={mid_val:.3g}, k={s_val:.2g})'
                )
            ax.plot(x_grid, y_hat, color=color, lw=1.7, label=lbl_str, zorder=4)
            if show_ribbon and np.all(np.isfinite(ci_l)) and np.all(np.isfinite(ci_h)):
                ax.fill_between(x_grid, ci_l, ci_h, color=color, alpha=0.14, linewidth=0, zorder=1)

            # Midpoint drop-line
            mid_x = (mid_val if x_is_log10 else (10.0 ** mid_val)) if curve_mode == 'hill' else mid_val
            mid_y = 0.5 * (float(fit_g['params'][0]) + float(fit_g['params'][1]))
            if float(np.min(x_grid)) <= mid_x <= float(np.max(x_grid)):
                ax.plot([mid_x], [mid_y], marker='o', markersize=4.2, color='#111111', zorder=5)
                ax.axvline(mid_x, color=color, lw=0.75, linestyle=':', alpha=0.65, zorder=1)
            fitted_ok = True
        except ValueError:
            pass

        ax.scatter(m_xs, m_ys, s=26, marker=marker, color=color, edgecolors='white', linewidths=0.45,
                   label=(None if fitted_ok else lbl_str), zorder=4)
        if has_eb:
            ax.errorbar(m_xs, m_ys, yerr=np.array([e_lo, e_hi]), fmt='none', ecolor=color,
                        elinewidth=1.0, capsize=2.8, capthick=0.8, alpha=0.88, zorder=4)

    if use_log_scale and len(pos_all) > 0:
        ax.set_xscale('log')
        all_disp_x = np.where(xs_np[valid_m] == 0.0, zero_plot_x, xs_np[valid_m])
        lo_lx = math.log10(max(float(np.min(all_disp_x)), 1e-30))
        hi_lx = math.log10(max(float(np.max(all_disp_x)), 1e-30))
        pad_lx = max(0.09 * (hi_lx - lo_lx), 0.15)
        ax.set_xlim(10.0 ** (lo_lx - pad_lx), 10.0 ** (hi_lx + pad_lx))

    _apply_y_bounds(ax, style)

    # Multi-group extra-sum-of-squares F-test callout
    p_mode = style.get('p_display', 'none')
    is_narrow = float(style.get('width_mm', 140)) <= 105.0
    if p_mode != 'none' and isinstance(result, dict):
        for tbl in result.get('tables') or []:
            if tbl.get('title') == 'Curve midpoint comparison' and tbl.get('rows'):
                crow = tbl['rows'][0]
                pv = crow.get('p')
                if isinstance(pv, (int, float)) and math.isfinite(float(pv)):
                    tag_prefix = 'EC50 shift p' if curve_mode == 'hill' else 'ΔV1/2 p'
                    lbl_c = _format_p_label(float(pv), p_mode, prefix=tag_prefix)
                    ax.text(
                        0.03, 0.96, lbl_c, transform=ax.transAxes, ha='left', va='top',
                        fontsize=max(7.2 if is_narrow else 8.0, style['font_size'] - 0.8), color='#111111',
                        bbox={'facecolor': 'white', 'alpha': 0.82, 'edgecolor': 'none', 'pad': 1.5}, zorder=6,
                    )
                break

    ax.legend(frameon=False, fontsize=max(7.0 if is_narrow else 8.0, style['font_size'] - (1.0 if is_narrow else 0.6)), loc='lower right' if curve_mode == 'hill' else 'best')
    default_xl = f'{x_col} (log10)' if (use_log_scale and is_narrow) else (f'{x_col} (log10 scale)' if use_log_scale else x_col)
    ax.set_xlabel(style.get('xlabel', _safe_label(default_xl, 30 if is_narrow else 45)))
    ax.set_ylabel(style.get('ylabel', _safe_label(y_col, 26 if is_narrow else 34)))
    kind_t = ('4PL Hill' if is_narrow else '4PL Hill dose–response') if curve_mode == 'hill' else 'Boltzmann curve'
    ax.set_title(_safe_label(style.get('title') or f'{kind_t}: {y_col} vs {x_col}', 34 if is_narrow else 60), loc='left', pad=12)
    return f'{kind_t} nonlinear least-squares fit' + ('; 95% delta-method confidence band' if show_ribbon else '')


def _default_plot_for(method: str, plan: dict) -> str:
    if method == 'survival':
        return 'survival'
    if method == 'dose_response':
        return 'dose_response'
    if method == 'boltzmann':
        return 'boltzmann'
    if method in {'timecourse_compare', 'two_way_anova'}:
        return 'timecourse'
    if plan.get('pool_by') and method in {'ttest', 'anova', 'mannwhitney', 'kruskal', 'batch_compare'}:
        return 'superplot'
    if method in {'paired_t', 'wilcoxon', 'rm_anova', 'friedman'}:
        return 'paired'
    if method in ('pearson', 'spearman', 'regression'):
        return 'scatter'
    if method in {'chi2', 'fisher_exact'}:
        return 'heatmap'
    if method in ('mannwhitney', 'kruskal') or (method == 'batch_compare' and plan.get('test') in {'mannwhitney', 'kruskal'}):
        return 'box'
    return 'distribution'


@_serialized_render
def make_figure(dataset, result: dict, plan: dict, style: dict | None = None) -> Figure:
    if result.get('method') == 'study_execution':
        from .study_figures import make_figure as make_study_figure
        return make_study_figure(dataset, result, plan, style)
    if getattr(dataset, 'kind', None) == 'large_table':
        from .large_figures import make_large_figure
        return make_large_figure(dataset, result, plan, style)
    if getattr(dataset, 'kind', None) == 'recording':
        if result.get('method') == 'action_potentials':
            from .ap_figures import make_ap_figure
            return make_ap_figure(dataset, result, plan, style)
        if result.get('method') == 'spikes':
            from .spike_figures import make_spike_figure
            return make_spike_figure(dataset, result, plan, style)
        from .trace_figures import make_trace_figure
        return make_trace_figure(dataset, plan, style)
    """Create a fixed-size Matplotlib figure without modifying source data."""
    settings = _style(plan, style)
    frame = _selected_frame(dataset, result)
    if frame.empty or not len(frame.columns):
        raise ValueError('There are no usable observations to plot.')
    method = result.get('method', plan.get('method', 'describe'))
    plot = plan.get('plot') or _default_plot_for(method, plan)
    if plot not in PLOT_TYPES:
        raise ValueError(f'Unsupported figure type: {plot}.')
    colors = _resolve_palette_colors(settings)
    t_spec = _theme_spec(settings)
    font_name = FONT_FAMILY_MAP.get(settings.get('font_family', 'sans'), 'DejaVu Sans')
    theme = dict(
        RC,
        **{
            'font.family': font_name,
            'font.size': settings['font_size'],
            'text.color': t_spec['fg'],
            'axes.labelcolor': t_spec['label_fg'],
            'axes.edgecolor': t_spec['spine_fg'],
            'xtick.color': t_spec['spine_fg'],
            'ytick.color': t_spec['spine_fg'],
            'figure.facecolor': t_spec['fig_fc'],
            'axes.facecolor': t_spec['ax_fc'],
            'savefig.facecolor': t_spec['fig_fc'],
        },
    )
    with mpl.rc_context(theme):
        fig = Figure(figsize=(settings['width_mm'] / 25.4, settings['height_mm'] / 25.4), dpi=150, layout='constrained', facecolor=t_spec['fig_fc'])
        fig.get_layout_engine().set(w_pad=.10, h_pad=.10, wspace=.12, hspace=.12)

        if method == 'batch_compare':
            batch_cols = _numeric_columns(frame, plan)
            if len(batch_cols) < 2:
                raise ValueError('batch_compare requires at least two numeric outcome columns.')
            if len(batch_cols) > 12:
                raise ValueError('batch_compare supports at most 12 outcome panels per figure.')
            if plot not in {'distribution', 'box', 'violin', 'raincloud', 'bar', 'superplot'}:
                raise ValueError('batch_compare figures support distribution, superplot, raincloud, box, violin, or bar panels.')
            ncols = 2 if len(batch_cols) <= 4 else 3 if len(batch_cols) <= 9 else 4
            nrows = math.ceil(len(batch_cols) / ncols)
            axes = fig.subplots(nrows, ncols, squeeze=False).ravel()
            sub_method = plan.get('test') or ('mannwhitney' if plan.get('nonparametric') else 'ttest')
            for i, name in enumerate(batch_cols):
                subplan = dict(plan, method=sub_method, y=name, columns=[name])
                substyle = {k: v for k, v in settings.items() if k not in {'title', 'ylabel'}}
                if plot == 'superplot':
                    _superplot(axes[i], frame, subplan, substyle, colors, result=result, variable=name)
                else:
                    _distribution(axes[i], frame, subplan, substyle, colors, plot, result=result, variable=name)
                axes[i].set_title(_safe_label(name, 26), loc='left', pad=8)
                _axes_style(axes[i], settings['font_size'], settings)
            for ax in axes[len(batch_cols):]:
                ax.remove()
            if settings.get('title'):
                fig.suptitle(_safe_label(settings['title'], 70), fontsize=settings['font_size'] + 1.2, fontweight='semibold', color=t_spec['fg'])
            footer = f'Multi-endpoint comparison across {len(batch_cols)} measures in original units; Holm–Bonferroni adjusted p-values used when displayed'
        else:
            multi_columns = _numeric_columns(frame, plan) if method == 'describe' and not plan.get('group') and plot in {'distribution', 'histogram', 'ecdf', 'box', 'violin', 'raincloud'} else []
            if len(multi_columns) > 1:
                if len(multi_columns) > 6:
                    raise ValueError('More than six numeric columns are available. Name the columns you want in this figure, or request a correlation heatmap.')
                ncols = 2 if len(multi_columns) <= 4 else 3
                nrows = math.ceil(len(multi_columns) / ncols)
                axes = fig.subplots(nrows, ncols, squeeze=False).ravel()
                for i, name in enumerate(multi_columns):
                    subplan = dict(plan, y=name, columns=[name])
                    substyle = {k: v for k, v in settings.items() if k != 'title'}
                    if plot in {'histogram', 'ecdf'}:
                        _hist_or_ecdf(axes[i], frame, subplan, substyle, colors, plot)
                    else:
                        _distribution(axes[i], frame, subplan, substyle, colors, plot, result=result, variable=name)
                    axes[i].set_title(_safe_label(name, 28), loc='left', pad=9)
                    _axes_style(axes[i], settings['font_size'], settings)
                for ax in axes[len(multi_columns):]:
                    ax.remove()
                if settings.get('title'):
                    fig.suptitle(_safe_label(settings['title'], 70), fontsize=settings['font_size'] + 1.2, fontweight='semibold', color=t_spec['fg'])
                footer = 'Separate scales and original units by column; all finite observations shown'
            else:
                ax = fig.subplots()
                if plot == 'survival':
                    footer = _survival_curve(ax, frame, result, plan, settings, colors)
                elif plot == 'dose_response':
                    footer = _nonlinear_curve_plot(ax, frame, result, plan, settings, colors, curve_mode='hill')
                elif plot == 'boltzmann':
                    footer = _nonlinear_curve_plot(ax, frame, result, plan, settings, colors, curve_mode='boltzmann')
                elif plot == 'timecourse':
                    footer = _timecourse(ax, frame, result, plan, settings, colors)
                elif plot == 'spaghetti':
                    footer = _spaghetti(ax, frame, result, plan, settings, colors)
                elif plot == 'grouped_bar':
                    footer = _grouped_two_way(ax, frame, result, plan, settings, colors, kind='bar')
                elif plot == 'grouped_box':
                    footer = _grouped_two_way(ax, frame, result, plan, settings, colors, kind='box')
                elif plot == 'grouped_violin':
                    footer = _grouped_two_way(ax, frame, result, plan, settings, colors, kind='violin')
                elif plot == 'line' and (
                    plan.get('group')
                    or (plan.get('x') in frame.columns and _numbers(frame[plan['x']]).dropna().empty)
                ):
                    footer = _timecourse(ax, frame, result, plan, settings, colors)
                elif plot in {'scatter', 'line'}:
                    footer = _scatter(ax, frame, result, plan, settings, colors, line=plot == 'line')
                elif plot == 'paired':
                    footer = _paired(ax, frame, plan, settings, colors, result=result)
                elif plot == 'heatmap':
                    footer = _heatmap(ax, fig, frame, result, plan, settings)
                elif plot in {'histogram', 'ecdf'}:
                    footer = _hist_or_ecdf(ax, frame, plan, settings, colors, plot)
                elif plot == 'superplot':
                    footer = _superplot(ax, frame, plan, settings, colors, result=result)
                elif not _numeric_columns(frame, plan):
                    footer = _categorical(ax, frame, plan, settings, colors)
                else:
                    footer = _distribution(ax, frame, plan, settings, colors, plot, result=result)
                if plot != 'heatmap':
                    _axes_style(ax, settings['font_size'], settings)
                else:
                    ax.title.set_color(t_spec['fg'])
                    ax.xaxis.label.set_color(t_spec['label_fg'])
                    ax.yaxis.label.set_color(t_spec['label_fg'])
                    ax.tick_params(colors=t_spec['spine_fg'])
                    for lbl in (*ax.get_xticklabels(), *ax.get_yticklabels()):
                        lbl.set_color(t_spec['label_fg'])

        # Extra metadata is deliberately outside the plotting area. Long
        # captions belong in the companion caption.txt, not tiny figure text.
        fig._statweave_style = settings
        fig._statweave_footer = footer
        fig._statweave_caption = figure_caption(dataset, result, plan, settings)
        FigureCanvasAgg(fig).draw()
        _assert_not_clipped(fig)
        return fig


def _assert_not_clipped(fig):
    """Refuse exports where titles, suptitles, legends, or axis labels leave the fixed-size page."""
    renderer = fig.canvas.get_renderer()
    bounds = fig.bbox
    extra_texts = []
    if getattr(fig, '_suptitle', None) is not None:
        extra_texts.append(fig._suptitle)
    for legend in list(getattr(fig, 'legends', [])):
        if legend is not None and legend.get_visible():
            extra_texts.extend(legend.get_texts())
    for ax in fig.axes:
        xmin, xmax = sorted(ax.get_xlim())
        ymin, ymax = sorted(ax.get_ylim())
        xtexts = [text for text in ax.get_xticklabels() if xmin <= text.get_position()[0] <= xmax]
        ytexts = [text for text in ax.get_yticklabels() if ymin <= text.get_position()[1] <= ymax]
        legend = ax.get_legend()
        leg_texts = list(legend.get_texts()) if legend is not None and legend.get_visible() else []
        texts = [ax.title, ax._left_title, ax._right_title, ax.xaxis.label, ax.yaxis.label, *xtexts, *ytexts, *leg_texts]
        for text in texts:
            if text is None or not text.get_visible() or not text.get_text():
                continue
            box = text.get_window_extent(renderer)
            if box.x0 < bounds.x0 - 1 or box.y0 < bounds.y0 - 1 or box.x1 > bounds.x1 + 1 or box.y1 > bounds.y1 + 1:
                raise ValueError('A figure label extends outside the page. Increase width/height or shorten the label before exporting.')
    for text in extra_texts:
        if text is None or not text.get_visible() or not text.get_text():
            continue
        box = text.get_window_extent(renderer)
        if box.x0 < bounds.x0 - 1 or box.y0 < bounds.y0 - 1 or box.x1 > bounds.x1 + 1 or box.y1 > bounds.y1 + 1:
            raise ValueError('A figure title or legend extends outside the page. Increase width/height or shorten the label before exporting.')


@_serialized_render
def export_figure(fig: Figure, path, dpi=600) -> str:
    """Export editable vector or high-resolution raster at exact page size."""
    target = Path(path).expanduser().resolve()
    suffix = target.suffix.lower()
    if suffix not in {'.pdf', '.svg', '.png', '.tif', '.tiff'}:
        raise ValueError('Export figures as PDF, SVG, PNG, or TIFF.')
    try: dpi = int(dpi)
    except (ValueError, TypeError): raise ValueError('Resolution must be a number from 72 to 1200 dpi.') from None
    if not 72 <= dpi <= 1200: raise ValueError('Resolution must be 72–1200 dpi.')
    target.parent.mkdir(parents=True, exist_ok=True)
    with mpl.rc_context(RC):
        if hasattr(fig.canvas, 'get_renderer'):
            fig.canvas.draw()
            _assert_not_clipped(fig)
        metadata = {'Creator': f'StatWeave {__version__}'} if suffix == '.pdf' else {'Creator': f'StatWeave {__version__}', 'Date': None} if suffix == '.svg' else None
        fig.savefig(str(target), dpi=dpi, bbox_inches=None, metadata=metadata, **figure_savefig_kwargs(fig))
    return str(target)


def figure_caption(dataset, result: dict, plan: dict, style: dict | None = None) -> str:
    if result.get('method') == 'study_execution':
        from .study_figures import figure_caption as study_caption
        return study_caption(dataset, result, plan, style)
    if getattr(dataset, 'kind', None) == 'large_table':
        from .large_figures import large_caption
        return large_caption(dataset, result, plan, style)
    if getattr(dataset, 'kind', None) == 'recording':
        if result.get('method') == 'action_potentials':
            from .ap_figures import ap_caption
            return ap_caption(dataset, result, plan, style)
        if result.get('method') == 'spikes':
            from .spike_figures import spike_caption
            return spike_caption(dataset, result, plan, style)
        from .trace_figures import trace_caption
        return trace_caption(dataset, plan, style)
    """Explain observations, summary, intervals, and source-row accounting."""
    settings = _style(plan, style)
    accounting = result.get('row_accounting') or {}
    total = accounting.get('total', len(dataset.df))
    used = accounting.get('used', total)
    omitted = accounting.get('omitted', total - used)
    method = result.get('method', plan.get('method', 'describe'))
    plot = plan.get('plot') or _default_plot_for(method, plan)
    eb_mode = settings.get('error_bar', 'ci' if settings.get('ci', True) else 'none')
    allow_inferential = plan.get('design') == 'independent' and method not in {'mannwhitney', 'kruskal'}

    if plot == 'paired':
        body = 'Matched observations; lines connect measurements from the same unit across conditions. Only complete matched blocks are displayed.'
    elif plot == 'dose_response':
        body = f'Four-parameter logistic (4PL Hill) concentration–response curve of {plan.get("y", "response")} versus {plan.get("x", "concentration")}.'
        if settings.get('ci', True) and plan.get('design') == 'independent':
            body += ' Shaded bands show pointwise 95% delta-method confidence intervals around the fitted curve.'
    elif plot == 'boltzmann':
        body = f'Four-parameter Boltzmann voltage-dependence curve of {plan.get("y", "response")} versus {plan.get("x", "voltage")}.'
        if settings.get('ci', True) and plan.get('design') == 'independent':
            body += ' Shaded bands show pointwise 95% delta-method confidence intervals around the fitted curve.'
    elif plot == 'survival':
        body = f'Kaplan–Meier product-limit survival curves of {plan.get("x", "follow-up time")} (event indicator: {plan.get("y", "status")})'
        body += f' stratified by {plan["group"]}.' if plan.get('group') else '.'
        if eb_mode == 'ci' and settings.get('ci', True) and plan.get('design') == 'independent':
            body += ' Shaded step bands show pointwise 95% Greenwood confidence intervals on the log(-log) scale.'
        if settings.get('show_points', True):
            body += ' Plus (+) tick marks denote right-censored observations.'
    elif plot == 'superplot':
        pool_col = plan.get('pool_by', 'unit')
        pool_stat = plan.get('pool_stat', 'mean')
        body = f'Superplot stratified by {pool_col}: translucent background symbols show individual observations (n), and bold outlined symbols show {pool_col}-level {pool_stat}s (N).'
        if eb_mode == 'ci' and allow_inferential:
            body += f' Error bars show two-sided 95% Student t confidence intervals computed across {pool_col} units (N), not pooled technical observations.'
        elif eb_mode == 'sem' and allow_inferential:
            body += f' Error bars show ±1 SEM computed across {pool_col} units (N).'
        elif eb_mode == 'sd':
            body += f' Error bars show ±1 SD across {pool_col} units (N).'
        elif eb_mode == 'iqr':
            body += f' Marks and bars show the median and interquartile range (Q1–Q3) across {pool_col} units (N).'
    elif plot == 'scatter':
        body = f'{plan.get("y", "Outcome")} plotted against {plan.get("x", "predictor")}; each point is one complete observation.'
        if method == 'regression':
            body += ' The line is a one-predictor ordinary least-squares fit.'
            if settings['ci'] and plan.get('design') == 'independent':
                body += ' Shading is the pointwise 95% t confidence interval for the fitted mean (not a prediction interval).'
    elif plot == 'timecourse' or (plot == 'line' and (plan.get('group') or (plan.get('x') in dataset.df.columns and _numbers(dataset.df[plan['x']]).dropna().empty))):
        body = f'Group trajectories of {plan.get("y", "outcome")} across {plan.get("x", "timepoint")}.'
        if eb_mode == 'iqr':
            body += ' Connected symbols show group medians and error bars span interquartile ranges (Q1–Q3).'
        elif eb_mode == 'ci' and allow_inferential:
            body += ' Connected symbols show group means with two-sided 95% Student t confidence intervals.'
        elif eb_mode == 'sem' and allow_inferential:
            body += ' Connected symbols show group means ± 1 SEM.'
        elif eb_mode == 'sd':
            body += ' Connected symbols show group means ± 1 SD.'
        else:
            body += ' Connected symbols show group arithmetic means.'
        if settings['show_points']:
            body += ' Translucent symbols show individual observations at each stratum.'
    elif plot == 'spaghetti':
        subj = plan.get('subject') or plan.get('pool_by') or 'subject'
        body = f'Individual longitudinal trajectories ({subj}) across {plan.get("x", "timepoint")}, overlaid with bold group mean trajectories.'
    elif plot == 'grouped_bar':
        body = f'Dodged group bars of {plan.get("y", "outcome")} stratified by {plan.get("x", "stratum")} and {plan.get("group", "group")}.'
    elif plot == 'grouped_box':
        body = f'Dodged quartile box plots of {plan.get("y", "outcome")} stratified by {plan.get("x", "stratum")} and {plan.get("group", "group")}; whiskers extend within 1.5 IQR.'
    elif plot == 'grouped_violin':
        body = f'Dodged Gaussian-kernel density violins and medians of {plan.get("y", "outcome")} stratified by {plan.get("x", "stratum")} and {plan.get("group", "group")}.'
    elif plot == 'raincloud':
        body = 'Raincloud plots display half-violin kernel density estimates on the right, median and interquartile range boxes at center, and individual jittered observations on the left.'
    elif plot == 'line':
        body = 'Observed values connected in numeric x order; no smoothing or interpolation beyond straight segments.'
    elif plot == 'heatmap':
        body = 'Cells show observed contingency counts.' if method in {'chi2', 'fisher_exact'} else 'Cells show descriptive Pearson correlations using pairwise complete numeric observations. Pair-specific sample sizes may differ; no significance tests are implied.'
    elif plot == 'histogram':
        body = 'Histograms use shared, data-derived bin boundaries; vertical values are observation counts.'
    elif plot == 'ecdf':
        body = 'Empirical cumulative distributions show the proportion of observations at or below each value.'
    elif plot == 'box':
        body = 'Boxes show the first and third quartiles, with the median inside; whiskers extend to the last observed value within 1.5 interquartile ranges. Values beyond the whiskers are retained.'
    elif plot == 'violin':
        body = 'Violins show Gaussian-kernel density estimates for groups with at least two nonconstant values; black marks show medians. Individual observations are retained.'
    else:
        if eb_mode == 'iqr':
            body = 'Black horizontal marks show medians; error bars span the interquartile range (Q1–Q3).'
        else:
            body = 'Black horizontal marks show arithmetic means.'
            if eb_mode == 'ci' and allow_inferential:
                body += ' Error bars show two-sided 95% Student t confidence intervals of each group mean, when n ≥ 2; these are not confidence intervals of between-group differences.'
            elif eb_mode == 'sem' and allow_inferential:
                body += ' Error bars show ±1 standard error of the mean (SEM) for each group when n ≥ 2.'
            elif eb_mode == 'sd':
                body += ' Error bars show ±1 sample standard deviation (SD) for each group when n ≥ 2.'
            else:
                body += ' No inferential confidence intervals are shown because independence has not been established, the method is rank based, or intervals were disabled.'

    if plot != 'superplot':
        if settings['show_points'] and plot in {'distribution', 'box', 'violin', 'bar'}:
            body += ' Each dot is an individual observation (or pooled unit summary when pool_by is active). Horizontal offsets are assigned independently of measured values to separate dots; they have no quantitative meaning.'
        elif not settings['show_points'] and plot in {'distribution', 'box', 'violin', 'bar'}:
            body += ' Individual-point display was explicitly disabled; source observations remain in the saved project.'
    if settings.get('p_display', 'none') != 'none':
        has_posthoc_tbl = any((t.get('title') == 'Post-hoc pairwise comparisons' and t.get('rows')) for t in (result.get('tables') or []))
        if method == 'batch_compare':
            body += ' Displayed comparison brackets report Holm–Bonferroni multiplicity-adjusted p-values across the batch of endpoints.'
        elif has_posthoc_tbl:
            body += ' Displayed pairwise brackets report multiplicity-adjusted post-hoc p-values.'
        elif method in {'timecourse_compare', 'two_way_anova'}:
            body += ' Per-stratum markers report Holm–Bonferroni multiplicity-adjusted p-values across strata.'
            if method == 'two_way_anova':
                body += ' Overall Group, Stratum, and Interaction effects come from the two-way OLS ANOVA.'
        else:
            body += ' Displayed bracket p-value comes directly from the executed statistical test.'
    if method == 'describe':
        body += ' Nonmissing finite values are used separately for each variable; n labels are variable/group-specific and do not establish independent experimental units.'
    body += f' Source rows: {total} total, {used} contributing, {omitted} not contributing to this analysis.'
    if omitted:
        body += ' Reasons and source row identifiers are listed in the analysis record; no automatic outlier removal is performed.'
    else:
        body += ' No source rows were removed from the analysis.'
    if plan.get('pool_by'):
        body += f' Biological/cluster unit column: {plan["pool_by"]} ({plan.get("pool_stat", "mean")}).'
    elif plan.get('subject'):
        body += f' Unit identifier: {plan["subject"]}.'
    body += f' Figure: {settings["width_mm"]:g} × {settings["height_mm"]:g} mm.'
    return body
