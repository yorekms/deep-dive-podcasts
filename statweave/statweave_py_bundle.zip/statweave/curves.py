"""Deterministic 4-parameter logistic (4PL Hill) dose-response and Boltzmann voltage-dependence curve fitting."""
from __future__ import annotations

import math
from typing import Any

import numpy as np
from scipy import optimize, stats

_LN10 = math.log(10.0)


def _sigmoid_eval_and_jac(
    u: np.ndarray,
    is_zero_dose: np.ndarray,
    params: np.ndarray,
    mode: str,
) -> tuple[np.ndarray, np.ndarray]:
    """Evaluate 4-parameter sigmoid f(u) and analytical Jacobian df/d(bottom, top, mid, slope_param).

    For mode == 'hill':
      f(u) = bottom + (top - bottom) / (1 + 10^((mid - u) * hill))
           = bottom + (top - bottom) / (1 + exp((mid - u) * hill * ln(10)))
    For mode == 'boltzmann':
      f(V) = bottom + (top - bottom) / (1 + exp((v_half - V) / k))
    """
    bottom, top, mid, s_par = (float(params[0]), float(params[1]), float(params[2]), float(params[3]))
    span = top - bottom
    n = len(u)
    yhat = np.empty(n, dtype=float)
    jac = np.zeros((n, 4), dtype=float)

    pos_mask = ~is_zero_dose
    if np.any(pos_mask):
        u_p = u[pos_mask]
        if mode == 'hill':
            z = np.clip((mid - u_p) * s_par * _LN10, -500.0, 500.0)
        else:
            k_safe = s_par if abs(s_par) > 1e-9 else (1e-9 if s_par >= 0 else -1e-9)
            z = np.clip((mid - u_p) / k_safe, -500.0, 500.0)

        # Stable logistic: g = 1 / (1 + exp(z))
        g = np.where(z >= 0.0, np.exp(-z) / (1.0 + np.exp(-z)), 1.0 / (1.0 + np.exp(z)))
        dg_dz = -g * (1.0 - g)
        yhat[pos_mask] = bottom + span * g

        jac[pos_mask, 0] = 1.0 - g
        jac[pos_mask, 1] = g
        if mode == 'hill':
            jac[pos_mask, 2] = span * dg_dz * (s_par * _LN10)
            jac[pos_mask, 3] = span * dg_dz * ((mid - u_p) * _LN10)
        else:
            k_safe = s_par if abs(s_par) > 1e-9 else (1e-9 if s_par >= 0 else -1e-9)
            jac[pos_mask, 2] = span * dg_dz * (1.0 / k_safe)
            jac[pos_mask, 3] = span * dg_dz * (-(mid - u_p) / (k_safe * k_safe))

    if np.any(is_zero_dose):
        # As concentration X -> 0 (u -> -inf):
        # if slope > 0, z -> +inf => g -> 0 => f -> bottom
        # if slope < 0, z -> -inf => g -> 1 => f -> top
        if s_par >= 0.0:
            yhat[is_zero_dose] = bottom
            jac[is_zero_dose, 0] = 1.0
        else:
            yhat[is_zero_dose] = top
            jac[is_zero_dose, 1] = 1.0

    return yhat, jac


def _initial_guesses(u: np.ndarray, y: np.ndarray, is_zero_dose: np.ndarray, mode: str) -> list[np.ndarray]:
    y_min = float(np.min(y))
    y_max = float(np.max(y))
    y_rng = max(y_max - y_min, 1e-6)
    b0 = y_min - 0.02 * y_rng
    t0 = y_max + 0.02 * y_rng

    u_pos = u[~is_zero_dose]
    y_pos = y[~is_zero_dose]
    u_min = float(np.min(u_pos))
    u_max = float(np.max(u_pos))
    u_mid_default = 0.5 * (u_min + u_max)
    u_span = max(u_max - u_min, 1e-3)

    # Determine overall trend direction
    if len(u_pos) >= 3 and np.ptp(u_pos) > 0:
        r_corr = float(np.corrcoef(u_pos, y_pos)[0, 1])
        sign = 1.0 if (not math.isfinite(r_corr) or r_corr >= 0.0) else -1.0
    else:
        sign = 1.0

    # Logit self-starter on interior observations
    prop = np.clip((y_pos - b0) / max(t0 - b0, 1e-9), 0.03, 0.97)
    logit_y = np.log(prop / (1.0 - prop))  # = -z
    mid_est = u_mid_default
    slope_est = sign * (1.0 if mode == 'hill' else max(u_span / 6.0, 1.0))

    if len(u_pos) >= 3 and np.ptp(u_pos) > 0:
        slope_lin, intercept_lin = np.polyfit(u_pos, logit_y, 1)
        if abs(slope_lin) > 1e-6 and math.isfinite(slope_lin):
            cand_mid = -intercept_lin / slope_lin
            if (u_min - u_span) <= cand_mid <= (u_max + u_span):
                mid_est = float(cand_mid)
            if mode == 'hill':
                slope_est = float(np.clip(slope_lin / _LN10, -8.0, 8.0))
                if abs(slope_est) < 0.15:
                    slope_est = 0.8 * sign
            else:
                k_cand = 1.0 / slope_lin
                slope_est = float(np.clip(k_cand, -80.0, 80.0))

    guesses = [
        np.array([b0, t0, mid_est, slope_est], dtype=float),
        np.array([y_min, y_max, u_mid_default, sign * (1.0 if mode == 'hill' else max(u_span / 8.0, 4.0))], dtype=float),
        np.array([y_min, y_max, u_mid_default, -sign * (1.0 if mode == 'hill' else max(u_span / 8.0, 4.0))], dtype=float),
    ]
    return guesses


def fit_four_param_curve(
    u: np.ndarray,
    y: np.ndarray,
    is_zero_dose: np.ndarray,
    mode: str,
) -> dict[str, Any]:
    """Fit 4PL ('hill') or Boltzmann ('boltzmann') curve via exact Gauss-Newton / TRF nonlinear least squares."""
    n = len(y)
    n_distinct_x = len(np.unique(np.where(is_zero_dose, -1e99, u)))
    if n < 5 or n_distinct_x < 4:
        label = '4-parameter logistic (4PL) dose-response' if mode == 'hill' else '4-parameter Boltzmann'
        raise ValueError(
            f"{label} fitting requires at least 5 observations across at least 4 distinct predictor levels "
            f"(found n = {n}, distinct x levels = {n_distinct_x})."
        )
    if float(np.ptp(y)) <= 0.0:
        raise ValueError("Response values are constant; nonlinear sigmoid parameters are unidentifiable.")

    u_pos = u[~is_zero_dose]
    u_min, u_max = float(np.min(u_pos)), float(np.max(u_pos))
    u_span = max(u_max - u_min, 1.0)
    y_min, y_max = float(np.min(y)), float(np.max(y))
    y_span = max(y_max - y_min, 1.0)

    # Wide physiological/pharmacological bounds prevent runaway divergence on noisy small-n data
    # while leaving interior MLE/NLS solutions completely unconstrained (matching R SSfpl).
    lb = np.array([
        y_min - 5.0 * y_span,
        y_min - 2.0 * y_span,
        u_min - 4.0 * u_span,
        -25.0 if mode == 'hill' else -500.0,
    ], dtype=float)
    ub = np.array([
        y_max + 2.0 * y_span,
        y_max + 5.0 * y_span,
        u_max + 4.0 * u_span,
        25.0 if mode == 'hill' else 500.0,
    ], dtype=float)

    def fun_res(p: np.ndarray) -> np.ndarray:
        yhat, _ = _sigmoid_eval_and_jac(u, is_zero_dose, p, mode)
        return yhat - y

    def fun_jac(p: np.ndarray) -> np.ndarray:
        _, jac = _sigmoid_eval_and_jac(u, is_zero_dose, p, mode)
        return jac

    best_sol = None
    best_cost = math.inf
    for p0 in _initial_guesses(u, y, is_zero_dose, mode):
        p0_clip = np.clip(p0, lb + 1e-7, ub - 1e-7)
        try:
            sol = optimize.least_squares(
                fun_res,
                p0_clip,
                jac=fun_jac,
                bounds=(lb, ub),
                method='trf',
                ftol=1e-13,
                xtol=1e-13,
                gtol=1e-13,
                max_nfev=4000,
            )
            if sol.cost < best_cost and np.all(np.isfinite(sol.x)):
                best_cost = float(sol.cost)
                best_sol = sol
        except Exception:
            continue

    if best_sol is None:
        raise ValueError("Nonlinear least-squares optimization failed to converge on these observations.")

    theta = np.asarray(best_sol.x, dtype=float)
    # Canonicalize so bottom <= top: swapping (bottom, top) and negating slope gives the exact same curve!
    if theta[0] > theta[1]:
        theta = np.array([theta[1], theta[0], theta[2], -theta[3]], dtype=float)
        # Re-polish from canonical orientation
        theta_clip = np.clip(theta, lb + 1e-7, ub - 1e-7)
        try:
            pol = optimize.least_squares(
                fun_res, theta_clip, jac=fun_jac, bounds=(lb, ub),
                method='trf', ftol=1e-14, xtol=1e-14, gtol=1e-14, max_nfev=2000,
            )
            if pol.cost <= best_cost * (1.0 + 1e-10):
                theta = np.asarray(pol.x, dtype=float)
        except Exception:
            pass

    yhat, jac = _sigmoid_eval_and_jac(u, is_zero_dose, theta, mode)
    resid = y - yhat
    rss = float(np.sum(resid * resid))
    tss = float(np.sum((y - float(np.mean(y))) ** 2))
    r_sq = 1.0 - (rss / tss) if tss > 0 else None
    df_res = n - 4
    s2 = rss / df_res if df_res > 0 else math.nan
    sigma_res = math.sqrt(s2) if (df_res > 0 and s2 >= 0) else None

    # SVD pseudoinverse for covariance = s^2 * (J^T J)^+
    cov = np.full((4, 4), math.nan, dtype=float)
    se = np.full(4, math.nan, dtype=float)
    if df_res > 0 and math.isfinite(s2):
        try:
            u_svd, s_vals, vt_svd = np.linalg.svd(jac, full_matrices=False)
            tol = max(jac.shape) * np.finfo(float).eps * (float(s_vals[0]) if len(s_vals) else 1.0)
            inv_s2 = np.where(s_vals > tol, 1.0 / (s_vals * s_vals), 0.0)
            jtj_inv = (vt_svd.T * inv_s2) @ vt_svd
            cov = s2 * jtj_inv
            diag = np.diag(cov)
            se = np.where(diag >= 0.0, np.sqrt(diag), math.nan)
        except np.linalg.LinAlgError:
            pass

    t_crit = float(stats.t.ppf(0.975, df_res)) if df_res > 0 else math.nan
    ci_low = theta - t_crit * se if math.isfinite(t_crit) else np.full(4, math.nan)
    ci_high = theta + t_crit * se if math.isfinite(t_crit) else np.full(4, math.nan)

    return {
        'params': theta,  # [bottom, top, mid, slope_or_k]
        'se': se,
        'ci_low': ci_low,
        'ci_high': ci_high,
        'cov': cov,
        'n': n,
        'df_residual': df_res,
        'rss': rss,
        'r_squared': r_sq,
        'residual_sd': sigma_res,
        't_crit': t_crit,
        'converged': bool(best_sol.success),
    }


def predict_curve_grid(
    fit: dict[str, Any],
    u_grid: np.ndarray,
    mode: str,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Evaluate fitted curve and pointwise 95% delta-method confidence band on u_grid."""
    zeros = np.zeros(len(u_grid), dtype=bool)
    yhat, jac = _sigmoid_eval_and_jac(u_grid, zeros, fit['params'], mode)
    cov = fit['cov']
    t_crit = fit['t_crit']
    if np.all(np.isfinite(cov)) and math.isfinite(t_crit):
        var_pred = np.einsum('ij,jk,ik->i', jac, cov, jac)
        se_pred = np.sqrt(np.maximum(var_pred, 0.0))
        lo = yhat - t_crit * se_pred
        hi = yhat + t_crit * se_pred
    else:
        lo = np.full_like(yhat, math.nan)
        hi = np.full_like(yhat, math.nan)
    return yhat, lo, hi


def compare_shared_midpoint(
    group_data: list[tuple[str, np.ndarray, np.ndarray, np.ndarray]],
    separate_fits: list[dict[str, Any]],
    mode: str,
) -> dict[str, Any] | None:
    """Extra-sum-of-squares F-test comparing group-specific midpoints (log10 EC50 or V1/2) vs a shared midpoint."""
    k = len(group_data)
    if k < 2:
        return None
    n_total = sum(len(y) for _, _, y, _ in group_data)
    df_sep = n_total - 4 * k
    df_shared = n_total - (3 * k + 1)
    if df_sep <= 0:
        return None

    rss_sep = sum(float(f['rss']) for f in separate_fits)

    # Parameter vector for reduced model: [shared_mid, b_0, t_0, s_0, b_1, t_1, s_1, ...]
    init_mids = [float(f['params'][2]) for f in separate_fits]
    p0_list = [float(np.mean(init_mids))]
    lb_list = [min(init_mids) - 15.0 * (1.0 if mode == 'hill' else 20.0)]
    ub_list = [max(init_mids) + 15.0 * (1.0 if mode == 'hill' else 20.0)]

    for (_, _u, y_g, _z), f_g in zip(group_data, separate_fits):
        b_g, t_g, _m_g, s_g = [float(x) for x in f_g['params']]
        y_min, y_max = float(np.min(y_g)), float(np.max(y_g))
        y_sp = max(y_max - y_min, 1.0)
        p0_list.extend([b_g, t_g, s_g])
        lb_list.extend([y_min - 5.0 * y_sp, y_min - 2.0 * y_sp, -25.0 if mode == 'hill' else -500.0])
        ub_list.extend([y_max + 2.0 * y_sp, y_max + 5.0 * y_sp, 25.0 if mode == 'hill' else 500.0])

    p0 = np.clip(np.asarray(p0_list, dtype=float), np.asarray(lb_list) + 1e-7, np.asarray(ub_list) - 1e-7)

    def reduced_res(vec: np.ndarray) -> np.ndarray:
        shared_mid = vec[0]
        chunks = []
        for idx, (_name, u_g, y_g, z_g) in enumerate(group_data):
            base = 1 + 3 * idx
            sub_p = np.array([vec[base], vec[base + 1], shared_mid, vec[base + 2]], dtype=float)
            yh, _ = _sigmoid_eval_and_jac(u_g, z_g, sub_p, mode)
            chunks.append(yh - y_g)
        return np.concatenate(chunks)

    try:
        sol = optimize.least_squares(
            reduced_res, p0, bounds=(np.asarray(lb_list), np.asarray(ub_list)),
            method='trf', ftol=1e-12, xtol=1e-12, gtol=1e-12, max_nfev=5000,
        )
    except Exception:
        return None

    rss_shared = float(np.sum(sol.fun * sol.fun))
    rss_diff = max(0.0, rss_shared - rss_sep)
    df_num = k - 1
    ms_sep = rss_sep / df_sep if df_sep > 0 else math.nan
    if not math.isfinite(ms_sep) or ms_sep <= 0.0:
        return None
    f_stat = (rss_diff / df_num) / ms_sep
    p_val = float(stats.f.sf(f_stat, df_num, df_sep))

    out: dict[str, Any] = {
        'test': 'Extra-sum-of-squares F-test (shared vs group-specific midpoint)',
        'groups': k,
        'shared_midpoint': float(sol.x[0]),
        'rss_shared': rss_shared,
        'rss_separate': rss_sep,
        'F': float(f_stat),
        'df_between': df_num,
        'df_within': df_sep,
        'p': p_val,
    }
    if k == 2:
        g1, g2 = group_data[0][0], group_data[1][0]
        m1, m2 = float(separate_fits[0]['params'][2]), float(separate_fits[1]['params'][2])
        se1, se2 = float(separate_fits[0]['se'][2]), float(separate_fits[1]['se'][2])
        diff = m2 - m1
        out['comparison'] = f'{g2} vs {g1}'
        out['midpoint_shift'] = diff
        if math.isfinite(se1) and math.isfinite(se2):
            se_diff = math.hypot(se1, se2)
            t_c = float(stats.t.ppf(0.975, df_sep))
            out['shift_ci_low'] = diff - t_c * se_diff
            out['shift_ci_high'] = diff + t_c * se_diff
        if mode == 'hill' and abs(diff) < 50:
            out['potency_ratio'] = 10.0 ** diff
    return out
