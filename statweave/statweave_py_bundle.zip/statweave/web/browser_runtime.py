"""Serverless in-browser (Pyodide / WebAssembly) runtime for StatWeave Workbench.

Runs the exact StatWeave scientific engine (`scipy`, `statsmodels`, `pandas`,
`numpy`, `matplotlib`, `openpyxl`, `r_learning_set`, `working_sheets`, `explore`,
`figures`, `reproduce`) inside a browser Web Worker without requiring FastAPI,
Pydantic, or a paid cloud container. Raw spreadsheets never leave client memory.
"""
from __future__ import annotations

import base64
from collections import OrderedDict
from copy import deepcopy
import io
import json
from pathlib import Path
import re
import secrets
import shutil
import sys
import tempfile
import threading
from typing import Any
from urllib.parse import urlparse
import zipfile

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt  # noqa: E402
import openpyxl  # noqa: E402

from .. import __version__  # noqa: E402
from ..api_provider import DEFAULT_MODEL, OpenAIError, OpenAIPlanner  # noqa: E402
from ..api_tools import inspect_data, safe_text, state_digest  # noqa: E402
from ..figures import figure_caption, make_figure  # noqa: E402
from ..planner import PLOTS, STYLE_KEYS  # noqa: E402
from ..scrubber import inspect_ooxml_workbook, zip_guard  # noqa: E402
from ..session import Session  # noqa: E402
from .config import sanitize_api_key  # noqa: E402
from .store import WebStore  # noqa: E402

ALLOWED_UPLOAD_SUFFIXES = {'.xlsx', '.xls', '.csv', '.tsv', '.txt', '.ods'}
_FORBIDDEN_BROWSER_HEADERS = {'user-agent', 'host', 'connection', 'content-length', 'accept-encoding', 'api-revision'}


def _is_model_unavailable_error(detail: str) -> bool:
    low = (detail or '').casefold()
    return any(phrase in low for phrase in (
        'selected openai model is unavailable',
        'check the selected model',
        'was not found for this api key',
        'rejected the request or api key',
        'permission for this model',
        'permission for this request or selected model',
    ))


class BrowserAPIError(Exception):
    def __init__(self, status: int, detail: str):
        super().__init__(detail)
        self.status = int(status)
        self.detail = str(detail)


class _WorkerHTTPResponse:
    def __init__(self, status: int, body_bytes: bytes):
        self.status = int(status)
        self._buf = io.BytesIO(body_bytes)

    def read(self, amt: int | None = None) -> bytes:
        return self._buf.read() if amt is None else self._buf.read(amt)

    def close(self) -> None:
        self._buf.close()


class _WorkerHTTPSConnection:
    """Synchronous HTTPS bridge for Dedicated Web Workers via XMLHttpRequest."""

    def __init__(self, host: str, timeout: float = 60.0):
        self.host = host
        self.timeout = max(3.0, float(timeout))
        self.sock = None
        self._response: _WorkerHTTPResponse | None = None

    def request(self, method: str, path: str, body: bytes | str | None = None, headers: dict[str, str] | None = None) -> None:
        import js  # type: ignore[import-not-found]

        url = path if path.startswith(('https://', 'http://')) else f'https://{self.host}{path}'
        xhr = js.XMLHttpRequest.new()
        xhr.open(method, url, False)
        for k, v in (headers or {}).items():
            if k.lower() in _FORBIDDEN_BROWSER_HEADERS:
                continue
            xhr.setRequestHeader(k, str(v))

        payload: str | None = None
        if isinstance(body, bytes):
            payload = body.decode('utf-8')
        elif isinstance(body, str):
            payload = body

        try:
            if payload is not None:
                xhr.send(payload)
            else:
                xhr.send()
        except Exception as exc:
            raise OpenAIError(f'Browser network request to {self.host} failed ({safe_text(str(exc), 180)}). Check internet connectivity or CORS settings.') from None

        raw_text = str(xhr.responseText or '')
        raw_bytes = raw_text.encode('utf-8')
        self._response = _WorkerHTTPResponse(int(xhr.status or 0), raw_bytes)

    def getresponse(self) -> _WorkerHTTPResponse:
        if self._response is None:
            raise OpenAIError('No HTTP response received.')
        return self._response

    def close(self) -> None:
        self._response = None


def _try_parse_chat_raw_numbers(message: str) -> dict[str, list[float]] | None:
    pattern = re.compile(
        r'([A-Za-z][A-Za-z0-9_ +/-]{0,30}?)\s*[:=]\s*([-+]?\d+(?:\.\d+)?(?:\s*[,;\s]\s*[-+]?\d+(?:\.\d+)?)+)'
    )
    groups: dict[str, list[float]] = {}
    for match in pattern.finditer(message):
        label = re.sub(r'^(?:vs\.?|versus|and)\s+', '', match.group(1).strip(), flags=re.I).strip() or f'Group_{len(groups) + 1}'
        nums = [float(x) for x in re.findall(r'[-+]?\d+(?:\.\d+)?', match.group(2))]
        if len(nums) >= 2:
            groups[label[:40]] = nums
    if len(groups) >= 1 and sum(len(v) for v in groups.values()) >= 3:
        return groups
    return None


def _build_synthetic_clampflow_workbook(target: Path) -> Path:
    wb = openpyxl.Workbook()
    ws1 = wb.active
    ws1.title = '1_Master_Wide'
    ws1.append(['Cell_ID', 'Animal_ID', 'Group', 'RMP_mV', 'Rin_MOhms', 'Rheobase_pA', 'AP_Peak_mV', 'APD50_ms', 'MaxFiringRate_Hz'])
    rows = [
        ('C01', 'M1', 'Vehicle', -68.4, 182.0, 90.0, 83.2, 1.18, 28.0),
        ('C02', 'M1', 'Vehicle', -67.1, 176.5, 95.0, 81.9, 1.21, 26.5),
        ('C03', 'M2', 'Vehicle', -69.2, 190.2, 85.0, 84.5, 1.15, 29.0),
        ('C04', 'M2', 'Vehicle', -68.0, 184.1, 90.0, 82.8, 1.19, 27.5),
        ('C05', 'M3', 'Vehicle', -66.8, 171.0, 100.0, 80.4, 1.24, 25.0),
        ('C06', 'M4', 'Drug_X', -61.5, 228.4, 55.0, 92.6, 0.91, 44.0),
        ('C07', 'M4', 'Drug_X', -60.8, 235.0, 50.0, 94.1, 0.88, 46.5),
        ('C08', 'M5', 'Drug_X', -62.1, 219.5, 60.0, 91.2, 0.94, 41.0),
        ('C09', 'M5', 'Drug_X', -60.2, 241.0, 45.0, 95.3, 0.86, 48.0),
        ('C10', 'M6', 'Drug_X', -61.9, 225.8, 55.0, 92.0, 0.92, 43.0),
    ]
    for r in rows:
        ws1.append(list(r))

    ws2 = wb.create_sheet('2_PerSweep_LONG')
    ws2.append(['Cell_ID', 'Animal_ID', 'Group', 'Sweep', 'Step_pA', 'AP_Peak_mV', 'Upstroke_Vs'])
    for cell_id, animal_id, grp, _rmp, _rin, _rheo, base_peak, _apd, _fr in rows:
        for sw, step in ((1, 100), (2, 150), (3, 200)):
            ws2.append([
                cell_id, animal_id, grp, sw, step,
                round(base_peak + (sw - 2) * 0.9, 2),
                round((135.0 if grp == 'Vehicle' else 178.0) + sw * 3.5, 2),
            ])

    for tab in ('3_PerSweep_WIDE', '4_Master_LONG', '5_ISI_Matrix', '6_Phase_Data'):
        ws = wb.create_sheet(tab)
        ws.append(['Cell_ID', 'Group', 'Note'])
        ws.append(['C01', 'Vehicle', f'Synthetic {tab} summary'])

    wb.save(target)
    return target


class BrowserWorkbenchRuntime:
    """Stateful local-browser workbench matching FastAPI routes 1:1."""

    def __init__(self, data_dir: Path | str | None = None, gsheet_fetcher: Any = None):
        base = Path(data_dir) if data_dir else (Path(tempfile.gettempdir()) / 'statweave_browser_runtime')
        self.data_dir = base.resolve()
        self.data_dir.mkdir(parents=True, exist_ok=True)
        (self.data_dir / 'workspaces').mkdir(parents=True, exist_ok=True)
        self.session_secret = secrets.token_hex(32)
        self.store = WebStore(self.data_dir / 'statweave_browser.sqlite3', self.session_secret)
        self.gsheet_fetcher = gsheet_fetcher
        self._render_lock = threading.Lock()
        self._sessions: OrderedDict[str, Session] = OrderedDict()
        self._resolved_models: dict[str, str] = {}
        self.connection_factory: Any = None
        self._default_user = self.store.upsert_user(
            auth_provider='browser_local',
            provider_subject='local_wasm_researcher',
            display_name='Local Browser Researcher',
            handle_or_orcid=None,
            affiliation='In-Browser WebAssembly Engine (100% Client-Side)',
            allow_private_evaluation=True,
            allow_model_training=True,
            allow_public_example_library=False,
        )

    def _user_workspace(self, user_id: str) -> Path:
        ws = (self.data_dir / 'workspaces' / user_id).resolve()
        ws.mkdir(parents=True, exist_ok=True)
        return ws

    def _key_fingerprint(self, clean_key: str) -> str:
        import hashlib
        return hashlib.sha256((self.session_secret + ':' + clean_key).encode('utf-8')).hexdigest()[:16]

    def _candidate_models(self, clean_key: str, api_model: str = '') -> list[str]:
        explicit = (api_model or '').strip()
        if explicit:
            return [explicit]
        is_gemini = clean_key.startswith('AIza')
        defaults = (
            ['gemini-3.8-flash', 'gemini-4-argon', 'gemini-4-hydrogen', 'gemini-3.6-flash']
            if is_gemini
            else [DEFAULT_MODEL, 'gpt-4.1-mini', 'gpt-4o-mini']
        )
        cached = self._resolved_models.get(self._key_fingerprint(clean_key))
        if cached and cached in defaults:
            return [cached] + [m for m in defaults if m != cached]
        return defaults

    def _auth_config(self, api_key: str = '', api_model: str = '') -> dict[str, Any]:
        clean_key = sanitize_api_key(api_key)
        has_key = len(clean_key) >= 16
        is_gemini = clean_key.startswith('AIza')
        chosen_model = (api_model or '').strip()
        if not chosen_model and has_key:
            chosen_model = self._candidate_models(clean_key, '')[0]
        elif not chosen_model:
            chosen_model = 'gemini-3.8-flash' if is_gemini else DEFAULT_MODEL
        return {
            'version': __version__,
            'browser_wasm_mode': True,
            'openai_configured': has_key,
            'llm_provider': ('gemini' if is_gemini else 'openai') if has_key else 'offline',
            'openai_model': chosen_model if has_key else None,
            'github_oauth_enabled': False,
            'orcid_oauth_enabled': False,
            'invite_login_enabled': True,
            'require_invite_code': False,
            'carrd_portal_url': 'https://my-statweave.carrd.co',
            'clampflow_portal_url': 'https://my-clampflow.carrd.co',
            'daily_turn_limit': 500,
            'monthly_turn_limit': 5000,
        }

    def _build_single_planner(self, clean_key: str, model_name: str) -> Any:
        is_gemini = clean_key.startswith('AIza')
        if is_gemini:
            from ..gemini_provider import GEMINI_API_HOST, GEMINI_DEFAULT_MODEL, GeminiPlanner
            gmodel = model_name if model_name.startswith(('gemini-', 'gemma-')) else GEMINI_DEFAULT_MODEL
            planner = GeminiPlanner(api_key=clean_key, model=gmodel, timeout=60)
            if self.connection_factory is not None:
                planner._make_connection = lambda timeout: self.connection_factory(GEMINI_API_HOST, timeout=timeout)  # type: ignore[method-assign]
            elif sys.platform == 'emscripten':
                planner._make_connection = lambda timeout: _WorkerHTTPSConnection(GEMINI_API_HOST, timeout=timeout)  # type: ignore[method-assign]
            return planner
        from ..api_provider import API_HOST
        planner = OpenAIPlanner(api_key=clean_key, model=model_name or DEFAULT_MODEL, timeout=60)
        if self.connection_factory is not None:
            planner._make_connection = lambda timeout: self.connection_factory(API_HOST, timeout=timeout)  # type: ignore[method-assign]
        elif sys.platform == 'emscripten':
            planner._make_connection = lambda timeout: _WorkerHTTPSConnection(API_HOST, timeout=timeout)  # type: ignore[method-assign]
        return planner

    def _build_planner(self, api_key: str, api_model: str = '') -> Any:
        clean_key = sanitize_api_key(api_key)
        if len(clean_key) < 16:
            return None
        explicit = bool((api_model or '').strip())
        candidates = self._candidate_models(clean_key, api_model)
        key_fp = self._key_fingerprint(clean_key)
        rt = self

        class _BrowserFallbackPlanner:
            provider = 'gemini' if clean_key.startswith('AIza') else 'openai'
            supports_tools = True
            cancelled = False

            def __init__(self) -> None:
                self.model = candidates[0]

            def converse(self, text: str, toolbox: Any, dialogue: Any = None, context: Any = None) -> dict[str, Any]:
                last_err: Exception | None = None
                for idx, cand in enumerate(candidates):
                    inner = rt._build_single_planner(clean_key, cand)
                    try:
                        out = inner.converse(text, toolbox, dialogue=dialogue, context=context)
                        rt._resolved_models[key_fp] = inner.model
                        self.model = inner.model
                        return out
                    except OpenAIError as err:
                        last_err = err
                        ran_tools = bool(getattr(toolbox, 'tool_names', None))
                        if not explicit and not ran_tools and idx + 1 < len(candidates) and _is_model_unavailable_error(str(err)):
                            continue
                        raise
                assert last_err is not None
                raise last_err

            def check_connection(self) -> dict[str, Any]:
                last_err: Exception | None = None
                for idx, cand in enumerate(candidates):
                    inner = rt._build_single_planner(clean_key, cand)
                    try:
                        out = inner.check_connection()
                        rt._resolved_models[key_fp] = inner.model
                        self.model = inner.model
                        return out
                    except OpenAIError as err:
                        last_err = err
                        if not explicit and idx + 1 < len(candidates) and _is_model_unavailable_error(str(err)):
                            continue
                        raise
                assert last_err is not None
                raise last_err

        return _BrowserFallbackPlanner()

    def _load_session(self, project_id: str) -> tuple[dict, Session]:
        user_id = self._default_user['user_id']
        meta = self.store.get_user_project(project_id, user_id)
        if not meta:
            raise BrowserAPIError(404, 'Project not found.')
        if project_id in self._sessions:
            self._sessions.move_to_end(project_id)
            return meta, self._sessions[project_id]
        ws = self._user_workspace(user_id)
        proj_dir = (ws / meta['project_dir_rel']).resolve()
        if not proj_dir.is_relative_to(ws) or not (proj_dir / 'project.json').is_file():
            raise BrowserAPIError(404, 'Project files are unavailable.')
        sess = Session(ws, allow_host_paths=False)
        sess.style['dpi'] = 300
        sess.defer_figure_validation = True
        sess.open_project(proj_dir, recover=True)
        self._sessions[project_id] = sess
        return meta, sess

    def _render_svg_preview(self, session: Session) -> tuple[str | None, str | None]:
        if session.dataset is None or session.result is None:
            return None, None
        with self._render_lock:
            fig = None
            try:
                fig = make_figure(session.dataset, session.result, session.plan, session.style)
                buf = io.StringIO()
                fig.savefig(buf, format='svg', bbox_inches='tight', facecolor='white')
                caption = figure_caption(session.dataset, session.result, session.plan, session.style)
                return buf.getvalue(), caption
            except Exception as err:
                return None, f'Figure preview needs adjustment: {safe_text(str(err), 300)}'
            finally:
                if fig is not None:
                    plt.close(fig)

    def _serialize_workspace(self, meta: dict, session: Session) -> dict[str, Any]:
        user = self._default_user
        ds = session.dataset
        schema = inspect_data(session) if ds is not None else {}
        preview_rows = []
        columns = []
        row_numbers = []
        if ds is not None and hasattr(ds, 'df'):
            columns = [str(c) for c in ds.df.columns]
            sub = ds.df.iloc[:150]
            row_numbers = [int(r) for r in ds.row_numbers[:150]]
            for _, row in sub.iterrows():
                preview_rows.append([
                    None if (v is None or (isinstance(v, float) and v != v))
                    else str(v) if not isinstance(v, (int, float, bool))
                    else v
                    for v in row.tolist()
                ])

        svg_markup, caption = self._render_svg_preview(session)
        api_prop = session.context.get('api_proposal')
        pending_summary = None
        if api_prop:
            pending_summary = {
                'proposal_id': api_prop.get('proposal_id'),
                'kind': api_prop.get('kind'),
                'preview': api_prop.get('preview'),
            }

        audit_tail = []
        if session.project_dir and (session.project_dir / 'history.jsonl').is_file():
            lines = (session.project_dir / 'history.jsonl').read_text(encoding='utf-8').splitlines()[-40:]
            for ln in lines:
                try:
                    ev = json.loads(ln)
                    audit_tail.append({
                        'time_utc': ev.get('time_utc'),
                        'type': ev.get('type'),
                        'hash_prefix': str(ev.get('hash', ''))[:12],
                    })
                except Exception:
                    continue

        visible_sheets = list(getattr(ds, 'sheets', []))
        if ds is not None and getattr(ds, 'source_path', None) and Path(ds.source_path).suffix.lower() in {'.xlsx', '.xlsm'}:
            hidden_set = set(inspect_ooxml_workbook(ds.source_path).get('hidden_sheets') or ())
            if hidden_set:
                visible_sheets = [s for s in visible_sheets if s not in hidden_set]

        from ..explore import build_spreadsheet_overview
        spreadsheet_overview = build_spreadsheet_overview(ds)

        return {
            'project': meta,
            'schema': schema,
            'spreadsheet_overview': spreadsheet_overview,
            'source': {
                'filename': Path(ds.source_path).name if ds and getattr(ds, 'source_path', None) else meta['title'],
                'sha256': getattr(ds, 'source_hash', meta['source_sha256']),
                'is_clampflow': bool(getattr(ds, 'is_clampflow', False)),
                'sheets': visible_sheets,
                'active_sheet': getattr(ds, 'sheet', None),
                'row_count': int(len(ds.df)) if ds is not None and hasattr(ds, 'df') else 0,
                'column_count': len(columns),
                'warnings': list(getattr(ds, 'warnings', [])),
            },
            'preview_table': {
                'columns': columns,
                'row_numbers': row_numbers,
                'rows': preview_rows,
                'truncated': bool(ds is not None and hasattr(ds, 'df') and len(ds.df) > 150),
            },
            'conversation': [
                {'role': m.get('role', 'assistant'), 'text': safe_text(str(m.get('text', '')), 12000)}
                for m in session.conversation[-60:]
            ],
            'pending_proposal': pending_summary,
            'working_sheets': list(session.context.get('working_sheets') or []),
            'plan': session.plan,
            'style': session.style,
            'result': session.result,
            'figure_svg': svg_markup,
            'figure_caption': caption,
            'audit_events': audit_tail,
            'quota': self.store.usage_status(user['user_id'], 500, 5000, 5_000_000),
        }

    def _fetch_gsheet_bytes(self, url: str) -> tuple[bytes, str]:
        from ..working_sheets import fetch_google_sheet_xlsx, parse_google_sheets_url
        doc_id, gid_str = parse_google_sheets_url(url)
        if self.gsheet_fetcher is not None:
            res = self.gsheet_fetcher(url)
            data = res[0] if isinstance(res, tuple) else res
            return data, '.xlsx'
        if sys.platform == 'emscripten':
            import js  # type: ignore[import-not-found]
            export_url = f'https://docs.google.com/spreadsheets/d/{doc_id}/export?format=xlsx'
            if gid_str and gid_str.isdigit():
                export_url += f'&gid={gid_str}'
            xhr = js.XMLHttpRequest.new()
            xhr.open('GET', export_url, False)
            xhr.overrideMimeType('text/plain; charset=x-user-defined')
            try:
                xhr.send()
            except Exception as exc:
                raise ValueError(
                    'Could not download that Google Sheet directly from the browser. '
                    'Make sure sharing is set to "Anyone with the link can view", or copy/paste the cells into Paste 2+ Columns.'
                ) from exc
            if int(xhr.status or 0) != 200:
                raise ValueError(
                    f'Google Sheets returned HTTP {int(xhr.status or 0)}. Set the sheet to "Anyone with the link can view" or paste cells directly.'
                )
            raw_text = str(xhr.responseText or '')
            return bytes(ord(ch) & 0xFF for ch in raw_text), '.xlsx'
        xlsx_bytes, _ = fetch_google_sheet_xlsx(url)
        return xlsx_bytes, '.xlsx'

    def _import_gsheet(self, url: str, title: str) -> dict[str, Any]:
        from ..explore import build_spreadsheet_welcome_message
        from ..working_sheets import parse_google_sheets_url
        try:
            doc_id, _gid = parse_google_sheets_url(url)
            raw_bytes, ext = self._fetch_gsheet_bytes(url)
        except ValueError as err:
            raise BrowserAPIError(400, safe_text(str(err), 600)) from None

        user_id = self._default_user['user_id']
        ws = self._user_workspace(user_id)
        slug = ''.join(c if c.isalnum() or c in '-_' else '_' for c in (title.strip() or f'google_sheet_{doc_id[:10]}'))[:60] or 'google_sheet'
        with tempfile.TemporaryDirectory(dir=ws) as tmp_str:
            staged = Path(tmp_str) / f'{slug}{ext}'
            staged.write_bytes(raw_bytes)
            if ext == '.xlsx':
                zip_guard(staged, max_uncompressed_bytes=64 * 1024 * 1024)
                info = inspect_ooxml_workbook(staged)
                if info.get('has_vba_macros'):
                    raise BrowserAPIError(400, 'Workbooks containing embedded VBA macros are rejected.')
            sess = Session(ws, allow_host_paths=False)
            sess.style['dpi'] = 300
            sess.defer_figure_validation = True
            try:
                ds = sess.import_file(staged)
            except ValueError as err:
                raise BrowserAPIError(400, safe_text(str(err), 600)) from None
            sess.context['origin'] = 'google_sheets_import'
            msg = build_spreadsheet_welcome_message(ds, source_label=f'{slug}{ext}')
            sess.conversation.append({'role': 'assistant', 'text': 'Imported from Google Sheets.\n\n' + msg})
            sess.save()

        detected = 'clampflow_6tab' if getattr(ds, 'is_clampflow', False) else 'google_sheet'
        rel = str(sess.project_dir.relative_to(ws))
        clean_title = (title.strip() or f'Google Sheet ({ds.sheet or doc_id[:8]})')[:120]
        meta = self.store.register_project(user_id, rel, clean_title, detected, ds.source_hash)
        self._sessions[meta['project_id']] = sess
        return self._serialize_workspace(meta, sess)

    def dispatch(
        self,
        method: str,
        raw_path: str,
        body: dict[str, Any] | None = None,
        file_payload: dict[str, Any] | None = None,
        api_key: str = '',
        api_model: str = '',
    ) -> dict[str, Any]:
        try:
            return self._dispatch_inner(method.upper(), raw_path, body or {}, file_payload, api_key, api_model)
        except BrowserAPIError as berr:
            return {'status': berr.status, 'kind': 'error', 'detail': berr.detail}
        except Exception as exc:
            return {'status': 500, 'kind': 'error', 'detail': safe_text(f'Unexpected engine error: {exc}', 500)}

    def _dispatch_inner(
        self,
        method: str,
        raw_path: str,
        body: dict[str, Any],
        file_payload: dict[str, Any] | None,
        api_key: str,
        api_model: str,
    ) -> dict[str, Any]:
        parsed = urlparse(raw_path)
        path = parsed.path.rstrip('/') or '/'
        user = self._default_user
        user_id = user['user_id']

        if method == 'GET' and path == '/healthz':
            cfg = self._auth_config(api_key, api_model)
            return {'status': 200, 'kind': 'json', 'data': {'status': 'ok', 'version': __version__, 'browser_wasm_mode': True, 'openai_configured': cfg['openai_configured']}}

        if method == 'GET' and path == '/api/auth/config':
            return {'status': 200, 'kind': 'json', 'data': self._auth_config(api_key, api_model)}

        if method == 'GET' and path == '/api/auth/me':
            return {
                'status': 200,
                'kind': 'json',
                'data': {
                    'user': user,
                    'quota': self.store.usage_status(user_id, 500, 5000, 5_000_000),
                    'config': self._auth_config(api_key, api_model),
                },
            }

        if method == 'POST' and path in {'/api/auth/invite', '/api/auth/consent'}:
            return {'status': 200, 'kind': 'json', 'data': {'token': 'browser_local_token', 'user': user}}

        if method == 'POST' and path == '/api/auth/logout':
            return {'status': 200, 'kind': 'json', 'data': {'status': 'logged_out'}}

        if method == 'POST' and path == '/api/auth/test_key':
            candidate_key = sanitize_api_key(str(body.get('api_key') or api_key or ''))
            candidate_model = str(body.get('api_model') or api_model or '').strip()
            if len(candidate_key) < 16:
                raise BrowserAPIError(400, 'Paste a valid OpenAI (sk-...) or Google AI Studio Gemini (AIza...) API key first.')
            planner = self._build_planner(candidate_key, candidate_model)
            if planner is None:
                raise BrowserAPIError(400, 'API key format was not recognized.')
            try:
                res = planner.check_connection()
            except OpenAIError as err:
                raise BrowserAPIError(400, safe_text(str(err), 400)) from None
            return {
                'status': 200,
                'kind': 'json',
                'data': {
                    'ok': True,
                    'provider': planner.provider,
                    'model': res.get('model', planner.model),
                    'message': res.get('message', 'API key verified.'),
                },
            }

        if method == 'GET' and path == '/api/projects':
            return {
                'status': 200,
                'kind': 'json',
                'data': {
                    'projects': self.store.list_user_projects(user_id),
                    'quota': self.store.usage_status(user_id, 500, 5000, 5_000_000),
                },
            }

        if method == 'GET' and path == '/api/r_datasets':
            from ..r_learning_set import list_r_datasets
            items = list_r_datasets()
            return {'status': 200, 'kind': 'json', 'data': {'count': len(items), 'datasets': items}}

        if method == 'POST' and path == '/api/projects/demo':
            from ..explore import build_spreadsheet_welcome_message
            kind = str(body.get('kind') or 'clampflow').strip()
            ws = self._user_workspace(user_id)
            sess = Session(ws, allow_host_paths=False)
            sess.style['dpi'] = 300
            sess.defer_figure_validation = True
            repo_examples = Path(__file__).resolve().parents[2] / 'examples'
            with tempfile.TemporaryDirectory(dir=ws) as tmp_str:
                tmp_dir = Path(tmp_str)
                if kind == 'clampflow':
                    demo_path = _build_synthetic_clampflow_workbook(tmp_dir / 'Synthetic_ClampFlow_Compiled.xlsx')
                    title = 'Synthetic ClampFlow 6-Tab AP Sheet'
                elif kind == 'timecourse':
                    demo_path = tmp_dir / 'Wt_v_KO_time_demo.xlsx'
                    wb_tc = openpyxl.Workbook()
                    ws_tc = wb_tc.active
                    ws_tc.title = 'Sheet1'
                    ws_tc.append([None, 'Wt-1', 'Wt-2', 'Wt-3', 'Ko-1', 'Ko-2', 'Ko-3'])
                    ws_tc.append(['2026-01-01', 14.8, 15.6, 14.9, 14.5, 15.1, 14.7])
                    ws_tc.append(['2026-01-02', 15.2, 16.0, 15.4, 21.8, 23.4, 22.1])
                    ws_tc.append(['2026-01-03', 15.5, 15.9, 15.1, 29.4, 31.2, 28.9])
                    ws_tc.append(['2026-01-04', 15.0, 16.2, 15.3, 36.1, 38.5, 35.8])
                    wb_tc.save(demo_path)
                    title = 'Synthetic WT vs KO Timecourse'
                elif kind == 'paired':
                    src_ex = repo_examples / 'paired_measurements.csv'
                    demo_path = tmp_dir / 'paired_measurements.csv'
                    if src_ex.is_file():
                        shutil.copyfile(src_ex, demo_path)
                    else:
                        demo_path.write_text('Before,After\n12.4,18.1\n11.9,17.5\n13.1,19.4\n12.0,16.8\n12.7,18.9\n', encoding='utf-8')
                    title = 'Synthetic Paired Before/After Table'
                elif kind == 'survival':
                    demo_path = tmp_dir / 'Preclinical_Survival_Cohort.csv'
                    surv_lines = [
                        'Subject_ID,Group,Time_Days,Event_Status',
                        'S01,Vehicle,18,1', 'S02,Vehicle,24,1', 'S03,Vehicle,29,1', 'S04,Vehicle,34,0',
                        'S05,Vehicle,38,1', 'S06,Vehicle,42,1', 'S07,Vehicle,47,1', 'S08,Vehicle,53,1',
                        'S09,Vehicle,59,1', 'S10,Vehicle,64,0', 'S11,Vehicle,68,1', 'S12,Vehicle,74,1',
                        'S13,Vehicle,81,1', 'S14,Vehicle,89,1', 'S15,Vehicle,96,1', 'S16,Vehicle,112,0',
                        'S17,Drug_X,36,1', 'S18,Drug_X,49,0', 'S19,Drug_X,58,1', 'S20,Drug_X,71,1',
                        'S21,Drug_X,84,0', 'S22,Drug_X,95,1', 'S23,Drug_X,108,1', 'S24,Drug_X,119,0',
                        'S25,Drug_X,128,1', 'S26,Drug_X,142,1', 'S27,Drug_X,155,0', 'S28,Drug_X,164,1',
                        'S29,Drug_X,180,0', 'S30,Drug_X,180,0', 'S31,Drug_X,180,0', 'S32,Drug_X,180,0',
                    ]
                    demo_path.write_text('\n'.join(surv_lines) + '\n', encoding='utf-8')
                    title = 'Synthetic Kaplan–Meier Survival Study'
                else:
                    src_ex = repo_examples / 'independent_groups.csv'
                    demo_path = tmp_dir / 'independent_groups.csv'
                    if src_ex.is_file():
                        shutil.copyfile(src_ex, demo_path)
                    else:
                        demo_path.write_text('Treatment,Score\nControl,10.2\nControl,11.4\nControl,10.8\nDrug,16.5\nDrug,17.9\nDrug,17.1\n', encoding='utf-8')
                    title = 'Synthetic 2-Group Comparison'

                ds = sess.import_file(demo_path)
                sess.context['synthetic_demo'] = True
                msg = build_spreadsheet_welcome_message(ds, source_label=demo_path.name)
                sess.conversation.append({'role': 'assistant', 'text': 'Synthetic demonstration dataset.\n\n' + msg})
                sess.save()

            detected = 'clampflow_6tab' if getattr(ds, 'is_clampflow', False) else 'table'
            rel = str(sess.project_dir.relative_to(ws))
            meta = self.store.register_project(user_id, rel, title, detected, ds.source_hash)
            self._sessions[meta['project_id']] = sess
            return {'status': 200, 'kind': 'json', 'data': self._serialize_workspace(meta, sess)}

        if method == 'POST' and path == '/api/projects/r_dataset':
            from ..explore import build_spreadsheet_welcome_message
            from ..r_learning_set import get_r_dataset_entry
            ds_id = str(body.get('dataset_id') or '').strip()
            try:
                entry = get_r_dataset_entry(ds_id)
            except KeyError as err:
                raise BrowserAPIError(404, safe_text(str(err), 300)) from None

            ws = self._user_workspace(user_id)
            sess = Session(ws, allow_host_paths=False)
            sess.style['dpi'] = 300
            sess.defer_figure_validation = True
            with tempfile.TemporaryDirectory(dir=ws) as tmp_str:
                csv_path = Path(tmp_str) / f"{entry['id']}.csv"
                csv_path.write_text(entry['csv'], encoding='utf-8')
                ds = sess.import_file(csv_path)
                sess.context['r_learning_dataset'] = {
                    'id': entry['id'],
                    'r_ref': entry['r_ref'],
                    'archetype': entry['archetype'],
                    'title': entry['title'],
                }
                msg = build_spreadsheet_welcome_message(ds, source_label=f"{entry['r_ref']} ({entry['id']}.csv)")
                prompts_md = '\n'.join(f'- *"{p}"*' for p in (entry.get('sample_prompts') or [])[:2])
                header = (
                    f"**📚 R Repository Learning Set — `{entry['r_ref']}`**\n"
                    f"{entry['title']} · *{entry['archetype']}* (numerically cross-verified against R `Rscript` to `< 1e-12`).\n\n"
                )
                extra = f"\n\n**Try asking in chat:**\n{prompts_md}" if prompts_md else ''
                sess.conversation.append({'role': 'assistant', 'text': header + msg + extra})
                sess.save()

            title = f"R: {entry['r_ref']} — {entry['title']}"[:120]
            rel = str(sess.project_dir.relative_to(ws))
            meta = self.store.register_project(user_id, rel, title, 'r_learning_set', ds.source_hash)
            self._sessions[meta['project_id']] = sess
            return {'status': 200, 'kind': 'json', 'data': self._serialize_workspace(meta, sess)}

        if method == 'POST' and path == '/api/projects/gsheet':
            url = str(body.get('url') or '').strip()
            title = str(body.get('title') or '').strip()
            return {'status': 200, 'kind': 'json', 'data': self._import_gsheet(url, title)}

        if method == 'POST' and path == '/api/projects/paste':
            from ..explore import build_spreadsheet_welcome_message
            text = str(body.get('text') or '')
            title = str(body.get('title') or 'Pasted Table')
            stripped = text.strip()
            if stripped.startswith('https://docs.google.com/spreadsheets/') and '\n' not in stripped and ' ' not in stripped:
                return {'status': 200, 'kind': 'json', 'data': self._import_gsheet(stripped, '' if title == 'Pasted Table' else title)}
            if len(stripped) < 3:
                raise BrowserAPIError(400, 'Paste at least 2 rows of tabular data.')
            ws = self._user_workspace(user_id)
            sess = Session(ws, allow_host_paths=False)
            sess.style['dpi'] = 300
            sess.defer_figure_validation = True
            try:
                paste_name = f"{title.strip()[:80] or 'pasted_table'}.tsv"
                ds = sess.import_pasted_table(text, name=paste_name)
            except ValueError as err:
                raise BrowserAPIError(400, safe_text(str(err), 600)) from None
            msg = build_spreadsheet_welcome_message(ds, source_label=paste_name)
            sess.conversation.append({'role': 'assistant', 'text': msg})
            sess.save()
            rel = str(sess.project_dir.relative_to(ws))
            meta = self.store.register_project(user_id, rel, title.strip()[:120] or 'Pasted Table', 'pasted_table', ds.source_hash)
            self._sessions[meta['project_id']] = sess
            return {'status': 200, 'kind': 'json', 'data': self._serialize_workspace(meta, sess)}

        if method == 'POST' and path == '/api/projects/upload':
            from ..explore import build_spreadsheet_welcome_message
            if not file_payload or not file_payload.get('base64'):
                raise BrowserAPIError(400, 'Uploaded file is empty.')
            raw_name = Path(str(file_payload.get('filename') or 'dataset.csv')).name
            ext = Path(raw_name).suffix.lower()
            if ext == '.xlsm':
                raise BrowserAPIError(400, 'Macro-enabled .xlsm workbooks are blocked for safety. Save as standard .xlsx or .csv first.')
            if ext not in ALLOWED_UPLOAD_SUFFIXES:
                raise BrowserAPIError(400, f'Unsupported file type {ext!r}. Upload .xlsx, .csv, .tsv, .txt, or .ods.')
            raw_bytes = base64.b64decode(file_payload['base64'])
            if not raw_bytes:
                raise BrowserAPIError(400, 'Uploaded file is empty.')
            ws = self._user_workspace(user_id)
            with tempfile.TemporaryDirectory(dir=ws) as tmp_str:
                staged = Path(tmp_str) / raw_name
                staged.write_bytes(raw_bytes)
                if ext in {'.xlsx', '.ods'}:
                    try:
                        zip_guard(staged, max_uncompressed_bytes=min(128 * 1024 * 1024, max(4 * 1024 * 1024, len(raw_bytes) * 200)))
                    except ValueError as err:
                        raise BrowserAPIError(400, safe_text(str(err), 500)) from None
                    info = inspect_ooxml_workbook(staged)
                    if info.get('has_vba_macros'):
                        raise BrowserAPIError(400, 'Workbooks containing embedded VBA macros are rejected.')
                sess = Session(ws, allow_host_paths=False)
                sess.style['dpi'] = 300
                sess.defer_figure_validation = True
                sheet_name = str(file_payload.get('sheet') or '').strip() or None
                try:
                    ds = sess.import_file(staged, sheet=sheet_name)
                except ValueError as err:
                    raise BrowserAPIError(400, safe_text(str(err), 600)) from None
                msg = build_spreadsheet_welcome_message(ds, source_label=raw_name)
                sess.conversation.append({'role': 'assistant', 'text': msg})
                sess.save()

            detected = 'clampflow_6tab' if getattr(ds, 'is_clampflow', False) else 'table'
            rel = str(sess.project_dir.relative_to(ws))
            meta = self.store.register_project(user_id, rel, Path(ds.source_path).name, detected, ds.source_hash)
            self._sessions[meta['project_id']] = sess
            return {'status': 200, 'kind': 'json', 'data': self._serialize_workspace(meta, sess)}

        if method == 'POST' and path == '/api/projects/chat_start':
            message = str(body.get('message') or '').strip()
            title = str(body.get('title') or 'Chat Working Sheet').strip() or 'Chat Working Sheet'
            if message.startswith('https://docs.google.com/spreadsheets/') and '\n' not in message and ' ' not in message:
                return {'status': 200, 'kind': 'json', 'data': self._import_gsheet(message, title)}
            ws = self._user_workspace(user_id)
            sess = Session(ws, allow_host_paths=False)
            sess.style['dpi'] = 300
            sess.defer_figure_validation = True
            parsed_groups = _try_parse_chat_raw_numbers(message)
            if parsed_groups:
                lines = ['Group\tValue']
                for grp_label, vals in parsed_groups.items():
                    safe_grp = grp_label.replace('\t', ' ').replace('\n', ' ')
                    for val in vals:
                        lines.append(f'{safe_grp}\t{val:g}')
                seed_tsv = '\n'.join(lines) + '\n'
                seed_name = '0_Raw_Chat_Numbers.tsv'
            else:
                seed_tsv = 'Chat_Intake\tStatus\nRaw_Input_In_Chat\tBuild_Working_Sheet\nRaw_Input_In_Chat\tReady\n'
                seed_name = '0_Raw_Chat_Intake.tsv'
            ds = sess.import_pasted_table(seed_tsv, name=seed_name)
            sess.context['origin'] = 'chat_raw_numbers'
            sess.save()
            rel = str(sess.project_dir.relative_to(ws))
            meta = self.store.register_project(user_id, rel, title[:120], 'chat_working_sheet', ds.source_hash)
            self._sessions[meta['project_id']] = sess
            return self._handle_chat_turn(
                meta['project_id'],
                message=message,
                mode=str(body.get('mode') or 'auto'),
                auto_execute=bool(body.get('auto_execute', True)),
                api_key=api_key,
                api_model=api_model,
            )

        if method == 'GET' and path == '/api/me/contributions':
            return {'status': 200, 'kind': 'json', 'data': self.store.list_user_contributions(user_id)}

        if method == 'GET' and path == '/api/me/export.zip':
            listing = self.store.list_user_contributions(user_id)
            buf = io.BytesIO()
            with zipfile.ZipFile(buf, 'w', compression=zipfile.ZIP_DEFLATED) as zf:
                zf.writestr('account_summary.json', json.dumps({'user': user, **listing}, indent=2))
            return {
                'status': 200,
                'kind': 'binary',
                'mime': 'application/zip',
                'filename': 'statweave_browser_workspace.zip',
                'base64': base64.b64encode(buf.getvalue()).decode('ascii'),
            }

        if method == 'POST' and path == '/api/me/anonymize':
            self._sessions.clear()
            return {'status': 200, 'kind': 'json', 'data': {'status': 'account_anonymized', 'policy': 'Local browser session reset.'}}

        # --- /api/projects/{project_id}... routes ---
        m_proj = re.match(r'^/api/projects/([^/]+)(?:/(.*))?$', path)
        if m_proj:
            project_id = m_proj.group(1)
            sub = m_proj.group(2) or ''

            if method == 'GET' and sub == '':
                meta, sess = self._load_session(project_id)
                return {'status': 200, 'kind': 'json', 'data': self._serialize_workspace(meta, sess)}

            if method == 'GET' and sub == 'explore':
                _meta, sess = self._load_session(project_id)
                from ..explore import build_exploratory_gallery
                with self._render_lock:
                    return {'status': 200, 'kind': 'json', 'data': build_exploratory_gallery(sess)}

            if method == 'POST' and sub == 'apply_card':
                meta, sess = self._load_session(project_id)
                from ..explore import apply_exploratory_card
                try:
                    with self._render_lock:
                        apply_exploratory_card(
                            sess,
                            list(body.get('prep_ops') or []),
                            body.get('plan'),
                            body.get('style'),
                        )
                except ValueError as err:
                    raise BrowserAPIError(400, safe_text(str(err), 600)) from None
                self.store.touch_project(project_id, user_id)
                return {'status': 200, 'kind': 'json', 'data': self._serialize_workspace(meta, sess)}

            if method == 'POST' and sub == 'sheet':
                meta, sess = self._load_session(project_id)
                sheet = str(body.get('sheet') or '').strip()
                try:
                    user_text = f'Switch to worksheet "{sheet}".'
                    sess.conversation.append({'role': 'user', 'text': user_text})
                    sess._event('instruction', {'text': user_text, 'interpreter': 'web worksheet selector'})
                    sess.select_sheet(sheet, reply=True)
                except ValueError as err:
                    raise BrowserAPIError(400, safe_text(str(err), 500)) from None
                self.store.touch_project(project_id, user_id)
                return {'status': 200, 'kind': 'json', 'data': self._serialize_workspace(meta, sess)}

            if method == 'POST' and sub == 'chat':
                return self._handle_chat_turn(
                    project_id,
                    message=str(body.get('message') or ''),
                    mode=str(body.get('mode') or 'auto'),
                    auto_execute=bool(body.get('auto_execute', False)),
                    api_key=api_key,
                    api_model=api_model,
                )

            if method == 'POST' and sub == 'proposal/approve':
                meta, sess = self._load_session(project_id)
                pending = sess.context.get('api_proposal')
                prop_id = body.get('proposal_id')
                if pending and prop_id and prop_id != pending.get('proposal_id'):
                    raise BrowserAPIError(409, 'The displayed proposal ID is out of date; review the latest proposal.')
                if pending and prop_id and prop_id == pending.get('proposal_id') and getattr(sess, '_api_conversation_token', None) is None and pending.get('token'):
                    sess._api_conversation_token = pending['token']
                try:
                    reply = sess.approve_proposal()
                except ValueError as err:
                    raise BrowserAPIError(400, safe_text(str(err), 600)) from None
                self.store.touch_project(project_id, user_id)
                payload = self._serialize_workspace(meta, sess)
                payload['reply_message'] = reply.get('message', '')
                payload['open_explore_gallery'] = bool(reply.get('explore_gallery', False))
                return {'status': 200, 'kind': 'json', 'data': payload}

            if method == 'POST' and sub == 'proposal/dismiss':
                meta, sess = self._load_session(project_id)
                reply = sess.dismiss_proposal()
                self.store.touch_project(project_id, user_id)
                payload = self._serialize_workspace(meta, sess)
                payload['reply_message'] = reply.get('message', '')
                payload['open_explore_gallery'] = bool(reply.get('explore_gallery', False))
                return {'status': 200, 'kind': 'json', 'data': payload}

            if method == 'POST' and sub == 'style':
                meta, sess = self._load_session(project_id)
                if sess.dataset is None or sess.result is None:
                    raise BrowserAPIError(400, 'Run an analysis first before styling the figure.')
                new_plan = deepcopy(sess.plan or {})
                plot_type = body.get('plot')
                if plot_type is not None:
                    if plot_type not in PLOTS:
                        raise BrowserAPIError(400, f'Unsupported plot type {plot_type!r}.')
                    new_plan['plot'] = plot_type
                clean_style = deepcopy(sess.style)
                for k, v in (body.get('style') or {}).items():
                    if k not in STYLE_KEYS:
                        raise BrowserAPIError(400, f'Unsupported style field {k!r}.')
                    if v is None:
                        clean_style.pop(k, None)
                    else:
                        clean_style[k] = v
                with self._render_lock:
                    fig = None
                    try:
                        fig = make_figure(sess.dataset, sess.result, new_plan, clean_style)
                    except ValueError as err:
                        raise BrowserAPIError(400, safe_text(str(err), 500)) from None
                    finally:
                        if fig is not None:
                            plt.close(fig)
                sess.plan = new_plan
                sess.style = clean_style
                if not sess.is_study and isinstance(sess.result, dict):
                    sess.result['plan'] = deepcopy(new_plan)
                sess._event('web_figure_style_changed', {
                    'plot': new_plan.get('plot'),
                    'style': clean_style,
                    'calculations_performed': False,
                })
                sess.save()
                self.store.touch_project(project_id, user_id)
                return {'status': 200, 'kind': 'json', 'data': self._serialize_workspace(meta, sess)}

            if method == 'GET' and sub in {'figure.svg', 'figure.png', 'figure.pdf'}:
                fmt_clean = sub.split('.', 1)[1]
                meta, sess = self._load_session(project_id)
                if sess.dataset is None or sess.result is None:
                    raise BrowserAPIError(400, 'No completed figure is available in this project yet.')
                with self._render_lock:
                    fig = None
                    try:
                        fig = make_figure(sess.dataset, sess.result, sess.plan, sess.style)
                        buf = io.BytesIO()
                        dpi = 600 if fmt_clean == 'png' else int(sess.style.get('dpi', 300))
                        fig.savefig(buf, format=fmt_clean, dpi=dpi, bbox_inches='tight', facecolor='white')
                        data_bytes = buf.getvalue()
                    finally:
                        if fig is not None:
                            plt.close(fig)
                media = {'svg': 'image/svg+xml', 'png': 'image/png', 'pdf': 'application/pdf'}[fmt_clean]
                safe_slug = ''.join(c if c.isalnum() or c in '-_' else '_' for c in Path(meta['title']).stem)[:40] or 'statweave_figure'
                return {
                    'status': 200,
                    'kind': 'binary',
                    'mime': media,
                    'filename': f'{safe_slug}.{fmt_clean}',
                    'base64': base64.b64encode(data_bytes).decode('ascii'),
                }

            if method == 'GET' and sub == 'workbook.xlsx':
                from ..working_sheets import build_multi_tab_export_xlsx
                meta, sess = self._load_session(project_id)
                if sess.dataset is None or sess.is_study or sess.is_large_table or sess.is_recording:
                    raise BrowserAPIError(400, 'Working workbook export is available for tabular projects.')
                xlsx_bytes = build_multi_tab_export_xlsx(sess)
                safe_slug = ''.join(c if c.isalnum() or c in '-_' else '_' for c in Path(meta['title']).stem)[:40] or 'statweave_workbook'
                return {
                    'status': 200,
                    'kind': 'binary',
                    'mime': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                    'filename': f'{safe_slug}_working_sheets.xlsx',
                    'base64': base64.b64encode(xlsx_bytes).decode('ascii'),
                }

            if method == 'GET' and sub == 'export.zip':
                meta, sess = self._load_session(project_id)
                if sess.dataset is None or sess.result is None:
                    raise BrowserAPIError(400, 'Complete an analysis before exporting a reproducibility package.')
                with self._render_lock:
                    exported = sess.export_bundle()
                archive_path = Path(exported['archive']).resolve()
                zip_bytes = archive_path.read_bytes()
                safe_slug = ''.join(c if c.isalnum() or c in '-_' else '_' for c in Path(meta['title']).stem)[:40] or 'statweave_export'
                return {
                    'status': 200,
                    'kind': 'binary',
                    'mime': 'application/zip',
                    'filename': f'{safe_slug}_reproducible.zip',
                    'base64': base64.b64encode(zip_bytes).decode('ascii'),
                }

            if method == 'POST' and sub == 'feedback':
                _meta, sess = self._load_session(project_id)
                sess._event('contributor_feedback', {'rating': str(body.get('rating') or 'up'), 'note': safe_text(str(body.get('note') or ''), 1000)})
                sess.save()
                return {'status': 200, 'kind': 'json', 'data': {'status': 'recorded', 'trajectory_id': None}}

            if method == 'POST' and sub == 'contribute':
                return {'status': 200, 'kind': 'json', 'data': {'status': 'saved_locally', 'case_id': f'local-{project_id[:8]}'}}

        raise BrowserAPIError(404, f'Unknown API endpoint: {method} {path}')

    def _handle_chat_turn(
        self,
        project_id: str,
        message: str,
        mode: str,
        auto_execute: bool,
        api_key: str,
        api_model: str,
    ) -> dict[str, Any]:
        meta, sess = self._load_session(project_id)
        model = self._build_planner(api_key, api_model) if mode in {'auto', 'openai'} else None

        pending_pre = sess.context.get('api_proposal')
        if (
            isinstance(pending_pre, dict)
            and getattr(sess, '_api_conversation_token', None) is None
            and pending_pre.get('token')
            and pending_pre.get('base_digest') == state_digest(sess)
        ):
            sess._api_conversation_token = pending_pre['token']

        prev_auto = getattr(sess, 'auto_execute_proposals', False)
        sess.auto_execute_proposals = bool(auto_execute)
        try:
            reply = sess.command(message, model=model)
        finally:
            sess.auto_execute_proposals = prev_auto

        self.store.touch_project(project_id, self._default_user['user_id'])
        payload = self._serialize_workspace(meta, sess)
        payload['reply_message'] = reply.get('message', '')
        payload['open_explore_gallery'] = bool(reply.get('explore_gallery', False))
        return {'status': 200, 'kind': 'json', 'data': payload}


_DEFAULT_RUNTIME: BrowserWorkbenchRuntime | None = None


def get_browser_runtime() -> BrowserWorkbenchRuntime:
    global _DEFAULT_RUNTIME
    if _DEFAULT_RUNTIME is None:
        _DEFAULT_RUNTIME = BrowserWorkbenchRuntime()
    return _DEFAULT_RUNTIME


def dispatch_browser_json(payload_json: str) -> str:
    req = json.loads(payload_json)
    rt = get_browser_runtime()
    resp = rt.dispatch(
        method=str(req.get('method') or 'GET'),
        raw_path=str(req.get('path') or '/'),
        body=req.get('body'),
        file_payload=req.get('file'),
        api_key=str(req.get('api_key') or ''),
        api_model=str(req.get('api_model') or ''),
    )
    return json.dumps(resp, ensure_ascii=False)
