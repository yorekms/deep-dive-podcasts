"""Project persistence, command execution and traceable non-destructive exports."""
from __future__ import annotations
import csv
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import shutil
import sys
from datetime import datetime, timezone
import uuid
import zipfile
from copy import deepcopy

from . import __version__
from .data import load_dataset, prepare_pasted_table
from .engine import analyze
from .planner import interpret, capabilities
from .scrubber import escape_csv_rows, sanitize_source_filename


def clean(value):
    if isinstance(value, dict):
        return {str(k): clean(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [clean(v) for v in value]
    if isinstance(value, float):
        import math
        return value if math.isfinite(value) else None
    if isinstance(value, (str, int, bool)) or value is None:
        return value
    if hasattr(value, 'item'):
        return clean(value.item())
    return str(value)


def canonical(value):
    return json.dumps(clean(value), ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)


def sha256(path):
    h = hashlib.sha256()
    with open(path, 'rb') as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def verify_audit(path, expected_head=None):
    previous = '0' * 64
    count = 0
    with open(path, encoding='utf-8') as handle:
        for line in handle:
            event = json.loads(line)
            actual = event.pop('hash')
            if event.get('previous_hash') != previous:
                raise ValueError('The project history has changed or a history entry is missing.')
            digest = hashlib.sha256(canonical(event).encode()).hexdigest()
            if digest != actual:
                raise ValueError('A project history entry has changed. Open a verified copy of the project.')
            previous = actual
            count += 1
    if expected_head and previous != expected_head:
        raise ValueError('The project history does not match the saved project. It may have been truncated.')
    return previous, count


def versions():
    result = {'StatWeave': __version__, 'Python': sys.version.split()[0]}
    for name in ['numpy', 'scipy', 'pandas', 'matplotlib', 'statsmodels', 'PySide6', 'openpyxl', 'xlrd', 'odfpy', 'defusedxml', 'neo', 'quantities', 'duckdb']:
        try:
            result[name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            result[name] = 'not installed'
    return result


class CheckpointRecoveryRequired(ValueError):
    """A valid later audit tail exists beyond the last complete checkpoint."""


class Session:
    def __init__(self, workspace, allow_host_paths=True):
        self.workspace = Path(workspace).resolve()
        self.allow_host_paths = bool(allow_host_paths)
        self.project_dir = None
        self.dataset = None
        self.plan = None
        self.result = None
        self.style = {'width_mm': 178, 'height_mm': 110, 'font_size': 9, 'palette': 'teal', 'show_points': True, 'dpi': 600}
        self.context = {'design': 'unknown'}
        self.conversation = []
        self.last_hash = '0' * 64
        self.source_original_path = None
        self.pending_plan = None
        self.defer_figure_validation = False
        self.auto_execute_proposals = False
        self.storage_error = None

    def _make_event(self, kind, payload):
        event = {'time_utc': datetime.now(timezone.utc).isoformat(), 'type': kind,
                 'payload': clean(payload), 'previous_hash': self.last_hash}
        event['hash'] = hashlib.sha256(canonical(event).encode()).hexdigest()
        return event

    def _storage_failure(self, error, action='save the project'):
        from .storage import storage_error
        error = storage_error(error, action)
        self.storage_error = str(error)
        return error

    def _event(self, kind, payload):
        if not self.project_dir:
            return
        from .storage import append_record
        event = self._make_event(kind, payload)
        try:
            append_record(self.project_dir / 'history.jsonl', (canonical(event) + '\n').encode('utf-8'))
        except OSError as error:
            raise self._storage_failure(error, 'record the latest processing step')
        self.last_hash = event['hash']

    def _unsaved_reply(self, error):
        """Report a write failure without trying to log another failed write."""
        message = str(self._storage_failure(error))
        self.conversation.append({'role': 'assistant', 'text': message})
        return {'message': message, 'refresh': False, 'save_failed': True}

    def _assert_integrity(self, full=False):
        if not self.dataset:
            return
        if self.is_large_table or self.is_study:
            self.dataset.verify_integrity(full=full)
            if self.is_study:
                from .study_bridge import verify_run_records
                verify_run_records(self,full=full)
        elif sha256(self.dataset.source_path) != self.dataset.source_hash:
            raise ValueError('The preserved source file has changed. Analysis stopped to protect its provenance.')
        verify_audit(self.project_dir / 'history.jsonl', self.last_hash)

    def import_file(self, path, sheet=None, header_row=0):
        from .storage import require_space, MIB
        original = Path(path).expanduser().resolve()
        if original.suffix.lower() == '.abf':
            return self.import_recording(original)
        if original.is_file() and original.stat().st_size >= 32*1024*1024:
            if original.suffix.lower() in ('.csv','.tsv','.txt'):
                if sheet not in (None,'','Data') or header_row!=0:
                    raise ValueError('Large delimited tables currently use their first record as the header and have no worksheets.')
                return self.import_large_table(original)
            if original.suffix.lower() in ('.xlsx','.xlsm','.xls','.ods'):
                raise ValueError('This workbook exceeds the current in-memory workbook limit. Export the required sheet as CSV/TSV to use the disk-backed large-table reader; the original workbook is unchanged.')
        if original.is_file():
            require_space(self.workspace, max(16 * MIB, original.stat().st_size * 2 + 8 * MIB), 'import the spreadsheet')
        # Validate before creating a project or changing the active session.
        initial = load_dataset(original, sheet=sheet, header_row=header_row)
        clean_info = sanitize_source_filename(original.name)
        clean_name = clean_info['sanitized_name']
        clean_stem = Path(clean_name).stem
        stamp = datetime.now().strftime('%Y%m%d-%H%M%S')
        slug = ''.join(c if c.isalnum() or c in '-_' else '-' for c in clean_stem)[:45]
        directory = self.workspace / 'projects' / f'{stamp}-{slug}-{uuid.uuid4().hex[:6]}'
        old = dict(self.__dict__)
        try:
            (directory / 'source').mkdir(parents=True)
            snapshot = directory / 'source' / clean_name
            shutil.copy2(original, snapshot)
            snapshot.chmod(0o444)
            imported = load_dataset(snapshot, sheet=initial.sheet, header_row=header_row)
            if clean_info['student_name_scrubbed']:
                imported.warnings.append(
                    f"Scrubbed contributor/student identifier from filename ('{clean_name}') while preserving exact source bytes."
                )
            recorded_origin = clean_name if (not self.allow_host_paths or clean_info['student_name_scrubbed']) else str(original)
            self.project_dir, self.dataset = directory, imported
            self.source_original_path = recorded_origin
            self.last_hash = '0' * 64
            self.plan = self.result = self.pending_plan = None
            self.context = {'design': 'unknown'}
            self.conversation = []
            self.style = {'width_mm': 178, 'height_mm': 110, 'font_size': 9, 'palette': 'teal', 'show_points': True, 'dpi': 600}
            self._event('import', {'original_path': recorded_origin, 'snapshot': str(snapshot.relative_to(directory)),
                                   'metadata': imported.metadata(), 'source_sha256': imported.source_hash})
            self.save()
            return imported
        except BaseException:
            self.__dict__.clear()
            self.__dict__.update(old)
            shutil.rmtree(directory, ignore_errors=True)
            raise

    def import_pasted_table(self, text, name='pasted_table.tsv'):
        from .storage import require_space, MIB
        tsv_bytes, paste_notes = prepare_pasted_table(text)
        require_space(self.workspace, max(16 * MIB, len(tsv_bytes) * 2 + 8 * MIB), 'save the pasted table')
        clean_name = sanitize_source_filename(name)['sanitized_name']
        if Path(clean_name).suffix.lower() not in {'.tsv', '.csv', '.txt'}:
            clean_name = Path(clean_name).stem + '.tsv'
        stamp = datetime.now().strftime('%Y%m%d-%H%M%S')
        slug = ''.join(c if c.isalnum() or c in '-_' else '-' for c in Path(clean_name).stem)[:45] or 'pasted-table'
        directory = self.workspace / 'projects' / f'{stamp}-{slug}-{uuid.uuid4().hex[:6]}'
        old = dict(self.__dict__)
        try:
            (directory / 'source').mkdir(parents=True)
            snapshot = directory / 'source' / clean_name
            with snapshot.open('xb') as handle:
                handle.write(tsv_bytes)
                handle.flush()
                os.fsync(handle.fileno())
            snapshot.chmod(0o444)
            imported = load_dataset(snapshot)
            for note in paste_notes:
                if note not in imported.warnings:
                    imported.warnings.insert(0, note)
            self.project_dir, self.dataset = directory, imported
            self.source_original_path = clean_name
            self.last_hash = '0' * 64
            self.plan = self.result = self.pending_plan = None
            self.context = {'design': 'unknown', 'origin': 'clipboard_paste'}
            self.conversation = []
            self.style = {'width_mm': 178, 'height_mm': 110, 'font_size': 9, 'palette': 'teal', 'show_points': True, 'dpi': 600}
            self._event('import', {'origin': 'clipboard_paste', 'original_path': clean_name,
                                   'snapshot': str(snapshot.relative_to(directory)),
                                   'metadata': imported.metadata(), 'source_sha256': imported.source_hash})
            self.save()
            return imported
        except BaseException:
            self.__dict__.clear()
            self.__dict__.update(old)
            shutil.rmtree(directory, ignore_errors=True)
            raise

    @property
    def is_recording(self):
        return getattr(self.dataset, 'kind', None) == 'recording'

    @property
    def is_large_table(self):
        return getattr(self.dataset,'kind',None)=='large_table'

    @property
    def is_study(self):
        return getattr(self.dataset,'kind',None)=='study'

    def import_study(self,paths):
        from .study_session import import_study
        data = import_study(self,paths)
        self.__dict__.pop('_study_conversation_token', None)
        return data

    def import_study_folder(self,path):
        folder=Path(path).expanduser().resolve()
        if not folder.is_dir():raise ValueError('Choose an existing folder of workbook exports.')
        paths=[p for p in folder.iterdir() if p.is_file() and p.suffix.lower() in ('.xlsx','.csv','.tsv','.txt') and not p.name.startswith('~$')]
        if not paths:raise ValueError('No supported XLSX/CSV/TSV/TXT files were found directly in this folder. Subfolders are not automatically merged.')
        return self.import_study(paths)

    def import_large_table(self,path):
        from .large_table import LargeTable
        from .storage import require_space, MIB
        original=Path(path).expanduser().resolve()
        if not original.is_file():raise ValueError('The data file does not exist.')
        require_space(self.workspace, max(32 * MIB, original.stat().st_size * 2 + 16 * MIB), 'import the large table')
        clean_info=sanitize_source_filename(original.name)
        clean_name=clean_info['sanitized_name']
        stamp=datetime.now().strftime('%Y%m%d-%H%M%S')
        slug=''.join(c if c.isalnum() or c in '-_' else '-' for c in Path(clean_name).stem)[:45]
        directory=self.workspace/'projects'/f'{stamp}-{slug}-{uuid.uuid4().hex[:6]}'
        old=dict(self.__dict__)
        try:
            (directory/'source').mkdir(parents=True)
            snapshot=directory/'source'/clean_name
            before=original.stat();signature=(before.st_size,before.st_mtime_ns,before.st_ctime_ns)
            digest=hashlib.sha256()
            with original.open('rb') as src,snapshot.open('xb') as dst:
                for chunk in iter(lambda:src.read(8*1024*1024),b''):
                    dst.write(chunk);digest.update(chunk)
                dst.flush();os.fsync(dst.fileno())
            after=original.stat()
            if signature!=(after.st_size,after.st_mtime_ns,after.st_ctime_ns):
                raise ValueError('The source changed while its preserved copy was being created. Open a stable original.')
            shutil.copystat(original,snapshot);snapshot.chmod(0o444)
            imported=LargeTable(snapshot,directory/'cache'/'data.duckdb',source_hash=digest.hexdigest())
            result=imported.execute_plan({'action':'large_analyze','method':'profile'})
            recorded_origin=clean_name if not self.allow_host_paths else str(original)
            self.project_dir,self.dataset=directory,imported
            self.source_original_path=recorded_origin;self.last_hash='0'*64
            self.plan,self.result=clean(result['plan']),clean(result)
            self.pending_plan=None;self.context={'design':'unknown','input_type':'large_table'}
            self.conversation=[]
            self.style={'width_mm':178,'height_mm':110,'font_size':9,'palette':'teal','show_points':True,'dpi':600}
            self._event('large_table_import',{'original_path':recorded_origin,'snapshot':str(snapshot.relative_to(directory)),
                'metadata':imported.metadata(),'source_sha256':imported.source_hash,'cache_identity':imported.cache_identity(),'environment':versions()})
            self.save()
            return imported
        except BaseException:
            self.__dict__.clear();self.__dict__.update(old)
            shutil.rmtree(directory,ignore_errors=True)
            raise

    def import_recording(self, path):
        from .recording import ABFRecording
        from .trace_figures import trace_result
        from .storage import require_space, MIB
        original = Path(path).expanduser().resolve()
        if original.is_file():
            require_space(self.workspace, max(16 * MIB, original.stat().st_size * 2 + 8 * MIB), 'import the ABF recording')
        initial = ABFRecording(original)
        stamp = datetime.now().strftime('%Y%m%d-%H%M%S')
        slug = ''.join(c if c.isalnum() or c in '-_' else '-' for c in original.stem)[:45]
        directory = self.workspace / 'projects' / f'{stamp}-{slug}-{uuid.uuid4().hex[:6]}'
        old = dict(self.__dict__)
        try:
            (directory / 'source').mkdir(parents=True)
            snapshot = directory / 'source' / original.name
            shutil.copy2(original, snapshot)
            snapshot.chmod(0o444)
            imported = ABFRecording(snapshot)
            if imported.source_hash != initial.source_hash:
                raise ValueError('The recording changed while its source copy was being preserved. Open a stable original.')
            initial_result = trace_result(imported, {'action':'trace','method':'trace','channels':[0],'sweeps':[0]})
            recorded_origin = original.name if not self.allow_host_paths else str(original)
            self.project_dir, self.dataset = directory, imported
            self.source_original_path = recorded_origin
            self.last_hash = '0' * 64
            self.plan, self.result = clean(initial_result['plan']), clean(initial_result)
            self.pending_plan = None
            self.context = {'design':'unknown','input_type':'recording'}
            self.conversation = []
            self.style = {'width_mm':178,'height_mm':110,'font_size':9,'palette':'teal','show_points':True,'dpi':600}
            self._event('recording_import', {'original_path':recorded_origin,'snapshot':str(snapshot.relative_to(directory)),
                                          'metadata':imported.metadata(),'source_sha256':imported.source_hash})
            self.save()
            return imported
        except BaseException:
            self.__dict__.clear();self.__dict__.update(old)
            shutil.rmtree(directory, ignore_errors=True)
            raise

    def save(self):
        if not self.project_dir:
            raise ValueError('Open a spreadsheet first to create a project.')
        state = {'format_version': 1, 'app_version': __version__, 'source': str(Path(self.dataset.source_path).relative_to(self.project_dir)),
                 'source_sha256': self.dataset.source_hash, 'original_path': self.source_original_path,
                 'input_type': 'study' if self.is_study else 'large_table' if self.is_large_table else 'recording' if self.is_recording else 'table',
                 'sheet': getattr(self.dataset,'sheet',None), 'header_row': getattr(self.dataset,'header_row',0),
                 'plan': self.plan, 'result': self.result, 'style': self.style, 'context': self.context,
                 'pending_plan': self.pending_plan, 'conversation': self.conversation,
                 'environment': versions()}
        if self.is_large_table:
            state['cache']={'database':str(Path(self.dataset.database_path).relative_to(self.project_dir)),
                            'identity':self.dataset.cache_identity()}
        self._assert_integrity()
        from .storage import append_record, require_space, MIB
        saved_payload = {'state_sha256': hashlib.sha256(canonical(state).encode()).hexdigest()}
        if self.storage_error:
            saved_payload['recovered_storage_failure'] = self.storage_error
        event = self._make_event('state_saved', saved_payload)
        state['audit_head'] = event['hash']
        encoded = json.dumps(clean(state), ensure_ascii=False, indent=2, allow_nan=False).encode('utf-8')
        target = self.project_dir / 'project.json'
        temp = self.project_dir / ('.project-' + uuid.uuid4().hex + '.tmp')
        try:
            require_space(self.project_dir, max(8 * MIB, len(encoded) * 2 + MIB), 'save the project')
            # Stage and flush the checkpoint BEFORE extending its audit head.
            # A full disk can therefore never truncate the current checkpoint.
            with temp.open('xb') as handle:
                handle.write(encoded)
                handle.flush()
                os.fsync(handle.fileno())
            append_record(self.project_dir / 'history.jsonl', (canonical(event) + '\n').encode('utf-8'),
                          finalize=lambda: os.replace(temp, target))
        except OSError as error:
            raise self._storage_failure(error)
        finally:
            temp.unlink(missing_ok=True)
        self.last_hash = event['hash']
        self.storage_error = None
        return str(self.project_dir / 'project.json')

    def open_project(self, path, recover=False, read_only=False):
        path = Path(path).expanduser().resolve()
        if path.is_dir():
            path = path / 'project.json'
        state = json.loads(path.read_text(encoding='utf-8'))
        if state.get('format_version') != 1:
            raise ValueError('This project format is not supported by this version.')
        root = path.parent
        raw_source_entry = root / state['source']
        if raw_source_entry.is_symlink():
            raise ValueError('Refusing to open a symbolic-link project source.')
        source = raw_source_entry.resolve()
        if not source.is_relative_to(root) or not source.is_file():
            raise ValueError('The saved source path is invalid or missing.')
        if sha256(source) != state['source_sha256']:
            raise ValueError('The preserved spreadsheet has changed. Source verification failed.')
        head, _ = verify_audit(root / 'history.jsonl')
        events = [json.loads(line) for line in (root / 'history.jsonl').read_text(encoding='utf-8').splitlines()]
        checkpoint_index = next((index for index, event in enumerate(events) if event['hash'] == state['audit_head']), None)
        if checkpoint_index is None:
            raise ValueError('The project history does not match the saved project. It may have been truncated.')
        checkpoint_event = events[checkpoint_index]
        saved_content = {k: v for k, v in state.items() if k != 'audit_head'}
        state_hash = hashlib.sha256(canonical(saved_content).encode()).hexdigest()
        if checkpoint_event.get('type') != 'state_saved' or checkpoint_event.get('payload', {}).get('state_sha256') != state_hash:
            raise ValueError('The saved analysis, figure settings, or conversation has changed outside the recorded history. Open a verified project copy.')
        tail = events[checkpoint_index + 1:]
        if tail and not recover:
            raise CheckpointRecoveryRequired(
                'The project history does not match the latest saved checkpoint: later complete processing records exist. '
                'The checkpoint itself is verified. Reopen through the application to recover that checkpoint while preserving all later history; '
                'later actions will not be replayed automatically.')
        if tail and read_only:
            raise ValueError('Read-only project opening cannot write a checkpoint recovery record.')
        if state.get('input_type') == 'study':
            from .study import Study
            data=Study.open(source)
        elif state.get('input_type') == 'large_table':
            from .large_table import LargeTable
            cache=(root/state['cache']['database']).resolve()
            if not cache.is_relative_to(root):raise ValueError('The saved data cache points outside this project.')
            data=LargeTable(source,cache,source_hash=state['source_sha256'],create=False)
            if canonical(data.cache_identity())!=canonical(state['cache']['identity']):
                raise ValueError('The large-data cache changed outside the saved project checkpoint.')
            data.verify_integrity(full=True)
        elif state.get('input_type') == 'recording':
            from .recording import ABFRecording
            data = ABFRecording(source)
        else:
            from .data import list_sheets
            from .working_sheets import WORKING_WORKBOOK_REL, load_working_sheet_dataset
            wpath = root / WORKING_WORKBOOK_REL
            ws_sheets = list_sheets(wpath) if wpath.is_file() else []
            if ws_sheets:
                native_sheets = list_sheets(source) or ['0_Raw_Source']
                combined_sheets = list(dict.fromkeys(native_sheets + ws_sheets))
                req_sheet = state.get('sheet')
                if req_sheet in ws_sheets:
                    data = load_working_sheet_dataset(
                        source, state['source_sha256'], wpath, req_sheet, combined_sheets
                    )
                else:
                    eff_sheet = None if req_sheet == '0_Raw_Source' else req_sheet
                    data = load_dataset(source, sheet=eff_sheet, header_row=state.get('header_row', 0))
                    data.sheets = combined_sheets
                    if not data.sheet:
                        data.sheet = '0_Raw_Source'
            else:
                data = load_dataset(source, sheet=state.get('sheet'), header_row=state.get('header_row', 0))
        recovery = None
        recovery_dir = None
        if tail:
            from .storage import require_space, MIB
            try:
                require_space(root, max(8 * MIB, path.stat().st_size * 2 + MIB), 'preserve and recover the last saved checkpoint')
                recovery_dir = root / 'recovery' / (datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ') + '-' + uuid.uuid4().hex[:6])
                if not recovery_dir.resolve().is_relative_to(root.resolve()):
                    raise ValueError('The checkpoint recovery directory points outside this project.')
                recovery_dir.mkdir(parents=True, exist_ok=False)
                backup = recovery_dir / 'checkpoint-before.json'
                with backup.open('xb') as handle:
                    handle.write(path.read_bytes());handle.flush();os.fsync(handle.fileno())
                backup.chmod(0o444)
                recovery = {'recovered_utc': datetime.now(timezone.utc).isoformat(),
                            'checkpoint_audit_head': state['audit_head'], 'retained_history_head': head,
                            'retained_later_events': len(tail), 'later_event_types': sorted({event['type'] for event in tail}),
                            'checkpoint_copy': str(backup.relative_to(root)), 'checkpoint_sha256': sha256(backup),
                            'policy': 'Restored the last complete checkpoint. All later valid processing records remain in history; their actions were not replayed.'}
                (recovery_dir / 'recovery.json').write_text(json.dumps(recovery, indent=2), encoding='utf-8')
            except OSError as error:
                if recovery_dir is not None:
                    shutil.rmtree(recovery_dir, ignore_errors=True)
                raise self._storage_failure(error, 'preserve the checkpoint recovery record')
        old = dict(self.__dict__)
        try:
            self.project_dir, self.dataset = root, data
            self.last_hash, self.source_original_path = head, state.get('original_path')
            self.plan, self.result = state.get('plan'), state.get('result')
            self.style = state.get('style', self.style)
            self.context, self.conversation = state.get('context', {}), state.get('conversation', [])
            self.pending_plan = state.get('pending_plan')
            if self.is_study:
                from .study_bridge import verify_run_records
                verify_run_records(self,full=True)
            if recovery:
                self.context['checkpoint_recovery'] = recovery
                self.pending_plan = None
                if self.is_study:
                    from .study_bridge import invalidate_approval
                    invalidate_approval(self)
                    self.context.get('study_execution', {}).pop('conversation_proposal', None)
                self._event('checkpoint_recovered', recovery)
            # A saved preview remains inspectable, but agreement must follow a
            # preview displayed during this opening, even when reusing the Session.
            self.__dict__.pop('_study_conversation_token', None)
            self.__dict__.pop('_api_conversation_token', None)
            if not read_only:
                self._event('project_opened', {'environment': versions()})
                self.save()
            return data
        except BaseException:
            self.__dict__.clear()
            self.__dict__.update(old)
            raise

    def select_sheet(self, name, header_row=None, reply=True):
        """Switch the active worksheet of a multi-sheet workbook cleanly across all modes."""
        self._assert_integrity()
        if not self.dataset:
            raise ValueError('Open a spreadsheet with worksheet tabs first.')
        if self.is_study:
            raise ValueError('Multi-file studies manage worksheet roles per source in Study / Metadata.')
        if self.is_large_table:
            raise ValueError('A delimited table has no worksheet tabs. Use its columns and explicit queries; the full source stays preserved.')
        if self.is_recording:
            raise ValueError('ABF files have channels and sweeps rather than worksheet tabs. Try “show channel 1” or “overlay sweeps 1 through 2”.')
        if not name or name not in self.dataset.sheets:
            raise ValueError('Available sheets: ' + ', '.join(self.dataset.sheets))
        prior_dialogue = self.context.get('api_dialogue')
        prior_working = deepcopy(self.context.get('working_sheets'))
        combined_sheets = list(self.dataset.sheets)
        wpath = (self.project_dir / 'derived' / 'working_sheets.xlsx') if self.project_dir else None
        from .data import list_sheets
        from .working_sheets import load_working_sheet_dataset
        ws_sheets = list_sheets(wpath) if (wpath and wpath.is_file()) else []
        if name in ws_sheets and wpath is not None:
            self.dataset = load_working_sheet_dataset(
                self.dataset.source_path,
                self.dataset.source_hash,
                wpath,
                name,
                combined_sheets,
            )
        else:
            target_header = self.dataset.header_row if header_row is None else header_row
            eff_name = None if name == '0_Raw_Source' else name
            loaded = load_dataset(self.dataset.source_path, sheet=eff_name, header_row=target_header)
            if ws_sheets:
                loaded.sheets = combined_sheets
                if not loaded.sheet:
                    loaded.sheet = '0_Raw_Source'
            self.dataset = loaded
        self.plan = self.result = self.pending_plan = None
        self.context = {'design': 'unknown'}
        if prior_dialogue:
            self.context['api_dialogue'] = prior_dialogue[-24:]
        if prior_working:
            self.context['working_sheets'] = prior_working
        self._event('sheet_changed', self.dataset.metadata())
        message = self.import_message()
        if reply:
            return self._reply(message, True)
        if self.project_dir:
            self.save()
        return {'message': message, 'refresh': True}

    def register_working_sheet(self, sheet_name, df, summary, spec, save_state=True):
        """Persist an intermediate working tab in `derived/working_sheets.xlsx` without touching `source/`."""
        self._assert_integrity()
        if not self.project_dir or not self.dataset or self.is_study or self.is_large_table or self.is_recording:
            raise ValueError('Working sheets require an open tabular project.')
        from .data import list_sheets
        from .working_sheets import MAX_WORKING_SHEETS, WORKING_WORKBOOK_REL, load_working_sheet_dataset, save_working_sheet_to_workbook
        wpath = self.project_dir / WORKING_WORKBOOK_REL
        existing_ws = list_sheets(wpath) if wpath.is_file() else []
        if sheet_name not in existing_ws and len(existing_ws) >= MAX_WORKING_SHEETS:
            raise ValueError(f'Reached maximum of {MAX_WORKING_SHEETS} intermediate working sheets in this project.')
        save_working_sheet_to_workbook(wpath, sheet_name, df)
        updated_ws = list_sheets(wpath)
        native_sheets = list_sheets(self.dataset.source_path) or ['0_Raw_Source']
        combined_sheets = list(dict.fromkeys(native_sheets + updated_ws))
        self.dataset = load_working_sheet_dataset(
            self.dataset.source_path,
            self.dataset.source_hash,
            wpath,
            sheet_name,
            combined_sheets,
        )
        self.plan = self.result = self.pending_plan = None
        history_list = list(self.context.get('working_sheets') or [])
        op_sig = hashlib.sha256(canonical(spec).encode('utf-8')).hexdigest()[:16] if isinstance(spec, dict) else ''
        entry = {
            'sheet_name': sheet_name,
            'op': str(spec.get('op', '')),
            'op_signature': op_sig,
            'summary': str(summary)[:500],
            'rows': int(len(df)),
            'columns': [str(c) for c in df.columns],
        }
        history_list = [h for h in history_list if h.get('sheet_name') != sheet_name] + [entry]
        self.context['working_sheets'] = history_list[-MAX_WORKING_SHEETS:]
        self._event('working_sheet_built', {
            'sheet_name': sheet_name,
            'op': entry['op'],
            'rows': entry['rows'],
            'columns': entry['columns'],
            'derived_workbook_sha256': sha256(wpath),
            'source_sha256': self.dataset.source_hash,
        })
        if save_state:
            self.save()
        return self.dataset

    def approve_proposal(self):
        """Execute the currently displayed proposal via explicit local UI approval."""
        self._assert_integrity()
        pending = self.context.get('api_proposal')
        if pending:
            from .api_session import _execute
            from .api_tools import safe_text
            text = 'Proceed with the displayed proposal.'
            self.conversation.append({'role': 'user', 'text': text})
            self._event('instruction', {'text': text, 'interpreter': 'explicit UI proposal approval'})
            outcome = _execute(self, {'proposal_id': pending.get('proposal_id')}, text)
            dialogue = list(self.context.get('api_dialogue', []))[-24:]
            self.context['api_dialogue'] = (dialogue + [{'role': 'user', 'text': text},
                {'role': 'assistant', 'text': safe_text(outcome.get('message', ''), 6000)}])[-24:]
            message = outcome.pop('message')
            refresh = outcome.pop('refresh', False)
            return self._reply(message, refresh, **outcome)
        if self.is_study and self.context.get('study_execution', {}).get('conversation_proposal'):
            return self.command('yes, run that')
        return {'message': 'There is no pending proposal to approve.', 'refresh': False}

    def dismiss_proposal(self):
        """Dismiss the currently displayed proposal without mutating scientific state."""
        self._assert_integrity()
        had_api = self.context.pop('api_proposal', None) is not None
        had_study = False
        if self.is_study and self.context.get('study_execution', {}).get('conversation_proposal'):
            self.context['study_execution']['conversation_proposal'] = None
            had_study = True
        if not had_api and not had_study:
            return {'message': 'There is no pending proposal to dismiss.', 'refresh': False}
        self._event('proposal_dismissed', {'origin': 'ui_dismiss_button', 'calculations_performed': False})
        return self._reply('Dismissed the pending proposal. Completed results and raw data remain unchanged.', False)

    def _reply(self, message, refresh=False, **kwargs):
        self.conversation.append({'role': 'assistant', 'text': message})
        self._event('response', {'text': message})
        if self.project_dir:
            self.save()
        return {'message': message, 'refresh': refresh, **kwargs}

    def command(self, text, model=None):
        text = text.strip()
        if not text:
            return {'message': 'Tell me what you would like to do.', 'refresh': False}
        # File operations are explicit user instructions, not model proposals.
        import re
        folder_request=re.fullmatch(r'(?:open|import|load)\s+(?:study\s+folder|study|batch|folder)\s+["\x27]?(.+?)["\x27]?\s*',text,re.I)
        if folder_request:
            if not self.allow_host_paths:
                return {'message': 'Opening server filesystem paths from chat is disabled in this session. Upload or paste your spreadsheet directly.', 'refresh': False}
            try:
                self._assert_integrity()
                self.import_study_folder(folder_request.group(1))
                self._event('instruction',{'text':text,'interpreter':'explicit study folder import'})
                return self._reply(self.import_message(),True)
            except Exception as error:
                return {'message':str(error),'refresh':False}
        # API conversation is the primary interpreter, not an unknown-command
        # fallback. Explicit file opens and worksheet switches remain local user actions.
        if model and getattr(model, 'provider', None) in ('openai', 'gemini') and not self.is_recording:
            opening = interpret(text, None) if re.match(r'^(?:open|load|import)\s+', text, re.I) else {}
            if opening.get('action') == 'open' and not self.allow_host_paths:
                return {'message': 'Opening server filesystem paths from chat is disabled in this session. Upload or paste your spreadsheet directly.', 'refresh': False}
            if re.match(r'^(?:use\s+)?sheet\b', text, re.I) and self.dataset and not self.is_study and not self.is_large_table:
                sheet_cmd = interpret(text, self.dataset, self.plan, self.context)
                if sheet_cmd.get('action') == 'sheet':
                    self._assert_integrity()
                    self.conversation.append({'role': 'user', 'text': text})
                    self._event('instruction', {'text': text, 'interpreter': 'explicit worksheet selection'})
                    name = sheet_cmd.get('sheet')
                    if not name or name not in self.dataset.sheets:
                        return self._reply('Available sheets: ' + ', '.join(self.dataset.sheets))
                    return self.select_sheet(name, sheet_cmd.get('header_row'), reply=True)
            if opening.get('action') != 'open':
                from .api_session import command_api
                return command_api(self, text, model)
        if self.is_study:
            if re.match(r'^(?:open|load|import)\s+',text,re.I):
                opening=interpret(text,None)
                if opening.get('action')=='open':
                    if not self.allow_host_paths:
                        return {'message':'Opening server filesystem paths from chat is disabled in this session. Upload or paste your spreadsheet directly.','refresh':False}
                    try:
                        self._assert_integrity();path=opening['path']
                        if Path(path).name=='project.json' or Path(path).is_dir():self.open_project(path,recover=True)
                        else:self.import_file(path)
                        self._event('instruction',{'text':text,'interpreter':'explicit file import'})
                        return self._reply(self.import_message(),True)
                    except Exception as error:return {'message':str(error),'refresh':False}
            from .study_session import command_study
            return command_study(self,text,model)
        self._assert_integrity()
        conv_len = len(self.conversation)
        self.conversation.append({'role': 'user', 'text': text})
        self._event('instruction', {'text': text, 'interpreter': 'local parser with optional local-model fallback' if model and not self.is_recording else 'offline commands'})
        ctx = dict(self.context)
        if self.is_large_table and self.result:
            from .large_reporting import model_aggregate_context
            ctx['computed_aggregate']=model_aggregate_context(self.result)
        elif self.result and not self.is_recording:
            ctx['result_summary'] = {'method': self.result.get('method'), 'summary': self.result.get('summary', '')}
        if self.pending_plan:
            ctx['pending_plan'] = self.pending_plan
        checkpoint = {key: deepcopy(getattr(self, key)) for key in ('plan', 'result', 'style', 'context', 'pending_plan')}
        try:
            # Essential open/export/style/help instructions work with no model service.
            command = interpret(text, self.dataset, self.plan, ctx)
            if model and not self.is_recording and not command.get('unsupported') and command.get('action') in ('help', 'clarify', 'unknown', 'recommend') and self.dataset:
                # Do not bypass source-protection blocking rules with a model.
                from .knowledge import session_reference_library
                refs = [] if self.is_large_table else session_reference_library(self).search(text)
                if refs:
                    ctx['reference_snippets'] = refs
                    self._event('references_supplied_to_model', [{'id': r['id'], 'text_sha256': r['text_sha256'], 'url': r.get('url')} for r in refs])
                command = model.plan(text, self.dataset, self.plan, ctx)
                if getattr(model, 'cancelled', False):
                    from .llm import ModelCancelledError
                    raise ModelCancelledError('The local reply was cancelled. No new calculation was run.')
                self._event('model_plan_supplied',{'model':getattr(model,'model','configured local model'),
                    'configured_model_digest':getattr(model,'configured_model_digest',None),
                    'input_type':'large_table' if self.is_large_table else 'table','plan':command})
            action = command.get('action')
            self._event('interpreted_plan', command)
            if action == 'open':
                if not self.allow_host_paths:
                    return self._reply('Opening server filesystem paths from chat is disabled in this session. Upload or paste your spreadsheet directly.')
                path = command.get('path')
                if not path:
                    return self._reply('Use Open spreadsheet, or type open followed by the full file path.', open_dialog=True)
                if Path(path).name == 'project.json' or Path(path).is_dir():
                    self.open_project(path,recover=True)
                else:
                    self.import_file(path)
                return self._reply(self.import_message(), True)
            if action == 'help':
                return self._reply(command.get('message') or capabilities())
            if not self.dataset:
                return self._reply('Open a spreadsheet, drop a file here, or choose Try example data. Then tell me what to do.')
            if action == 'blocked':
                return self._reply(command.get('message', 'Observations are retained. No automatic outlier removal is applied.'))
            if action == 'large_analyze':
                if not self.is_large_table:return self._reply('Open a large delimited table before requesting a disk-backed query.')
                command.pop('message',None)
                result=self.dataset.execute_plan(command)
                self._assert_integrity()
                candidate_style={**self.style,**command.get('style',{})}
                if not self.defer_figure_validation:
                    from .figures import make_figure
                    make_figure(self.dataset,result,result['plan'],candidate_style)
                self.plan,self.result=clean(result['plan']),clean(result)
                self.style,self.pending_plan=candidate_style,None
                self._event('large_table_analysis',{'plan':self.plan,'result':self.result,
                    'source_sha256':self.dataset.source_hash,'cache_identity':self.dataset.cache_identity(),'environment':versions()})
                from .large_reporting import large_message
                return self._reply(large_message(result),True)
            if action == 'ap_query':
                from .ap_reporting import measurement_message
                return self._reply(measurement_message(self.result,start=command.get('start',0),stop=command.get('stop',20),event_id=command.get('event_id')))
            if action == 'pipeline_save':
                from .pipelines import save_pipeline
                return self._reply(save_pipeline(self,command['name']))
            if action in ('pipeline_check','pipeline_run'):
                if not self.allow_host_paths:
                    return self._reply('Server-side folder batch pipelines are disabled in this session.')
                from .pipelines import run_folder
                return self._reply(run_folder(self,command['folder'],check_only=action=='pipeline_check'))
            if action == 'pipeline_export':
                batch=self.context.get('last_batch')
                if not batch:return self._reply('Run a saved pipeline on a folder first, then ask “export pipeline figures”.')
                return self._reply('Preparing figures for the completed pipeline projects.',batch_export_request={'batch_dir':batch})
            if action in ('trace', 'spikes', 'action_potentials'):
                from .trace_figures import trace_result
                command.pop('message',None)
                if not self.is_recording:
                    return self._reply('Open an ABF recording before requesting a trace view.')
                if action == 'action_potentials':
                    from .action_potentials import ap_result
                    result = ap_result(self.dataset,command)
                elif action == 'spikes':
                    from .spikes import spike_result
                    result = spike_result(self.dataset,command)
                else:
                    result = trace_result(self.dataset,command)
                self._assert_integrity()
                candidate_style = {**self.style,**command.get('style',{})}
                if not self.defer_figure_validation:
                    from .figures import make_figure
                    make_figure(self.dataset,result,result['plan'],candidate_style)
                self.plan,self.result = clean(result['plan']),clean(result)
                self.style,self.pending_plan = candidate_style,None
                if action in ('spikes','action_potentials'):
                    self._event('action_potential_analysis' if action=='action_potentials' else 'spike_analysis', {'plan': self.plan, 'result': self.result,
                        'source_sha256': self.dataset.source_hash, 'environment': versions()})
                else:
                    self._event('recording_view',{'plan':self.plan,'trace_accounting':self.result.get('trace_accounting'),
                                                  'environment':versions()})
                if action == 'action_potentials':
                    from .ap_reporting import measurement_message
                    return self._reply(result['summary']+'\n\n'+measurement_message(result),True)
                return self._reply(result['summary'],True)
            if action == 'clarify':
                self.pending_plan = command.get('plan', {k: v for k, v in command.items() if k not in ('message', 'action')})
                if self.pending_plan.get('design') == 'unknown':
                    self.context['design'] = 'unknown'
                return self._reply(command['message'])
            if action == 'design':
                self.context['design'] = command['design']
                if self.pending_plan:
                    command = dict(self.pending_plan)
                    command.update(action='analyze', design=self.context['design'])
                    self.pending_plan = None
                else:
                    return self._reply(f"Recorded study structure: {self.context['design']}. Tell me which analysis to run.")
            if action == 'mask_rows':
                if self.is_large_table or self.is_recording:
                    return self._reply('Row-exclusion masks apply to standard data tables; for ABF recordings use “exclude X to Y s because …”.')
                from .engine import _excluded_mask
                if command.get('mode') == 'clear':
                    self.context.pop('excluded_rows', None)
                else:
                    by_row = {int(item['row']): dict(item) for item in self.context.get('excluded_rows', []) if isinstance(item, dict) and 'row' in item}
                    for item in command.get('excluded_rows', []):
                        by_row[int(item['row'])] = {'row': int(item['row']), 'reason': str(item['reason'])}
                    merged = [by_row[r] for r in sorted(by_row)]
                    _excluded_mask(self.dataset, {'excluded_rows': merged})
                    self.context['excluded_rows'] = merged
                self._event('row_mask_updated', {'mode': command.get('mode'), 'excluded_rows': deepcopy(self.context.get('excluded_rows', []))})
                if self.plan and self.result:
                    updated_plan = deepcopy(self.plan)
                    if self.context.get('excluded_rows'):
                        updated_plan['excluded_rows'] = deepcopy(self.context['excluded_rows'])
                    else:
                        updated_plan.pop('excluded_rows', None)
                    result = analyze(self.dataset, updated_plan)
                    candidate_plan = clean(result.get('plan', updated_plan))
                    if not self.defer_figure_validation:
                        from .figures import make_figure
                        make_figure(self.dataset, result, candidate_plan, self.style)
                    self.plan, self.result = candidate_plan, clean(result)
                    self._event('analysis', {'plan': self.plan, 'result': self.result, 'environment': versions()})
                    return self._reply(command['message'] + '\n\n' + result['summary'], True)
                return self._reply(command['message'], False)
            if action == 'sheet':
                if self.is_large_table:return self._reply('A delimited table has no worksheet tabs. Use its columns and explicit queries; the full source stays preserved.')
                if self.is_recording:
                    return self._reply('ABF files have channels and sweeps rather than worksheet tabs. Try “show channel 1” or “overlay sweeps 1 through 2”.')
                name = command.get('sheet')
                if not name or name not in self.dataset.sheets:
                    return self._reply('Available sheets: ' + ', '.join(self.dataset.sheets))
                return self.select_sheet(name, command.get('header_row', self.dataset.header_row), reply=True)
            if action == 'style':
                changes = command.get('style', {})
                candidate_style = {**self.style, **changes}
                candidate_plan = dict(self.plan or {})
                if command.get('plot'):
                    candidate_plan['plot'] = command['plot']
                if self.result and not self.defer_figure_validation:
                    from .figures import make_figure
                    make_figure(self.dataset, self.result, candidate_plan, candidate_style)
                else:
                    from .figures import _style
                    _style(candidate_plan, candidate_style)
                self.style, self.plan = candidate_style, candidate_plan or self.plan
                if self.result:
                    self.result['plan'] = clean(self.plan)
                return self._reply(command.get('message', 'Updated the figure.'), bool(self.result))
            if action == 'export':
                if not self.result:
                    return self._reply('Run an analysis or make a plot first, then ask me to export it.')
                if command.get('path') and not self.allow_host_paths:
                    return self._reply('Custom server export paths are disabled in this session.')
                return self._reply('Preparing the figure and reproducibility package.', export_request=command)
            if action == 'recommend':
                return self._reply(command.get('message', 'Tell me the outcome, group or predictor, and whether observations are independent or paired.'))
            if action != 'analyze':
                return self._reply(command.get('message') or 'I did not recognize that request. Type help for supported instructions.')
            command.pop('message', None)
            command['design'] = command.get('design') or self.context.get('design', 'unknown')
            if command['design'] in ('independent', 'paired'):
                self.context['design'] = command['design']
            if 'excluded_rows' not in command and self.context.get('excluded_rows'):
                command['excluded_rows'] = deepcopy(self.context['excluded_rows'])
            result = analyze(self.dataset, command)
            candidate_style = {**self.style, **command.get('style', {})}
            candidate_plan = clean(result.get('plan', command))
            from .figures import make_figure
            if not self.defer_figure_validation:
                make_figure(self.dataset, result, candidate_plan, candidate_style)
            self.plan, self.result, self.pending_plan = candidate_plan, clean(result), None
            if 'excluded_rows' in candidate_plan:
                if candidate_plan['excluded_rows']:
                    self.context['excluded_rows'] = deepcopy(candidate_plan['excluded_rows'])
                else:
                    self.context.pop('excluded_rows', None)
            self.style = candidate_style
            self._event('analysis', {'plan': self.plan, 'result': self.result, 'environment': versions()})
            return self._reply(result['summary'], True)
        except Exception as error:
            from .storage import StorageError, is_space_error
            if isinstance(error, StorageError) or is_space_error(error):
                for key, value in checkpoint.items():
                    setattr(self, key, value)
                del self.conversation[conv_len:]
                return self._unsaved_reply(error)
            self._event('request_cancelled' if model and getattr(model, 'cancelled', False) else 'request_failed', {'error': str(error)})
            message = str(error) or type(error).__name__
            if self.result:
                message += '\n\nThe previous successful analysis and figure are still displayed. This request did not replace them.'
            return self._reply(message)

    def import_message(self):
        message = self._import_message()
        recovery = self.context.get('checkpoint_recovery')
        if recovery:
            message = ('Recovered the last complete saved checkpoint. '+str(recovery.get('retained_later_events', 0))+
                       ' later processing records remain preserved in the history, but their actions were not replayed. '
                       'Review the restored choices before running another analysis.\n\n'+message)
        return message

    def _import_message(self):
        d = self.dataset
        if self.is_study:
            if self.result and self.result.get('method')=='study_execution':
                from .study_bridge import status_text
                return (self.result['summary']+'\n\n'+status_text(self)+
                    '\n\nCalculated results and figures are retained. Ask about an outcome, refine the figure, review a revised execution recipe or export analysis. The Study plan and Metadata review tabs retain the scientific context and source issues.')
            from .study_planner import study_reply
            return study_reply(d,self.context['study_state'])
        if self.is_large_table:
            profiles=d.metadata().get('profiles',{})
            numeric=[c for c in d.columns if profiles.get(c,{}).get('numeric_compatible')]
            examples=['“describe this data”','“show columns”']
            if d.columns:examples.append('“count rows by '+d.columns[0]+'”')
            if numeric:examples.append('“summarize '+numeric[0]+'”')
            return (f'Opened {Path(d.source_path).name}: {d.row_count:,} source records and {len(d.columns)} columns, using a disk-backed table. '
                'The original file is preserved; the visible grid is a bounded preview. No statistical test or row-independence assumption is made. '
                'Try '+', '.join(examples)+', or ask about the available analysis plan. '
                'The optional model receives only bounded column/aggregate metadata; calculations run locally.')
        if self.is_recording:
            m = d.metadata()
            units = ', '.join(f"{c['index']+1}: {c['name']} ({c['unit'] or 'unit unavailable'})" for c in d.channels)
            return (f"Opened {Path(d.source_path).name}: ABF {m.get('abf_version','')}, {m['acquisition_mode']}, "
                    f"{len(d.channels)} channels, {len(d.sweeps)} sweeps/segments.\n"
                    f"Channels (numbered from 1): {units}.\n"
                    f"Sampled duration per channel: {m['sampled_duration_s']:g} s; elapsed recording extent: {m['elapsed_duration_s']:g} s.\n"
                    'The raw source is preserved. The first channel/sweep is previewed for up to 10 seconds. '
                    'Try “show channel 1 from 0 to 1 seconds”, “overlay sweeps 1 through 2”, “show full recording”, or “show metadata”. '
                    'For a voltage channel, try “detect spikes using threshold -20 mV and refractory 2 ms”, then “firing rate in 100 ms bins”. '
                    'No signal filtering or statistical test is applied.')
        columns = ', '.join(str(c) for c in d.df.columns)
        msg = f'Opened {Path(d.source_path).name}: {len(d.df):,} rows and {len(d.df.columns)} columns.\nColumns: {columns}.\nThe original file is preserved. '
        if getattr(d, 'is_clampflow', False):
            msg += (
                f"Detected a ClampFlow compiled electrophysiology workbook (active sheet: {d.sheet}; "
                f"available sheets: {', '.join(d.sheets)}). "
                'Try “describe the data”, compare an extracted measure across groups (or pool sweeps/cells by animal ID), or switch sheets.'
            )
        else:
            msg += 'Try “describe the data”, “compare Score by Treatment”, or name the columns you want to plot.'
        warnings = d.metadata().get('warnings', [])
        if warnings:
            msg += '\n\nImport notes:\n' + '\n'.join(str(w) for w in warnings)
        return msg

    def export_bundle(self, request=None):
        from .storage import require_space, MIB
        request = request or {}
        if request.get('path') and not self.allow_host_paths:
            raise ValueError('Custom host export paths are disabled in this session.')
        # Keep room for both output files and their ZIP, plus a saved checkpoint.
        source_bytes = 0
        if self.dataset:
            if self.is_study:
                if request.get('include_source', False):
                    source_bytes = sum((self.project_dir / source['relative_path']).stat().st_size
                                       for source in self.dataset.manifest()['sources'])
            elif not self.is_large_table or request.get('include_source', False):
                source_bytes = Path(self.dataset.source_path).stat().st_size
        needed = 64 * MIB + 2 * source_bytes
        require_space(self.project_dir or self.workspace, needed, 'export the figures and analysis record')
        if request.get('path'):
            require_space(Path(request['path']).expanduser(), needed, 'export the figures and analysis record')
        if self.is_study:
            if self.result and self.result.get('method')=='study_execution' and request.get('action')!='study_export':
                from .study_exports import export_study_analysis
                return export_study_analysis(self,request)
            from .study_session import export_study
            return export_study(self,request)
        if self.is_large_table:
            from .large_exports import export_large_bundle
            return export_large_bundle(self,request)
        if self.is_recording:
            return self.export_recording_bundle(request)
        from .figures import make_figure, export_figure, figure_caption
        self._assert_integrity()
        if not self.result:
            raise ValueError('There is no result to export.')
        source = Path(self.dataset.source_path)
        if source.is_symlink():
            raise ValueError('Refusing to export a symlinked source file.')
        stamp = datetime.now().strftime('%Y%m%d-%H%M%S') + '-' + uuid.uuid4().hex[:4]
        parent = Path(request.get('path') or self.project_dir / 'exports').expanduser().resolve()
        parent.mkdir(parents=True, exist_ok=True)
        # An export is always a new directory; source files are never destinations.
        stem_name = f'figure-{stamp}'
        folder = parent / stem_name
        stage = parent / f'.{stem_name}.tmp'
        archive = folder.with_suffix('.zip')
        temp_archive = parent / f'.{stem_name}.zip.tmp'
        stage.mkdir(parents=True, exist_ok=False)
        style = dict(self.style)
        style.update(request.get('style', {}))
        formats = ['pdf', 'svg', 'png']
        requested = request.get('format') or request.get('style', {}).get('format')
        if requested in ('tif', 'tiff'):
            formats.append('tiff')
        try:
            figure = make_figure(self.dataset, self.result, self.plan, style)
            for fmt in formats:
                export_figure(figure, stage / f'figure.{fmt}', dpi=style.get('dpi', 600))
            caption = figure_caption(self.dataset, self.result, self.plan, style)
            if self.context.get('synthetic_demo'):
                caption = 'Synthetic demonstration data. ' + caption
            (stage / 'caption.txt').write_text(caption + '\n', encoding='utf-8')
            for i, table in enumerate(self.result.get('tables', []), 1):
                with open(stage / f'results-{i}.csv', 'w', encoding='utf-8', newline='') as handle:
                    writer = csv.DictWriter(handle, fieldnames=table['columns'], extrasaction='ignore')
                    writer.writeheader()
                    writer.writerows(escape_csv_rows(table['rows'], table['columns']))
            (stage / 'source').mkdir()
            shutil.copy2(source, stage / 'source' / source.name)
            self.dataset.df.to_csv(stage / 'imported-data.csv', index=False)
            reproducibility = {'app_version': __version__, 'environment': versions(), 'synthetic_demo': bool(self.context.get('synthetic_demo')), 'source': 'source/' + source.name,
                               'source_sha256': self.dataset.source_hash, 'sheet': self.dataset.sheet,
                               'header_row': self.dataset.header_row, 'plan': self.plan, 'style': style, 'result': self.result}
            wpath = self.project_dir / 'derived' / 'working_sheets.xlsx'
            if wpath.is_file():
                from .data import list_sheets
                if self.dataset.sheet in list_sheets(wpath):
                    (stage / 'derived').mkdir(exist_ok=True)
                    shutil.copy2(wpath, stage / 'derived' / 'working_sheets.xlsx')
                    reproducibility['derived_workbook'] = 'derived/working_sheets.xlsx'
                    reproducibility['derived_workbook_sha256'] = sha256(wpath)
                    reproducibility['working_sheets_provenance'] = deepcopy(self.context.get('working_sheets') or [])
            (stage / 'analysis.json').write_text(json.dumps(clean(reproducibility), ensure_ascii=False, indent=2), encoding='utf-8')
            (stage / 'methods.txt').write_text(self.methods_text(caption), encoding='utf-8')
            (stage / 'reproduce.py').write_text(REPRODUCE, encoding='utf-8')
            # Keep the engine and figure source with each export so the exact recipe is runnable.
            code = stage / 'reproduction-source' / 'statweave'
            code.mkdir(parents=True)
            module_root = Path(__file__).parent
            if getattr(sys, 'frozen', False):
                module_root = Path(sys._MEIPASS) / 'reproduction-source' / 'statweave'
            for name in ['__init__.py', 'scrubber.py', 'data.py', 'curves.py', 'engine.py', 'figures.py', 'working_sheets.py']:
                if (module_root / name).is_file():
                    shutil.copy2(module_root / name, code / name)
            requirements = '\n'.join(f'{k}=={v}' for k, v in versions().items() if k in ('numpy','pandas','scipy','matplotlib','statsmodels','openpyxl','xlrd','odfpy','defusedxml') and v != 'not installed')
            (stage / 'requirements.txt').write_text(requirements + '\n', encoding='utf-8')
            shutil.copy2(self.project_dir / 'history.jsonl', stage / 'history.jsonl')
            manifest = {str(p.relative_to(stage)): sha256(p) for p in sorted(stage.rglob('*')) if p.is_file()}
            (stage / 'SHA256.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
            with temp_archive.open('xb') as raw_zip:
                with zipfile.ZipFile(raw_zip, 'w', compression=zipfile.ZIP_DEFLATED) as handle:
                    for path in sorted(stage.rglob('*')):
                        if path.is_file():
                            handle.write(path, str(Path(folder.name) / path.relative_to(stage)))
                raw_zip.flush()
                os.fsync(raw_zip.fileno())
            os.replace(stage, folder)
            os.replace(temp_archive, archive)
        except BaseException:
            shutil.rmtree(stage, ignore_errors=True)
            temp_archive.unlink(missing_ok=True)
            raise
        try:
            self._event('export', {'directory': str(folder), 'formats': formats, 'source_sha256': self.dataset.source_hash,
                                   'plan': self.plan, 'style': style})
            self.save()
        except BaseException:
            shutil.rmtree(folder, ignore_errors=True)
            archive.unlink(missing_ok=True)
            raise
        return {'folder': str(folder), 'archive': str(archive), 'figure': str(folder / 'figure.png')}

    def export_recording_bundle(self, request=None):
        from .figures import make_figure, export_figure, figure_caption
        from .storage import require_space, MIB
        self._assert_integrity()
        if not self.is_recording or not self.result:
            raise ValueError('Open an ABF recording and choose a trace view first.')
        request = request or {}
        if request.get('path') and not self.allow_host_paths:
            raise ValueError('Custom host export paths are disabled in this session.')
        source=Path(self.dataset.source_path)
        if source.is_symlink():
            raise ValueError('Refusing to export a symlinked recording.')
        stamp = datetime.now().strftime('%Y%m%d-%H%M%S') + '-' + uuid.uuid4().hex[:4]
        parent = Path(request.get('path') or self.project_dir / 'exports').expanduser().resolve()
        require_space(parent, 64 * MIB + 2 * source.stat().st_size, 'export the recording figures and analysis record')
        parent.mkdir(parents=True, exist_ok=True)
        is_ap = self.result.get('method') == 'action_potentials'
        is_spikes = self.result.get('method') in ('spikes','action_potentials')
        stem = 'action-potentials' if is_ap else 'spikes' if is_spikes else 'trace'
        stem_name = f'{stem}-{stamp}'
        folder = parent / stem_name
        stage = parent / f'.{stem_name}.tmp'
        archive = folder.with_suffix('.zip')
        temp_archive = parent / f'.{stem_name}.zip.tmp'
        stage.mkdir(parents=True, exist_ok=False)
        style = {**self.style, **request.get('style', {})}
        formats = ['pdf','svg','png']
        if (request.get('format') or request.get('style',{}).get('format')) in ('tif','tiff'):
            formats.append('tiff')
        try:
            figure = make_figure(self.dataset,self.result,self.plan,style)
            for fmt in formats:
                export_figure(figure,stage/f'{stem}.{fmt}',dpi=style.get('dpi',600))
            caption = figure_caption(self.dataset,self.result,self.plan,style)
            (stage/'caption.txt').write_text(caption+'\n',encoding='utf-8')
            (stage/'recording.json').write_text(json.dumps(clean(self.dataset.metadata()),indent=2),encoding='utf-8')
            for index,table in enumerate(self.result.get('tables',[]),1):
                name = (''.join(c.lower() if c.isalnum() else '-' for c in table['title']).strip('-')
                        if is_spikes else f'metadata-{index}')
                with open(stage/f'{name}.csv','w',encoding='utf-8',newline='') as handle:
                    writer=csv.DictWriter(handle,fieldnames=table['columns'],extrasaction='ignore')
                    writer.writeheader();writer.writerows(escape_csv_rows(table['rows'],table['columns']))
            if is_spikes:
                from .spikes import EVENT_COLUMNS
                candidates = self.result.get('candidates', [])
                fields = list(dict.fromkeys(key for row in candidates for key in row))
                with open(stage/'detection-candidates.csv','w',encoding='utf-8',newline='') as handle:
                    writer=csv.DictWriter(handle,fieldnames=fields or EVENT_COLUMNS)
                    writer.writeheader();writer.writerows(candidates)
                (stage/'processing-steps.json').write_text(json.dumps(clean(self.result.get('processing_steps',[])),indent=2),encoding='utf-8')
            if is_ap:
                (stage/'review-decisions.json').write_text(json.dumps(clean(self.plan.get('event_decisions',[])),indent=2),encoding='utf-8')
                (stage/'analysis-regions.json').write_text(json.dumps(clean({'start_s':self.plan.get('start_s'),'end_s':self.plan.get('end_s'),
                    'excluded_regions':self.plan.get('excluded_regions',[])}),indent=2),encoding='utf-8')
            (stage/'source').mkdir()
            shutil.copy2(source,stage/'source'/source.name)
            specification={'input_type':'recording','app_version':__version__,'environment':versions(),
                'source':'source/'+source.name,'source_sha256':self.dataset.source_hash,
                'plan':self.plan,'style':style,'result':self.result,
                'display':clean(getattr(figure,'_statweave_trace_display',{})),
                'raw_source_included':True,'processing':self.result.get('processing_steps', 'No filtering, baseline correction, analytical resampling or inference.')}
            (stage/'analysis.json').write_text(json.dumps(clean(specification),indent=2),encoding='utf-8')
            methods=(self.result['summary']+'\n\n'+caption+'\n\nThe original ABF is included in source/. '
                'Selected windows and display reduction do not alter the recording. '+
                ('Spike detection and descriptive waveform/firing-rate measurements use full-resolution calibrated voltage samples. No inferential statistical tests were performed. ' if is_spikes else
                 'No signal measurements or inferential statistical tests were performed. ')+
                'Raw time samples are not independent biological replicates.\n\nView plan\n'+json.dumps(self.plan,indent=2)+
                '\n\nSource SHA-256\n'+self.dataset.source_hash+'\n')
            (stage/'methods.txt').write_text(methods,encoding='utf-8')
            (stage/'reproduce.py').write_text(REPRODUCE_RECORDING,encoding='utf-8')
            code=stage/'reproduction-source/statweave';code.mkdir(parents=True)
            module_root=Path(__file__).parent
            if getattr(sys,'frozen',False):module_root=Path(sys._MEIPASS)/'reproduction-source/statweave'
            for name in ['__init__.py','curves.py','recording.py','trace_figures.py','figures.py','spikes.py','spike_figures.py','action_potentials.py','ap_figures.py']:
                shutil.copy2(module_root/name,code/name)
            pinned='\n'.join(f'{k}=={v}' for k,v in versions().items() if k in ('numpy','pandas','scipy','matplotlib','neo','quantities') and v!='not installed')
            (stage/'requirements.txt').write_text(pinned+'\n',encoding='utf-8')
            shutil.copy2(self.project_dir/'history.jsonl',stage/'history.jsonl')
            manifest={str(p.relative_to(stage)):sha256(p) for p in sorted(stage.rglob('*')) if p.is_file()}
            (stage/'SHA256.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
            with temp_archive.open('xb') as raw_zip:
                with zipfile.ZipFile(raw_zip,'w',compression=zipfile.ZIP_DEFLATED) as handle:
                    for path in sorted(stage.rglob('*')):
                        if path.is_file():handle.write(path,str(Path(folder.name)/path.relative_to(stage)))
                raw_zip.flush();os.fsync(raw_zip.fileno())
            os.replace(stage,folder)
            os.replace(temp_archive,archive)
        except BaseException:
            shutil.rmtree(stage,ignore_errors=True)
            temp_archive.unlink(missing_ok=True)
            raise
        try:
            self._event('recording_export',{'directory':str(folder),'formats':formats,
                'source_sha256':self.dataset.source_hash,'plan':self.plan,'style':style,
                'display':specification['display'],'raw_source_included':True})
            self.save()
        except BaseException:
            shutil.rmtree(folder,ignore_errors=True)
            archive.unlink(missing_ok=True)
            raise
        return {'folder':str(folder),'archive':str(archive),'figure':str(folder/f'{stem}.png'),'input_type':'recording'}

    def methods_text(self, caption=''):
        return ('StatWeave ' + __version__ + '\n\n' + self.result['summary'] + '\n\nAnalysis plan\n' +
                json.dumps(self.plan, indent=2, ensure_ascii=False) + '\n\nSource SHA-256\n' + self.dataset.source_hash +
                '\n\nRow accounting\n' + json.dumps(self.result.get('row_accounting', {}), indent=2) +
                '\n\nNotes\n' + '\n'.join(self.result.get('warnings', [])) + '\n\nFigure caption\n' + caption +
                '\n\nSource retained; no automatic outlier deletion. History hashes detect accidental edits or inconsistent history; they are not an externally signed or tamper-proof record.\n')


REPRODUCE = '''"""Reproduce exported analysis and figures. Install requirements.txt first."""
import json,math,sys,hashlib
from pathlib import Path
root=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'reproduction-source'))
from statweave.data import load_dataset
from statweave.engine import analyze
from statweave.figures import make_figure,export_figure
def _clean(v):
    if isinstance(v,dict):return {str(k):_clean(val) for k,val in v.items()}
    if isinstance(v,(list,tuple)):return [_clean(val) for val in v]
    if isinstance(v,float):return v if math.isfinite(v) else None
    if isinstance(v,(str,int,bool)) or v is None:return v
    if hasattr(v,'item'):return _clean(v.item())
    return str(v)
spec=json.loads((root/'analysis.json').read_text())
source=root/spec['source']
if hashlib.sha256(source.read_bytes()).hexdigest()!=spec['source_sha256']:
    raise ValueError('Source file changed')
data_file=root/spec['derived_workbook'] if spec.get('derived_workbook') else source
if spec.get('derived_workbook') and hashlib.sha256(data_file.read_bytes()).hexdigest()!=spec['derived_workbook_sha256']:
    raise ValueError('Derived working workbook changed')
eff_sheet=None if (not spec.get('derived_workbook') and spec.get('sheet')=='0_Raw_Source') else spec['sheet']
if spec.get('derived_workbook'):
    from statweave.working_sheets import load_working_sheet_dataset
    data=load_working_sheet_dataset(source,spec['source_sha256'],data_file,eff_sheet,[eff_sheet])
else:
    data=load_dataset(data_file,sheet=eff_sheet,header_row=spec.get('header_row',0))
result=_clean(analyze(data,spec['plan']))
(root/'reproduced-results.json').write_text(json.dumps(result,indent=2,ensure_ascii=False))
if {k:v for k,v in result.items() if k!='plan'}!={k:v for k,v in spec['result'].items() if k!='plan'}:
    raise ValueError('Recomputed results differ from the recorded result; inspect reproduced-results.json.')
figure=make_figure(data,result,spec['plan'],spec['style'])
for extension in ['pdf','svg','png']:
    export_figure(figure,root/('reproduced-figure.'+extension),dpi=spec['style'].get('dpi',600))
print('Reproduced results and figures in',root)
'''


REPRODUCE_RECORDING = '''"""Reproduce an ABF view or derived spike measurements without modifying the source."""
import json,math,sys,hashlib
from pathlib import Path
root=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'reproduction-source'))
from statweave.recording import ABFRecording
from statweave.trace_figures import trace_result
from statweave.spikes import spike_result
from statweave.action_potentials import ap_result
from statweave.figures import make_figure,export_figure
def _clean(v):
    if isinstance(v,dict):return {str(k):_clean(val) for k,val in v.items()}
    if isinstance(v,(list,tuple)):return [_clean(val) for val in v]
    if isinstance(v,float):return v if math.isfinite(v) else None
    if isinstance(v,(str,int,bool)) or v is None:return v
    if hasattr(v,'item'):return _clean(v.item())
    return str(v)
spec=json.loads((root/'analysis.json').read_text())
source=root/spec['source']
if hashlib.sha256(source.read_bytes()).hexdigest()!=spec['source_sha256']:
    raise ValueError('Source file changed')
recording=ABFRecording(source)
method=spec['plan'].get('method')
result=_clean({'spikes':spike_result,'action_potentials':ap_result,'trace':trace_result}[method](recording,spec['plan']))
stem={'spikes':'spikes','action_potentials':'action-potentials','trace':'trace'}[method]
(root/'reproduced-results.json').write_text(json.dumps(result,indent=2,ensure_ascii=False))
if {k:v for k,v in result.items() if k!='plan'}!={k:v for k,v in spec['result'].items() if k!='plan'}:
    raise ValueError('Recomputed recording results differ from the recorded result; inspect reproduced-results.json.')
figure=make_figure(recording,result,spec['plan'],spec['style'])
for extension in ['pdf','svg','png']:
    export_figure(figure,root/('reproduced-'+stem+'.'+extension),dpi=spec['style'].get('dpi',600))
print('Reproduced ABF view in',root)
'''
