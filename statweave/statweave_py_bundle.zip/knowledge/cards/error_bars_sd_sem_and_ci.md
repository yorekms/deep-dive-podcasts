# Understanding Error Bars: SD vs. SEM vs. 95% Confidence Intervals vs. IQR

Different error bars answer fundamentally different scientific questions—never switch to `SEM` merely to make bars look smaller:

1. **Standard Deviation (`error_bar="sd"` — Descriptive Spread):**
   Measures biological dispersion among individual observations around the group mean. `SD` does not shrink as sample size grows; use `SD` when readers need to see how variable individual subjects or cells are.

2. **95% Confidence Interval (`error_bar="ci"` — Inferential Precision, StatWeave Default):**
   Shows the range of population mean values compatible with the observed data under the statistical model (`mean ± t_{0.975, df} * SEM`). Unlike bare `SEM` bars, `95% CI` accounts for small-sample `t` critical values and directly conveys estimation uncertainty (Greenland et al., 2016).

3. **Standard Error of the Mean (`error_bar="sem"` — `SD / sqrt(N)`):**
   Measures sampling standard deviation of the sample mean (`~68%` interval in large samples). Because `SEM` is roughly half the width of a `95% CI`, non-overlapping `SEM` bars do **not** guarantee `p < 0.05`, and overlapping `SEM` bars must always be labeled explicitly in the caption (`Mean ± SEM, N = ...`).

4. **Interquartile Range (`error_bar="iqr"` — Nonparametric Spread):**
   Pairs naturally with medians (`mannwhitney`, `kruskal`) to show the middle 50% (25th to 75th percentile) of skewed distributions.
