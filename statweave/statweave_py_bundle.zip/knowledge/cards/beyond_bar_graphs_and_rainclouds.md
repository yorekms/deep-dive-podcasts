# Beyond Bar Graphs: Honest Data Presentation for Continuous Outcomes

Summary bar charts ("dynamite plots") show only group mean and one error bar, concealing sample size, skewness, bimodal responders, and extreme values—four completely different datasets can produce the exact same bar graph (Weissgerber et al., 2015, *PLOS Biology*).

1. **When bar graphs are appropriate vs. misleading:**
   - Bar heights anchored at zero work naturally for true **counts or proportions**, or when individual data points are overlaid (`StatWeave`'s `plot="bar"` always overlays individual observations by default).
   - Avoid bars for variables that cannot meaningfully reach zero (e.g., resting membrane potential in `mV`, body temperature in `°C`, or `log`-ratio outcomes) because anchoring at zero distorts visual effect size.

2. **Recommended distribution geometries in StatWeave:**
   - **`plot="raincloud"`** (Allen et al., 2021, *Wellcome Open Research*): Combines a half-violin kernel density ("cloud"), median/IQR quartile box, and jittered raw observations ("raindrops") for `n >= 6`.
   - **`plot="distribution"` or `plot="box"`**: Ideal for small wet-lab cohorts (`n = 3..12`), foregrounding every individual replicate alongside summary intervals.
   - **`plot="superplot"`**: Best whenever subreplicates are nested inside animals, slices, or donors.
   - **`plot="paired"`**: Mandatory for pre/post or matched within-subject designs.
