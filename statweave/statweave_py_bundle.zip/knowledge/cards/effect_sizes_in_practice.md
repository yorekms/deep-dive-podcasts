# Reporting Effect Sizes Alongside P-Values

While a p-value depends heavily on sample size (`N`), an **effect size** quantifies the magnitude of a phenomenon for biological interpretation, future sample-size planning, and meta-analysis (Lakens, 2013, *Frontiers in Psychology*):

1. **Physical / unstandardized effect size first:**
   Always state the difference in calibrated domain units first—for example, `+14.2 Hz` firing rate, `-8.5 mmHg` systolic blood pressure, or `2.4-fold` gene induction—alongside its 95% confidence interval.

2. **Standardized effect sizes computed automatically by StatWeave:**
   - **Hedges' `g` (bias-corrected Cohen's `d`)** for two-group `ttest`: difference in means divided by pooled SD, corrected for small-sample upward bias (`|g| ~ 0.2` small, `0.5` medium, `0.8+` large as rough context—always judge against domain biology).
   - **Eta-squared (`η²`)** for `anova`: proportion (`0` to `1`) of total outcome variance explained by group membership (`SS_between / SS_total`).
   - **Pearson `r` / `R²` and Spearman `ρ`** for continuous associations: linear variance explained (`R²`) vs. monotonic rank correlation (`ρ`).
   - **Cramér's `V`** for `chi2` contingency tables: association strength (`0` = independent to `1` = perfectly determined) scaled for table dimensions.
   - **Hazard Ratio (`HR` + 95% CI)** for `survival`: relative instantaneous event rate between groups (`HR < 1` protective, `HR > 1` elevated hazard).
