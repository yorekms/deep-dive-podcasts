# Two-Group Independent Comparisons: Welch's t-Test vs. Mann–Whitney U

When comparing one continuous outcome across two independent biological groups (such as Control vs. Drug, or WT vs. KO), two foundational questions govern method choice:

1. **Why Welch's t-test is preferred over Student's equal-variance t-test:**
   Classic Student's t-test assumes both groups share identical population variances. In real laboratory assays—where a drug or mutation alters both the mean response and animal-to-animal variability—equal-variance pooling can inflate false positives when group sizes are unequal. **Welch's t-test** estimates each group's variance separately and adjusts degrees of freedom via the Welch–Satterthwaite formula, losing virtually zero power when variances happen to be equal while protecting Type I error when variances differ.

2. **When to switch to Mann–Whitney U (Wilcoxon rank-sum):**
   Use `method="mannwhitney"` when outcomes are strongly skewed (e.g., raw cytokine titers, amyloid plaques, latency-to-event), bounded/ordinal scores, or small samples (`n < 8` per group) where extreme observations dominate the sample mean. Mann–Whitney compares rank distributions and reports `U`, exact/asymptotic `p`, medians, and IQRs.

3. **Complete reporting checklist:**
   Always report group sample sizes (`n`), central tendency and spread, test statistic and degrees of freedom (`t(df)` or `U`), exact `p`-value, 95% confidence interval for the difference, and standardized effect size (Hedges' `g`).
