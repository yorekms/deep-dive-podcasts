# Comparing 3+ Groups & Controlling False Positives Across Multiple Tests

1. **Why running separate unadjusted t-tests is invalid:**
   With `k = 4` groups there are `6` pairwise comparisons; running 6 unadjusted t-tests at `alpha = 0.05` inflates the family-wise chance of at least one false positive from `5%` to `1 - 0.95^6 = 26.5%` (and over `64%` across 20 tests).

2. **Omnibus test + Holm step-down post-hoc comparisons:**
   - **One-way ANOVA (`method="anova"`)** tests whether group means differ overall (`F(df1, df2)` and `eta-squared` effect size), followed by pairwise Welch comparisons adjusted via the **Holm–Bonferroni (`p_holm`)** step-down procedure.
   - **Kruskal–Wallis (`method="kruskal"`)** is the rank-based nonparametric counterpart (`H` statistic + Holm-adjusted pairwise Mann–Whitney tests) for skewed, heavy-tailed, or ordinal outcomes across 3+ groups.

3. **Why Holm–Bonferroni beats plain Bonferroni:**
   Holm's step-down correction controls the exact same family-wise error rate (`FWER <= alpha`) as classic Bonferroni under arbitrary test dependence, while being uniformly more powerful (less overly conservative) on ranked p-values.
