# Two-Factor Experiments (Group × Time / Dose) and Timecourse Comparisons

When outcomes are measured across **two experimental factors**—such as `Genotype × Dose`, `Diet × Sex`, or `Treatment × Timepoint`—choose the method that matches your scientific question:

1. **Testing whether a treatment changes the trajectory (`method="two_way_anova"`):**
   Evaluates three distinct hypotheses simultaneously:
   - **Main effect of Group:** overall vertical shift between groups across levels.
   - **Main effect of Time / Dose (`x`):** overall change across timepoints or doses.
   - **Group × Time Interaction:** whether the slope or response profile across `x` differs between groups (often the primary hypothesis in drug wash-in, LTP, or dose-response studies). When an interaction is substantial, interpret simple group differences at specific levels rather than pooled main effects alone.

2. **Pinpointing which timepoints/doses differ (`method="timecourse_compare"`):**
   Runs Welch t-test / ANOVA (or Mann–Whitney / Kruskal when `nonparametric=True`) at each discrete timepoint or step and applies **Holm–Bonferroni multiplicity adjustment** across all tested timepoints automatically, placing adjusted stars directly onto **`plot="timecourse"`** (or `grouped_bar`, `grouped_box`, `spaghetti`).

3. **Audited baseline / control normalization:**
   Use `build_working_sheet` (`pct_of_baseline_group_mean`, `pct_of_group_mean`, or `pow2_neg_ddct` for RT-qPCR `2^(-ΔΔCt)`) so raw instrument values remain intact in `0_Raw_Source` while normalized values are analyzed reproducibly.
