# Designing Clear Scientific Figures: Medium, Color, and Honest Axes

Effective scientific figures adapt typography, geometry, and color to their target audience and medium (Rougier, Droettboom & Bourne, 2014, *PLOS Computational Biology*):

1. **Adapt the preset to the medium:**
   A dense 89 mm single-column journal figure becomes unreadable when pasted directly onto a projector slide. Use journal presets (`nature_1col`, `journal_single`, `nejm_clinical`, `prism_classic`) for manuscripts, and switch to `slide_16_9`, `slide_dark`, or `poster` (larger typography and thicker `line_width`) for talks and posters.

2. **Design for colorblindness and grayscale printing:**
   Roughly 8% of male readers have red–green color vision deficiency. Prefer **`palette="okabe_ito"`** or **`palette="tol_muted"`** for universal colorblind safety, and pair **`palette="mono"` + `fill_style="hatched"` + `point_style="by_group_shape"`** when figures may be printed in black and white.

3. **Choose honest scales and reference lines:**
   - Use **`yscale="log10"`** (or `xscale="log10"`) for strictly positive quantities spanning orders of magnitude (such as `IC50_nM`, viral titers, or fold-changes).
   - Add **`hline=100.0`** (for `% of control/baseline`) or **`hline=1.0`** (for fold-change / hazard ratio) so readers immediately see the no-effect reference level.
