# Paired Within-Subject vs. Independent Experimental Designs

Before running a two-condition test, verify whether observations are **paired** or **independent**:

1. **Recognizing a paired design (`design="paired"`):**
   Observations are paired whenever both conditions are measured on the **same experimental unit**—for example: Baseline vs. Drug wash-in on the same patched neuron, pre- vs. post-treatment on the same patient, left vs. right hemisphere of the same animal, or identical twins / matched textbook ISBNs.

2. **Why pairing matters statistically:**
   An unpaired t-test treats baseline subject-to-subject variability as unexplained noise, masking consistent within-subject shifts. A **paired t-test (`method="paired_t"`)** analyzes the within-unit differences (`d_i = y_i - x_i`) directly, testing whether the mean within-subject change differs from zero with `df = N_pairs - 1`. If within-pair differences are heavily skewed or ordinal, use the **Wilcoxon signed-rank test (`method="wilcoxon"`)**.

3. **Best figure geometry for paired data:**
   Always plot paired designs with **`plot="paired"`** (connecting each subject's pre/post values with a trajectory line) rather than two disconnected bar charts, so readers can inspect whether individual subjects moved in a consistent direction.
