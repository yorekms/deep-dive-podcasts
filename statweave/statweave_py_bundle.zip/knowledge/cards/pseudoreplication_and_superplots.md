# Avoiding Pseudoreplication: Biological Units (N) vs. Technical Subreplicates (n)

**Pseudoreplication** occurs when multiple non-independent measurements from the same biological unit—such as 36 patched cells or sweeps from 6 mice, triplicate RT-qPCR wells per donor, or repeated trials per subject—are analyzed as if they were independent biological replicates (Lazic, 2010, *BMC Neuroscience*).

1. **Why unpooled row tests fail:**
   When a treatment is applied at the animal, donor, or litter level, the independent experimental unit is the **animal/donor (`N = 6`)**, not the sweep, cell, or well (`n = 36`). Running a t-test or ANOVA on all 36 rows inflates degrees of freedom artificially and can push the false-positive rate above 30–50%.

2. **How to analyze nested data properly in StatWeave:**
   Pass **`pool_by="<UnitColumn>"`** (e.g., `Animal_ID`, `Donor_ID`, `Slice_ID`, `Litter`, or `Subject`) with `pool_stat="mean"` (or `"median"`), and choose **`plot="superplot"`**.
   - StatWeave collapses subreplicates within each independent biological unit prior to hypothesis testing so degrees of freedom reflect true biological `N`.
   - The **Superplot** overlays translucent subreplicate points in the background alongside bold unit-level means, showing both technical variability and true biological reproducibility on one honest axes frame.
