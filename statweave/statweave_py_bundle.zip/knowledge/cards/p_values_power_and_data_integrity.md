# Interpreting P-Values Honestly & Preserving Raw Data Integrity

From Greenland et al. (2016, *European Journal of Epidemiology*), three rules prevent the most common student statistical errors:

1. **`p > 0.05` (e.g., `p = 0.06`) does NOT prove "no effect":**
   A p-value measures incompatibility between the observed data and the null model (assuming all model assumptions hold). In small wet-lab samples, `p = 0.06` often accompanies a wide 95% confidence interval compatible with both zero and a biologically meaningful effect. Report the exact `p`-value, point estimate, and `95% CI` rather than dichotomizing `0.049` vs. `0.051` as "real" vs. "zero".

2. **Conversely, a tiny `p`-value does NOT prove practical importance or causation:**
   With large `N`, trivial differences produce tiny `p`-values, and observational associations (confounders) can yield `p < 0.0001` without a causal mechanism.

3. **Never drop "outliers" post-hoc to cross `p < 0.05`:**
   Inspecting a p-value and deleting extreme observations to shrink `p` invalidates Type I error guarantees ("p-hacking"). Raw rows may only be masked via `excluded_rows` when backed by a **concrete, pre-specified technical failure** (such as a lost gigaseal, spilled well, or instrument saturation), recorded transparently in the processing audit log. If real biological values are heavy-tailed, keep all observations and compare with a rank-based test (`mannwhitney` / `kruskal`).
