# Analyzing Right-Censored Time-to-Event Data (`method="survival"`)

1. **Why t-tests and ordinary regressions fail on survival times:**
   In clinical cohorts and animal longevity/relapse studies, some subjects have not experienced the event by the end of follow-up or leave the study early (**right censoring**). Dropping censored subjects biases survival estimates downward, while treating follow-up times as actual event times biases them upward.

2. **How StatWeave analyzes survival data (`method="survival"`, `plot="survival"`):**
   Pass `x="<FollowUpTime>"`, `y="<EventIndicator>"` (`0` = censored / `1` = event, or R convention `1` = censored / `2` = event), and optional `group="<Arm>"`:
   - **Kaplan–Meier estimator:** step-function survival probability curve with Greenwood `log(-log)` 95% confidence bands, `+` tick marks at exact right-censored follow-up times, and Brookmeyer–Crowley median survival CIs.
   - **Mantel–Cox Log-Rank test:** nonparametric comparison of entire survival curves across two or more groups.
   - **Univariate Cox Proportional Hazards (`HR` + 95% CI):** estimates relative event rate across follow-up assuming roughly proportional hazards over time (check visually whether Kaplan–Meier curves cross strongly).
