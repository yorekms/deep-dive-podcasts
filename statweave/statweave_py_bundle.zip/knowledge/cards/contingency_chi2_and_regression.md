# Categorical Contingency Tables (Chi-Square) & Continuous Regression

1. **Categorical outcomes across groups (`method="chi2"`, `plot="heatmap"`):**
   When both variables are categorical (e.g., `Treatment` arm vs. binary `Responder / Stroke / Pain_Free` status), do not encode categories as arbitrary numbers for a t-test. Use **Pearson's Chi-Square test of independence (`method="chi2"`)**:
   - **Row-level participant sheets:** pass `x="<GroupCol>"`, `y="<OutcomeCol>"` (leave `count` empty).
   - **Pre-tabulated frequency sheets:** pass `x="<RowFactor>"`, `y="<ColFactor>"`, and **`count="<FreqCol>"`** so StatWeave weights cells by their actual counts rather than counting summary rows!
   - Watch for **Simpson's paradox** (e.g., UC Berkeley admissions) when a confounding stratum (`Department` / `Site`) reverses aggregate proportions.

2. **Continuous X vs. Y relationships (`regression`, `pearson`, `spearman`, `plot="scatter"`):**
   - **OLS Linear Regression (`method="regression"`)** estimates slope, intercept, `95% CI`, `R²`, and `p` when `Y` varies linearly with continuous `X`.
   - **Spearman rank correlation (`method="spearman"`)** is preferred when the relationship is nonlinear but monotonic (such as saturating binding or dose-response curves) or contains leverage outliers.
   - **Correlation ≠ causation:** Even `r > 0.99` in observational time series (such as Maine divorce rates vs. margarine consumption) reflects shared temporal trends unless randomized or controlled experimentally.
