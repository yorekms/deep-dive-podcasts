# Local reference library

This folder contains source pointers and explicitly reviewed, open-licensed local `.txt` or `.md` pedagogical reference cards (`cards/*.md`). External links to third-party sites without redistribution permissions (such as GraphPad's Statistics Guide) remain **link only** (`status: "unreviewed"`, no local `text_file`) and are never retrieved into model context.

The application never downloads these links. Unreviewed material and link-only entries are excluded from model retrieval. A link in the catalog means a source exists; it does not mean the source was consulted by the model or that its contents support a result.

`sources.json` has `version: 1` and an `items` list. Each item needs a unique `id`, `title`, `url`, `license` description, and `status` (`unreviewed` or `reviewed`). A local `text_file` is optional. It must be a relative `.txt` or `.md` path contained within this directory. The library rejects path traversal, external symlinks, binary files, unsupported formats and oversized files.

For reviewed local text, record authorship, source/version, the actual reuse terms, attribution, reviewer and review date. Prefer a `text_sha256` checksum: when reviewed text changes, the old checksum prevents it being retrieved until review is updated. A review flag is a maintainer's statement; software cannot verify the truth of scientific or licensing review.

Retrieval uses bounded keyword matching. At most eight local excerpts, totaling 6,000 snippet characters, can enter a model request. The model receives those excerpts as untrusted reference evidence, never as instructions or executable code. Numerical methods remain restricted to the independently tested analysis engine. Log the retrieved reference IDs and source-text checksums with the conversation.

GraphPad's website terms restrict reproduction or storage in electronic retrieval systems without permission. Its guide is deliberately **link only**. R manuals and package documentation have their own document/package licenses; check the exact source and retain required notices rather than assuming every R-related document has the same license.

See `../CONTRIBUTING.md` for proposed reference and test contributions.
