# OpenAI conversation in StatWeave

StatWeave 0.9.0 adds an optional OpenAI conversation provider. Development, coding and simulated tests are performed in the existing Codex account. Your API key is used by StatWeave for conversations you submit in the application and for a connection test you explicitly request. Opening the app, importing data, rendering figures and running the deterministic analysis engine do not themselves request an OpenAI model response.

## Create the key and connect

1. Open [OpenAI API keys](https://platform.openai.com/api-keys) in your browser. Check that the selected project is the one you intend to use for StatWeave.
2. Create a new secret key named **StatWeave**. Key creation gives access to your API account; complete this step yourself. Keep the full secret private. Never paste it into a chat, a spreadsheet, a project note or a support report.
3. In StatWeave, open the conversation provider settings. Select **OpenAI**, leave the model as **gpt-6-luna**, and paste the key into the masked API key field.
4. Choose whether to keep the key for this app session or remember it in the system credential wallet. StatWeave does not write the key to its settings JSON or analysis projects. If the wallet is unavailable, use the session option. An existing `OPENAI_API_KEY` environment variable is also supported.
5. Use **Test connection** when you are ready. This makes a small, billable model request without project data. A successful response verifies access for that key and model at that time. Funding and model availability are controlled by your OpenAI project.
6. Save the provider choice, open your project and start a conversation. A configured key alone is not evidence that the connection has been tested.

Use [OpenAI Usage](https://platform.openai.com/usage) to review billed activity. You can revoke this separate key on the API Keys page without changing the Codex account used for software development. Do not turn on automatic credit recharge unless you choose to do so yourself.

## What leaves the computer

With OpenAI selected, StatWeave sends the text you enter, a bounded conversation history, and supported metadata, design information and computed result summaries needed to discuss the loaded project. Column names, units, group labels and numerical summaries can therefore leave the computer. Treat what you type into the conversation as information sent to OpenAI.

This integration does not upload the original spreadsheet or ABF file, send observation rows, send full local file paths, or grant the model arbitrary code execution. A model can request supported read-only summaries and propose a restricted action. StatWeave validates proposals locally. User agreement applies to the concrete plan shown by the app; the model cannot authorize its own execution.

The transport uses the OpenAI Responses endpoint with `store: false` and locally managed conversation history. This is not a promise of zero provider retention. OpenAI's [data controls documentation](https://developers.openai.com/api/docs/guides/your-data) describes applicable retention and data-use rules.

## Local work and charges

Statistics, source preservation, figures, tables, exports and the audit record remain local. A conversation can require several model requests as the model asks for summaries or develops a proposal. Cancellation stops StatWeave waiting and applying a reply; it does not guarantee a request already received by OpenAI will be unbilled.

The default model is [GPT-6 Luna](https://developers.openai.com/api/docs/models/gpt-6-luna). StatWeave does not silently switch to a more expensive model. Token use depends on the current conversation and tool exchanges; a low per-request example is not a fixed price for a complete analysis. The OpenAI Usage page is the authority for billing.

Offline commands and the separately configured local Ollama model remain available. Selecting OpenAI changes the conversational provider, not the numerical methods that StatWeave supports.

## Scientific scope

The conversation can discuss an analysis more broadly than the application can execute it. It should explain missing prerequisites and unsupported methods. Existing supported ordinary-table, large-table and pleth Summary analysis routines remain the execution boundary. Bayesian study models, mixed models and additional figure layouts must be implemented and verified before the model can execute them.

The pleth API path is intended for a study with reviewed source identities and protocol windows, such as the completed test project. It can propose identity/group/trial-handling changes for review. Creating or editing the protocol-window ledger through API tools is not implemented in this release; those existing review commands remain available with **Offline commands** selected. The model should explain that prerequisite instead of claiming the window review is complete.

Existing GraphPad or MATLAB data can be supplied through supported spreadsheet or delimited-table exports. Native `.pzf`, `.pzfx`, `.prism` and `.mat` project import is not added by this release. Original files remain intact; imports do not silently reconstruct proprietary analysis settings.

## Verification boundary

Release tests use synthetic projects and simulated API responses. They verify transport controls, credential handling, conversation routing, proposal validation, local execution, cancellation and source preservation without spending your API balance. They do not establish the scientific accuracy or conversational quality of a live Luna response. The first live connection and scientific discussion occur when you choose to use the configured provider inside StatWeave.

Official setup reference: [OpenAI developer quickstart](https://developers.openai.com/api/docs/quickstart).
