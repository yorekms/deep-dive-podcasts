# Start StatWeave

The current build is **0.9.0**. Open the conversation provider settings to choose **OpenAI**, **Local Ollama** or **Offline commands**. The OpenAI option defaults to **gpt-6-luna** and accepts your key in a masked field. Follow **API_SETUP.md** to create a separate key and choose when to make the first billable connection test. Development checks use simulated replies and do not spend your API balance. Importing, statistics and figure rendering remain local.

Start with ordinary language: “Did we run any statistics?”, “Show me the respiratory frequency figure”, or “Give me figures and descriptives for all available measures.” With OpenAI selected, discussion is routed through the API conversation bridge, whose restricted tools can inspect supported metadata and saved summaries and stage a locally validated proposal. Read the displayed proposal before agreeing to execute it. **CONVERSATION.md** explains the workflow and supported scope. Model replies show elapsed time and offer **Cancel reply**; closing requests safe cancellation and saving. Storage errors are reported without replacing the last complete checkpoint; see **STORAGE_RECOVERY.md** and **CLOSING_AND_RECOVERY.md**. Existing percent-of-baseline reporting and complete subject/per-session descriptive statistics remain available.

## Execute a reviewed pleth study in version 0.7.0

Open the source batch, discuss the goal and confirm its current source/subject/session/group mapping. For a supported pleth Summary export, develop an execution recipe through conversation. The following assumes identities and groups are already reviewed. Proposed phase/dose labels still need inspection before approval.

```text
experimental unit is subject
pool trials equally within subject
report all available measures
propose protocol windows
show windows
review execution recipe
confirm execution recipe
run agreed analysis
export analysis
```

The report inventories all 21 registered measures plus source diagnostics. Supported complete measures receive descriptive tables and individual figures; missing, invalid or calibration-blocked entries retain their counts and reasons. Source-window n is not biological subject n. There is no automatic battery of group tests.

For a single endpoint use `use RR_bpm`. For subject slopes, then say `use CO2 slopes` and `fit slope over 0, 3, 6%`, followed by a new review/confirmation/run. `use HCVR slope` selects calibrated minute ventilation; frequency and syringe-only slopes retain their own names and units. Bayesian and mixed-model execution are not implemented.

Correct a proposed window with `set window S001 row 2 to baseline at 0% CO2`, or record a protocol/measurement omission with `set window S001 row 6 to omit because calibration pulse outside the breathing protocol`. These are syntax examples, not advice to exclude any row in your study. Original source cells stay intact. Scientific changes invalidate approval and mark earlier results as historical.

`export analysis` includes PDF/SVG/600 dpi PNG, all per-measure figures, CSV tables, window/processing ledgers, recipe, audit, frozen implementation/version records and an AI-free reproduction script. It is compact by default. `export analysis with sources` deliberately includes verified originals. `export study plan` exports proposals and metadata without calculated results.

Read **EXECUTION_METHODS.md** for supported outcomes, calibration, aggregation, normalization and sample-SD figure semantics. See **NEXT_DATASETS.md** for the proposed qPCR → incomplete longitudinal data → transcriptomics adapter progression. The first pleth bridge reads Summary exports, not raw waveforms or PerBreath observations.

## Study intake and scientific planning in version 0.6.0

Select several supported source files through **Open data** or drop them on the window to create a study project. **File → Plan a study from files…** also supports a single file when its metadata, sheets and scientific meaning need discussion first. **File → Open study folder…** opens supported files directly inside a folder; it does not recursively combine subfolders. Opening an existing project folder retains the saved-project behavior.

Study mode preserves every original and inspects bounded source metadata. It can propose a data family, distinguish standardized exports from completed-analysis references, show identity/calibration/condition issues, ask for the scientific goal and grouping, and discuss candidate methods and figures. It keeps observed facts, proposed interpretations and your confirmations separate.

Try one instruction at a time:

```text
show study
my goal is compare responses across exposures while accounting for repeated recordings
show metadata conflicts
suggest analyses
remember that my primary interest is the response within each subject
study note: retain baseline and recovery as distinct protocol epochs
keep trials separate
select method study_repeated_measures
plan figures
export study plan
```

For a supported plethysmography proposal, try `discuss HCVR`. This presents candidate definitions, prerequisites, source links and execution status. It does not compute HCVR. Source-ID resolutions and group assignments use the current inventory; for example, `resolve source S003 subject as subject-A` and `group subjects subject-A, subject-B as Reference`, with fabricated names replaced by your reviewed identities. `accept proposed subject and session mappings` stops for missing/conflicting identities. After resolving them and assigning groups, use `confirm study mapping`. `confirm analysis plan` requires a goal, confirmed mapping and selected method and records acknowledgement only.

The original 0.6 study layer performs intake and planning without executing a method-card suggestion. Version 0.7 extends supported pleth Summary projects through separately reviewed execution recipes. Existing spreadsheet, large-table and recording workflows below retain their calculations and exports.

Study sources are XLSX/CSV/TSV/TXT: 1–100 files, at most 32 MiB each and 512 MiB total; XLSX supports up to 32 sheets and 256 columns per sheet. Metadata/design/Summary inspection reads at most 64 data rows per captured sheet. Observation sheets such as `PerBreath` receive header-only inspection, while their full bytes remain preserved.

Explicit study notes persist across reopen/export as user declarations, separately from source evidence and typed mappings. A new note clears plan acknowledgement but does not change calibration or method-readiness facts. Local-model continuity retains only bounded notes and up to two recent local-model exchanges. `save import profile Respiratory export` stores schema/domain/role hints. Applying that profile checks drift and proposes its hints without transferring subject identities, groups, study notes or accepted conflicts. `export study plan` saves Markdown/JSON evidence, state, method references, conversation and history; `export study plan with sources` explicitly includes the originals. No numerical result or calculated figure is included in a study-plan export. Read **STUDY_PLANNING.md** for the complete workflow and limits.

## Large CSV, TSV and TXT tables in version 0.5.0

Use **Open data** for a CSV, TSV or delimited TXT file. Files of **32 MiB or larger** automatically use a disk-backed local table. The original source is preserved, and the grid shows at most 200 source records. This is a general table reader; the scientific meaning and experimental unit must still be specified.

Try one instruction at a time, using columns that actually exist:

- `Describe this data`
- `Show columns`
- `Count rows by Group`
- `Find exact "control" in "Condition"`
- `Summarize Value`
- `Histogram Value using 40 bins`
- `Use all rows`
- `Scatter X against Y`
- `Export as SVG`

For a table with `GeneSymbol`, `logFC`, `Species` and related result fields, try `find gene RAB7A`, then `summarize logFC`. Gene matching ignores case but uses the exact symbol, so it does not also select `RAB7A-AS1`. This searches an existing result table; it does not rerun differential expression or establish biological replication.

Explicit conditions persist across follow-up queries. `Histogram Value where Condition is "control"` selects that condition, and a following `summarize Value` keeps it. Use `use all rows` to clear the derived selection. Source records are retained throughout. Generated row labels are one-based CSV **data-record numbers**, excluding the header; multiline fields do not create extra records, and a supplied `SourceRow` field remains unchanged.

Numeric summaries and histograms use all selected finite values with blank, invalid and nonfinite counts reported. Searches return at most 200 records per page; use `next page` after a find query. Scatter figures show at most 5,000 deterministic points and disclose the full finite-pair count. Group output reports any groups/records beyond its 200-group limit. See **LARGE_DATA.md** for exact accounting, commands and display bounds.

Large-table exports are **compact by default**: the full original stays in its project, while the package records its path and checksum with the results and reproduction source. Provide the exact source separately when reproducing elsewhere, using `python reproduce.py --source /path/to/exact-original.csv`. Ask `export with source` to deliberately include the full file. Ordinary spreadsheet and ABF exports continue to include their originals.

Large Excel/ODS workbooks at or above 32 MiB currently stop with guidance to export the required sheet as CSV/TSV. Other large-file adapters and arbitrary statistical analyses remain future work; the optional model cannot generate executable analysis code.

## Action potentials and reviewed time regions in version 0.4.0

Use the conversation for the workflow, without an additional panel of controls. Open the public episodic voltage example or a representative laboratory ABF and try one instruction at a time:

- `Show channel 1 full sweep`
- `Overlay sweeps 1 through 2`
- `Measure action potential amplitude half-width and inter-spike intervals`
- `Show analysis plan`
- `Show measurements for peak ch1-sw1-p2547`
- `Show measurements from 9 to 15`
- `Analyze spikes from 100 to 900 ms`
- `Set baseline window to 3 ms`
- `Set baseline gap to 1 ms`
- `Export as SVG`

Amplitude is sampled peak voltage minus an explicit local pre-peak median. Half-width uses half that baseline-relative amplitude; ISIs are peak-to-peak within one included segment. The same definitions apply to automatic and manually selected peaks. Missing baseline or width context produces a flagged unavailable measurement, while the event remains counted.

For an artifact, use `Exclude region from 0.2 to 0.25 seconds because pipette artifact`. To review an individual event, use its stable ID from Results: `Reject peak ch1-sw1-p2547 because artifact review`, or `Restore peak ch1-sw1-p2547 because waveform checked`. Manual additions use an explicit search interval: `Add peak near 0.127 s within 1 ms on channel 1 sweep 1 because manually confirmed spike`. All annotations preserve raw samples and require reasons.

After testing one representative file, use `Save pipeline as "Current clamp"`, `Check folder "/path/to/ABFs"`, `Run pipeline on folder "/path/to/ABFs"`, and `Export pipeline figures`. File-specific peak decisions and artifact masks are not copied into a reusable pipeline. Each file’s compatibility, failure or completed result is recorded. Header/channel compatibility cannot verify the biological protocol or actual stimulus waveform.

Read **AP_METHODS.md** for definitions, manual-review semantics, pipeline checks, reproducibility and testing limits. Exports include editable Python numerical source and ordinary CSV/JSON/SVG/PDF files; no AI account is needed to run these deterministic workflows.

## Spike detection and firing rates in version 0.3.0

Open the public episodic voltage example, or a voltage-valued ABF channel, and try:

- `Show channel 1 full sweep`
- `Detect spikes using threshold -20 mV and refractory 2 ms`
- `Overlay sweeps 1 through 2`
- `Firing rate in 100 ms bins`
- `Set spike threshold to -10 mV`
- `Use a refractory period of 3 ms`
- `Export as SVG`

Detected peaks appear on the recorded trace, with binned firing rate in an aligned panel. Results include counts and rates by sweep and a duration-weighted summary for each channel. Adjust settings to the actual recording; the initial −20 mV/2 ms settings are starting values, not a universal action-potential definition. For the gap-free public example, select **channel 2** (mV); its first channel is dB.

The detector reads full-resolution samples without filtering. The original source stays intact, and the history retains each analysis, its settings and processing steps. Incomplete excursions at window boundaries are omitted and reported. Rate denominators use sampled duration, excluding gaps between sweeps. See **SPIKE_METHODS.md** for the exact rule and verification limits. Use `show raw trace` to return to inspection without event markers.

## ABF recording import and viewing

Use **Open data** to open an `.abf` recording, or choose one of the four **Examples → Public ABF** entries. Selecting a public example explicitly downloads it if needed and verifies its pinned byte count and SHA-256. Examples are cached locally; no example is downloaded at startup. The raw public recordings are not bundled in the portable application because a data-specific redistribution grant was not established. Source links and reuse status are recorded in `examples/abf/SOURCES.json`.

The first channel and first sweep are previewed for up to ten seconds. Channel and sweep numbers start at **1** in conversation. Try:

- `Show metadata`
- `Show channel 2 from 0 to 5 seconds`
- `Show channel 1 sweep 2 from 100 to 500 ms`
- `Overlay sweeps 1 through 2`
- `Show all channels`
- `Show full sweep`
- `Show full recording`
- `Use recording time`
- `Set the title to Membrane voltage`
- `Export as SVG`

Windows ordinarily refer to time within each selected sweep. Overlays use that within-sweep axis. **Use recording time** changes the displayed axis to the actual header-derived start time, preserving gaps between sweeps. An explicit absolute-time request is supported for one selected sweep, for example `show sweep 2 from 60 to 61 seconds using recording time` when that sweep begins at 60 seconds. Multi-sweep absolute-window requests ask for a more specific selection rather than silently changing its meaning.

The initial view supports up to four channels and twelve sweeps, with separate channel panels and original channel units. Longer windows use a bounded, extrema-preserving display representation, disclosed in the caption and export record. This is display reduction, not analytical resampling. Raw trace inspection performs no filtering, baseline correction, event detection, command-waveform reconstruction or statistical inference. Requesting spike detection separately runs the documented derived measurement. The full raw source remains preserved; time samples are not independent biological replicates.

ABF exports include PDF/SVG/PNG figures, metadata, the exact viewing plan, display counts and settings, the original ABF, history, checksums and a reproduction script. **A local export ZIP contains its original recording.** Public-fixture exports used during development are kept out of the redistributable app archive.

Version 0.1.1 fixes the distribution-plot dot layout. Horizontal display offsets now use a separate reproducible sequence independent of the measurements. Existing projects can be reopened; their original values and statistical results are retained. Previously exported figures remain unchanged; export again to create a corrected figure.

StatWeave is a local desktop application for spreadsheet statistics and publication figure preparation. This first working version runs a defined set of statistical workflows through conversational instructions. It preserves original observations and records analysis decisions.

## Open the app

In this project folder, double-click **Start StatWeave.desktop** or **Start_StatWeave.sh**. In the portable download, run **Start_StatWeave.sh** inside the extracted StatWeave folder. The launcher opens the compiled Linux application; no separate Python installation is required. The development folder keeps its builds under `releases/`; the portable folder keeps the executable beside its launcher.

This computer also has a **StatWeave** application-menu entry in the Science/Education categories. It calls the stable launcher in this folder, which follows the explicitly activated build at `releases/current`. Projects, settings and local model configuration continue to use this workspace when the active build changes. Creating or compiling a new release does not activate it.

For development updates, finish the new release's verification first, then run `python3 scripts/install_desktop_entry.py --release releases/v0.8.1/StatWeave`, replacing the version with the checked release. This atomically switches the active-build link and refreshes the existing menu entry; it does not alter older builds, saved projects or originals. Run the same command with an older verified version to switch back. The installer requires an executable and a StatWeave verification record with passing tests. Portable downloads retain their own adjacent executable and do not use this development-workspace link.

Open a single spreadsheet, drag one onto the window, or choose **Try example data** for the existing calculation workflows. Select several supported files or choose **Plan a study from files…** for the study-planning workflow above. The built-in calculation examples are synthetic, not research observations.

CSV, TSV, delimited TXT, XLSX, XLSM, XLS and ODS readers are included, subject to the large-file boundary above. A rectangular table with column names in the first record is the current supported layout. Large delimited files use the disk-backed reader; large workbooks need a CSV/TSV export of the required sheet. Excel formulas use the workbook's saved values; StatWeave does not recalculate Excel formulas. Missing formula caches are reported. Macros are not executed. Workbook tabs can be selected from the sheet list or by typing `use sheet "Sheet name"`.

## Try a complete analysis

For the built-in independent-group example, send these instructions one at a time:

1. `Compare Score by Treatment`
2. `Independent observations`
3. `Set the title to Treatment response`
4. `Make it blue`
5. `Export as SVG`

The export includes PDF, SVG and PNG; SVG text stays editable. Asking for TIFF adds a TIFF file. Exports always create a new versioned folder and ZIP, preserving earlier exports.

Other examples:

- `Describe the data`
- `Plot Score by Treatment`
- `Show a box plot`
- `Show a violin plot`
- `Scatter Dose against Score`
- `Pearson correlation between Dose and Score, independent observations`
- `Spearman correlation between Dose and Score, independent observations`
- `Regress Score on Dose, independent observations`
- `One-way ANOVA of Score by Treatment, independent observations`
- `Mann-Whitney of Score by Treatment, independent observations`
- `Kruskal-Wallis of Score by Treatment, independent observations`
- `Set width to 178 mm`
- `Set height to 110 mm`
- `Label y as Response (mV)`
- `Make the title "Treatment response"`
- `Make it single-column`
- `Export as TIFF`

For paired data, open **Examples → Paired observations** and type `Paired t-test Before and After`. Measurements in the same row must refer to the same unit. Long-format pairing uses an explicit subject-ID column and two condition levels; duplicate subject-condition measurements stop for clarification.

Type `help` for more instructions. This version does not understand every possible phrasing. Unsupported analyses receive an explanation; they are not silently replaced with another test.

## What runs without AI

The default **Offline commands** mode is a rule-based interpreter, not an LLM. It interprets supported instructions and invokes local numerical routines. No model, account, subscription, or network connection is needed for those workflows, plotting, project readback, or export.

For broader wording or discussion, use **Conversation → Local AI settings**. Enable local AI after installing and starting Ollama and a suitable model separately; enter the exact installed model name. The adapter contacts only a local loopback service. StatWeave does not install or train a model automatically. This development computer has separately configured Ollama with `qwen3.5:4b`; broader scientific replies can take tens of seconds. Common saved-result questions and supported everyday requests use the local application directly; **Cancel reply** is available during model generation. Exact observed timings are recorded in **VERIFICATION.json**. A timeout or invalid proposal is reported without replacing the previous successful result; supported offline commands remain available.

Model context depends on the project type. Ordinary/large-table adapters use bounded column/structural metadata and approved already-computed numeric summaries, without raw table rows, category-value inventories, scatter coordinates or source paths. Study mode supplies bounded source basenames, schemas, proposed identifiers, condition/calibration evidence, planning state and cited method cards; it omits full source paths, raw numeric outcome rows and per-breath samples. The instruction you type is the request. Ordinary table workflows can also supply permitted reviewed local reference excerpts; the study cards' primary-source bibliography is separate from that reference catalog. Study discussion can propose a goal or methods and ask next questions, but cannot confirm identities or execute calculations. Model output cannot execute generated Python, R, SQL or shell code or add an unimplemented method. Ollama and model weights are not included in the portable app.

## Protecting the observations

- The original file is copied into a project and verified by SHA-256 before analysis/export.
- Source values are read-only in the interface. No source-row deletion or automatic outlier removal is provided. Large-table conditions create explicit derived selections with complete selected-record counts.
- For ordinary spreadsheet inferential methods, nonblank text in a required numeric column stops the analysis rather than silently becoming missing. Large-table numeric queries separately count finite, nonfinite, invalid and blank/null fields.
- Ordinary spreadsheet omissions retain source-row accounting and reasons. Large-table queries retain fixed data-record identities for returned rows and compact aggregate accounting, without listing millions of row numbers. ABF measurement boundaries and review masks are documented in the recording methods guides.
- Instructions, attempted analyses, results, figure settings and exports are recorded.
- Changes to a saved result, source, or history are detected against the saved state and history hashes.

This cannot detect observations removed before import or establish that a spreadsheet contains every collected measurement. The history is not an external signature or a tamper-proof research registry; someone with full filesystem control could rewrite a project and its hashes. It is a transparent local record, not a guarantee against deliberate fraud.

## Where work is saved

Projects save automatically under `projects/` in the app workspace. **File → Open saved project** reopens a project's `project.json`. Each project contains its preserved source, analysis history and export folders.

Ordinary-table, large-table and recording figure export packages include:

- PDF and SVG vector figures; PNG defaults to 600 dpi.
- Optional TIFF on request.
- Numerical result tables as CSV.
- Caption, methods/settings and complete omission accounting.
- Original source and imported values for ordinary spreadsheet/ABF exports. Large-table exports instead record an external source reference/checksum by default; request `export with source` for a full included copy.
- Analysis settings and software versions.
- History and a SHA-256 file manifest.
- A `reproduce.py` script and the analysis/figure source it needs.

To reproduce an export in a separate Python environment, install its `requirements.txt` and run `reproduce.py`. For a compact large-table export, supply the exact source with `--source` when needed. The reproduction script checks the original source hash before calculating; the large-table recipe also compares the recalculated result with the saved result. Original figure files are not overwritten; reproduced outputs get separate names.

Study-plan exports instead contain the plan, observed metadata evidence, source hashes, method references, conversation and audit record. They are compact by default, with raw sources optional. They contain no calculated figures or numerical reproduction recipe; see `STUDY_PLANNING.md`.

## Current statistical coverage

The ordinary spreadsheet engine supports descriptive summaries; Welch independent-samples t-test; paired t-test; classical one-way ANOVA; Mann–Whitney; Kruskal–Wallis; Pearson and Spearman correlation; one-predictor ordinary least-squares regression; Pearson chi-square for observation-level categorical data.

The large-table engine currently supports the six descriptive methods described above: profile, count by group, find, numeric summary, histogram and scatter. The presence of a familiar column or an optional language model does not make an ordinary-table inferential routine available on a large table.

Independent inferential methods require an explicit statement that the observations are independent. That statement is recorded; the program cannot infer the experimental unit from a matrix of numbers. A request describing paired/repeated data is not treated as independent.

Mixed models, repeated-measures ANOVA, survival models, multiple regression, nonlinear models, post-hoc comparisons, multiplicity adjustments and many other methods are not implemented yet. Repeated exploratory tests are recorded but do not receive a multiple-testing correction automatically. The application does not search for the smallest p-value.

## Figures and publication requirements

Figures use fixed physical dimensions, editable vector text, restrained typography and visible observations. The default is 178 × 110 mm; single-column is 85 × 60 mm. Labels outside the page stop an export rather than being silently clipped. Means receive 95% t intervals only when independence is confirmed and the sample supports an interval; paired plots preserve connections.

These are general publication defaults, not a claim of compliance with every journal. Set dimensions, units, labels and uncertainty definitions for the target journal and inspect the actual export before submission.

## Method references and contributions

Version 0.6.0 adds the scientific intake/planning workflow in `STUDY_PLANNING.md`, including primary-source method cards and proposal-only HCVR/repeated/hierarchical/Bayesian discussion. Those study-execution backends remain unavailable. Bayesian analysis, filtering and advanced electrophysiology methods remain planned in `DEVELOPMENT_ROADMAP.md`. Version 0.5.0 adds the general disk-backed descriptive table workflow documented in `LARGE_DATA.md`. Version 0.4.0 adds AP measurements, explicit regions, manual review and recording pipelines to the read-only ABF workflow. See `AP_METHODS.md` and `SPIKE_METHODS.md` for exact definitions.

**Knowledge → Reference library** shows the local catalog. The initial catalog contains links only; no Prism help folder, R manuals, journal collection, or model training corpus has been copied into the application. Add only permitted, reviewed local text following `knowledge/README.md`.

See `CONTRIBUTING.md` for how people can contribute synthetic worked examples, expected results, interpretation corrections and licensed reference metadata. Public contribution hosting, model fine-tuning and an automatic training service are future work; none is running in this version.

## Verification and platform

See `VERIFICATION.json` for the exact build checks. This is a Linux x86-64 build tested on this TUXEDO computer. Windows/macOS packages and installation on a clean second computer have not been tested.

Source launch: `.venv/bin/python -m statweave`.

Source tests: `.venv/bin/python -m pytest -q`.

Build a Linux standalone folder: `scripts/build_linux.sh`.
