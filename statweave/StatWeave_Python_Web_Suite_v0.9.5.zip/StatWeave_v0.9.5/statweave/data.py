"""Local spreadsheet imports with immutable-source identifiers and physical row numbers."""
from __future__ import annotations

import csv
from dataclasses import dataclass, field
import hashlib
import io
import math
from pathlib import Path
import re
from typing import Any

import warnings as _warnings

import pandas as pd

try:
    with _warnings.catch_warnings():
        _warnings.simplefilter("ignore", DeprecationWarning)
        import defusedxml
        defusedxml.defuse_stdlib()
except ImportError:  # pragma: no cover
    pass

from .scrubber import inspect_ooxml_workbook, is_clampflow_sheets, zip_guard

MAX_WORKBOOK_ROWS = 100_000
MAX_WORKBOOK_COLS = 1_024
MAX_WORKBOOK_CELLS = 5_000_000
MAX_PASTED_BYTES = 32 * 1024 * 1024


@dataclass
class Dataset:
    df: pd.DataFrame
    source_path: str
    source_hash: str
    sheet: str | None = None
    sheets: list[str] = field(default_factory=list)
    header_row: int = 0
    row_numbers: list[int] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    def __post_init__(self):
        self.df = self.df.copy(deep=True)
        self.df.columns = [str(c) for c in self.df.columns]
        if not self.df.columns.is_unique:
            raise ValueError("Dataset columns must have unique names.")
        self.df = self.df.reset_index(drop=True)
        if not self.row_numbers:
            self.row_numbers = list(range(self.header_row + 2, self.header_row + 2 + len(self.df)))
        if len(self.row_numbers) != len(self.df):
            raise ValueError("Source row numbers do not match the imported data.")

    @property
    def is_clampflow(self) -> bool:
        return is_clampflow_sheets(self.sheets)

    def metadata(self) -> dict:
        meta = {
            "source_path": self.source_path, "source_hash": self.source_hash,
            "sheet": self.sheet, "sheets": list(self.sheets), "header_row": self.header_row,
            "rows": len(self.df), "columns": [str(c) for c in self.df.columns],
            "dtypes": {str(c): str(self.df[c].dtype) for c in self.df.columns},
            "row_numbers": list(self.row_numbers), "warnings": list(self.warnings),
        }
        if self.is_clampflow:
            meta["detected_format"] = "clampflow_compiled"
        return meta


def _source(path: str | Path) -> Path:
    p = Path(path).expanduser().resolve()
    if not p.is_file():
        raise ValueError(f"The spreadsheet does not exist: {p}")
    return p


def list_sheets(path: str | Path) -> list[str]:
    p = _source(path)
    suffix = p.suffix.lower()
    if suffix in {".csv", ".tsv", ".txt"}:
        return []
    if suffix not in {".xlsx", ".xlsm", ".xls", ".ods"}:
        raise ValueError("Open an Excel workbook (.xlsx/.xlsm/.xls), .ods, .csv, or .tsv file.")
    if suffix in {".xlsx", ".xlsm", ".ods"}:
        zip_guard(p)
    try:
        with pd.ExcelFile(p) as book:
            return [str(x) for x in book.sheet_names]
    except ImportError as exc:
        raise ValueError(f"The reader required for {p.suffix} files is not installed: {exc}") from exc
    except ValueError:
        raise
    except Exception as exc:
        raise ValueError(f"The workbook could not be read: {exc}") from exc


def _blank(value: Any) -> bool:
    if value is None:
        return True
    if isinstance(value, str):
        return not value.strip()
    try:
        return bool(pd.isna(value))
    except (ValueError, TypeError):
        return False


def _column_names(values: list, warnings: list[str]) -> list[str]:
    used: set[str] = set()
    names = []
    for index, value in enumerate(values):
        base = f"Column {index + 1}" if _blank(value) else str(value).strip()
        candidate, suffix = base, 2
        while candidate in used:
            candidate = f"{base} [{suffix}]"
            suffix += 1
        if _blank(value):
            warnings.append(f"Blank header in column {index + 1} was named '{candidate}'.")
        elif candidate != str(value):
            warnings.append(f"Header '{value}' was imported as '{candidate}' to keep names clear and unique.")
        used.add(candidate)
        names.append(candidate)
    return names


def _read_delimited(p: Path, header_row: int, warnings: list[str]):
    raw = p.read_bytes()
    if b"\x00" in raw:
        raise ValueError("Binary or UTF-16 input is unsupported; save the table as UTF-8 CSV or TSV.")
    try:
        content = raw.decode("utf-8-sig")
    except UnicodeDecodeError:
        try:
            content = raw.decode("cp1252")
        except UnicodeDecodeError as exc:
            raise ValueError("The text file is not UTF-8 or Windows-1252. Save it as UTF-8 CSV.") from exc
        warnings.append("Text was decoded as Windows-1252; verify non-English labels.")
    delimiter = "\t" if p.suffix.lower() == ".tsv" else ","
    try:
        dialect = csv.Sniffer().sniff(content[:16384], delimiters=",\t;|")
        delimiter = dialect.delimiter
    except csv.Error:
        pass
    reader = csv.reader(io.StringIO(content, newline=""), delimiter=delimiter)
    records, physical_rows = [], []
    previous_end = 0
    try:
        for row in reader:
            records.append(row)
            physical_rows.append(previous_end + 1)
            previous_end = reader.line_num
    except csv.Error as exc:
        raise ValueError(f"The delimited file could not be parsed: {exc}") from exc
    if header_row >= len(records):
        raise ValueError("The selected header row is beyond the end of the file.")
    headers = records[header_row]
    if not headers:
        raise ValueError("The selected header row is empty. Choose the row containing column names.")
    rows = records[header_row + 1:]
    for index, row in enumerate(rows):
        if len(row) > len(headers):
            raise ValueError(f"Source row {physical_rows[header_row + 1 + index]} has more cells than the header. Check the delimiter or header row.")
    names = _column_names(headers, warnings)
    padded = [row + [None] * (len(names) - len(row)) for row in rows]
    frame = pd.DataFrame(padded, columns=names)
    # Only blank cells are missing. Literal labels such as 'NA' are preserved.
    for c in names:
        frame[c] = frame[c].map(lambda value: None if _blank(value) else value)
    # Preserve CSV spellings, including leading-zero identifiers. Numeric
    # conversion belongs to an explicit analysis, not the import step.
    return frame, physical_rows[header_row + 1:]


def _is_finite_float_token(value: str) -> bool:
    token = value.strip()
    if not token:
        return False
    try:
        num = float(token)
        return math.isfinite(num)
    except ValueError:
        return False


def prepare_pasted_table(text: str) -> tuple[bytes, list[str]]:
    """Parse pasted clipboard text from Excel, Prism, Sheets, or ClampFlow into canonical TSV bytes."""
    if not isinstance(text, str) or not text.strip():
        raise ValueError("Clipboard does not contain any tabular text to paste.")
    if "\x00" in text:
        raise ValueError("Pasted text contains unsupported binary characters.")
    encoded_check = text.encode("utf-8")
    if len(encoded_check) > MAX_PASTED_BYTES:
        raise ValueError("Pasted table exceeds the 32 MB in-memory paste limit; save as a CSV/TSV file and open it directly.")
    normalized = text.replace("\r\n", "\n").replace("\r", "\n")
    lines = [line for line in normalized.split("\n")]
    while lines and not lines[-1].strip():
        lines.pop()
    while lines and not lines[0].strip():
        lines.pop(0)
    if not lines:
        raise ValueError("Clipboard does not contain any non-blank rows.")

    notes: list[str] = []
    first_line = lines[0]
    if "\t" in first_line:
        delimiter = "\t"
    elif any(sep in first_line for sep in (",", ";", "|")):
        try:
            delimiter = csv.Sniffer().sniff("\n".join(lines[:25]), delimiters=",\t;|").delimiter
        except csv.Error:
            delimiter = "," if "," in first_line else (";" if ";" in first_line else "|")
    elif len(re.split(r"\s{2,}|\s+", first_line.strip())) >= 2:
        # Plain whitespace-separated columns pasted from R, MATLAB, or console output
        records = [re.split(r"\s+", ln.strip()) if ln.strip() else [] for ln in lines]
        delimiter = None
    else:
        delimiter = "\t"

    if delimiter is not None:
        reader = csv.reader(io.StringIO("\n".join(lines), newline=""), delimiter=delimiter)
        records = list(reader)

    # Trim trailing empty cells on rows that exceed the widest non-empty column
    max_nonempty_cols = 0
    for row in records:
        last_nonempty = 0
        for idx, cell in enumerate(row):
            if cell.strip():
                last_nonempty = idx + 1
        max_nonempty_cols = max(max_nonempty_cols, last_nonempty)
    if max_nonempty_cols == 0:
        raise ValueError("Clipboard contains only empty cells.")

    cleaned_records: list[list[str]] = []
    for row in records:
        trimmed = list(row[:max(len(row), max_nonempty_cols)])
        while len(trimmed) > max_nonempty_cols and not trimmed[-1].strip():
            trimmed.pop()
        if len(trimmed) < max_nonempty_cols:
            trimmed.extend([""] * (max_nonempty_cols - len(trimmed)))
        cleaned_records.append(trimmed)

    first_nonblank = [c for c in cleaned_records[0] if c.strip()]
    if (
        len(cleaned_records) >= 2
        and first_nonblank
        and all(_is_finite_float_token(c) for c in first_nonblank)
    ):
        prefix = "Group" if max_nonempty_cols <= 6 else "Column"
        synth_headers = [f"{prefix} {i + 1}" for i in range(max_nonempty_cols)]
        cleaned_records.insert(0, synth_headers)
        notes.append(
            f"The first pasted row contained numeric observations rather than column labels; "
            f"added headers ({', '.join(synth_headers)}) so the first row was preserved as data."
        )
    elif len(cleaned_records) < 2:
        raise ValueError("Paste at least one header row and one data row (or at least two numeric rows).")

    buf = io.StringIO()
    writer = csv.writer(buf, delimiter="\t", lineterminator="\n")
    writer.writerows(cleaned_records)
    return buf.getvalue().encode("utf-8"), notes


def load_dataset(path: str | Path, sheet: str | None = None, header_row: int = 0) -> Dataset:
    p = _source(path)
    if isinstance(header_row, bool) or not isinstance(header_row, int) or header_row < 0:
        raise ValueError("Header row must be a nonnegative whole number (zero means the first row).")
    warnings: list[str] = []
    sheets = list_sheets(p)
    suffix = p.suffix.lower()
    if suffix in {".csv", ".tsv", ".txt"}:
        if sheet not in {None, "", "Data"}:
            raise ValueError("CSV and TSV files do not contain workbook sheets.")
        frame, row_numbers = _read_delimited(p, header_row, warnings)
        selected_sheet = None
    else:
        if not sheets:
            raise ValueError("The workbook contains no readable sheets.")
        if sheet:
            selected_sheet = sheet
        elif is_clampflow_sheets(sheets) and "1_Master_Wide" in sheets:
            selected_sheet = "1_Master_Wide"
        else:
            selected_sheet = sheets[0]
        if selected_sheet not in sheets:
            raise ValueError(f"Sheet '{selected_sheet}' was not found. Available sheets: {', '.join(sheets)}")
        if suffix in {".xlsx", ".xlsm"}:
            ooxml_info = inspect_ooxml_workbook(p)
            if ooxml_info["has_vba_macros"]:
                warnings.append("Workbook contains embedded VBA macros (vbaProject.bin); macros are never executed by StatWeave.")
            if ooxml_info["hidden_sheets"]:
                warnings.append("Hidden worksheet(s) present (" + ", ".join(ooxml_info["hidden_sheets"][:8]) + "); hidden tabs are not analyzed unless explicitly selected.")
            try:
                from openpyxl import load_workbook
                formula_book = load_workbook(p, read_only=True, data_only=False, keep_links=False)
                cached_book = load_workbook(p, read_only=True, data_only=True, keep_links=False)
                try:
                    ws, caches = formula_book[selected_sheet], cached_book[selected_sheet]
                    # Use the formula sheet to establish occupied rows/columns;
                    # a missing cached result must not erase a formula-only row.
                    last_row, last_col = 0, 0
                    no_cache = []
                    for row in ws.iter_rows():
                        for cell in row:
                            if cell.value is not None:
                                if cell.row > MAX_WORKBOOK_ROWS or cell.column > MAX_WORKBOOK_COLS:
                                    raise ValueError(
                                        f"Worksheet '{selected_sheet}' exceeds the bounded in-memory grid limit "
                                        f"({MAX_WORKBOOK_ROWS:,} rows or {MAX_WORKBOOK_COLS:,} columns). "
                                        "Export the required sheet as CSV/TSV to use the disk-backed large-table reader."
                                    )
                                last_row = max(last_row, cell.row)
                                last_col = max(last_col, cell.column)
                            if cell.data_type == "f" and cell.row >= header_row + 2 and caches.cell(cell.row, cell.column).value is None:
                                no_cache.append(cell.coordinate)
                    if header_row + 1 > last_row:
                        raise ValueError("The selected header row is beyond the end of the sheet.")
                    if (last_row - header_row) * last_col > MAX_WORKBOOK_CELLS:
                        raise ValueError(
                            f"Worksheet '{selected_sheet}' exceeds the bounded {MAX_WORKBOOK_CELLS:,}-cell in-memory limit. "
                            "Export the required sheet as CSV/TSV to use the disk-backed large-table reader."
                        )
                    cached_values = list(caches.iter_rows(min_row=header_row + 1, max_row=last_row, max_col=last_col, values_only=True))
                    names = _column_names(list(cached_values[0]), warnings)
                    frame = pd.DataFrame(cached_values[1:], columns=names)
                    if no_cache:
                        warnings.append("Formula results are unavailable in cells " + ", ".join(no_cache[:30]) + (f" and {len(no_cache) - 30} others" if len(no_cache) > 30 else "") + ". Recalculate and save the workbook in Excel or LibreOffice before analysis; these cells import as missing.")
                finally:
                    formula_book.close()
                    cached_book.close()
            except ImportError:
                raise ValueError("The Excel reader openpyxl is not installed.")
            except ValueError:
                raise
            except Exception as exc:
                raise ValueError(f"The worksheet could not be read: {exc}") from exc
        else:
            try:
                raw = pd.read_excel(p, sheet_name=selected_sheet, header=None, dtype=object, keep_default_na=False)
            except Exception as exc:
                raise ValueError(f"The worksheet could not be read: {exc}") from exc
            if len(raw) > MAX_WORKBOOK_ROWS or len(raw.columns) > MAX_WORKBOOK_COLS or len(raw) * len(raw.columns) > MAX_WORKBOOK_CELLS:
                raise ValueError(
                    f"Worksheet '{selected_sheet}' exceeds the bounded in-memory grid limit. "
                    "Export the required sheet as CSV/TSV to use the disk-backed large-table reader."
                )
            if header_row >= len(raw):
                raise ValueError("The selected header row is beyond the end of the sheet.")
            names = _column_names(raw.iloc[header_row].tolist(), warnings)
            frame = raw.iloc[header_row + 1:].copy().reset_index(drop=True)
            frame.columns = names
            warnings.append("Formula caches are not inspected for this workbook format; verify calculated values in the source application.")
        for c in names:
            frame[c] = frame[c].map(lambda value: None if _blank(value) else value)
        row_numbers = list(range(header_row + 2, header_row + 2 + len(frame)))
    if frame.empty or not len(frame.columns):
        raise ValueError("The selected sheet has headers but no data rows.")
    return Dataset(frame, str(p), hashlib.sha256(p.read_bytes()).hexdigest(), selected_sheet, sheets, header_row, row_numbers, warnings)
