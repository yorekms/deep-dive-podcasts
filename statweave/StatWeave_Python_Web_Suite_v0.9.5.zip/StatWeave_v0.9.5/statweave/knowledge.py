"""Small local reference library with explicit review and provenance.

This is keyword retrieval over reviewed local text. It neither downloads sources
nor trains a language model, and it never treats document text as instructions.
"""
from __future__ import annotations

from copy import deepcopy
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import sys
from urllib.parse import urlsplit

MAX_MANIFEST_BYTES=1_048_576
MAX_TEXT_BYTES=262_144
MAX_ITEMS=2000
MAX_SNIPPETS=8
MAX_CONTEXT_CHARS=6000
MAX_SNIPPET_CHARS=1400
_ITEM_KEYS={'id','title','url','license','text_file','status','authors','version','reviewed_by','reviewed_on','notes','license_url','attribution','tags','text_sha256'}
_STOPWORDS={'the','and','are','for','from','that','this','with','what','which','how','can','does','should','would','could','please','use','using','data','statistical','statistics','test','tests','analysis','analyze','analyse','about','have','has','all','you','your','our','my','into','help','want','need','not','been','when','then','but','than','between'}


def default_reference_root() -> Path:
    """Resolve the read-only bundled library in source and frozen applications."""
    if getattr(sys,'frozen',False) and hasattr(sys,'_MEIPASS'):
        return Path(sys._MEIPASS)/'knowledge'
    return Path(__file__).resolve().parent.parent/'knowledge'


def _read_bounded(path: Path,limit: int,label: str) -> bytes:
    if not path.is_file(): raise ValueError(f'{label} is not a regular local file: {path.name}')
    if path.stat().st_size>limit: raise ValueError(f'{label} exceeds the {limit:,}-byte limit.')
    with path.open('rb') as handle:
        raw=handle.read(limit+1)
    if len(raw)>limit: raise ValueError(f'{label} exceeds the {limit:,}-byte limit.')
    if b'\x00' in raw: raise ValueError(f'{label} contains binary data; use UTF-8 text.')
    return raw


def _tokens(text: str) -> set[str]:
    tokens=set(re.findall(r'[a-z0-9]{2,40}',text.casefold()))-_STOPWORDS
    if 'ttest' in tokens: tokens.update(('welch','paired'))
    if 'anova' in tokens: tokens.add('variance')
    if 'regression' in tokens: tokens.update(('linear','model'))
    return tokens


def _validate_url(value, label: str) -> str:
    if not isinstance(value,str) or len(value)>2048: raise ValueError(f'{label} must be a source URL.')
    parsed=urlsplit(value)
    if parsed.scheme not in ('http','https') or not parsed.hostname or parsed.username or parsed.password:
        raise ValueError(f'{label} must be an HTTP or HTTPS source link, without embedded credentials.')
    return value


def prepare_reference_context(items, max_chars: int=MAX_CONTEXT_CHARS) -> list[dict]:
    """Validate and bound reference snippets again at the model boundary.

    The returned list is evidence, not a set of executable instructions. No path
    or text-file field is sent to the model.
    """
    if not isinstance(items,list): raise ValueError('Reference snippets must be a list.')
    if isinstance(max_chars,bool) or not isinstance(max_chars,int) or not 0<=max_chars<=MAX_CONTEXT_CHARS: raise ValueError('Reference context must be bounded to 6,000 characters.')
    prepared=[]; seen=set()
    for item in items[:MAX_SNIPPETS]:
        if not isinstance(item,dict): raise ValueError('Each reference snippet must contain provenance fields.')
        if item.get('status')!='reviewed': continue
        ref_id=item.get('id')
        if not isinstance(ref_id,str) or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,99}',ref_id): raise ValueError('Reference IDs must be short stable identifiers.')
        if ref_id in seen: continue
        title=item.get('title'); license_text=item.get('license'); snippet=item.get('snippet')
        if not isinstance(title,str) or not title.strip() or len(title)>300: raise ValueError('Reference title is missing or too long.')
        if not isinstance(license_text,str) or not license_text.strip() or len(license_text)>2000: raise ValueError('Reference license/provenance is missing or too long.')
        if not isinstance(snippet,str) or '\x00' in snippet: raise ValueError('A reference snippet must be plain text.')
        url=_validate_url(item.get('url'),'Reference URL')
        digest=item.get('text_sha256')
        if digest is not None and (not isinstance(digest,str) or not re.fullmatch(r'[a-f0-9]{64}',digest)): raise ValueError('Reference text checksum is invalid.')
        if not snippet.strip(): continue
        base={'id':ref_id,'title':title,'url':url,'license':license_text,'status':'reviewed','snippet':'',**({'text_sha256':digest} if digest else {})}
        # Bound the entire serialized reference context, including provenance and escapes.
        low,high=0,min(len(snippet),MAX_SNIPPET_CHARS)
        while low<high:
            middle=(low+high+1)//2
            candidate={**base,'snippet':snippet[:middle]}
            size=len(json.dumps(prepared+[candidate],ensure_ascii=False,separators=(',',':')))
            if size<=max_chars: low=middle
            else: high=middle-1
        if low<1: continue
        prepared.append({**base,'snippet':snippet[:low]});seen.add(ref_id)
    return prepared


class ReferenceLibrary:
    """Retrieve only explicitly reviewed, license-recorded local text.

    Malformed manifests and unsafe paths raise ValueError. A missing library is
    an empty library. A missing optional text file or checksum mismatch is skipped
    with a warning; it can never become model evidence.
    """
    def __init__(self, root: str|Path|None=None):
        self.root=Path(root) if root is not None else default_reference_root()
        self.warnings: list[str]=[]

    def _contained_text(self,name: str) -> Path:
        if not isinstance(name,str) or not name or len(name)>512 or '\\' in name or '\x00' in name:
            raise ValueError('Reference text_file must be a relative .txt or .md path inside the library.')
        pure=PurePosixPath(name)
        if pure.is_absolute() or '..' in pure.parts or ':' in name or pure.suffix.casefold() not in ('.txt','.md'):
            raise ValueError('Reference text_file must be a contained relative .txt or .md path; traversal is not allowed.')
        root=self.root.resolve(); path=(root/Path(*pure.parts)).resolve()
        if not path.is_relative_to(root): raise ValueError('Reference text_file resolves outside the library.')
        return path

    def entries(self) -> list[dict]:
        self.warnings=[]
        root=self.root.resolve(); manifest=root/'sources.json'
        if not manifest.exists():
            self.warnings.append('No sources.json manifest is present; no reference text is loaded.')
            return []
        if not manifest.resolve().is_relative_to(root): raise ValueError('The reference manifest resolves outside the library.')
        raw=_read_bounded(manifest,MAX_MANIFEST_BYTES,'Reference manifest')
        try: payload=json.loads(raw.decode('utf-8-sig'))
        except (UnicodeDecodeError,json.JSONDecodeError) as e: raise ValueError('Reference manifest must be valid UTF-8 JSON.') from e
        if not isinstance(payload,dict) or set(payload)-{'version','items'} or payload.get('version')!=1 or not isinstance(payload.get('items'),list):
            raise ValueError('Reference manifest must contain version 1 and an items list.')
        if len(payload['items'])>MAX_ITEMS: raise ValueError(f'Reference manifest has more than {MAX_ITEMS} items.')
        result=[]; ids=set()
        for source in payload['items']:
            if not isinstance(source,dict) or set(source)-_ITEM_KEYS: raise ValueError('Reference manifest contains unknown fields.')
            entry=deepcopy(source)
            for key,limit in [('id',100),('title',300),('license',2000)]:
                if not isinstance(entry.get(key),str) or not entry[key].strip() or len(entry[key])>limit: raise ValueError(f'Reference {key} is missing or too long.')
            if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,99}',entry['id']) or entry['id'] in ids: raise ValueError('Reference IDs must be unique short stable identifiers.')
            ids.add(entry['id'])
            _validate_url(entry.get('url'),'Reference source URL')
            if entry.get('status') not in ('reviewed','unreviewed'): raise ValueError('Reference status must be reviewed or unreviewed.')
            if 'license_url' in entry: _validate_url(entry['license_url'],'Reference license URL')
            if 'tags' in entry and (not isinstance(entry['tags'],list) or any(not isinstance(t,str) or len(t)>80 for t in entry['tags']) or len(entry['tags'])>30): raise ValueError('Reference tags must be a bounded list of short text labels.')
            for key in ('authors','version','reviewed_by','reviewed_on','notes','attribution'):
                if key in entry and (not isinstance(entry[key],str) or len(entry[key])>4000): raise ValueError(f'Reference {key} must be bounded text.')
            if 'text_sha256' in entry and (not isinstance(entry['text_sha256'],str) or not re.fullmatch(r'[a-f0-9]{64}',entry['text_sha256'])): raise ValueError('Reference text_sha256 must be a lowercase SHA-256 checksum.')
            if entry.get('text_file') is not None: self._contained_text(entry['text_file'])
            result.append(entry)
        return result

    def search(self,query: str,limit: int=4,max_chars: int=MAX_CONTEXT_CHARS) -> list[dict]:
        if not isinstance(query,str) or len(query)>12000: raise ValueError('Reference search needs a query below 12,000 characters.')
        if isinstance(limit,bool) or not isinstance(limit,int) or not 0<=limit<=MAX_SNIPPETS: raise ValueError('Reference search limit must be between 0 and 8.')
        if isinstance(max_chars,bool) or not isinstance(max_chars,int) or not 0<=max_chars<=MAX_CONTEXT_CHARS: raise ValueError('Reference context must be bounded to 6,000 characters.')
        entries=self.entries(); terms=_tokens(query)
        if not terms or not limit or not max_chars: return []
        ranked=[]
        for entry in entries:
            if entry['status']!='reviewed' or not entry.get('text_file'): continue
            path=self._contained_text(entry['text_file'])
            try:
                raw=_read_bounded(path,MAX_TEXT_BYTES,f'Reference {entry["id"]} text')
                text=raw.decode('utf-8-sig').strip()
            except (ValueError,UnicodeDecodeError,OSError) as e:
                self.warnings.append(f'Skipped {entry["id"]}: {e}')
                continue
            digest=hashlib.sha256(raw).hexdigest()
            if entry.get('text_sha256') and entry['text_sha256']!=digest:
                self.warnings.append(f'Skipped {entry["id"]}: the reviewed text checksum no longer matches.')
                continue
            overlap=terms&_tokens(text)
            header_overlap=terms&_tokens(entry['title']+' '+' '.join(entry.get('tags',[])))
            score=4*len(header_overlap)+len(overlap)
            if not score or not text: continue
            # Center a bounded excerpt near a matched body term. No whole-book readout.
            matches=[m.start() for term in sorted(overlap) for m in list(re.finditer(r'\b'+re.escape(term)+r'\b',text,re.I))[:1]]
            start=max(0,min(matches)-180) if matches else 0
            snippet=text[start:start+MAX_SNIPPET_CHARS]
            if start: snippet='…'+snippet[1:]
            ranked.append((score,entry['id'],{'id':entry['id'],'title':entry['title'],'url':entry['url'],'license':entry['license'],'status':'reviewed','snippet':snippet,'text_sha256':digest}))
        ranked.sort(key=lambda row:(-row[0],row[1]))
        return prepare_reference_context([row[2] for row in ranked[:limit]],max_chars=max_chars)

    def summary(self) -> dict:
        entries=self.entries()
        return {'root':str(self.root.resolve()),'total':len(entries),
            'reviewed':sum(e['status']=='reviewed' for e in entries),
            'reviewed_with_text':sum(e['status']=='reviewed' and bool(e.get('text_file')) for e in entries),
            'unreviewed':sum(e['status']=='unreviewed' for e in entries),
            'link_only':sum(not e.get('text_file') for e in entries),
            'warnings':list(self.warnings)}
