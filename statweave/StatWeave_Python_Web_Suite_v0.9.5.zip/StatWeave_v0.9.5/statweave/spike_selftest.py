"""Bounded standalone spike workflow check against an explicitly downloaded ABF."""
from pathlib import Path
import hashlib
import json
import zipfile
import numpy as np

from .session import Session, verify_audit


def run(workspace, examples_dir):
    path = Path(examples_dir).resolve() / '17o05027_ic_ramp.abf'
    before = hashlib.sha256(path.read_bytes()).hexdigest()
    session = Session(Path(workspace).resolve() / 'spike-self-test')
    session.import_file(path)
    commands = ['show channel 1 full sweep',
                'detect spikes using threshold -20 mV and refractory 2 ms',
                'overlay sweeps 1 through 2',
                'firing rate in 100 ms bins',
                'set spike threshold to -10 mV']
    for command in commands:
        reply = session.command(command)
        assert reply['refresh'], reply['message']
    assert session.result['method'] == 'spikes'
    assert session.result['events']
    reference = []
    for sweep in (0, 1):
        raw = session.dataset.read_window(0, sweep)
        above = raw['values'] >= -10
        transitions = np.diff(above.astype(int))
        starts = np.flatnonzero(transitions == 1) + 1
        ends = np.flatnonzero(transitions == -1) + 1
        accepted = []
        for index in starts:
            if np.any(ends > index) and (not accepted or index - accepted[-1] >= 40):
                accepted.append(int(index))
        measured = [e['crossing_sample_index'] for e in session.result['events'] if e['sweep'] == sweep + 1]
        assert measured == accepted, (measured, accepted)
        reference.append({'sweep': sweep + 1, 'accepted_crossings': accepted})
    old = session.result.copy()
    reply = session.command('filter the voltage then detect spikes')
    assert not reply['refresh'] and session.result == old
    saved = session.save()
    reopened = Session(session.workspace)
    reopened.open_project(saved)
    assert reopened.result == session.result
    output = reopened.export_bundle()
    folder = Path(output['folder'])
    for name, digest in json.loads((folder / 'SHA256.json').read_text()).items():
        assert hashlib.sha256((folder / name).read_bytes()).hexdigest() == digest
    with zipfile.ZipFile(output['archive']) as archive:
        assert archive.testzip() is None
    assert hashlib.sha256(path.read_bytes()).hexdigest() == before
    assert hashlib.sha256(Path(session.dataset.source_path).read_bytes()).hexdigest() == before
    head, count = verify_audit(reopened.project_dir / 'history.jsonl', reopened.last_hash)
    return {'status': 'passed', 'commands': commands, 'source_sha256': before,
            'event_count': len(session.result['events']), 'independent_vector_reference': reference,
            'original_unchanged': True, 'project_reopen': 'exact result match',
            'unsupported_filter_request': 'retained previous result',
            'history_events': count, 'audit_head': head, 'export': output}
