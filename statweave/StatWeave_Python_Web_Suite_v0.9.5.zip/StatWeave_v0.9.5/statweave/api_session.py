"""Application-owned API conversation, proposal review and local execution.

Network/tool turns cannot mutate analysis state. A proposal remains available
through explanatory turns, but scientific changes and reopening invalidate its
agreement. The provider never supplies an approval flag accepted by this module.
"""
from __future__ import annotations

from copy import deepcopy
import re
import uuid

from .api_tools import ApiToolbox, digest, safe_text, safe_value, state_digest


def direct_agreement(text):
    """Conservative independent check of the current human's positive act.

    The model handles semantics and proposal reference; this check rejects
    questions, attributed/quoted speech, hypothetical, compound edits, and
    qualified permission. It never reads assistant prose as consent.
    """
    value = text.strip()
    if not value or '?' in value:
        return False
    lower = value.casefold()
    if re.search(r"\b(?:not|no|never|don['’]?t|do\s+not|cancel|stop|wait|hold\s+off|unless|if|maybe|might|would|could|should|but|except|before|after|change|instead|rather|why|how|whether)\b", lower):
        return False
    if re.search(r'\b(?:says?|said|wrote|quoted?|model|assistant|example|suppose|imagine|hypothetical)\b', lower):
        return False
    if re.search(r'["“”]|(?<!\w)[\x27‘](?![st]\b)', value):
        return False
    # Filler assent embedded in a request to explain, display, prune, or revise
    # is not execution permission. Longer replies must consist solely of optional
    # positive appraisal plus an anchored positive assent clause.
    if re.search(
        r'\b(?:use|switch|adjust|normaliz\w*|blue|teal|mono|okabe|coral|viridis|red|box|violin|superplot|'
        r'width|height|palette|preset|font|larger|smaller|independent|paired|pool|pooled|weight|weighted|'
        r'exclude|include|filter|percent|drop|remove|delete|omit|prune|trim|discard|hide|mask|clear|reset|'
        r'only|without|skip|rename|reorder|swap|merge|split|subset)\b',
        lower,
    ):
        return False
    if re.search(r'\b(?:explain|discuss|tell|show|which|what|clarify|describe)\b', lower):
        return False
    simple = lower.rstrip('.!').strip()
    if re.fullmatch(
        r'(?:yes|yep|yeah|sure|okay|ok|sounds good|looks good|that works(?: for me)?|'
        r'agreed|approved|approve|i approve|approve and run|run|run it|do it|'
        r'generate|generate it|plot|plot it)(?:[, ]+(?:please|thank you|thanks))?',
        simple,
    ):
        return True
    target = r'(?:it|that|this|(?:the |our |this )?(?:(?:current|displayed|proposed|agreed|reviewed) )?(?:analysis|plan|proposal|report|figure|plot|graph|export|settings|sheet|worksheet))'
    action = (r'(?:proceed(?: with ' + target + r')?|go ahead(?: with ' + target + r')?|'
              r'(?:run|apply|execute|export|do|approve|generate|make|build|plot) ' + target + r'|carry (?:it|that) out|make it so|'
              r'approve (?:and|&) run(?: ' + target + r')?|'
              r"let['’]s (?:do|run|make|generate|plot) " + target + r')')
    lead_clause = (
        r'(?:(?:yes|yep|yeah|sure|okay|ok|agreed|approved|approve|thank you|thanks)[,!.\s]+|'
        r'(?:that|this|the)\s+(?:approach|plan|proposal|method|analysis|choice|setup)\s+'
        r'(?:looks|sounds|is|seems|suits|fits|works|makes\s+sense)(?:\s+[a-z]+){0,4}[,!.\s]+|'
        r'(?:looks|sounds)\s+(?:good|great|fine|right|reasonable)(?:\s+to\s+me)?[,!.\s]+)*'
    )
    return bool(
        re.fullmatch(lead_clause + r'(?:please[, ]+)*' + action + r'(?: now)?(?:[, ]+please)?[.!]*', lower)
        or re.fullmatch(lead_clause + r'i (?:approve|agree with) (?:this|that|the) (?:plan|proposal|analysis|figure|plot|sheet)[.!]*', lower)
    )


def _proposal_content(pending):
    return {key: value for key, value in pending.items() if key not in {'proposal_id', 'content_digest'}}


def _is_valid_pending(pending, expected_digest, expected_token):
    return bool(
        isinstance(pending, dict)
        and expected_token
        and pending.get('token') == expected_token
        and pending.get('base_digest') == expected_digest
        and pending.get('content_digest') == digest(_proposal_content(pending))
    )


def _stage(session, proposal):
    token = getattr(session, '_api_conversation_token', None)
    if token is None:
        token = uuid.uuid4().hex
        session._api_conversation_token = token
    pending = deepcopy(proposal)
    pending.update(base_digest=state_digest(session), token=token)
    pending['content_digest'] = digest(_proposal_content(pending))
    pending['proposal_id'] = pending['content_digest'][:24]
    session.context['api_proposal'] = pending
    session._event('api_proposal_displayed', {'proposal_id': pending['proposal_id'],
        'content_sha256': pending['content_digest'], 'base_state_sha256': pending['base_digest'],
        'kind': pending['kind'], 'calculations_performed': False})
    return pending['preview']


def _apply_pending_proposal(session, pending, origin='direct_user_agreement'):
    kind = pending['kind']
    style = {**session.style, **pending.get('style', {})}
    session._event('api_proposal_agreed', {'proposal_id': pending['proposal_id'],
        'content_sha256': pending['content_digest'], 'origin': origin, 'kind': kind})
    if kind == 'analysis' and session.is_study:
        from .study_bridge import _execution, _compile, _run
        from .study_execution import recipe_digest
        execution = _execution(session)
        session.context['study_state'] = deepcopy(pending['state'])
        execution['options'] = deepcopy(pending['options'])
        execution['options'].pop('pooling', None)
        recipe = _compile(session)
        if recipe_digest(recipe) != recipe_digest(pending['recipe']):
            raise ValueError('The proposed recipe changed. Review a fresh proposal before running.')
        execution['candidate_recipe'] = recipe
        execution['approved_digest'] = recipe_digest(recipe)
        execution['approved_state_sha256'] = digest(session.context['study_state'])
        execution['conversation_proposal'] = None
        session.style = style
        session._event('study_execution_recipe_confirmed', {'recipe': recipe,
            'recipe_sha256': recipe_digest(recipe), 'origin': 'api_displayed_proposal_' + origin})
        message = _run(session)
    elif kind == 'analysis':
        from .session import analyze, clean, versions
        plan = deepcopy(pending['plan'])
        result = session.dataset.execute_plan(plan) if session.is_large_table else analyze(session.dataset, plan)
        session._assert_integrity(full=True)
        if not session.defer_figure_validation:
            import matplotlib.pyplot as plt
            from .figures import make_figure
            plt.close(make_figure(session.dataset, result, result.get('plan', plan), style))
        session.plan = clean(result.get('plan', plan))
        session.result, session.style, session.pending_plan = clean(result), style, None
        if not session.is_large_table and plan.get('design') in {'independent', 'paired'}:
            session.context['design'] = plan['design']
        if not session.is_large_table and 'excluded_rows' in session.plan:
            if session.plan['excluded_rows']:
                session.context['excluded_rows'] = deepcopy(session.plan['excluded_rows'])
            else:
                session.context.pop('excluded_rows', None)
        session._event('large_table_analysis' if session.is_large_table else 'analysis',
            {'plan': session.plan, 'result': session.result, 'environment': versions(),
             'origin': 'api_displayed_proposal_' + origin})
        message = result.get('summary', 'Completed the agreed local query.')
    elif kind == 'figure':
        plan = deepcopy(session.plan or {})
        if pending['request'].get('plot'):
            plan['plot'] = pending['request']['plot']
        if not session.defer_figure_validation:
            from .figures import make_figure
            make_figure(session.dataset, session.result, plan, style)
        session.style, session.plan = style, plan
        if not session.is_study:
            session.result['plan'] = deepcopy(plan)
        session._event('api_figure_style_changed', {'style': style, 'plot': plan.get('plot'), 'calculations_performed': False})
        message = 'Updated the saved figure appearance. Numerical results and raw sources are preserved.'
    elif kind == 'view':
        measure = pending['request'].get('measure')
        if measure is None:
            session.context.pop('study_figure_focus', None)
        else:
            session.context['study_figure_focus'] = measure
        session._event('study_figure_view_changed', {'outcome': measure, 'calculations_performed': False})
        message = 'Showing the recorded ' + (measure or 'all-measures overview') + ' figure. No new statistics were calculated.'
    elif kind == 'sheet':
        outcome = session.select_sheet(pending['request']['sheet'], reply=False)
        message = outcome['message']
    elif kind == 'export':
        include_src = bool(pending.get('request', {}).get('include_source', False))
        session.context.pop('api_proposal', None)
        return {'message': 'Preparing your recorded figures, tables and processing record.', 'refresh': False,
                'export_request': {'action': 'study_analysis_export' if session.is_study else 'export', 'include_source': include_src}}
    elif kind == 'design':
        from .study_bridge import invalidate_approval
        session.context['study_state'] = deepcopy(pending['state'])
        invalidate_approval(session)
        session._event('api_study_design_reviewed', {'state': pending['state'], 'origin': origin, 'calculations_performed': False})
        message = 'Recorded your reviewed source identities, grouping and trial handling. Original metadata and its conflicts remain preserved. No statistics have run; we can now develop the analysis proposal.'
    else:
        raise ValueError('Unsupported saved proposal.')
    session.context.pop('api_proposal', None)
    return {'message': message, 'refresh': True}


def _execute(session, request, text):
    pending = session.context.get('api_proposal')
    if not direct_agreement(text):
        return {'message': 'I have not applied or run the proposal. We can keep discussing it; a direct instruction to proceed with the displayed plan is needed.', 'refresh': False}
    if (not pending or request.get('proposal_id') != pending.get('proposal_id')
            or not _is_valid_pending(pending, state_digest(session), getattr(session, '_api_conversation_token', None))):
        return {'message': 'That proposal needs to be displayed again before agreement. The scientific choices changed, the proposal changed, or the project was reopened. Ask me to show the current proposal. Nothing new has run.', 'refresh': False}
    return _apply_pending_proposal(session, pending, origin='direct_user_agreement')


def _audit_model(session, model, toolbox, reply):
    usage = reply.get('usage') if isinstance(reply, dict) else None
    allowed_usage = {'input_tokens', 'output_tokens', 'total_tokens', 'cached_tokens', 'reasoning_tokens', 'requests'}
    usage = {key: value for key, value in (usage or {}).items()
             if key in allowed_usage and type(value) is int and value >= 0} if isinstance(usage, dict) else {}
    provider_name = safe_text(getattr(model, 'provider', 'openai'), 32)
    session._event('api_conversation', {'provider': provider_name, 'model': safe_text(getattr(model, 'model', 'configured model'), 100),
        'usage': usage, 'tools': toolbox.tool_names, 'request_text_sha256': digest(toolbox.instruction),
        'scope': 'source-safe schema and saved aggregate summaries; proposals only during model request'})


def command_api(session, text, model):
    """Primary interpretation path for API providers, ahead of legacy commands."""
    session._assert_integrity()
    instruction = safe_text(text, 8000)
    checkpoint = {key: deepcopy(getattr(session, key)) for key in ('plan', 'result', 'style', 'context', 'pending_plan')}
    checkpoint_dataset = session.dataset
    session.conversation.append({'role': 'user', 'text': instruction})
    session._event('instruction', {'text': instruction, 'interpreter': 'API conversation with closed local tools'})
    toolbox = ApiToolbox(session, instruction)
    try:
        from .planner import _blocked_request
        if _blocked_request(text):
            return session._reply('Raw observations are preserved. I cannot automatically prune data to improve significance. We can discuss a scientifically justified, explicitly recorded rule before any processing.')
        dialogue = safe_value(session.context.get('api_dialogue', []))[-24:]
        reply = model.converse(instruction, toolbox, dialogue=dialogue,
            context={'schema': toolbox.call('inspect_data', {}),
                     'reviewed_design': toolbox.call('get_reviewed_design', {}),
                     'capabilities': toolbox.call('get_analysis_capabilities', {}),
                     'saved_results': toolbox.call('get_saved_results', {'measure': None}),
                     'current_proposal': toolbox.call('get_current_proposal', {})})
        if getattr(model, 'cancelled', False):
            from .llm import ModelCancelledError
            raise ModelCancelledError('The API reply was cancelled. No proposal was applied and no new calculation was run.')
        if not isinstance(reply, dict) or not isinstance(reply.get('message'), str) or len(reply['message']) > 32000:
            raise ValueError('The API returned an invalid conversation reply. No action was applied.')
        _audit_model(session, model, toolbox, reply)

        prior_pending = deepcopy(session.context.get('api_proposal'))
        prior_digest = state_digest(session)
        prior_token = getattr(session, '_api_conversation_token', None)
        prior_pending_valid = _is_valid_pending(prior_pending, prior_digest, prior_token)

        built_notes = []
        for ws_item in toolbox.staged_working_sheets:
            session.register_working_sheet(
                ws_item['sheet_name'],
                ws_item['df'],
                ws_item['summary'],
                spec=ws_item['spec'],
                save_state=False,
            )
            built_notes.append(ws_item['summary'])
        if built_notes:
            session.context.pop('api_proposal', None)
        ws_banner = ('Built intermediate sheet(s): ' + ' | '.join(built_notes)) if built_notes else ''

        auto_exec = bool(getattr(session, 'auto_execute_proposals', False))

        # Only the toolbox's app-validated objects are authoritative. Ignore
        # proposal/execution flags that appear solely in a model return value.
        if toolbox.proposal is not None and toolbox.proposal.get('kind') == 'figure' and session.result is not None:
            style = {**session.style, **toolbox.proposal.get('style', {})}
            plan = deepcopy(session.plan or {})
            if toolbox.proposal['request'].get('plot'):
                plan['plot'] = toolbox.proposal['request']['plot']
            if not session.defer_figure_validation:
                import matplotlib.pyplot as plt
                from .figures import make_figure
                plt.close(make_figure(session.dataset, session.result, plan, style))
            session.style, session.plan = style, plan
            if not session.is_study:
                session.result['plan'] = deepcopy(plan)
            session.context.pop('api_proposal', None)
            session._event('api_figure_style_changed', {
                'style': style, 'plot': plan.get('plot'),
                'origin': 'api_figure_refinement', 'calculations_performed': False,
            })
            applied_note = 'Updated the figure appearance; saved numerical results and raw sources are preserved.'
            prose = safe_text(reply['message'], 8000).strip()
            parts = [p for p in (ws_banner, prose, applied_note) if p]
            result = {'message': '\n\n'.join(parts), 'refresh': True}
        elif auto_exec and toolbox.proposal is not None and toolbox.proposal.get('kind') in {'analysis', 'sheet', 'view'}:
            _stage(session, toolbox.proposal)
            pending_now = session.context['api_proposal']
            exec_res = _apply_pending_proposal(session, pending_now, origin='draft_first_auto_execute')
            prose = safe_text(reply['message'], 8000).strip()
            assumption_note = ''
            if pending_now.get('kind') == 'analysis' and isinstance(session.plan, dict):
                method_lbl = session.plan.get('method', 'analysis')
                design_lbl = session.plan.get('design', 'independent')
                pool_lbl = f", pooled by {session.plan['pool_by']}" if session.plan.get('pool_by') else ''
                assumption_note = (
                    f"Generated figure & result immediately (Draft-first: {method_lbl} · {design_lbl}{pool_lbl}). "
                    f"Reply in chat to switch to paired/pooled/nonparametric testing or refine figure styling."
                )
            parts = [p for p in (ws_banner, prose, exec_res.get('message', ''), assumption_note) if p]
            result = {'message': '\n\n'.join(parts), 'refresh': True}
        elif (
            not built_notes
            and prior_pending_valid
            and direct_agreement(text)
            and toolbox.proposal is not None
            and toolbox.proposal.get('kind') == prior_pending.get('kind')
            and toolbox.proposal.get('plan') == prior_pending.get('plan')
            and toolbox.proposal.get('style') == prior_pending.get('style')
        ):
            session.context['api_proposal'] = prior_pending
            result = _execute(session, {'proposal_id': prior_pending['proposal_id']}, text)
        elif toolbox.proposal is not None:
            preview = _stage(session, toolbox.proposal)
            prose = safe_text(reply['message'], 8000).strip()
            parts = [p for p in (ws_banner, prose, preview) if p]
            result = {'message': '\n\n'.join(parts), 'refresh': bool(built_notes)}
        elif toolbox.execution_request is not None:
            result = _execute(session, toolbox.execution_request, text)
        elif not built_notes and prior_pending_valid and direct_agreement(text):
            session.context['api_proposal'] = prior_pending
            result = _execute(session, {'proposal_id': prior_pending['proposal_id']}, text)
        else:
            if re.fullmatch(r'\s*(?:cancel|dismiss|discard|clear)\s+(?:(?:the|this|that|current)\s+)?(?:proposal|plan)[.!]*\s*', text, re.I):
                session.context.pop('api_proposal', None)
            prose = safe_text(reply['message'], 12000).strip()
            parts = [p for p in (ws_banner, prose) if p]
            result = {'message': '\n\n'.join(parts) if parts else safe_text(reply['message'], 12000), 'refresh': bool(built_notes)}
        if getattr(toolbox, 'explore_gallery_requested', False):
            result['explore_gallery'] = True
            result['refresh'] = True
        # Keep only API-era redacted exchanges. Never transmit prior offline
        # history, raw sheets, arbitrary model payloads, credentials or paths.
        session.context['api_dialogue'] = (dialogue + [{'role': 'user', 'text': instruction},
            {'role': 'assistant', 'text': safe_text(result['message'], 6000)}])[-24:]
        message, refresh = result.pop('message'), result.pop('refresh', False)
        return session._reply(message, refresh, **result)
    except Exception as error:
        session.dataset = checkpoint_dataset
        for key, value in checkpoint.items():
            setattr(session, key, value)
        from .storage import StorageError, is_space_error
        if isinstance(error, StorageError) or is_space_error(error):
            return session._unsaved_reply(error)
        cancelled = getattr(model, 'cancelled', False)
        # Provider failures can contain response payloads; keep only redacted,
        # bounded error text, never transport headers or model tool arguments.
        message = safe_text(str(error) or type(error).__name__, 1000)
        provider_name = safe_text(getattr(model, 'provider', 'openai'), 32)
        session._event('api_request_cancelled' if cancelled else 'api_request_failed',
                       {'provider': provider_name, 'error_type': type(error).__name__, 'calculations_performed': False})
        return session._reply(message + '\n\nYour prior scientific choices, completed results and raw sources are retained.')
