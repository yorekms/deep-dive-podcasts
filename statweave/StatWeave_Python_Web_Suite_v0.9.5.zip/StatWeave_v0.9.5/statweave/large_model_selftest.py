"""Private live-model smoke check for an existing indexed-table project.

This opens one fresh Session, never reimports the source, and calls the actual
configured local adapter through Session.command. The private report contains
validated plans and aggregate identity/count evidence, never matching records.
Do not run concurrently with another session writing this project's history.
"""
from __future__ import annotations
from copy import deepcopy
from datetime import datetime,timezone
import json
from pathlib import Path
import re
import time
import traceback
import urllib.request

from .llm import OllamaPlanner
from .large_table import validate_large_plan
from .session import Session,canonical,verify_audit,versions


def _require(condition,message):
    if not condition:raise ValueError(message)


def _local_json(url):
    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self,*args,**kwargs):return None
    opener=urllib.request.build_opener(urllib.request.ProxyHandler({}),NoRedirect)
    with opener.open(url,timeout=10) as response:raw=response.read(262145)
    _require(len(raw)<=262144,'The local service metadata exceeds its bounded response size.')
    value=json.loads(raw)
    _require(isinstance(value,dict),'The local service metadata must be a JSON object.')
    return value


def _last_model_event(project):
    count=0;latest=None
    with (Path(project)/'history.jsonl').open(encoding='utf-8') as handle:
        for line in handle:
            item=json.loads(line)
            if item.get('type')=='model_plan_supplied':
                count+=1;latest=deepcopy(item.get('payload',{}))
    return count,latest


def _identity(session):
    # Full verification recomputes source/database/metadata SHA-256 values and
    # checks the history. Returned identities are therefore verified digests.
    session._assert_integrity(full=True)
    return {'source_sha256':session.dataset.source_hash,
            'cache_identity':deepcopy(session.dataset.cache_identity()),
            'row_count':session.dataset.row_count,
            'column_count':len(session.dataset.metadata()['columns'])}


def _numeric_column(dataset):
    metadata=dataset.metadata();names=metadata['columns'];profiles=metadata.get('profiles',{})
    exact=[name for name in names if name=='logFC']
    if exact:return exact[0]
    for name in names:
        profile=profiles.get(name,{})
        if profile.get('numeric_compatible') is True and profile.get('finite_count',0)>0:return name
    for name in names:
        if profiles.get(name,{}).get('finite_count',0)>0:return name
    raise ValueError('This existing project has no column with finite numeric values for the live summary check.')


def run(workspace,project_path):
    """Run explicit live-model checks; write private work/large-model-self-test/result.json."""
    root=Path(workspace).expanduser().resolve()
    output=root/'work/large-model-self-test';output.mkdir(parents=True,exist_ok=True)
    report={'status':'running','started_utc':datetime.now(timezone.utc).isoformat(),
            'checks':[],'environment':versions(),
            'limits':'This is an explicitly invoked live local-model workflow check on an existing private project. It does not establish statistical-advice accuracy or inferential validity. No raw matching rows are included in this report.'}
    started=time.monotonic()
    try:
        settings=root/'statweave-settings.json'
        _require(settings.is_file(),'Configure the local model in this workspace before running its live self-test.')
        _require(settings.stat().st_size<=32768,'The local-model settings file exceeds its bound.')
        config=json.loads(settings.read_text(encoding='utf-8'))
        _require(isinstance(config,dict) and config.get('enabled') is True,'The live self-test requires explicitly enabled local AI settings.')
        model=config.get('model','');timeout=config.get('timeout',120)
        _require(isinstance(model,str) and bool(model.strip()),'Select an installed local model first.')
        _require(type(timeout) in (int,float) and 1<=timeout<=120,'The configured model timeout must be 1–120 seconds.')
        planner=OllamaPlanner(base_url=config.get('base_url','http://127.0.0.1:11434'),model=model,timeout=timeout)
        tags=_local_json(planner.base_url+'/api/tags')
        available=tags.get('models')
        _require(isinstance(available,list),'The local model service did not provide its installed models.')
        candidates=[item for item in available if isinstance(item,dict) and item.get('name',item.get('model')) in {model,model+':latest'}]
        _require(len(candidates)==1,'The configured model is not uniquely present in the local service; no model is downloaded by this test.')
        selected=candidates[0]
        _require(not selected.get('remote_host') and not selected.get('remote_model'),'This self-test requires an installed local model rather than a remote model alias.')
        digest=selected.get('digest','').removeprefix('sha256:')
        _require(bool(re.fullmatch(r'[0-9a-f]{64}',digest)),'The local model did not provide a valid manifest digest.')
        expected=config.get('model_digest')
        if expected is not None:
            _require(isinstance(expected,str) and expected.removeprefix('sha256:')==digest,'The installed local-model digest differs from the configured model checkpoint.')
        planner.configured_model_digest=digest
        report.update(model=model,model_digest=digest,model_digest_matches_config=expected is None or expected.removeprefix('sha256:')==digest,
                      model_size_bytes=selected.get('size'),runtime_version=_local_json(planner.base_url+'/api/version').get('version'),
                      base_url=planner.base_url,timeout_s=timeout)
        report['checks'].append('configured_loopback_model_and_digest')
        session=Session(root)
        # Never use import_file/import_large_table: reopen the existing index.
        session.open_project(project_path)
        _require(session.is_large_table,'Choose an existing indexed large-table project for this self-test.')
        report['project']=str(session.project_dir/'project.json')
        before=_identity(session);report['identity_before']=before
        report['checks'].append('existing_index_opened_without_source_reingest')
        column=_numeric_column(session.dataset)
        prompt='Please produce the numerical summary of '+column+' across all indexed records.'
        old_count,_=_last_model_event(session.project_dir)
        phase=time.monotonic();reply=session.command(prompt,model=planner);elapsed=time.monotonic()-phase
        new_count,event=_last_model_event(session.project_dir)
        _require(new_count>old_count and isinstance(event,dict),'The summary instruction did not produce a recorded live-model plan: '+str(reply.get('message',''))[:1000])
        proposal=event.get('plan',{})
        _require(proposal.get('action')=='large_analyze' and proposal.get('method')=='summary','The live model did not propose the requested summary method.')
        normalized=validate_large_plan(session.dataset,{key:value for key,value in proposal.items() if key!='message'})
        _require(normalized.get('columns')==[column],'The live model did not limit the summary to the requested column.')
        _require(reply.get('refresh') is True and session.result.get('method')=='summary','The actual Session did not execute the validated model summary: '+str(reply.get('message',''))[:1000])
        accounting=session.result.get('large_table_accounting',{})
        _require(accounting.get('source_record_count')==before['row_count'] and accounting.get('selected_record_count')==before['row_count'],'The model request asked for all indexed records, but the calculated selection did not cover them all.')
        _require(not normalized['predicates'],'The all-record summary unexpectedly introduced a derived selection.')
        report['summary_check']={'column':column,'elapsed_s':elapsed,'validated_plan':normalized,
            'source_record_count':accounting['source_record_count'],'selected_record_count':accounting['selected_record_count']}
        report['checks'].append('actual_model_plan_executed_as_full_index_summary')
        saved_result=canonical(session.result);saved_plan=canonical(session.plan);saved_style=canonical(session.style)
        old_count,_=_last_model_event(session.project_dir)
        discussion='Explain whether these indexed table rows can be assumed independent before choosing statistical tests.'
        phase=time.monotonic();reply=session.command(discussion,model=planner);elapsed=time.monotonic()-phase
        new_count,event=_last_model_event(session.project_dir)
        _require(new_count>old_count and isinstance(event,dict),'The discussion instruction did not produce a recorded live-model reply: '+str(reply.get('message',''))[:1000])
        action=event.get('plan',{}).get('action')
        _require(action in ('help','recommend'),'The model discussion proposed an unsolicited calculation or presentation change.')
        _require(not reply.get('refresh') and canonical(session.result)==saved_result and canonical(session.plan)==saved_plan and canonical(session.style)==saved_style,'The discussion changed the numerical result, analysis plan or figure settings.')
        _require('local model discussion' in reply.get('message','').casefold(),'The model discussion was not distinguished from computed engine results.')
        report['discussion_check']={'elapsed_s':elapsed,'recorded_action':action,'result_unchanged':True,'plan_unchanged':True,'style_unchanged':True}
        report['checks'].append('actual_model_discussion_performs_no_calculation')
        after=_identity(session);report['identity_after']=after
        _require(canonical(before)==canonical(after),'The source or indexed cache identity changed during the live-model workflow.')
        head,count=verify_audit(session.project_dir/'history.jsonl',session.last_hash)
        report.update(status='passed',completed_utc=datetime.now(timezone.utc).isoformat(),elapsed_s=time.monotonic()-started,
                      source_and_cache_unchanged=True,audit_head=head,audit_events=count,
                      model_input_scope='Full compact column/aggregate schema, previous plan metadata and approved computed numeric summaries only; no source paths, raw matching records or category values are supplied automatically.')
        report['checks'].append('source_cache_identity_and_complete_audit_verified')
        (output/'result.json').write_text(json.dumps(report,indent=2,allow_nan=False),encoding='utf-8')
        return report
    except Exception as error:
        report.update(status='failed',completed_utc=datetime.now(timezone.utc).isoformat(),elapsed_s=time.monotonic()-started,
                      error=str(error),traceback=traceback.format_exc())
        (output/'result.json').write_text(json.dumps(report,indent=2,allow_nan=False),encoding='utf-8')
        raise
