"""Source-preserving study intake, planning persistence, profiles and plan exports.

Study planning stays separate from explicit reviewed execution recipes.
"""
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import uuid
import zipfile


def import_study(session, paths):
    from .study import Study
    from .study_planner import initial_state
    from .session import sha256, versions
    from .storage import require_space, MIB
    originals=sorted([Path(p).expanduser().resolve() for p in paths],key=lambda p:(p.name.casefold(),p.name,str(p)))
    total_bytes=sum(p.stat().st_size for p in originals if p.is_file())
    require_space(session.workspace, max(16 * MIB, total_bytes * 2 + 8 * MIB), 'import the study files')
    # Validate the complete batch before creating a project or replacing a view.
    Study(originals)
    directory=session.workspace/'projects'/f'{datetime.now():%Y%m%d-%H%M%S}-study-{uuid.uuid4().hex[:6]}'
    old=dict(session.__dict__)
    try:
        snapshots=[]
        for index,original in enumerate(originals,1):
            before=original.stat()
            target=directory/'source'/f'S{index:03}'/original.name
            target.parent.mkdir(parents=True,exist_ok=False)
            digest=hashlib.sha256()
            with original.open('rb') as src,target.open('xb') as dst:
                for block in iter(lambda:src.read(1024*1024),b''):
                    dst.write(block);digest.update(block)
            after=original.stat()
            if (before.st_size,before.st_mtime_ns,before.st_ctime_ns)!=(after.st_size,after.st_mtime_ns,after.st_ctime_ns) or sha256(original)!=digest.hexdigest():
                raise ValueError('A workbook changed during import. Use stable original files and try again.')
            shutil.copystat(original,target);target.chmod(0o444);snapshots.append(target)
        study=Study(snapshots)
        study.write_manifest(directory/'study.json')
        session.project_dir,session.dataset=directory,study
        session.source_original_path=[str(p) for p in originals]
        session.last_hash='0'*64
        session.context={'design':'unknown','input_type':'study','study_state':initial_state(study)}
        session.plan={'action':'study_plan','status':'draft','calculations_performed':False}
        session.result=session.pending_plan=None;session.conversation=[]
        session.style={'width_mm':178,'height_mm':110,'font_size':9,'palette':'teal','show_points':True,'dpi':600}
        session._event('study_import',{'original_paths':session.source_original_path,'manifest_sha256':study.source_hash,
                                     'evidence':study.manifest(),'environment':versions(),'calculations_performed':False})
        session.save()
        return study
    except Exception:
        session.__dict__.clear();session.__dict__.update(old)
        if directory.exists():shutil.rmtree(directory)
        raise


def _profile_name(name):
    if not isinstance(name,str) or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9 _.-]{0,63}',name) or '..' in name:
        raise ValueError('Use a profile name of 1–64 letters, numbers, spaces, dots, underscores or hyphens, without .. or slashes.')
    return re.sub(r' +','-',name.strip()).casefold()


def _schema_signatures(study):
    signatures=[]
    for source in study.manifest().get('sources',[]):
        sheets=source.get('sheets',[])
        shape=[{'name':sheet.get('name',sheet.get('title')),'columns':sheet.get('columns',sheet.get('headers',[]))}
               for sheet in sheets if isinstance(sheet,dict)]
        signature=hashlib.sha256(json.dumps(shape,sort_keys=True,ensure_ascii=False).encode()).hexdigest()
        if signature not in signatures:signatures.append(signature)
    return sorted(signatures)


def save_profile(session,name):
    slug=_profile_name(name);parent=session.workspace/'study-profiles';parent.mkdir(exist_ok=True)
    path=parent/(slug+'.json')
    if not path.resolve().is_relative_to(parent.resolve()):raise ValueError('Invalid profile path.')
    domain=session.dataset.manifest().get('domain',{})
    known_roles={'Metadata':'metadata','Summary':'recording_summary','PerBreath':'observations','TextMarks':'protocol_labels'}
    role_hints={sheet.get('name',sheet.get('title','')):
                known_roles.get(sheet.get('name'),'unclassified') if source.get('role')=='standardized_export' else 'unclassified'
                for source in session.dataset.manifest().get('sources',[]) for sheet in source.get('sheets',[]) if isinstance(sheet,dict)}
    profile={'version':1,'name':name,'domain_hint':session.context['study_state'].get('domain_confirmation') or domain.get('name','unknown'),
             'schema_fingerprints':_schema_signatures(session.dataset),
             'preferred_sheet_roles':role_hints,
             'policy':'Schema and role hints only. Reconfirm subjects, groups, conflicts and analysis choices for every new study.'}
    # Reusable profiles never carry identities, original paths or accepted conflicts.
    with path.open('x',encoding='utf-8') as handle:json.dump(profile,handle,indent=2,ensure_ascii=False)
    session._event('study_import_profile_saved',{'name':name,'schema_fingerprints':profile['schema_fingerprints']})
    return 'Saved reusable import profile “'+name+'”. It contains schema/domain hints, without subject IDs, group assignments or accepted conflicts.'


def apply_profile(session,state,name):
    slug=_profile_name(name);parent=session.workspace/'study-profiles';path=parent/(slug+'.json')
    if not path.resolve().is_relative_to(parent.resolve()) or not path.is_file():raise ValueError('That import profile was not found in this workspace.')
    if path.stat().st_size>65536:raise ValueError('The import profile exceeds its supported size.')
    profile=json.loads(path.read_text(encoding='utf-8'))
    expected={'version','name','domain_hint','schema_fingerprints','preferred_sheet_roles','policy'}
    if not isinstance(profile,dict) or set(profile)!=expected or profile.get('version')!=1:
        raise ValueError('The import profile format is unsupported.')
    same=profile['schema_fingerprints']==_schema_signatures(session.dataset)
    new=deepcopy(state)
    new['profile_proposal']={'name':profile['name'],'domain_hint':profile['domain_hint'],'schema_matches':same,
                             'preferred_sheet_roles':profile['preferred_sheet_roles']}
    new['approved_plan']=False
    message=('The workbook schemas match this profile. Its domain/role hints are a proposal; current-study identities and grouping still require review.'
             if same else 'Schema drift detected: this batch differs from the saved profile. No mappings or accepted conflicts were transferred. Review the changed source inventory before adopting a plan.')
    session._event('study_import_profile_proposed',new['profile_proposal'])
    return new,message


def command_study(session,text,model=None):
    from .study_planner import interpret_study,apply_study_command,validate_discussion
    from .session import canonical
    session._assert_integrity()
    conv_len=len(session.conversation)
    session.conversation.append({'role':'user','text':text})
    session._event('instruction',{'text':text,'interpreter':'study control with optional local-model discussion' if model else 'offline study control'})
    before=deepcopy(session.context['study_state'])
    checkpoint={'context':deepcopy(session.context),'plan':deepcopy(session.plan),
                'result':deepcopy(session.result),'style':deepcopy(session.style)}
    try:
        from .study_bridge import handle_execution_command,invalidate_approval
        from .study_conversation import handle_natural_conversation,propose_action
        execution_reply=handle_natural_conversation(session,text)
        natural_reply=execution_reply is not None
        if execution_reply is None:execution_reply=handle_execution_command(session,text)
        if execution_reply is not None:
            message=execution_reply.pop('message')
            refresh=execution_reply.pop('refresh',False)
            if natural_reply:
                # Follow-up answers must see the app's own clarification, not
                # only previous model prose. Keep two bounded exchanges.
                session.context['study_dialogue']=(session.context.get('study_dialogue',[])+[
                    {'role':'user','text':text[:1500]},{'role':'assistant','text':message[:1500]}])[-4:]
            return session._reply(message,refresh,**execution_reply)
        note=re.fullmatch(r'(?:study note\s*:\s*|metadata note\s*:\s*|remember\s+(?:that\s+)?)(.+)',text.strip(),re.I|re.S)
        command={'action':'study_note','text':note.group(1).strip()} if note else interpret_study(text,session.dataset,before)
        if command.get('action')=='study_unknown' and not command.get('unsupported') and model:
            # Recent conversation is explicitly user-provided context, separate
            # from inspected source facts and from confirmed typed mappings.
            dialogue=session.context.get('study_dialogue',[])[-4:]
            from .study_bridge import discussion_context
            command=model.plan(text,session.dataset,None,{'study_state':before,'study_dialogue':dialogue,
                'study_execution_context':discussion_context(session,text)})
            if getattr(model,'cancelled',False):
                from .llm import ModelCancelledError
                raise ModelCancelledError('The local model request was cancelled. No calculation was run.')
            command=validate_discussion(command,session.dataset,before)
            session._event('model_plan_supplied',{'model':getattr(model,'model','configured local model'),
                'configured_model_digest':getattr(model,'configured_model_digest',None),'input_type':'study','plan':command,
                'calculations_performed':False})
        session._event('interpreted_plan',command)
        action=command.get('action')
        if action=='study_export':
            return session._reply('Preparing the study plan, source inventory, method references and conversation. No numerical analysis or scientific figure is included.',
                                  export_request={'action':'study_export','include_source':bool(command.get('include_source',False))})
        if action=='study_note':
            text_note=command['text']
            if not text_note or len(text_note)>2000 or '\x00' in text_note:raise ValueError('Keep one study note between 1 and 2,000 characters.')
            if len(before.get('notes',[]))>=32:raise ValueError('This study already has the supported 32 planning notes.')
            new=deepcopy(before)
            new.setdefault('notes',[]).append({'text':text_note,'origin':'user_supplied','status':'declaration; not independently verified against source'})
            new['approved_plan']=False
            message='Recorded your study note separately from the source evidence. It is available to the planning conversation and export; it does not rewrite source metadata or resolve a typed identity/calibration conflict.'
        elif action=='study_profile_save':
            message=save_profile(session,command['name']);new=before
        elif action=='study_profile_apply':
            new,message=apply_profile(session,before,command['name'])
        else:
            new,message=apply_study_command(session.dataset,before,command)
        if session.result and session.result.get('method')=='study_execution':
            from .study_bridge import status_text
            if action=='study_show':
                message=session.result['summary']+'\n\n'+status_text(session)+'\n\nThe complete planning state and source issues remain in the Study plan and Metadata review tabs. Use “show windows” or “review execution recipe” for current choices.'
            else:
                message+='\n\n'+status_text(session)
        # An invalid discussion/update cannot partially replace a confirmed plan.
        json.dumps(new,allow_nan=False)
        session.context['study_state']=new
        if canonical(new)!=canonical(before):invalidate_approval(session)
        if action=='study_discuss' and model and command.get('message','').startswith('Local model discussion'):
            session.context['study_dialogue']=(session.context.get('study_dialogue',[])+[
                {'role':'user','text':text},{'role':'assistant','text':command['message']}])[-4:]
        if session.result is None:
            session.plan={'action':'study_plan','status':'acknowledged' if new.get('approved_plan') else 'draft','calculations_performed':False}
        session._event('study_planning_step',{'action':action,'previous_state_sha256':hashlib.sha256(canonical(before).encode()).hexdigest(),
                                            'state_sha256':hashlib.sha256(canonical(new).encode()).hexdigest(),'calculations_performed':False})
        proposal=command.get('proposed_action') if action=='study_discuss' else None
        if proposal:
            proposal_reply=propose_action(session,proposal,origin='local_model_proposal')
            # App-owned choices and preview are authoritative; a model's prose
            # cannot replace the executable recipe or authorize itself.
            message+='\n\n'+proposal_reply.pop('message')
            pending=session.context.get('study_execution',{}).get('conversation_proposal')
            if pending:
                from .study_bridge import _hash
                pending['preview_message_sha256']=_hash(message)
            return session._reply(message,proposal_reply.pop('refresh',False),**proposal_reply)
        return session._reply(message,True)
    except Exception as error:
        session.context=checkpoint['context'];session.plan=checkpoint['plan']
        session.result=checkpoint['result'];session.style=checkpoint['style']
        from .storage import StorageError, is_space_error
        if isinstance(error, StorageError) or is_space_error(error):
            del session.conversation[conv_len:]
            return session._unsaved_reply(error)
        cancelled=bool(model and getattr(model,'cancelled',False))
        session._event('request_cancelled' if cancelled else 'request_failed',{'error':str(error),'input_type':'study'})
        return session._reply((str(error) or type(error).__name__)+'\n\nThe prior study plan is retained. No calculation was run.'+
            (' The previous successful result remains available.' if session.result else ''))


def plan_markdown(study,state):
    from .study_methods import method_cards
    evidence=study.manifest();domain=evidence.get('domain',{})
    lines=['# Study plan','', '**Planning export — this package contains proposals and evidence, without numerical results or calculated figures. Completed runs, if present in the project, are exported separately.**','',
           '## Scientific goal','',str(state.get('goal') or 'Not yet specified.'),'',
           '## Study structure','', 'Proposed domain: '+str(domain.get('name','unknown')),
           'Mapping confirmed: '+str(bool(state.get('mapping_confirmed'))),
           'Plan acknowledged: '+str(bool(state.get('approved_plan'))),
           'Trial handling: '+str(state.get('pooling','undecided')),'',
           '## Sources','']
    for source in evidence.get('sources',[]):
        lines.append('- '+str(source.get('source_id',''))+' · '+str(source.get('original_name',''))+' · '+str(source.get('role','unknown'))+' · SHA-256 '+str(source.get('sha256','')))
    lines+=['','## Source metadata requiring review','']
    for issue in evidence.get('issues',[]):lines.append('- '+json.dumps(issue,ensure_ascii=False))
    if not evidence.get('issues'):lines.append('No issues detected by the bounded intake checks. This does not establish complete metadata or scientific validity.')
    lines+=['','## Confirmed and proposed planning state','', '```json',json.dumps(state,indent=2,ensure_ascii=False),'```','',
            '## Candidate methods and figures','']
    for card in method_cards(study,state):
        lines+=['### '+str(card['title']),'','Method ID: '+str(card['id']),
                'Execution status: '+str(card.get('execution_status','planning only')),
                'Question: '+str(card.get('question','')),
                'Approach: '+str(card.get('formula_or_approach','')),
                'Requirements: '+json.dumps(card.get('requirements',[]),ensure_ascii=False),
                'Readiness: '+json.dumps(card.get('readiness',{}),ensure_ascii=False),
                'Figure proposal: '+json.dumps(card.get('suggested_figure',''),ensure_ascii=False),'']
        for reference in card.get('sources',[]):
            if isinstance(reference,dict):lines.append('- ['+str(reference.get('title',reference.get('id','Source')))+']('+str(reference.get('url',''))+')')
    lines+=['','## Execution boundary','',
            'Suggestions and plan acknowledgement do not execute statistics. The pleth Summary bridge separately requires review and confirmation of an exact recipe, followed by an explicit run instruction. Available-measure reports, response curves and per-subject CO2 slopes have defined adapters and calibration requirements. Bayesian/mixed-model routines remain planning-only.']
    return '\n'.join(lines)+'\n'


def export_study(session,request=None):
    from .session import clean,sha256,versions
    from .study_methods import method_cards
    session._assert_integrity(full=True);request=request or {}
    parent=session.project_dir/'exports'
    parent.mkdir(parents=True,exist_ok=True)
    stem_name=f'study-plan-{datetime.now():%Y%m%d-%H%M%S}-{uuid.uuid4().hex[:4]}'
    folder=parent/stem_name
    stage=parent/f'.{stem_name}.tmp'
    archive=folder.with_suffix('.zip')
    temp_archive=parent/f'.{stem_name}.zip.tmp'
    stage.mkdir(parents=True,exist_ok=False)
    study=session.dataset;state=session.context['study_state'];include=bool(request.get('include_source',False))
    try:
        spec={'version':1,'type':'study_planning_export','app_version':versions()['StatWeave'],
              'calculations_performed':False,'raw_sources_included':include,
              'evidence':study.manifest(),'planning_state':state,'method_cards':method_cards(study,state),
              'source_policy':'Exact original source files included.' if include else 'Exact original files remain preserved in the local project; this export records their hashes and relative identities.'}
        for name,value in [('study-plan.json',spec),('source-inventory.json',study.manifest()),('conversation.json',session.conversation),('environment.json',versions())]:
            (stage/name).write_text(json.dumps(clean(value),indent=2,ensure_ascii=False,allow_nan=False),encoding='utf-8')
        (stage/'STUDY_PLAN.md').write_text(plan_markdown(study,state),encoding='utf-8')
        (stage/'START_HERE.md').write_text('# Study planning export\n\nRead STUDY_PLAN.md for the scientific goal, metadata issues, candidate methods, sources and execution status. This package contains no numerical result or calculated figure.\n\n'+spec['source_policy']+'\n',encoding='utf-8')
        if include:
            for source in study.manifest()['sources']:
                original=session.project_dir/source['relative_path']
                if original.is_symlink():raise ValueError('Refusing to export a symlinked study source.')
                original=original.resolve()
                target=(stage/source['relative_path']).resolve()
                if not original.is_relative_to(session.project_dir.resolve()) or not target.is_relative_to(stage.resolve()):
                    raise ValueError('A study source path is outside its export/project.')
                target.parent.mkdir(parents=True,exist_ok=True)
                shutil.copy2(original,target)
                if sha256(target)!=source['sha256']:raise ValueError('A source changed while its export copy was created.')
            shutil.copy2(study.source_path,stage/'study.json')
        shutil.copy2(session.project_dir/'history.jsonl',stage/'history.jsonl')
        manifest={str(p.relative_to(stage)):sha256(p) for p in sorted(stage.rglob('*')) if p.is_file()}
        (stage/'SHA256.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
        with temp_archive.open('xb') as raw_zip:
            with zipfile.ZipFile(raw_zip,'w',compression=zipfile.ZIP_DEFLATED) as handle:
                for path in sorted(stage.rglob('*')):
                    if path.is_file():handle.write(path,str(Path(folder.name)/path.relative_to(stage)))
            raw_zip.flush();os.fsync(raw_zip.fileno())
        os.replace(stage,folder)
        os.replace(temp_archive,archive)
    except BaseException:
        shutil.rmtree(stage,ignore_errors=True)
        temp_archive.unlink(missing_ok=True)
        raise
    try:
        session._event('study_plan_export',{'directory':str(folder),'raw_sources_included':include,'calculations_performed':False})
        session.save()
    except BaseException:
        shutil.rmtree(folder,ignore_errors=True)
        archive.unlink(missing_ok=True)
        raise
    return {'input_type':'study','folder':str(folder),'archive':str(archive),'raw_sources_included':include,'calculations_performed':False}
