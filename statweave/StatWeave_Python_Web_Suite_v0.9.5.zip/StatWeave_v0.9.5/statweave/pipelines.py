"""Inspectable recording recipes and deterministic folder processing; no code execution."""
from copy import deepcopy
from datetime import datetime, timezone
import csv
import hashlib
import json
import math
from pathlib import Path
import re
import uuid

MAX_FILES = 100
PLAN_KEYS = {'action','method','channels','sweeps','start_s','end_s','time_reference',
             'detector','bin_width_s','measurements','style','excluded_regions','event_decisions','review_source_sha256'}


def interpret_pipeline(text):
    low=text.casefold().strip()
    if not re.search(r'\bpipeline\b|^(?:check|inspect)\s+folder\b',low):
        return None
    match=re.fullmatch(r'save\s+(?:this\s+)?pipeline\s+as\s+["\x27]([^"\x27]+)["\x27]\s*',text,re.I)
    if match:return {'action':'pipeline_save','name':match.group(1)}
    match=re.fullmatch(r'(run|apply|check|inspect)\s+(?:the\s+)?(?:pipeline\s+(?:on|to)\s+)?folder\s+["\x27]([^"\x27]+)["\x27]\s*',text,re.I)
    if match:return {'action':'pipeline_check' if match.group(1).casefold() in ('check','inspect') else 'pipeline_run','folder':match.group(2)}
    if re.fullmatch(r'export\s+(?:the\s+)?pipeline\s+figures',low):
        return {'action':'pipeline_export'}
    return {'action':'help','unsupported':True,'message':'Pipeline commands: save pipeline as "Current clamp"; check folder "/path/to/abfs"; run pipeline on folder "/path/to/abfs"; export pipeline figures. A recipe copies analysis settings; per-file artifact masks and peak decisions remain specific to their original recording.'}


def _canonical(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)


def _sha(path):
    h=hashlib.sha256()
    with open(path,'rb') as handle:
        for block in iter(lambda:handle.read(1024*1024),b''):h.update(block)
    return h.hexdigest()


def fingerprint(recording,plan):
    meta=recording.metadata()
    return {'protocol_name':meta.get('protocol_name'),'acquisition_mode_code':meta['acquisition_mode_code'],
            'channel_count':len(recording.channels),'sweep_count':len(recording.sweeps),
            'channels':[{'index':c['index'],'name':c['name'],'unit':c['unit'],
                         'sampling_rate_hz':float(c['sampling_rate_hz'])} for c in recording.channels],
            'selected_sweeps':[{'index':i,'duration_s':float(recording.sweeps[i]['duration_s']),
                                'sample_count':int(recording.sweeps[i]['sample_count'])} for i in plan['sweeps']]}


def compatibility(recording,recipe):
    from .action_potentials import validate_ap_plan
    reference=recipe['compatibility']
    try:candidate=fingerprint(recording,recipe['plan'])
    except (IndexError,KeyError):return ['the selected channels or sweeps are unavailable in this file']
    reasons=[]
    for key in ['acquisition_mode_code','channel_count','sweep_count','channels','selected_sweeps']:
        if candidate[key]!=reference[key]:reasons.append(key.replace('_',' ')+' differs from the reference recording')
    if reference.get('protocol_name') and candidate.get('protocol_name')!=reference['protocol_name']:
        reasons.append('header protocol name differs or is unavailable')
    try:validate_ap_plan(recording,recipe['plan'])
    except (ValueError,TypeError,KeyError) as error:reasons.append(str(error))
    return reasons


def save_pipeline(session,name):
    from .action_potentials import validate_ap_plan
    from .session import clean,versions
    if not session.is_recording or not session.result or session.result.get('method')!='action_potentials':
        raise ValueError('Measure action potentials on one representative recording before saving a pipeline.')
    name=str(name).strip()
    if not 1<=len(name)<=80 or any(ord(c)<32 for c in name):raise ValueError('Give the pipeline a short, readable name.')
    plan=deepcopy(session.plan)
    plan.pop('message',None)
    omitted={'excluded_regions':len(plan.get('excluded_regions',[])),'peak_decisions':len(plan.get('event_decisions',[]))}
    plan['excluded_regions']=[];plan['event_decisions']=[]
    plan.pop('review_source_sha256',None)
    plan=clean(validate_ap_plan(session.dataset,plan))
    recipe={'format_version':1,'kind':'abf_action_potential_pipeline','name':name,
            'created_utc':datetime.now(timezone.utc).isoformat(),'environment':versions(),
            'plan':plan,'style':clean(session.style),'compatibility':fingerprint(session.dataset,plan),
            'reference_source_sha256':session.dataset.source_hash,
            'per_file_annotations_not_copied':omitted,
            'limits':'Header/channel/rate/sweep compatibility does not verify the stimulus waveform, cell type, treatment or biological protocol. Review the experiment; no command waveform is reconstructed.'}
    slug=re.sub(r'[^a-zA-Z0-9_-]+','-',name).strip('-')[:50] or 'pipeline'
    path=session.workspace/'pipelines'/f'{slug}-{datetime.now(timezone.utc):%Y%m%d-%H%M%S}-{uuid.uuid4().hex[:6]}.json'
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('x',encoding='utf-8') as handle:handle.write(json.dumps(recipe,indent=2,ensure_ascii=False,allow_nan=False))
    path.chmod(0o444)
    session.context['last_pipeline']={'path':str(path),'sha256':_sha(path),'name':name}
    session._event('pipeline_saved',{'pipeline':session.context['last_pipeline'],'recipe':recipe})
    return (f'Saved pipeline “{name}” with the detector, analysis window, measurement definitions and figure settings. '
            'File-specific artifact masks and manual peak decisions were not copied. Each file will be checked for matching acquisition mode, channel names/units/sample rates, sweep structure and header protocol name where available. '
            'These checks cannot establish biological protocol equivalence.\n\nTry check folder "/path/to/abfs", then run pipeline on folder "/path/to/abfs".\nSaved in: '+str(path))


def load_pipeline(session):
    selected=session.context.get('last_pipeline')
    if not selected:raise ValueError('Save a pipeline from a representative action-potential analysis first.')
    path=Path(selected['path']).expanduser().resolve()
    if path.stat().st_size>2_000_000:raise ValueError('The pipeline file exceeds the supported size.')
    payload=path.read_bytes()
    if len(payload)>2_000_000:raise ValueError('The pipeline file exceeds the supported size.')
    if hashlib.sha256(payload).hexdigest()!=selected['sha256']:raise ValueError('The saved pipeline has changed since it was recorded. Save a new reviewed pipeline.')
    recipe=json.loads(payload.decode('utf-8'))
    if recipe.get('format_version')!=1 or recipe.get('kind')!='abf_action_potential_pipeline':raise ValueError('Unsupported pipeline format.')
    if not isinstance(recipe.get('plan'),dict) or set(recipe['plan'])-PLAN_KEYS:raise ValueError('The recipe contains unsupported plan fields.')
    if recipe['plan'].get('method')!='action_potentials' or recipe['plan'].get('event_decisions') or recipe['plan'].get('excluded_regions'):
        raise ValueError('Folder recipes must use action-potential settings without another file’s manual annotations.')
    return recipe,path


def _write_csv(path,rows,columns=None):
    columns=columns or list(dict.fromkeys(key for row in rows for key in row)) or ['file','status']
    with path.open('w',encoding='utf-8',newline='') as handle:
        writer=csv.DictWriter(handle,fieldnames=columns,extrasaction='ignore')
        writer.writeheader();writer.writerows(rows)


def _append_csv(path,rows,columns):
    with path.open('a',encoding='utf-8',newline='') as handle:
        writer=csv.DictWriter(handle,fieldnames=columns,extrasaction='ignore')
        writer.writerows(rows)


def _manifest(folder):
    files={p.name:_sha(p) for p in sorted(folder.iterdir()) if p.is_file() and p.name!='SHA256.json'}
    (folder/'SHA256.json').write_text(json.dumps(files,indent=2))


def run_folder(session,folder,check_only=False):
    from .recording import ABFRecording
    from .action_potentials import ap_result
    from .session import Session,clean,versions
    recipe,pipeline_path=load_pipeline(session)
    pipeline_identity=deepcopy(session.context['last_pipeline'])
    pipeline_identity['recipe_content_sha256']=hashlib.sha256(_canonical(recipe).encode('utf-8')).hexdigest()
    directory=Path(folder).expanduser().resolve()
    if not directory.is_dir():raise ValueError('Choose an existing folder containing ABF files.')
    files=sorted((p for p in directory.iterdir() if p.is_file() and p.suffix.casefold()=='.abf'),key=lambda p:p.name.casefold())
    if not files:raise ValueError('No ABF files were found directly inside that folder. Subfolders are not searched.')
    if len(files)>MAX_FILES:raise ValueError(f'This bounded folder run supports at most {MAX_FILES} ABF files. Select a smaller folder.')
    batch=None
    if not check_only:
        batch=session.workspace/'batches'/f'AP-{datetime.now(timezone.utc):%Y%m%d-%H%M%S}-{uuid.uuid4().hex[:6]}'
        batch.mkdir(parents=True,exist_ok=False)
        (batch/'pipeline.json').write_text(json.dumps(recipe,indent=2,ensure_ascii=False))
        from .action_potentials import AP_COLUMNS,ISI_COLUMNS,RATE_COLUMNS
        for name,columns in [('action-potential-measurements.csv',AP_COLUMNS),('inter-spike-intervals.csv',ISI_COLUMNS),('firing-rates.csv',RATE_COLUMNS)]:
            _write_csv(batch/name,[],['file','source_sha256',*columns])
    rows=[]
    for path in files:
        row={'file':path.name,'status':'incompatible','source_sha256':None,'reason':'','project':None}
        child=None
        try:
            recording=ABFRecording(path);row['source_sha256']=recording.source_hash
            problems=compatibility(recording,recipe)
            if problems:
                row['reason']='; '.join(problems)
            elif check_only:
                row['status']='compatible'
            else:
                child=Session(batch)
                child.import_file(path)
                if child.dataset.source_hash!=recording.source_hash:
                    raise ValueError('The input changed between its compatibility check and preserved snapshot. No pipeline analysis was run.')
                child.context['pipeline']={'name':recipe['name'],'sha256':pipeline_identity['sha256'],
                                           'recipe_content_sha256':pipeline_identity['recipe_content_sha256'],
                                           'reference_source_sha256':recipe['reference_source_sha256']}
                result=ap_result(child.dataset,recipe['plan'])
                child._assert_integrity()
                child.plan,child.result,child.style=clean(result['plan']),clean(result),clean(recipe['style'])
                child._event('pipeline_action_potential_analysis',{'pipeline':child.context['pipeline'],
                              'plan':child.plan,'result':child.result,'environment':versions()})
                child.conversation=[{'role':'assistant','text':result['summary']}]
                project=child.save()
                row.update(status='completed',project=project)
                for table in result['tables']:
                    target={'Action potential measurements':'action-potential-measurements.csv','Inter-spike intervals':'inter-spike-intervals.csv','Firing rate by sweep':'firing-rates.csv'}.get(table['title'])
                    if target is not None:
                        _append_csv(batch/target,({'file':path.name,'source_sha256':recording.source_hash,**clean(r)} for r in table['rows']),['file','source_sha256',*table['columns']])
        except Exception as error:
            row.update(status='failed',reason=str(error))
            if child and child.project_dir:
                row['project']=str(child.project_dir/'project.json')
                try:
                    child._event('pipeline_file_failed',{'error':str(error)})
                    child.save()
                except Exception as record_error:
                    # A compromised source must not be saved as valid, nor may
                    # its failure hide the remaining files from the batch log.
                    row['reason']+='; project verification/save also failed: '+str(record_error)
        rows.append(row)
    event={'pipeline':pipeline_identity,'folder':str(directory),'files':rows}
    if check_only:
        session._event('pipeline_folder_checked',event)
    else:
        report={**event,'status':'completed','name':recipe['name'],'created_utc':datetime.now(timezone.utc).isoformat(),
                'limits':recipe['limits'],'figures':'Not exported yet; ask export pipeline figures. Original ABFs are included in each saved project.'}
        (batch/'batch.json').write_text(json.dumps(report,indent=2,ensure_ascii=False))
        _write_csv(batch/'file-status.csv',rows)
        _manifest(batch)
        session.context['last_batch']=str(batch)
        session._event('pipeline_folder_run',{**event,'batch_dir':str(batch)})
    count=sum(r['status'] in ('compatible','completed') for r in rows)
    message=f'{"Checked" if check_only else "Processed"} {len(rows)} ABF files: {count} {"compatible" if check_only else "completed"}, {len(rows)-count} incompatible or failed.\n'
    message+='\n'.join(f'{r["file"]}: {r["status"]}'+(' — '+r['reason'] if r['reason'] else '') for r in rows[:15])
    if len(rows)>15:message+='\nAll file outcomes remain in the recorded batch report.'
    message+='\n'+recipe['limits']
    if batch:message+='\nSaved per-file projects and combined CSV tables in: '+str(batch)+'\nAsk “export pipeline figures” for a figure and reproduction package for each completed file. Raw originals remain intact.'
    return message


def batch_projects(batch_dir):
    folder=Path(batch_dir).resolve();report=json.loads((folder/'batch.json').read_text())
    expected=json.loads((folder/'SHA256.json').read_text())
    for name,digest in expected.items():
        if Path(name).name!=name or _sha(folder/name)!=digest:raise ValueError('The batch report or tables changed outside their recorded manifest.')
    projects=[]
    for row in report['files']:
        if row['status']=='completed':
            path=Path(row['project']).resolve()
            if not path.is_relative_to(folder/'projects'):raise ValueError('A batch project points outside this batch.')
            projects.append(path)
    return folder,report,projects


def record_batch_exports(session,batch_dir,exports):
    folder,report,_=batch_projects(batch_dir)
    report['exports']=exports
    count=sum(item.get('status')=='exported' for item in exports)
    report['figures']=f'{count} of {len(exports)} requested file figure/reproduction packages exported; see per-file export outcomes. Local packages include original ABFs.'
    (folder/'batch.json').write_text(json.dumps(report,indent=2,ensure_ascii=False))
    _manifest(folder)
    session._event('pipeline_figures_exported',{'batch_dir':str(folder),'files':exports})
    session.save()
