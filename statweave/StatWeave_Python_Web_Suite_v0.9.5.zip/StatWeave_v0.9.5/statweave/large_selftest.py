"""Synthetic production smoke checks for source and frozen disk-backed builds."""
from copy import deepcopy
import csv
import json
from pathlib import Path
import traceback
import zipfile

from .session import Session,sha256,verify_audit,versions


def _rows(result,title):
    return next(table['rows'] for table in result['tables'] if table['title']==title)


def _check_manifest(output):
    folder=Path(output['folder'])
    manifest=json.loads((folder/'SHA256.json').read_text(encoding='utf-8'))
    for name,digest in manifest.items():
        path=(folder/name).resolve()
        assert path.is_relative_to(folder.resolve()) and path.is_file(),name
        assert sha256(path)==digest,name
    with zipfile.ZipFile(output['archive']) as archive:assert archive.testzip() is None
    return len(manifest)


def run(workspace):
    """Exercise the shipped numerical/project/export paths without an AI model."""
    work=Path(workspace).resolve()/'large-self-test';work.mkdir(parents=True,exist_ok=True)
    checks=[];commands=[]
    try:
        source=work/'synthetic-large-table.csv'
        count=60
        with source.open('w',encoding='utf-8',newline='') as handle:
            writer=csv.writer(handle)
            writer.writerow(['GeneSymbol','Species','StudyID','ContrastID','logFC','AdjPValue','SourceRow','annotation'])
            for index in range(count):
                gene=['Rab7a','RAB7A','RAB7A-AS1'][index] if index<3 else f'SyntheticGene{index:03}'
                value={12:'NaN',13:'not_numeric',14:''}.get(index,f'{(index-30)/10:.1f}')
                writer.writerow([gene,['mouse','human'][index%2],f'SyntheticStudy{index%3}',
                    f'SyntheticContrast{index%2}',value,f'{(index%11)/10:.1f}',f'{index+1:04}',
                    'NA' if index==0 else 'synthetic software fixture only'])
        original=sha256(source)
        session=Session(work);session.import_large_table(source)
        assert session.is_large_table and not hasattr(session.dataset,'df')
        assert session.dataset.row_count==count
        frame=session.dataset.preview()
        assert len(frame)<=200 and frame.index[0]==1
        assert frame.iloc[0]['SourceRow']=='0001' and frame.iloc[0]['annotation']=='NA'
        checks.append('forced_disk_backed_import_and_text_identity')

        def command(text,method=None):
            commands.append(text);reply=session.command(text)
            assert reply.get('refresh'),(text,reply)
            if method:assert session.result['method']==method,(text,session.result['method'])
            return session.result

        profile=command('describe this data','profile')
        assert profile['large_table_accounting']['selected_record_count']==count
        profile_x=next(row for row in _rows(profile,'Column profile') if row['column']=='logFC')
        assert [profile_x[k] for k in ['finite_count','nonfinite_count','invalid_count','null_count']]==[57,1,1,1]
        checks.append('full_record_profile_and_missingness')
        grouped=command('count rows by Species','count_by')
        assert sum(row['count'] for row in _rows(grouped,'Counts by group'))+grouped['large_table_accounting']['remaining_record_count']==count
        checks.append('complete_group_counts')
        found=command('find gene RAB7A','find')
        assert found['large_table_accounting']['selected_record_count']==2
        assert {row['GeneSymbol'] for row in _rows(found,'Matching records')}=={'Rab7a','RAB7A'}
        checks.append('case_insensitive_exact_gene_without_suffix_match')
        summary=command('summarize logFC','summary')
        assert summary['large_table_accounting']['selected_record_count']==2
        assert _rows(summary,'Numeric summary')[0]['finite_count']==2
        checks.append('prior_explicit_selection_preserved')
        command('use all rows','summary')
        assert session.result['large_table_accounting']['selected_record_count']==count
        histogram=command('histogram logFC using 8 bins','histogram')
        assert sum(row['count'] for row in _rows(histogram,'Histogram'))==57
        checks.append('exact_full_selected_histogram')
        scatter=command('scatter logFC against AdjPValue','scatter')
        assert scatter['large_table_accounting']['finite_pair_count']==57
        assert len(_rows(scatter,'Scatter sample'))==57
        assert scatter['large_table_accounting']['selected_record_count']==count
        checks.append('finite_scatter_and_full_data_summaries')
        saved=deepcopy(session.result);cache=session.dataset.cache_identity()
        project=session.save()
        reopened=Session(work);reopened.open_project(project)
        assert reopened.result==saved and reopened.dataset.cache_identity()==cache
        # Reopening extends the audit. Continue exclusively with the fresh
        # session so no old audit head can be appended after the readback.
        session=reopened
        checks.append('project_reopen_exact_result_and_cache_identity')
        before=deepcopy(session.result)
        blocked=session.command('delete rows')
        assert not blocked.get('refresh') and session.result==before
        checks.append('source_pruning_blocked')
        command('histogram logFC using 8 bins','histogram')
        commands.append('export as SVG');request=session.command('export as SVG')
        assert request.get('export_request') is not None,request
        output=session.export_bundle(request['export_request'])
        assert not output['raw_source_included'] and not (Path(output['folder'])/'source').exists()
        files=_check_manifest(output)
        checks.append('compact_export_files_hashes_and_zip_crc')
        assert sha256(source)==original and sha256(session.dataset.source_path)==original
        session._assert_integrity(full=True)
        head,events=verify_audit(session.project_dir/'history.jsonl',session.last_hash)
        checks.append('unchanged_source_and_complete_audit')
        report={'status':'passed','checks':checks,'commands':commands,'environment':versions(),
            'source_sha256':original,'source_unchanged':True,'row_count':count,'finite_logFC_count':57,
            'cache_identity':session.dataset.cache_identity(),'project':str(session.project_dir),
            'audit_events':events,'audit_head':head,'export':output,'verified_export_files':files,
            'provenance':'Entirely fabricated CSV records generated solely for software verification.',
            'limits':'No private input, live language model or reproduction subprocess was used. Cross-platform and clean-machine execution are separate checks.'}
        (work/'result.json').write_text(json.dumps(report,indent=2,allow_nan=False),encoding='utf-8')
        return report
    except Exception as error:
        (work/'result.json').write_text(json.dumps({'status':'failed','checks':checks,'commands':commands,
            'error':str(error),'traceback':traceback.format_exc()},indent=2),encoding='utf-8')
        raise
