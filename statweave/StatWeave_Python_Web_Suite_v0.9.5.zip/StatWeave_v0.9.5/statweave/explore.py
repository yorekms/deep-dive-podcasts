"""Step 1 (Spreadsheet Description) & Step 2 (Exploratory Figure Gallery) engine."""
from __future__ import annotations

from copy import deepcopy
import io
import json
from pathlib import Path
import re
from typing import Any

import matplotlib.pyplot as plt
import pandas as pd

from .data import Dataset
from .engine import analyze
from .figures import export_figure, figure_savefig_kwargs, make_figure
from .working_sheets import (
    _TIME_OR_DOSE_FACTOR_RE,
    _UNIT_COL_HINT_RE,
    apply_working_sheet_op,
    describe_spreadsheet_structure,
)


def _render_svg_string(dataset: Dataset, result: dict, plan: dict, style: dict) -> str:
    """Render a compact, crisp SVG string for an exploratory gallery card."""
    fig = make_figure(dataset, result, plan, style)
    try:
        buf = io.BytesIO()
        fig.savefig(
            buf,
            format='svg',
            dpi=style.get('dpi', 300),
            bbox_inches=None,
            metadata={'Creator': 'StatWeave', 'Date': None},
            **figure_savefig_kwargs(fig),
        )
        text = buf.getvalue().decode('utf-8', errors='replace')
        idx = text.find('<svg')
        return text[idx:] if idx >= 0 else text
    finally:
        plt.close(fig)


def _shadow_dataset_from_ops(base_dataset: Dataset, prep_ops: list[dict[str, Any]]) -> Dataset:
    """Apply working-sheet operations in memory without mutating session or disk."""
    cur = Dataset(
        df=base_dataset.df.copy(deep=True),
        source_path=base_dataset.source_path,
        source_hash=base_dataset.source_hash,
        sheet=base_dataset.sheet,
        sheets=list(base_dataset.sheets),
        header_row=base_dataset.header_row,
        row_numbers=list(base_dataset.row_numbers),
        warnings=list(base_dataset.warnings),
    )
    for op_spec in prep_ops:
        sname, new_df, _ = apply_working_sheet_op(cur, op_spec, existing_sheets=cur.sheets)
        sheets = list(dict.fromkeys([*(cur.sheets or []), sname]))
        cur = Dataset(
            df=new_df,
            source_path=base_dataset.source_path,
            source_hash=base_dataset.source_hash,
            sheet=sname,
            sheets=sheets,
            header_row=0,
            row_numbers=list(range(2, 2 + len(new_df))),
            warnings=[],
        )
    return cur


def _detect_cluster_col(df: pd.DataFrame, exclude: set[str]) -> str | None:
    """Find a plausible biological replicate / subject / animal ID column in long sheets."""
    nrows = len(df)
    if nrows < 4:
        return None
    for col in df.columns:
        cs = str(col)
        if cs in exclude:
            continue
        if _UNIT_COL_HINT_RE.match(cs):
            s_non = df[col].dropna()
            if pd.api.types.is_float_dtype(s_non) and len(s_non) and not (s_non == s_non.round()).all():
                continue
            nunq = int(s_non.nunique())
            if 2 <= nunq < nrows:
                return cs
    return None


def _classify_subject_col(df: pd.DataFrame, subj_col: str | None, group_col: str | None) -> str:
    """Classify how a unit/subject column relates to a grouping column:
    'nested' -> each subject belongs to a single group with repeated measurements (Superplot / pool_by)
    'paired' -> each subject spans exactly 2 groups with 1 observation per (subject, group) (Paired t-test)
    'crossed_multi' -> subjects span multiple groups with repeated or >2 conditions
    'one_per_subject' -> 1 row per subject
    'none' -> no subject column
    """
    if not subj_col or not group_col or subj_col not in df.columns or group_col not in df.columns:
        return 'none'
    sub = df[[subj_col, group_col]].dropna()
    if len(sub) < 4:
        return 'none'
    s_str = sub[subj_col].astype(str)
    g_str = sub[group_col].astype(str)
    groups_per_subj = g_str.groupby(s_str).nunique()
    if bool((groups_per_subj == 1).all()):
        return 'nested' if len(sub) > int(s_str.nunique()) else 'one_per_subject'
    if int(g_str.nunique()) == 2 and not bool(pd.DataFrame({'s': s_str, 'g': g_str}).duplicated().any()):
        return 'paired'
    return 'crossed_multi'


def _can_run_timecourse_compare(df: pd.DataFrame, x_col: str, group_col: str, y_col: str) -> bool:
    """Return True iff at least one x_col stratum has >=2 groups with >=2 finite observations and non-zero spread."""
    if any(c not in df.columns for c in (x_col, group_col, y_col)):
        return False
    sub = pd.DataFrame({
        'x': df[x_col].astype(str),
        'g': df[group_col].astype(str),
        'y': pd.to_numeric(df[y_col], errors='coerce'),
    }).dropna()
    sub = sub[(sub['x'].str.strip() != '') & (sub['g'].str.strip() != '')]
    total_groups = int(sub['g'].nunique())
    if len(sub) < 4 or total_groups < 2 or sub['x'].nunique() < 2:
        return False
    for _x_val, x_df in sub.groupby('x', sort=False):
        grp_arrays = [g_df['y'].to_numpy(dtype=float) for _g, g_df in x_df.groupby('g', sort=False)]
        if len(grp_arrays) == total_groups and all(len(a) >= 2 for a in grp_arrays):
            all_v = pd.concat([pd.Series(a) for a in grp_arrays], ignore_index=True)
            if int(all_v.nunique()) >= 2:
                return True
    return False


def build_spreadsheet_overview(dataset: Any) -> dict[str, Any]:
    """Return enriched Step 1 spreadsheet description + 1-click preparation actions."""
    if dataset is None:
        return {'available': False, 'headline': 'No spreadsheet loaded.'}
    if getattr(dataset, 'kind', None) == 'recording':
        return {
            'available': True,
            'kind': 'recording',
            'sheet': getattr(dataset, 'name', 'Recording'),
            'headline': 'Electrophysiology recording loaded. Inspect sweeps/channels first, then measure spikes or action potentials.',
            'prep_actions': [],
            'columns_overview': [],
        }
    if getattr(dataset, 'kind', None) == 'large_table' or not hasattr(dataset, 'df'):
        return {
            'available': True,
            'kind': str(getattr(dataset, 'kind', 'study')),
            'headline': 'Structured dataset loaded. Inspect columns and exploratory plots before running statistical tests.',
            'prep_actions': [],
            'columns_overview': [],
        }

    base = describe_spreadsheet_structure(dataset)
    base['available'] = True
    base['kind'] = 'table'
    layout = base.get('detected_layout', 'general_table')
    rep = base.get('replicate_structure') or {}
    prep_actions: list[dict[str, Any]] = []

    if rep.get('detected'):
        ref_grp = rep.get('suggested_ref_group') or (list(rep['groups'].keys())[0] if rep.get('groups') else 'Control')
        clean_ref = re.sub(r'[^A-Za-z0-9]+', '_', str(ref_grp)).strip('_') or 'Control'
        norm_col = f'Pct_of_{clean_ref}_Mean'
        base_col = f'Pct_of_{clean_ref}_Baseline'
        prep_actions.append({
            'id': 'prep_tidy_raw',
            'label': '✨ Build Tidy Replicate Sheet',
            'description': f"Reshape wide columns into Timepoint, Group ({', '.join(rep['groups'].keys())}), Subject_ID, and Value.",
            'ops': [{
                'op': 'reshape_replicates',
                'sheet_name': 'Tidy_Replicates',
                'value_name': 'Value',
            }],
        })
        prep_actions.append({
            'id': 'prep_tidy_pct_mean',
            'label': f'✨ Build Normalized (% of {ref_grp} Mean) Sheet',
            'description': f"Reshape replicates and add '{norm_col}' = 100 × Value / mean({ref_grp}).",
            'ops': [{
                'op': 'reshape_replicates',
                'sheet_name': 'Tidy_Timecourse',
                'value_name': 'Value',
                'formula': 'pct_of_group_mean',
                'ref_group': ref_grp,
                'new_column': norm_col,
            }],
        })
        if rep.get('is_timecourse'):
            prep_actions.append({
                'id': 'prep_tidy_pct_baseline',
                'label': f'✨ Build Baseline-Normalized (% of Initial {ref_grp}) Sheet',
                'description': f"Reshape replicates and normalize to the initial timepoint mean of {ref_grp} ('{base_col}').",
                'ops': [{
                    'op': 'reshape_replicates',
                    'sheet_name': 'Tidy_Baseline_Norm',
                    'value_name': 'Value',
                    'formula': 'pct_of_baseline_group_mean',
                    'ref_group': ref_grp,
                    'new_column': base_col,
                }],
            })
    elif layout == 'wide_numeric' and len(base.get('numeric_columns') or []) >= 2:
        num_cols = list(base['numeric_columns'])
        ref_c = num_cols[0]
        clean_ref = re.sub(r'[^A-Za-z0-9]+', '_', str(ref_c)).strip('_') or 'Control'
        prep_actions.append({
            'id': 'prep_melt_wide',
            'label': '✨ Reshape Wide Columns → Tidy Long Sheet',
            'description': f"Stack {', '.join(num_cols[:5])} into Group and Value columns.",
            'ops': [{
                'op': 'melt_wide_to_long',
                'sheet_name': 'Tidy_Long',
                'value_cols': num_cols,
                'var_name': 'Group',
                'value_name': 'Value',
            }],
        })
        prep_actions.append({
            'id': 'prep_melt_pct_ctrl',
            'label': f'✨ Build % of {ref_c} Mean Working Sheet',
            'description': f"Stack columns and normalize values as % of '{ref_c}' mean.",
            'ops': [
                {
                    'op': 'melt_wide_to_long',
                    'sheet_name': 'Tidy_Long',
                    'value_cols': num_cols,
                    'var_name': 'Group',
                    'value_name': 'Value',
                },
                {
                    'op': 'compute_column',
                    'sheet_name': 'Normalized_Pct_Control',
                    'formula': 'pct_of_group_mean',
                    'col_a': 'Value',
                    'group_col': 'Group',
                    'ref_group': ref_c,
                    'new_column': f'Pct_of_{clean_ref}_Mean',
                },
            ],
        })
    elif layout in {'long_grouped', 'long_two_factor'}:
        num_cols = list(base.get('numeric_columns') or [])
        fac_cols = list(base.get('factor_columns') or base.get('categorical_columns') or [])
        if num_cols and fac_cols:
            g_col = fac_cols[-1] if layout == 'long_two_factor' and len(fac_cols) >= 2 else fac_cols[0]
            y_col = num_cols[0]
            levels = [str(x).strip() for x in dataset.df[g_col].dropna().unique().tolist() if str(x).strip()]
            if len(levels) >= 2:
                ref_g = levels[0]
                for lv in levels:
                    if lv.casefold() in {'wt', 'wildtype', 'control', 'ctrl', 'vehicle', 'veh', 'baseline', 'sham'}:
                        ref_g = lv
                        break
                clean_ref = re.sub(r'[^A-Za-z0-9]+', '_', ref_g).strip('_') or 'Control'
                prep_actions.append({
                    'id': 'prep_long_pct_ctrl',
                    'label': f'✨ Add % of {ref_g} Mean Column',
                    'description': f"Create working sheet adding 'Pct_of_{clean_ref}_Mean' normalized to {g_col}='{ref_g}'.",
                    'ops': [{
                        'op': 'compute_column',
                        'sheet_name': f'{dataset.sheet or "Sheet"}_Norm'[:28],
                        'formula': 'pct_of_group_mean',
                        'col_a': y_col,
                        'group_col': g_col,
                        'ref_group': ref_g,
                        'new_column': f'Pct_of_{clean_ref}_Mean',
                    }],
                })

    base['prep_actions'] = prep_actions
    return base


def build_spreadsheet_welcome_message(dataset: Any, source_label: str | None = None) -> str:
    """Create the clear Step 1 spreadsheet summary shown immediately when data is opened."""
    if dataset is None or not hasattr(dataset, 'df'):
        return f'Opened {source_label or "dataset"}.'
    ov = build_spreadsheet_overview(dataset)
    name = source_label or Path(dataset.source_path).name
    cols_preview = ', '.join(str(c) for c in list(dataset.df.columns)[:10])
    if len(dataset.df.columns) > 10:
        cols_preview += f', … (+{len(dataset.df.columns) - 10} more)'

    lines = [
        f"**Step ① — Spreadsheet Overview (`{name}`)**",
        f"- **Size:** {ov['row_count']} rows × {ov['column_count']} columns ({cols_preview}).",
        f"- **Detected structure:** {ov['headline']}",
    ]
    rep = ov.get('replicate_structure') or {}
    if rep.get('detected'):
        grp_bits = [f"**{g}** ({', '.join(cs)})" for g, cs in rep['groups'].items()]
        lines.append(f"- **Detected replicate groups:** {' vs '.join(grp_bits)}.")
        if rep.get('time_col') and rep.get('time_labels'):
            tl = ', '.join(str(t) for t in rep['time_labels'][:6])
            lines.append(f"- **Timepoint / stratum column:** `{rep['time_col']}` ({tl}).")
    surv_info = ov.get('survival_structure') or {}
    if surv_info.get('detected'):
        lines.append(
            f"- **Survival time-to-event columns:** time `{surv_info['time_col']}`, event `{surv_info['event_col']}` "
            f"({surv_info.get('events', 0)} events, {surv_info.get('censored', 0)} right-censored)."
        )
        if surv_info.get('group_cols'):
            lines.append(f"- **Candidate stratification group(s):** {', '.join(f'`{c}`' for c in surv_info['group_cols'][:4])}.")
    if getattr(dataset, 'warnings', None):
        lines.append('- **Import notes:** ' + '; '.join(dataset.warnings))
    lines.append(
        "\n**Next:** Review candidate plots in **② Explore All Figures** on the right (no assumptions or stars forced yet), "
        "click any plot to customize its appearance, and then choose a statistical test & stars in **③ Analysis & Stars**—or ask me in chat!"
    )
    return '\n'.join(lines)


def _two_factor_stat_options(
    x_col: str,
    y_col: str,
    group_col: str,
    plot_type: str,
    subject_col: str | None = None,
    allow_per_stratum: bool = True,
) -> list[dict[str, Any]]:
    """Build Step 3 statistical test + star options for a two-factor / timecourse plot."""
    base_plan: dict[str, Any] = {
        'x': x_col,
        'y': y_col,
        'group': group_col,
        'plot': plot_type,
        'design': 'independent',
    }
    if subject_col:
        base_plan['subject'] = subject_col
    opts: list[dict[str, Any]] = []
    if allow_per_stratum:
        opts.extend([
            {
                'id': 'timecourse_welch_stars',
                'label': '⭐ Per-Timepoint Welch t-test / ANOVA + Holm Stars',
                'summary': f'Compare {group_col} at each {x_col} with Holm–Bonferroni multiplicity-adjusted stars.',
                'plan': {**base_plan, 'method': 'timecourse_compare', 'nonparametric': False},
                'style': {'p_display': 'stars_and_p', 'error_bar': 'sem'},
            },
            {
                'id': 'timecourse_mw_stars',
                'label': '⭐ Per-Timepoint Mann–Whitney / Kruskal + Holm Stars',
                'summary': f'Nonparametric rank comparison of {group_col} at each {x_col} with Holm-adjusted stars.',
                'plan': {**base_plan, 'method': 'timecourse_compare', 'nonparametric': True},
                'style': {'p_display': 'stars_and_p', 'error_bar': 'iqr'},
            },
        ])
    opts.append({
        'id': 'two_way_anova_stars',
        'label': (
            f'⭐ Two-Way ANOVA ({group_col} × {x_col}) + Stars'
            if allow_per_stratum
            else f'⭐ Additive Two-Way ANOVA ({group_col} + {x_col})'
        ),
        'summary': (
            f'Test {group_col}, {x_col}, and {group_col} × {x_col} interaction plus per-stratum simple effects.'
            if allow_per_stratum
            else f'Unreplicated two-factor / randomized-block main-effects ANOVA across {group_col} and {x_col}.'
        ),
        'plan': {**base_plan, 'method': 'two_way_anova'},
        'style': {'p_display': 'stars_and_p', 'error_bar': 'sem' if allow_per_stratum else 'sd'},
    })
    return opts


def _single_factor_stat_options(
    y_col: str,
    group_col: str,
    n_groups: int,
    plot_type: str,
    pool_by: str | None = None,
) -> list[dict[str, Any]]:
    param_method = 'ttest' if n_groups == 2 else 'anova'
    nonparam_method = 'mannwhitney' if n_groups == 2 else 'kruskal'
    param_name = 'Welch t-test' if n_groups == 2 else 'One-Way ANOVA'
    nonparam_name = 'Mann–Whitney U' if n_groups == 2 else 'Kruskal–Wallis'
    base_plan: dict[str, Any] = {
        'y': y_col,
        'group': group_col,
        'plot': plot_type,
        'design': 'independent',
    }
    if pool_by:
        base_plan['pool_by'] = pool_by
        base_plan['pool_stat'] = 'mean'
    opts = [
        {
            'id': f'{param_method}_stars',
            'label': f'⭐ {param_name} + Stars' + (f' (Pooled by {pool_by})' if pool_by else ''),
            'summary': f'Parametric comparison of {y_col} across {group_col} with bracket stars & exact p-value.',
            'plan': {**base_plan, 'method': param_method},
            'style': {'p_display': 'stars_and_p', 'error_bar': 'ci'},
        },
        {
            'id': f'{nonparam_method}_stars',
            'label': f'⭐ {nonparam_name} + Stars' + (f' (Pooled by {pool_by})' if pool_by else ''),
            'summary': f'Rank-based comparison of {y_col} across {group_col} with bracket stars & exact p-value.',
            'plan': {
                **base_plan,
                **({'pool_stat': 'median'} if pool_by else {}),
                'method': nonparam_method,
            },
            'style': {'p_display': 'stars_and_p', 'error_bar': 'iqr'},
        },
    ]
    return opts


def build_exploratory_gallery(session: Any) -> dict[str, Any]:
    """Generate Step 1 spreadsheet overview + Step 2 rendered SVG exploratory figure gallery."""
    ds = getattr(session, 'dataset', None)
    overview = build_spreadsheet_overview(ds)
    if ds is None or not hasattr(ds, 'df'):
        return {'overview': overview, 'cards': []}

    base_palette = (getattr(session, 'style', None) or {}).get('palette', 'teal')
    card_base_style = {
        'width_mm': 156,
        'height_mm': 98,
        'font_size': 8.5,
        'palette': base_palette,
        'show_points': True,
        'p_display': 'none',
        'dpi': 300,
    }

    specs: list[dict[str, Any]] = []
    layout = overview.get('detected_layout', 'general_table')
    rep = overview.get('replicate_structure') or {}
    num_cols: list[str] = list(overview.get('numeric_columns') or [])
    cat_cols: list[str] = list(overview.get('categorical_columns') or [])

    if rep.get('detected'):
        ref_grp = rep.get('suggested_ref_group') or list(rep['groups'].keys())[0]
        clean_ref = re.sub(r'[^A-Za-z0-9]+', '_', str(ref_grp)).strip('_') or 'Control'
        norm_col = f'Pct_of_{clean_ref}_Mean'
        shared_ops = [{
            'op': 'reshape_replicates',
            'sheet_name': 'Tidy_Timecourse',
            'value_name': 'Value',
            'formula': 'pct_of_group_mean',
            'ref_group': ref_grp,
            'new_column': norm_col,
        }]
        n_groups = len(rep['groups'])
        if rep.get('is_timecourse'):
            specs.extend([
                {
                    'id': 'timecourse_raw',
                    'badge': 'Timecourse',
                    'title': 'Timecourse Line (Mean ± SD + Replicates)',
                    'subtitle': f"Group trajectories across {rep.get('time_col') or 'Timepoint'} in raw units.",
                    'prep_ops': shared_ops,
                    'plan': {'method': 'describe', 'x': 'Timepoint', 'y': 'Value', 'group': 'Group', 'plot': 'timecourse'},
                    'style': {'error_bar': 'sd', 'title': 'Raw Timecourse by Group'},
                    'recommended_analyses': _two_factor_stat_options('Timepoint', 'Value', 'Group', 'timecourse', 'Subject_ID'),
                },
                {
                    'id': 'timecourse_pct_ctrl',
                    'badge': 'Normalized %',
                    'title': f'Normalized Timecourse (% of {ref_grp} Mean)',
                    'subtitle': f"Values scaled to 100% of overall {ref_grp} mean across timepoints.",
                    'prep_ops': shared_ops,
                    'plan': {'method': 'describe', 'x': 'Timepoint', 'y': norm_col, 'group': 'Group', 'plot': 'timecourse'},
                    'style': {'error_bar': 'sd', 'title': f'% of {ref_grp} Mean over Time'},
                    'recommended_analyses': _two_factor_stat_options('Timepoint', norm_col, 'Group', 'timecourse', 'Subject_ID'),
                },
                {
                    'id': 'spaghetti_trajectories',
                    'badge': 'Longitudinal',
                    'title': 'Individual Subject Trajectories (Spaghetti)',
                    'subtitle': 'Every replicate column plotted across timepoints with bold group mean overlay.',
                    'prep_ops': shared_ops,
                    'plan': {'method': 'describe', 'x': 'Timepoint', 'y': 'Value', 'group': 'Group', 'subject': 'Subject_ID', 'plot': 'spaghetti'},
                    'style': {'error_bar': 'none', 'title': 'Individual Subject Trajectories'},
                    'recommended_analyses': _two_factor_stat_options('Timepoint', 'Value', 'Group', 'spaghetti', 'Subject_ID'),
                },
                {
                    'id': 'grouped_bar_time',
                    'badge': 'Two-Factor Bars',
                    'title': 'Grouped Bars by Timepoint',
                    'subtitle': f"Side-by-side {' vs '.join(rep['groups'].keys())} bars + individual dots at each timepoint.",
                    'prep_ops': shared_ops,
                    'plan': {'method': 'describe', 'x': 'Timepoint', 'y': 'Value', 'group': 'Group', 'plot': 'grouped_bar'},
                    'style': {'error_bar': 'sd', 'title': 'Group Comparison by Timepoint'},
                    'recommended_analyses': _two_factor_stat_options('Timepoint', 'Value', 'Group', 'grouped_bar', 'Subject_ID'),
                },
                {
                    'id': 'grouped_box_time',
                    'badge': 'Two-Factor Boxes',
                    'title': 'Grouped Box Plots by Timepoint',
                    'subtitle': 'Dodged quartile boxes and individual replicate points at each timepoint.',
                    'prep_ops': shared_ops,
                    'plan': {'method': 'describe', 'x': 'Timepoint', 'y': norm_col, 'group': 'Group', 'plot': 'grouped_box'},
                    'style': {'error_bar': 'iqr', 'title': f'Normalized % of {ref_grp} Boxes by Timepoint'},
                    'recommended_analyses': _two_factor_stat_options('Timepoint', norm_col, 'Group', 'grouped_box', 'Subject_ID'),
                },
                {
                    'id': 'superplot_subject_pooled',
                    'badge': 'Subject-Pooled N',
                    'title': 'Subject-Pooled Superplot (N per Replicate)',
                    'subtitle': 'Timepoints nested within each subject (translucent n) and subject means (bold N).',
                    'prep_ops': shared_ops,
                    'plan': {
                        'method': 'describe',
                        'y': norm_col,
                        'group': 'Group',
                        'pool_by': 'Subject_ID',
                        'pool_stat': 'mean',
                        'plot': 'superplot',
                    },
                    'style': {'error_bar': 'sd', 'title': f'Subject-Pooled % of {ref_grp} Mean'},
                    'recommended_analyses': _single_factor_stat_options(norm_col, 'Group', n_groups, 'superplot', pool_by='Subject_ID'),
                },
            ])
        else:
            # Single-row wide replicates
            specs.extend([
                {
                    'id': 'rep_dots',
                    'badge': 'Raw Dots',
                    'title': 'Replicate Dots + Mean ± SD',
                    'subtitle': f"Compare {' vs '.join(rep['groups'].keys())} in original units.",
                    'prep_ops': shared_ops,
                    'plan': {'method': 'describe', 'y': 'Value', 'group': 'Group', 'plot': 'distribution'},
                    'style': {'error_bar': 'sd'},
                    'recommended_analyses': _single_factor_stat_options('Value', 'Group', n_groups, 'distribution'),
                },
                {
                    'id': 'rep_pct_ctrl',
                    'badge': 'Normalized %',
                    'title': f'Normalized (% of {ref_grp} Mean) Bars + Dots',
                    'subtitle': f"Scaled so {ref_grp} mean = 100%.",
                    'prep_ops': shared_ops,
                    'plan': {'method': 'describe', 'y': norm_col, 'group': 'Group', 'plot': 'bar'},
                    'style': {'error_bar': 'sd'},
                    'recommended_analyses': _single_factor_stat_options(norm_col, 'Group', n_groups, 'bar'),
                },
                {
                    'id': 'rep_box',
                    'badge': 'Quartiles',
                    'title': 'Box Plot + Replicate Dots',
                    'subtitle': 'Median, interquartile range, and all individual replicates.',
                    'prep_ops': shared_ops,
                    'plan': {'method': 'describe', 'y': 'Value', 'group': 'Group', 'plot': 'box'},
                    'style': {'error_bar': 'iqr'},
                    'recommended_analyses': _single_factor_stat_options('Value', 'Group', n_groups, 'box'),
                },
            ])

    elif layout == 'survival_time_to_event' and (overview.get('survival_structure') or {}).get('detected'):
        surv = overview['survival_structure']
        t_col = surv['time_col']
        e_col = surv['event_col']
        g_cols = list(surv.get('group_cols') or [])
        for gc in g_cols[:4]:
            n_g_lv = int(ds.df[gc].dropna().nunique())
            hr_note = ' + Cox HR' if n_g_lv == 2 else ''
            specs.append({
                'id': f'survival_km_{gc}',
                'badge': 'Kaplan–Meier',
                'title': f'Kaplan–Meier Survival by {gc}',
                'subtitle': f"Right-censored step survival of '{t_col}' (event: '{e_col}') with '+' censoring ticks across {gc}.",
                'prep_ops': [],
                'plan': {'method': 'describe', 'x': t_col, 'y': e_col, 'group': gc, 'plot': 'survival'},
                'style': {'error_bar': 'ci', 'show_points': True, 'title': f'Kaplan–Meier Survival by {gc}'},
                'recommended_analyses': [
                    {
                        'id': f'surv_logrank_stars_{gc}',
                        'label': f'⭐ Mantel–Cox Log-Rank{hr_note} + 95% CI + Stars',
                        'summary': f'Compare right-censored survival across {gc} with Greenwood log(-log) 95% bands and log-rank test{hr_note}.',
                        'plan': {'method': 'survival', 'x': t_col, 'y': e_col, 'group': gc, 'design': 'independent', 'plot': 'survival'},
                        'style': {'p_display': 'stars_and_p', 'error_bar': 'ci', 'ci': True, 'show_points': True},
                    },
                    {
                        'id': f'surv_logrank_exact_{gc}',
                        'label': f'Mantel–Cox Log-Rank Exact p{hr_note}',
                        'summary': f'Show exact log-rank p-value{hr_note} and Brookmeyer–Crowley median survival intervals.',
                        'plan': {'method': 'survival', 'x': t_col, 'y': e_col, 'group': gc, 'design': 'independent', 'plot': 'survival'},
                        'style': {'p_display': 'exact', 'error_bar': 'ci', 'ci': True, 'show_points': True},
                    },
                ],
            })
        specs.append({
            'id': 'survival_km_overall',
            'badge': 'Cohort KM',
            'title': f'Overall Cohort Kaplan–Meier ({t_col})',
            'subtitle': f"Single-cohort product-limit survival curve ({surv.get('events', 0)} events, {surv.get('censored', 0)} censored).",
            'prep_ops': [],
            'plan': {'method': 'describe', 'x': t_col, 'y': e_col, 'plot': 'survival'},
            'style': {'error_bar': 'ci', 'show_points': True, 'title': f'Overall Cohort Survival ({t_col})'},
            'recommended_analyses': [
                {
                    'id': 'surv_cohort_ci',
                    'label': '⭐ Kaplan–Meier + Greenwood 95% CI + Median CI',
                    'summary': 'Estimate cohort survival probabilities, Brookmeyer–Crowley median survival 95% CI, and RMST.',
                    'plan': {'method': 'survival', 'x': t_col, 'y': e_col, 'design': 'independent', 'plot': 'survival'},
                    'style': {'p_display': 'none', 'error_bar': 'ci', 'ci': True, 'show_points': True},
                },
            ],
        })
        if g_cols and int(ds.df[e_col].dropna().nunique()) >= 2:
            gc0 = g_cols[0]
            specs.append({
                'id': f'survival_event_counts_{gc0}',
                'badge': 'Event Counts',
                'title': f'Event vs Right-Censoring Breakdown by {gc0}',
                'subtitle': f"Observed event and right-censored counts across {gc0} strata.",
                'prep_ops': [],
                'plan': {'method': 'describe', 'x': gc0, 'y': e_col, 'plot': 'heatmap'},
                'style': {'title': f'{e_col} Counts by {gc0}'},
                'recommended_analyses': [
                    {
                        'id': f'surv_event_chi2_{gc0}',
                        'label': 'Pearson Chi-Square Contingency Test',
                        'summary': f'Compare unadjusted event vs censoring proportions across {gc0} (ignoring follow-up duration).',
                        'plan': {'method': 'chi2', 'x': gc0, 'y': e_col, 'design': 'independent', 'plot': 'heatmap'},
                        'style': {'p_display': 'exact'},
                    },
                ],
            })
        if len(specs) < 4:
            specs.append({
                'id': 'survival_followup_hist',
                'badge': 'Follow-Up',
                'title': f'Observed Follow-Up Duration Histogram ({t_col})',
                'subtitle': f"Distribution of observed event and censoring follow-up times in '{t_col}'.",
                'prep_ops': [],
                'plan': {'method': 'describe', 'y': t_col, 'plot': 'histogram'},
                'style': {'title': f'Observed Follow-Up Times ({t_col})'},
                'recommended_analyses': [],
            })

    elif layout in {'contingency_counts', 'contingency_raw'} and (overview.get('contingency_structure') or {}).get('detected'):
        ct_info = overview['contingency_structure']
        cx = ct_info['x_col']
        cy = ct_info['y_col']
        cnt_col = ct_info.get('count_col')
        chi2_plan: dict[str, Any] = {'method': 'chi2', 'x': cx, 'y': cy, 'design': 'independent', 'plot': 'heatmap'}
        if cnt_col:
            chi2_plan['count'] = cnt_col
        chi2_recs = [
            {
                'id': 'chi2_exact_p',
                'label': f"⭐ Pearson χ² Independence Test{' (Weighted by ' + cnt_col + ')' if cnt_col else ''} + Cramér's V",
                'summary': f"Test categorical independence between {cx} and {cy}{' weighted by cell counts in ' + cnt_col if cnt_col else ''}.",
                'plan': dict(chi2_plan),
                'style': {'p_display': 'stars_and_p'},
            },
        ]
        specs.append({
            'id': 'contingency_heatmap',
            'badge': 'Contingency Matrix',
            'title': f'Observed Contingency Counts ({cx} × {cy})',
            'subtitle': f"Cell frequency matrix{' weighted by ' + cnt_col if cnt_col else ''} (total N = {ct_info.get('total_n', len(ds.df))}).",
            'prep_ops': [],
            'plan': dict(chi2_plan),
            'style': {'p_display': 'none', 'title': f'{cx} × {cy} Contingency Counts'},
            'recommended_analyses': chi2_recs,
        })
        if cnt_col:
            specs.append({
                'id': 'contingency_grouped_bars',
                'badge': 'Grouped Counts',
                'title': f'{cnt_col} by {cx} and {cy} (Grouped Bars)',
                'subtitle': f'Side-by-side cell count comparison of {cy} within each {cx} stratum.',
                'prep_ops': [],
                'plan': {'method': 'describe', 'x': cx, 'group': cy, 'y': cnt_col, 'plot': 'grouped_bar'},
                'style': {'error_bar': 'none', 'y_zero': True},
                'recommended_analyses': chi2_recs,
            })
            specs.append({
                'id': 'contingency_swapped_heatmap',
                'badge': 'Transposed View',
                'title': f'Transposed Contingency Matrix ({cy} × {cx})',
                'subtitle': f'Transposed cell counts with {cy} rows and {cx} columns.',
                'prep_ops': [],
                'plan': {'method': 'chi2', 'x': cy, 'y': cx, 'count': cnt_col, 'design': 'independent', 'plot': 'heatmap'},
                'style': {'p_display': 'none', 'title': f'{cy} × {cx} Contingency Counts'},
                'recommended_analyses': [{
                    'id': 'chi2_transposed_p',
                    'label': f"⭐ Pearson χ² Test ({cy} × {cx})",
                    'summary': f'Test categorical association between {cy} and {cx} weighted by {cnt_col}.',
                    'plan': {'method': 'chi2', 'x': cy, 'y': cx, 'count': cnt_col, 'design': 'independent', 'plot': 'heatmap'},
                    'style': {'p_display': 'stars_and_p'},
                }],
            })
        else:
            count_ops = [{
                'op': 'aggregate_units',
                'sheet_name': 'Cell_Counts',
                'group_cols': [cx, cy],
                'agg_stat': 'count',
                'new_column': 'Count',
            }]
            specs.append({
                'id': 'contingency_grouped_bars',
                'badge': 'Grouped Counts',
                'title': f'Observed Counts by {cx} and {cy} (Grouped Bars)',
                'subtitle': f'Tabulates row-level {cx} × {cy} frequencies into Cell_Counts and plots dodged bars.',
                'prep_ops': count_ops,
                'plan': {'method': 'describe', 'x': cx, 'group': cy, 'y': 'Count', 'plot': 'grouped_bar'},
                'style': {'error_bar': 'none', 'y_zero': True},
                'recommended_analyses': [{
                    'id': 'chi2_counted_p',
                    'label': f"⭐ Pearson χ² Independence Test ({cx} × {cy}) + Cramér's V",
                    'summary': f'Test categorical independence between {cx} and {cy} on tabulated Cell_Counts.',
                    'plan': {'method': 'chi2', 'x': cx, 'y': cy, 'count': 'Count', 'design': 'independent', 'plot': 'heatmap'},
                    'style': {'p_display': 'stars_and_p'},
                }],
            })
            specs.append({
                'id': 'contingency_swapped_heatmap',
                'badge': 'Transposed View',
                'title': f'Transposed Contingency Matrix ({cy} × {cx})',
                'subtitle': f'Transposed cell counts with {cy} rows and {cx} columns.',
                'prep_ops': [],
                'plan': {'method': 'chi2', 'x': cy, 'y': cx, 'design': 'independent', 'plot': 'heatmap'},
                'style': {'p_display': 'none', 'title': f'{cy} × {cx} Contingency Counts'},
                'recommended_analyses': [{
                    'id': 'chi2_transposed_p',
                    'label': f"⭐ Pearson χ² Test ({cy} × {cx})",
                    'summary': f'Test categorical association between {cy} and {cx}.',
                    'plan': {'method': 'chi2', 'x': cy, 'y': cx, 'design': 'independent', 'plot': 'heatmap'},
                    'style': {'p_display': 'stars_and_p'},
                }],
            })

    elif layout == 'long_two_factor' and len(overview.get('factor_columns') or cat_cols) >= 2 and num_cols:
        fac_cols = list(overview.get('factor_columns') or cat_cols)
        c0, c1 = fac_cols[0], fac_cols[1]
        n0 = int(ds.df[c0].dropna().nunique())
        n1 = int(ds.df[c1].dropna().nunique())
        c0_time = bool(_TIME_OR_DOSE_FACTOR_RE.match(c0))
        c1_time = bool(_TIME_OR_DOSE_FACTOR_RE.match(c1))
        grp_tokens = ('group', 'geno', 'treat', 'cond', 'drug', 'strain', 'supp', 'diet', 'sex', 'wool', 'type', 'state')
        c0_grp = any(k in c0.casefold() for k in grp_tokens)
        c1_grp = any(k in c1.casefold() for k in grp_tokens)
        if c0_time and not c1_time:
            x_col, group_col = c0, c1
        elif c1_time and not c0_time:
            x_col, group_col = c1, c0
        elif c0_grp and not c1_grp:
            group_col, x_col = c0, c1
        elif c1_grp and not c0_grp:
            x_col, group_col = c0, c1
        elif n0 <= n1 and n0 <= 4 and n1 > 2:
            group_col, x_col = c0, c1
        else:
            x_col, group_col = c0, c1

        y_primary = num_cols[-1] if len(num_cols) > 1 and 'pct' in num_cols[-1].casefold() else num_cols[0]
        unit_candidates = [u for u in (overview.get('unit_columns') or []) if u not in {x_col, group_col, *num_cols}]
        subj_col = unit_candidates[0] if unit_candidates else _detect_cluster_col(ds.df, {x_col, group_col, *num_cols})
        subj_mode = _classify_subject_col(ds.df, subj_col, group_col)
        n_groups = max(2, int(ds.df[group_col].dropna().nunique()))
        n_x_levels = int(ds.df[x_col].dropna().nunique())

        # If a subject column has technical subreplicates within a single (subject, x_col) cell, pool per cell first
        ltf_prep_ops: list[dict[str, Any]] = []
        if subj_col and subj_col in ds.df.columns:
            sub_dup = ds.df[[subj_col, x_col]].dropna().astype(str).duplicated().any()
            if sub_dup:
                ltf_prep_ops = [{
                    'op': 'aggregate_units',
                    'sheet_name': 'Pooled_Timepoints',
                    'group_cols': [subj_col, group_col, x_col],
                    'value_cols': [y_primary],
                    'agg_stat': 'mean',
                }]
        check_df = _shadow_dataset_from_ops(ds, ltf_prep_ops).df if ltf_prep_ops else ds.df
        allow_stratum = _can_run_timecourse_compare(check_df, x_col, group_col, y_primary)

        specs.append({
            'id': 'ltf_timecourse',
            'badge': 'Timecourse / Factor',
            'title': f'Interaction / Timecourse Line ({y_primary} across {x_col})',
            'subtitle': f'Mean ± SD trajectories for each {group_col} across {x_col}.',
            'prep_ops': ltf_prep_ops,
            'plan': {'method': 'describe', 'x': x_col, 'y': y_primary, 'group': group_col, 'plot': 'timecourse'},
            'style': {'error_bar': 'sd'},
            'recommended_analyses': _two_factor_stat_options(x_col, y_primary, group_col, 'timecourse', subj_col, allow_per_stratum=allow_stratum),
        })
        if n_x_levels <= 16 and n_groups <= 8:
            specs.extend([
                {
                    'id': 'ltf_grouped_bar',
                    'badge': 'Two-Factor Bars',
                    'title': f'Grouped Bars ({group_col} at each {x_col})',
                    'subtitle': 'Dodged group mean bars + individual observations per stratum.',
                    'prep_ops': ltf_prep_ops,
                    'plan': {'method': 'describe', 'x': x_col, 'y': y_primary, 'group': group_col, 'plot': 'grouped_bar'},
                    'style': {'error_bar': 'sd'},
                    'recommended_analyses': _two_factor_stat_options(x_col, y_primary, group_col, 'grouped_bar', subj_col, allow_per_stratum=allow_stratum),
                },
                {
                    'id': 'ltf_grouped_box',
                    'badge': 'Two-Factor Boxes',
                    'title': f'Grouped Boxes ({group_col} at each {x_col})',
                    'subtitle': 'Dodged quartile boxes and individual points per stratum.',
                    'prep_ops': ltf_prep_ops,
                    'plan': {'method': 'describe', 'x': x_col, 'y': y_primary, 'group': group_col, 'plot': 'grouped_box'},
                    'style': {'error_bar': 'iqr'},
                    'recommended_analyses': _two_factor_stat_options(x_col, y_primary, group_col, 'grouped_box', subj_col, allow_per_stratum=allow_stratum),
                },
            ])
        if subj_col:
            specs.append({
                'id': 'ltf_spaghetti',
                'badge': 'Longitudinal',
                'title': f'Individual {subj_col} Trajectories (Spaghetti)',
                'subtitle': f'Connected lines per {subj_col} overlaid with bold {group_col} means.',
                'prep_ops': ltf_prep_ops,
                'plan': {'method': 'describe', 'x': x_col, 'y': y_primary, 'group': group_col, 'subject': subj_col, 'plot': 'spaghetti'},
                'style': {'error_bar': 'none'},
                'recommended_analyses': _two_factor_stat_options(x_col, y_primary, group_col, 'spaghetti', subj_col, allow_per_stratum=allow_stratum),
            })
            if subj_mode == 'nested':
                specs.append({
                    'id': 'ltf_superplot',
                    'badge': 'Subject-Pooled N',
                    'title': f'Superplot Pooled by {subj_col}',
                    'subtitle': f'Nested observations (n) and {subj_col}-level means (N).',
                    'prep_ops': [],
                    'plan': {'method': 'describe', 'y': y_primary, 'group': group_col, 'pool_by': subj_col, 'pool_stat': 'mean', 'plot': 'superplot'},
                    'style': {'error_bar': 'sd'},
                    'recommended_analyses': _single_factor_stat_options(y_primary, group_col, n_groups, 'superplot', pool_by=subj_col),
                })
        else:
            specs.append({
                'id': 'ltf_pooled_box',
                'badge': 'Overall Group',
                'title': f'Overall {group_col} Distribution (Pooled Strata)',
                'subtitle': f'All observations grouped by {group_col} across {x_col}.',
                'prep_ops': [],
                'plan': {'method': 'describe', 'y': y_primary, 'group': group_col, 'plot': 'box'},
                'style': {'error_bar': 'iqr'},
                'recommended_analyses': _single_factor_stat_options(y_primary, group_col, n_groups, 'box'),
            })
            specs.append({
                'id': 'ltf_pooled_violin',
                'badge': 'Group Density',
                'title': f'Overall {group_col} Violin Density (Pooled Strata)',
                'subtitle': f'Kernel density + individual points grouped by {group_col} across {x_col}.',
                'prep_ops': [],
                'plan': {'method': 'describe', 'y': y_primary, 'group': group_col, 'plot': 'violin'},
                'style': {'error_bar': 'iqr'},
                'recommended_analyses': _single_factor_stat_options(y_primary, group_col, n_groups, 'violin'),
            })
        if len(num_cols) == 2:
            c_a, c_b = num_cols[0], num_cols[1]
            specs.append({
                'id': 'ltf_paired_cols',
                'badge': 'Row-Paired',
                'title': f'Paired Outcome Columns ({c_a} → {c_b})',
                'subtitle': f'Matched row pairs comparing {c_a} and {c_b}.',
                'prep_ops': [],
                'plan': {'method': 'describe', 'columns': [c_a, c_b], 'plot': 'paired', 'design': 'paired'},
                'style': {'error_bar': 'none'},
                'recommended_analyses': [{
                    'id': 'paired_t_stars',
                    'label': f'⭐ Paired t-test ({c_a} vs {c_b}) + Stars',
                    'summary': f'Parametric paired comparison of row-matched differences ({c_a} − {c_b}).',
                    'plan': {'method': 'paired_t', 'columns': [c_a, c_b], 'plot': 'paired', 'design': 'paired'},
                    'style': {'p_display': 'stars_and_p'},
                }],
            })

    elif layout == 'long_single_timecourse' and (overview.get('factor_columns') or cat_cols) and num_cols:
        fac_cols = list(overview.get('factor_columns') or cat_cols)
        x_col = fac_cols[0]
        y_col = num_cols[0]
        unit_candidates = [u for u in (overview.get('unit_columns') or []) if u not in {x_col, *num_cols}]
        subj_col = unit_candidates[0] if unit_candidates else _detect_cluster_col(ds.df, {x_col, *num_cols})
        specs.append({
            'id': 'lst_timecourse',
            'badge': 'Curve / Timecourse',
            'title': f'Trajectory Curve ({y_col} across {x_col})',
            'subtitle': f'Mean ± SD curve with individual {subj_col or "replicate"} measurements at each {x_col}.',
            'prep_ops': [],
            'plan': {'method': 'describe', 'x': x_col, 'y': y_col, 'plot': 'timecourse'},
            'style': {'error_bar': 'sd'},
            'recommended_analyses': [],
        })
        if subj_col:
            specs.append({
                'id': 'lst_spaghetti',
                'badge': 'Longitudinal',
                'title': f'Individual {subj_col} Curves (Spaghetti)',
                'subtitle': f'Connected {subj_col} trajectories across {x_col} overlaid with bold cohort mean.',
                'prep_ops': [],
                'plan': {'method': 'describe', 'x': x_col, 'y': y_col, 'subject': subj_col, 'plot': 'spaghetti'},
                'style': {'error_bar': 'none'},
                'recommended_analyses': [],
            })
        if int(ds.df[x_col].dropna().nunique()) <= 16:
            specs.append({
                'id': 'lst_box',
                'badge': 'By Stratum',
                'title': f'{y_col} Quartiles at Each {x_col}',
                'subtitle': f'Box plots and individual points across {x_col} levels.',
                'prep_ops': [],
                'plan': {'method': 'describe', 'y': y_col, 'group': x_col, 'plot': 'box'},
                'style': {'error_bar': 'iqr'},
                'recommended_analyses': [],
            })
        x_num_series = pd.to_numeric(ds.df[x_col], errors='coerce').dropna()
        if int(x_num_series.nunique()) >= 3:
            stratum_ops = [{
                'op': 'aggregate_units',
                'sheet_name': 'Stratum_Means',
                'group_cols': [x_col],
                'value_cols': [y_col],
                'agg_stat': 'mean',
            }]
            specs.append({
                'id': 'lst_stratum_trend',
                'badge': 'Trend / Association',
                'title': f'Stratum-Mean Trend ({y_col} vs {x_col})',
                'subtitle': f'Mean {y_col} at each {x_col} level for linear / monotonic trend testing.',
                'prep_ops': stratum_ops,
                'plan': {'method': 'describe', 'x': x_col, 'y': y_col, 'plot': 'scatter'},
                'style': {'error_bar': 'none'},
                'recommended_analyses': [
                    {
                        'id': 'ols_reg',
                        'label': f'⭐ Linear Trend Regression ({y_col} ~ {x_col})',
                        'summary': f'OLS linear slope and R² across {x_col} stratum means.',
                        'plan': {'method': 'regression', 'x': x_col, 'y': y_col, 'plot': 'scatter', 'design': 'independent'},
                        'style': {'ci': True, 'error_bar': 'ci'},
                    },
                    {
                        'id': 'spearman_corr',
                        'label': f'⭐ Spearman Monotonic Trend ({x_col}, {y_col})',
                        'summary': f'Rank monotonic association across {x_col} stratum means.',
                        'plan': {'method': 'spearman', 'x': x_col, 'y': y_col, 'plot': 'scatter', 'design': 'independent'},
                        'style': {'error_bar': 'none'},
                    },
                ],
            })

    elif layout == 'long_grouped' and (overview.get('factor_columns') or cat_cols) and num_cols:
        fac_cols = list(overview.get('factor_columns') or cat_cols)
        clean_facs = [c for c in fac_cols if 2 <= int(ds.df[c].dropna().nunique()) <= 16] or fac_cols
        group_col = clean_facs[0]
        for cc in clean_facs:
            if any(k in cc.casefold() for k in (
                'group', 'geno', 'treat', 'cond', 'drug', 'strain', 'supp', 'diet', 'spray', 'species',
                'format', 'class', 'cohort', 'arm', 'regimen', 'therapy', 'stimulus', 'variant', 'subunit', 'form',
            )):
                group_col = cc
                break
        y_col = num_cols[0]
        n_groups = max(2, int(ds.df[group_col].dropna().nunique()))
        unit_candidates = [u for u in (overview.get('unit_columns') or []) if u not in {group_col, *num_cols}]
        raw_cluster_col = unit_candidates[0] if unit_candidates else _detect_cluster_col(ds.df, {group_col, *num_cols})
        subj_mode = _classify_subject_col(ds.df, raw_cluster_col, group_col)
        nested_pool_col = raw_cluster_col if subj_mode == 'nested' else None

        if subj_mode == 'paired' and raw_cluster_col and n_groups == 2:
            paired_opt = {
                'id': 'paired_t_stars',
                'label': f'⭐ Paired t-test (Matched by {raw_cluster_col}) + Stars',
                'summary': f'Within-subject paired comparison of {y_col} across {group_col} matched by {raw_cluster_col}.',
                'plan': {'method': 'paired_t', 'subject': raw_cluster_col, 'group': group_col, 'y': y_col, 'plot': 'paired', 'design': 'paired'},
                'style': {'p_display': 'stars_and_p'},
            }
            specs.append({
                'id': 'lg_paired_subject',
                'badge': 'Within-Subject Paired',
                'title': f'Paired Trajectories by {raw_cluster_col} ({y_col} across {group_col})',
                'subtitle': f'Lines connect matched {raw_cluster_col} observations across the 2 {group_col} conditions.',
                'prep_ops': [],
                'plan': {'method': 'describe', 'subject': raw_cluster_col, 'group': group_col, 'y': y_col, 'plot': 'paired', 'design': 'paired'},
                'style': {'error_bar': 'none'},
                'recommended_analyses': [paired_opt],
            })

        if nested_pool_col:
            specs.append({
                'id': 'lg_superplot',
                'badge': 'Superplot (N)',
                'title': f'Superplot Stratified by {nested_pool_col}',
                'subtitle': f'Individual technical measurements (n) + {nested_pool_col} biological means (N).',
                'prep_ops': [],
                'plan': {'method': 'describe', 'y': y_col, 'group': group_col, 'pool_by': nested_pool_col, 'pool_stat': 'mean', 'plot': 'superplot'},
                'style': {'error_bar': 'sd'},
                'recommended_analyses': _single_factor_stat_options(y_col, group_col, n_groups, 'superplot', pool_by=nested_pool_col),
            })

        def _lg_stat_opts(ptype: str) -> list[dict[str, Any]]:
            if subj_mode == 'paired' and raw_cluster_col and n_groups == 2:
                return [{
                    'id': 'paired_t_stars',
                    'label': f'⭐ Paired t-test (Matched by {raw_cluster_col}) + Stars',
                    'summary': f'Within-subject paired t-test of {y_col} across {group_col} matched by {raw_cluster_col}.',
                    'plan': {'method': 'paired_t', 'subject': raw_cluster_col, 'group': group_col, 'y': y_col, 'plot': ptype, 'design': 'paired'},
                    'style': {'p_display': 'stars_and_p'},
                }]
            return _single_factor_stat_options(y_col, group_col, n_groups, ptype, pool_by=nested_pool_col)

        specs.extend([
            {
                'id': 'lg_dots',
                'badge': 'Dots + Mean',
                'title': f'{y_col} by {group_col} (Dots + Mean ± SD)',
                'subtitle': 'Every observation plotted directly with group mean and SD.',
                'prep_ops': [],
                'plan': {'method': 'describe', 'y': y_col, 'group': group_col, 'plot': 'distribution'},
                'style': {'error_bar': 'sd'},
                'recommended_analyses': _lg_stat_opts('distribution'),
            },
            {
                'id': 'lg_box',
                'badge': 'Box + Dots',
                'title': f'{y_col} by {group_col} (Box + Quartiles)',
                'subtitle': 'Median, interquartile box, 1.5×IQR whiskers, and individual observations.',
                'prep_ops': [],
                'plan': {'method': 'describe', 'y': y_col, 'group': group_col, 'plot': 'box'},
                'style': {'error_bar': 'iqr'},
                'recommended_analyses': _lg_stat_opts('box'),
            },
            {
                'id': 'lg_violin',
                'badge': 'Violin + Dots',
                'title': f'{y_col} by {group_col} (Violin Density)',
                'subtitle': 'Kernel density shape with median mark and individual points.',
                'prep_ops': [],
                'plan': {'method': 'describe', 'y': y_col, 'group': group_col, 'plot': 'violin'},
                'style': {'error_bar': 'iqr'},
                'recommended_analyses': _lg_stat_opts('violin'),
            },
            {
                'id': 'lg_raincloud',
                'badge': 'Raincloud',
                'title': f'{y_col} by {group_col} (Half-Violin + Box + Dots)',
                'subtitle': 'Half-violin density, slim quartile box, and jittered raw observations.',
                'prep_ops': [],
                'plan': {'method': 'describe', 'y': y_col, 'group': group_col, 'plot': 'raincloud'},
                'style': {'error_bar': 'iqr'},
                'recommended_analyses': _lg_stat_opts('raincloud'),
            },
            {
                'id': 'lg_bar',
                'badge': 'Bar + Dots',
                'title': f'{y_col} by {group_col} (Bars + Individual Dots)',
                'subtitle': 'Publication bar chart overlaid with transparent raw data points.',
                'prep_ops': [],
                'plan': {'method': 'describe', 'y': y_col, 'group': group_col, 'plot': 'bar'},
                'style': {'error_bar': 'sd'},
                'recommended_analyses': _lg_stat_opts('bar'),
            },
        ])
        if len(num_cols) == 2:
            c_a, c_b = num_cols[0], num_cols[1]
            specs.append({
                'id': 'lg_paired_cols',
                'badge': 'Row-Paired',
                'title': f'Paired Before/After ({c_a} → {c_b})',
                'subtitle': f'Row-matched trajectories across {c_a} and {c_b}.',
                'prep_ops': [],
                'plan': {'method': 'describe', 'columns': [c_a, c_b], 'plot': 'paired', 'design': 'paired'},
                'style': {'error_bar': 'none'},
                'recommended_analyses': [{
                    'id': 'paired_t_stars',
                    'label': f'⭐ Paired t-test ({c_a} vs {c_b}) + Stars',
                    'summary': f'Parametric paired comparison of row-matched differences ({c_a} − {c_b}).',
                    'plan': {'method': 'paired_t', 'columns': [c_a, c_b], 'plot': 'paired', 'design': 'paired'},
                    'style': {'p_display': 'stars_and_p'},
                }],
            })
        if len(num_cols) >= 2 and (nested_pool_col or subj_mode == 'none' or subj_mode == 'one_per_subject'):
            batch_cols = num_cols[:6]
            keep_cols = [group_col, *([nested_pool_col] if nested_pool_col else []), *batch_cols]
            batch_base_plan: dict[str, Any] = {
                'method': 'batch_compare',
                'group': group_col,
                'columns': batch_cols,
                'plot': 'box',
                'design': 'independent',
            }
            if nested_pool_col:
                batch_base_plan['pool_by'] = nested_pool_col
            specs.append({
                'id': 'lg_batch',
                'badge': 'Multi-Endpoint',
                'title': f'Multi-Endpoint Panel ({len(batch_cols)} Outcomes)',
                'subtitle': f"Compare {', '.join(batch_cols[:4])} side by side across {group_col}.",
                'prep_ops': [{
                    'op': 'rename_or_select',
                    'sheet_name': 'Selected_Endpoints',
                    'value_cols': keep_cols,
                }] if len(num_cols) > 6 else [],
                'plan': batch_base_plan,
                'style': {'p_display': 'none', 'error_bar': 'iqr', 'width_mm': 170, 'height_mm': 110},
                'recommended_analyses': [
                    {
                        'id': 'batch_holm_stars',
                        'label': '⭐ Batch Compare All Endpoints + Holm Stars',
                        'summary': f'Test all {len(batch_cols)} endpoints across {group_col} with Holm–Bonferroni multiplicity adjustment.',
                        'plan': dict(batch_base_plan),
                        'style': {'p_display': 'stars_and_p', 'error_bar': 'iqr'},
                    },
                ],
            })

    elif num_cols:
        # Wide numeric or single numeric column
        cols6 = num_cols[:6]
        melt_ops = [{
            'op': 'melt_wide_to_long',
            'sheet_name': 'Tidy_Long',
            'value_cols': cols6,
            'var_name': 'Group',
            'value_name': 'Value',
        }] if len(cols6) >= 2 else []

        if len(cols6) >= 2:
            specs.extend([
                {
                    'id': 'wn_dots',
                    'badge': 'Columns → Groups',
                    'title': 'Side-by-Side Column Distributions (Dots + Mean ± SD)',
                    'subtitle': f"Compare {', '.join(cols6[:4])} on a shared outcome axis.",
                    'prep_ops': melt_ops,
                    'plan': {'method': 'describe', 'y': 'Value', 'group': 'Group', 'plot': 'distribution'},
                    'style': {'error_bar': 'sd'},
                    'recommended_analyses': _single_factor_stat_options('Value', 'Group', len(cols6), 'distribution'),
                },
                {
                    'id': 'wn_box',
                    'badge': 'Box + Dots',
                    'title': 'Side-by-Side Column Box Plots',
                    'subtitle': 'Quartiles, whiskers, and all individual values across columns.',
                    'prep_ops': melt_ops,
                    'plan': {'method': 'describe', 'y': 'Value', 'group': 'Group', 'plot': 'box'},
                    'style': {'error_bar': 'iqr'},
                    'recommended_analyses': _single_factor_stat_options('Value', 'Group', len(cols6), 'box'),
                },
            ])
            if len(cols6) == 2:
                c_a, c_b = cols6[0], cols6[1]
                specs.append({
                    'id': 'wn_paired',
                    'badge': 'Row-Paired',
                    'title': f'Paired Before/After Lines ({c_a} → {c_b})',
                    'subtitle': 'Connects matched observations sharing the same spreadsheet row.',
                    'prep_ops': [],
                    'plan': {'method': 'describe', 'columns': [c_a, c_b], 'plot': 'paired', 'design': 'paired'},
                    'style': {'error_bar': 'none'},
                    'recommended_analyses': [
                        {
                            'id': 'paired_t_stars',
                            'label': f'⭐ Paired t-test ({c_a} vs {c_b}) + Stars',
                            'summary': 'Parametric paired comparison of row-matched differences.',
                            'plan': {'method': 'paired_t', 'columns': [c_a, c_b], 'plot': 'paired', 'design': 'paired'},
                            'style': {'p_display': 'stars_and_p'},
                        },
                    ],
                })
            c_x, c_y = cols6[0], cols6[1]
            wn_unit_col = (overview.get('unit_columns') or [None])[0]
            scatter_prep_ops: list[dict[str, Any]] = []
            if wn_unit_col and wn_unit_col in ds.df.columns and int(ds.df[wn_unit_col].dropna().nunique()) >= 3:
                scatter_prep_ops = [{
                    'op': 'aggregate_units',
                    'sheet_name': f'{wn_unit_col}_Means',
                    'group_cols': [wn_unit_col],
                    'value_cols': cols6,
                    'agg_stat': 'mean',
                }]
            specs.append({
                'id': 'wn_scatter',
                'badge': 'Unit-Pooled Assoc.' if scatter_prep_ops else 'Association',
                'title': f'Scatter Plot ({c_y} vs {c_x})' + (f' [{wn_unit_col} Means]' if scatter_prep_ops else ''),
                'subtitle': (
                    f'Bivariate relationship across {wn_unit_col} means ({c_x} vs {c_y}).'
                    if scatter_prep_ops
                    else f'Inspect bivariate relationship between {c_x} and {c_y}.'
                ),
                'prep_ops': scatter_prep_ops,
                'plan': {'method': 'describe', 'x': c_x, 'y': c_y, 'plot': 'scatter'},
                'style': {'error_bar': 'none'},
                'recommended_analyses': [
                    {
                        'id': 'ols_reg',
                        'label': f'⭐ Linear Regression ({c_y} ~ {c_x}) + 95% CI',
                        'summary': 'Ordinary least-squares slope, R², and p-value.',
                        'plan': {'method': 'regression', 'x': c_x, 'y': c_y, 'plot': 'scatter', 'design': 'independent'},
                        'style': {'ci': True, 'error_bar': 'ci'},
                    },
                    {
                        'id': 'pearson_corr',
                        'label': f'⭐ Pearson Correlation ({c_x}, {c_y})',
                        'summary': 'Parametric linear correlation coefficient r and p-value.',
                        'plan': {'method': 'pearson', 'x': c_x, 'y': c_y, 'plot': 'scatter', 'design': 'independent'},
                        'style': {'error_bar': 'none'},
                    },
                    {
                        'id': 'spearman_corr',
                        'label': f'⭐ Spearman Rank Correlation ({c_x}, {c_y})',
                        'summary': 'Monotonic rank correlation rho and p-value.',
                        'plan': {'method': 'spearman', 'x': c_x, 'y': c_y, 'plot': 'scatter', 'design': 'independent'},
                        'style': {'error_bar': 'none'},
                    },
                ],
            })
            specs.append({
                'id': 'wn_heatmap',
                'badge': 'Correlations',
                'title': 'Pairwise Correlation Matrix Heatmap',
                'subtitle': 'Pearson correlations across all numeric columns.',
                'prep_ops': [],
                'plan': {'method': 'describe', 'columns': cols6, 'plot': 'heatmap'},
                'style': {'error_bar': 'none'},
                'recommended_analyses': [],
            })
        else:
            c0 = cols6[0]
            specs.extend([
                {
                    'id': 'single_hist',
                    'badge': 'Histogram',
                    'title': f'Distribution Histogram ({c0})',
                    'subtitle': 'Data-derived bin counts in original units.',
                    'prep_ops': [],
                    'plan': {'method': 'describe', 'y': c0, 'plot': 'histogram'},
                    'style': {'error_bar': 'none'},
                    'recommended_analyses': [],
                },
                {
                    'id': 'single_box',
                    'badge': 'Box + Dots',
                    'title': f'Quartiles & Observations ({c0})',
                    'subtitle': 'Median, IQR box, and all finite observations.',
                    'prep_ops': [],
                    'plan': {'method': 'describe', 'y': c0, 'plot': 'box'},
                    'style': {'error_bar': 'iqr'},
                    'recommended_analyses': [],
                },
            ])

    # Cache shadow datasets keyed by canonical prep_ops JSON so gallery builds in minimal time
    shadow_cache: dict[str, Dataset] = {'[]': ds}
    cards: list[dict[str, Any]] = []
    for sp in specs:
        ops = sp.get('prep_ops') or []
        ops_key = json.dumps(ops, sort_keys=True)
        try:
            if ops_key not in shadow_cache:
                shadow_cache[ops_key] = _shadow_dataset_from_ops(ds, ops)
            target_ds = shadow_cache[ops_key]
            c_style = {**card_base_style, **(sp.get('style') or {})}
            c_plan = dict(sp['plan'])
            res = analyze(target_ds, c_plan)
            svg = _render_svg_string(target_ds, res, c_plan, c_style)
            cards.append({
                'id': sp['id'],
                'badge': sp.get('badge', 'Explore'),
                'title': sp['title'],
                'subtitle': sp.get('subtitle', ''),
                'prep_ops': ops,
                'explore_plan': c_plan,
                'explore_style': {k: v for k, v in (sp.get('style') or {}).items() if k not in {'width_mm', 'height_mm'}},
                'recommended_analyses': sp.get('recommended_analyses') or [],
                'svg': svg,
            })
        except Exception:
            # Skip any exploratory view that does not fit this specific table cleanly
            continue

    return {
        'overview': overview,
        'cards': cards,
    }


def _find_reusable_working_sheet(session: Any, prep_ops: list[dict[str, Any]]) -> str | None:
    """Check if an identical prep_ops sequence already produced a working sheet in this project."""
    if not prep_ops:
        return None
    import hashlib
    from .session import canonical
    records = (getattr(session, 'context', None) or {}).get('working_sheets') or []
    target_sig = hashlib.sha256(canonical(prep_ops[-1]).encode('utf-8')).hexdigest()[:16]
    avail = set(getattr(session.dataset, 'sheets', []) or [])
    for rec in reversed(records):
        sname = rec.get('sheet_name') or rec.get('name')
        if sname in avail and rec.get('op_signature') == target_sig:
            return str(sname)
    return None


def apply_exploratory_card(
    session: Any,
    prep_ops: list[dict[str, Any]] | None,
    plan: dict[str, Any] | None,
    style: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Materialize any intermediate working sheets, execute the chosen plan, and update the studio."""
    if session.dataset is None or not hasattr(session.dataset, 'df'):
        raise ValueError('Open a spreadsheet first.')

    ops = list(prep_ops or [])
    created_summaries: list[str] = []
    if ops:
        reusable = _find_reusable_working_sheet(session, ops)
        if reusable and session.dataset.sheet != reusable:
            session.select_sheet(reusable, reply=False)
        elif not reusable:
            for op_spec in ops:
                sname, new_df, summary_txt = apply_working_sheet_op(
                    session.dataset,
                    op_spec,
                    existing_sheets=list(session.dataset.sheets),
                )
                session.register_working_sheet(sname, new_df, summary_txt, op_spec, save_state=False)
                created_summaries.append(summary_txt)

    if not plan:
        # Pure Step 1 working-sheet preparation action without forcing a single figure
        if created_summaries:
            msg = 'Prepared working sheet: ' + ' | '.join(created_summaries)
            session.conversation.append({'role': 'assistant', 'text': msg})
        if session.project_dir:
            session.save()
        return {
            'active_sheet': session.dataset.sheet,
            'created_sheets': created_summaries,
            'summary': ' | '.join(created_summaries) if created_summaries else f'Active sheet: {session.dataset.sheet}',
        }

    eff_plan = deepcopy(dict(plan))
    merged_style = dict(session.style)
    for k, v in (eff_plan.pop('style', None) or {}).items():
        if v is not None:
            merged_style[k] = v
    for k, v in (style or {}).items():
        if v is not None:
            merged_style[k] = v
    # Default exploratory describe views to no p-value brackets unless explicitly running stats
    if eff_plan.get('method', 'describe') == 'describe' and 'p_display' not in (style or {}):
        merged_style['p_display'] = 'none'

    result = analyze(session.dataset, eff_plan)
    fig = make_figure(session.dataset, result, eff_plan, merged_style)
    plt.close(fig)

    session.plan = eff_plan
    session.result = result
    session.style = merged_style
    if eff_plan.get('design') in {'independent', 'paired'}:
        session.context['design'] = eff_plan['design']
    session._event('analysis', {
        'plan': eff_plan,
        'summary': result.get('summary', ''),
        'sheet': session.dataset.sheet,
        'source_sha256': session.dataset.source_hash,
    })
    note_prefix = ('Built working sheet (' + '; '.join(created_summaries) + ').\n\n') if created_summaries else ''
    mode_tag = 'Exploratory figure ready' if eff_plan.get('method') == 'describe' else 'Statistical analysis & figure updated'
    session.conversation.append({
        'role': 'assistant',
        'text': f"{note_prefix}**{mode_tag}:** {result.get('summary', '')}",
    })
    if session.project_dir:
        session.save()
    return {
        'active_sheet': session.dataset.sheet,
        'created_sheets': created_summaries,
        'summary': result.get('summary', ''),
    }
