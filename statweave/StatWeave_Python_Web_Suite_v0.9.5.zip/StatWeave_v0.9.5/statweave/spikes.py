"""Versioned upward-threshold event detection on full-resolution raw voltage.

Defaults are an explicit -20 mV threshold, 2 ms refractory interval and 0.1 s
rate bins. An event starts at the first sample at/above threshold preceded by a
below-threshold sample. Its peak is the earliest maximal raw value before the
signal returns below threshold. Candidates are accepted chronologically when
their crossing is at least ceil(refractory_ms * fs / 1000) samples after the
last accepted crossing. Rejected refractory candidates remain in the result.

No filtering or baseline correction is performed. Excursions already above
threshold at the selected left boundary, or still above at the right boundary,
are excluded and counted explicitly. A run can touch both boundaries; accounting
reports that overlap and the number of distinct excluded boundary excursions.
Nonfinite or discontinuous samples stop the calculation. This detector identifies
threshold events, not independently validated action potentials or sorted units.
Rates use actual selected sampled duration; sweep gaps are not exposure time.
"""
from __future__ import annotations

from copy import deepcopy
import math
import re

import numpy as np

from .trace_figures import validate_trace_plan

DETECTOR_VERSION = '1.0.0'
DETECTOR_METHOD = 'upward-threshold-excursion'
MAX_CANDIDATES = 100_000
MAX_BIN_ROWS = 100_000
CHUNK_SAMPLES = 65_536
EVENT_COLUMNS = ['channel','sweep','channel_name','crossing_sample_index',
    'peak_sample_index','crossing_time_s','peak_time_s','recording_crossing_time_s',
    'recording_peak_time_s','peak_value','unit','peak_mv','threshold_mv',
    'refractory_samples','accepted','rejection_reason']
SWEEP_COLUMNS = ['channel','sweep','channel_name','unit','spike_count',
    'sampled_duration_s','firing_rate_hz','first_sample_index','stop_sample_index',
    'sampling_rate_hz','refractory_samples','bin_width_samples','candidate_count',
    'refractory_rejected','left_boundary_excursions','right_boundary_excursions',
    'spanning_both_boundaries','boundary_excursions_excluded']
POOLED_COLUMNS = ['channel','channel_name','unit','spike_count',
    'sampled_duration_s','firing_rate_hz','selected_sweeps']
BIN_COLUMNS = ['channel','sweep','start_s','end_s','duration_s','spike_count',
    'firing_rate_hz','recording_start_s','recording_end_s',
    'first_sample_index','stop_sample_index','bin_width_samples']


def _number(value, label, positive=False, nonnegative=False):
    if isinstance(value,(bool,np.bool_)) or not isinstance(value,(int,float,np.integer,np.floating)):
        raise ValueError(f'{label} must be a finite number.')
    result=float(value)
    if not math.isfinite(result):
        raise ValueError(f'{label} must be finite.')
    if positive and result<=0:
        raise ValueError(f'{label} must be greater than zero.')
    if nonnegative and result<0:
        raise ValueError(f'{label} cannot be negative.')
    return result


def voltage_factor_to_mv(unit):
    """Return the explicit raw-unit multiplier to mV; never guess current units."""
    normalized=str(unit).strip().casefold().replace('µ','u').replace('μ','u')
    factors={'mv':1.0,'v':1000.0,'uv':0.001}
    if normalized not in factors:
        raise ValueError(f'Spike detection requires a voltage channel in mV, V or uV; {unit!r} is not supported. No voltage unit is assumed.')
    return factors[normalized]


def _ceil_point(point):
    # Resolve representation error around exact integer sample boundaries only.
    return int(math.ceil(point-max(1e-10,abs(point)*4*np.finfo(float).eps)))


def _selections(recording,plan):
    result=[]
    for channel_index in plan['channels']:
        channel=next(c for c in recording.channels if int(c['index'])==channel_index)
        rate=_number(channel['sampling_rate_hz'],'Sampling rate',positive=True)
        factor=voltage_factor_to_mv(channel.get('unit',''))
        refractory_points=plan['detector']['refractory_ms']*rate/1000
        width_points=plan['bin_width_s']*rate
        if not math.isfinite(refractory_points) or not math.isfinite(width_points):
            raise ValueError('The requested refractory interval or bin width exceeds supported sample-count arithmetic.')
        refractory=max(1 if plan['detector']['refractory_ms']>0 else 0,_ceil_point(refractory_points))
        width=max(1,_ceil_point(width_points))
        for sweep_index in plan['sweeps']:
            sweep=next(s for s in recording.sweeps if int(s['index'])==sweep_index)
            end=float(sweep['duration_s']) if plan['end_s'] is None else plan['end_s']
            first=max(0,_ceil_point(plan['start_s']*rate))
            stop=min(int(sweep['sample_count']),_ceil_point(end*rate))
            if stop<=first:
                raise ValueError('The selected interval contains no acquired samples.')
            origin=_number(sweep['start_s'],'Recording sweep start')
            result.append({'channel_index':channel_index,'sweep_index':sweep_index,
                'channel':channel_index+1,'sweep':sweep_index+1,
                'channel_name':str(channel['name']),'unit':str(channel['unit']),
                'sampling_rate_hz':rate,'factor_to_mv':factor,
                'first_sample_index':first,'stop_sample_index':stop,
                'sampled_duration_s':(stop-first)/rate,'recording_sweep_start_s':origin,
                'refractory_samples':refractory,'bin_width_samples':width,
                'bin_count':(stop-first+width-1)//width})
    return result


def validate_spike_plan(recording,plan):
    """Validate selection and explicit detector settings without loading samples."""
    if not isinstance(plan,dict) or plan.get('method','spikes')!='spikes':
        raise ValueError('Spike detection needs a supported spikes plan.')
    candidate=deepcopy(plan)
    candidate.update(action='trace',method='trace')
    normalized=validate_trace_plan(recording,candidate)
    normalized.update(action='spikes',method='spikes')
    detector=normalized.get('detector',{})
    if not isinstance(detector,dict) or set(detector)-{'threshold_mv','refractory_ms'}:
        raise ValueError('Supported detector settings are threshold_mv and refractory_ms only.')
    normalized['detector']={
        'threshold_mv':_number(detector.get('threshold_mv',-20.0),'Threshold in mV'),
        'refractory_ms':_number(detector.get('refractory_ms',2.0),'Refractory interval in ms',nonnegative=True)}
    normalized['bin_width_s']=_number(normalized.get('bin_width_s',.1),'Rate-bin width in seconds',positive=True)
    selections=_selections(recording,normalized)
    if sum(s['bin_count'] for s in selections)>MAX_BIN_ROWS:
        raise ValueError(f'This selection would create more than {MAX_BIN_ROWS:,} rate-bin rows. Select a shorter interval or a larger bin width.')
    return normalized


def _chunks(recording,selection,plan):
    expected=selection['first_sample_index']
    stop=selection['stop_sample_index']
    rate=selection['sampling_rate_hz']
    for chunk in recording.iter_window_chunks(channel_index=selection['channel_index'],
            sweep_index=selection['sweep_index'],start_s=plan['start_s'],
            end_s=plan['end_s'],chunk_samples=CHUNK_SAMPLES):
        try:
            values=np.asarray(chunk['values'],dtype=float)
            times=np.asarray(chunk['time_s'],dtype=float)
            indices=np.asarray(chunk['sample_indices'])
        except (KeyError,TypeError,ValueError) as error:
            raise ValueError('The recording reader returned an invalid signal chunk.') from error
        if values.ndim!=1 or times.ndim!=1 or indices.ndim!=1 or not (len(values)==len(times)==len(indices)):
            raise ValueError('The recording chunk has inconsistent sample, time or index arrays.')
        if not len(values):
            continue
        if len(values)>CHUNK_SAMPLES:
            raise ValueError('The recording reader exceeded the bounded detector chunk size.')
        if not np.isfinite(values).all() or not np.isfinite(times).all():
            raise ValueError('Spike detection stopped because selected samples contain nonfinite values. No gaps are silently removed from the firing-rate denominator.')
        if not np.issubdtype(indices.dtype,np.integer) or int(indices[0])!=expected or np.any(np.diff(indices)!=1):
            raise ValueError('Spike detection requires contiguous acquired sample indices; a gap or discontinuity was found.')
        if int(indices[-1])>=stop:
            raise ValueError('The recording reader returned samples outside the selected interval.')
        tolerance=max(1e-12,abs(int(indices[-1])/rate)*8*np.finfo(float).eps)
        if not np.allclose(times,indices.astype(float)/rate,rtol=0,atol=tolerance):
            raise ValueError('Sample timestamps do not match the recorded sampling rate. Spike detection will not invent continuous exposure time.')
        expected=int(indices[-1])+1
        yield indices.astype(np.int64,copy=False),times,values
    if expected!=stop:
        raise ValueError('The recording reader did not return every sample in the selected interval. Spike detection stopped instead of shortening the denominator.')


def _event(selection,crossing,peak_index,peak_value,threshold):
    rate=selection['sampling_rate_hz'];origin=selection['recording_sweep_start_s']
    peak_mv=float(peak_value*selection['factor_to_mv'])
    if not math.isfinite(peak_mv):
        raise ValueError('The calibrated voltage cannot be represented finitely in mV.')
    return {'channel':selection['channel'],'sweep':selection['sweep'],
        'channel_name':selection['channel_name'],'crossing_sample_index':int(crossing),
        'peak_sample_index':int(peak_index),'crossing_time_s':float(crossing/rate),
        'peak_time_s':float(peak_index/rate),
        'recording_crossing_time_s':float(origin+crossing/rate),
        'recording_peak_time_s':float(origin+peak_index/rate),
        'peak_value':float(peak_value),'unit':selection['unit'],'peak_mv':peak_mv,
        'threshold_mv':float(threshold),'refractory_samples':selection['refractory_samples'],
        'accepted':False,'rejection_reason':None}


def spike_result(recording,plan):
    """Detect and account for threshold events using unmodified acquired samples."""
    plan=validate_spike_plan(recording,plan)
    selections=_selections(recording,plan)
    accepted=[];candidates=[];sweep_rows=[];bin_rows=[];selection_account=[]
    threshold=plan['detector']['threshold_mv']
    for selected in selections:
        raw_threshold=threshold/selected['factor_to_mv']
        if not math.isfinite(raw_threshold):
            raise ValueError('The requested mV threshold cannot be represented in this channel unit.')
        active=None;previous_accepted=None;left=0;right=0;both=0;rejected=0
        accepted_here=[];candidate_count=0
        for indices,times,values in _chunks(recording,selected,plan):
            above=values>=raw_threshold
            boundaries=np.r_[0,np.flatnonzero(above[1:]!=above[:-1])+1,len(values)]
            for first,last in zip(boundaries[:-1],boundaries[1:]):
                first=int(first);last=int(last)
                if above[first]:
                    if active is None:
                        boundary=int(indices[first])==selected['first_sample_index']
                        if boundary:left+=1
                        active={'left_boundary':boundary,'crossing':None if boundary else int(indices[first]),
                                'peak_index':int(indices[first]),'peak_value':float(values[first])}
                    peak=first+int(np.argmax(values[first:last]))
                    # Strict comparison preserves earliest peak in an exact plateau.
                    if values[peak]>active['peak_value']:
                        active.update(peak_index=int(indices[peak]),peak_value=float(values[peak]))
                elif active is not None:
                    if not active['left_boundary']:
                        row=_event(selected,active['crossing'],active['peak_index'],active['peak_value'],threshold)
                        accept=(previous_accepted is None or row['crossing_sample_index']-previous_accepted>=selected['refractory_samples'])
                        row.update(accepted=bool(accept),rejection_reason=None if accept else 'refractory')
                        candidate_count+=1
                        if len(candidates)>=MAX_CANDIDATES:
                            raise ValueError(f'More than {MAX_CANDIDATES:,} completed threshold candidates were found. Select a shorter interval or revise the explicit detector settings.')
                        candidates.append(row)
                        if accept:
                            previous_accepted=row['crossing_sample_index']
                            accepted.append(dict(row));accepted_here.append(row)
                        else:rejected+=1
                    active=None
        if active is not None:
            right=1
            both=int(active['left_boundary'])
        distinct_boundary=left+right-both
        rate=selected['sampling_rate_hz'];first=selected['first_sample_index'];stop=selected['stop_sample_index']
        counts=np.zeros(selected['bin_count'],dtype=np.int64)
        for event in accepted_here:
            counts[(event['crossing_sample_index']-first)//selected['bin_width_samples']]+=1
        for number,count in enumerate(counts):
            begin=first+number*selected['bin_width_samples']
            end=min(stop,begin+selected['bin_width_samples'])
            duration=(end-begin)/rate
            bin_rows.append({'channel':selected['channel'],'sweep':selected['sweep'],
                'start_s':float(begin/rate),'end_s':float(end/rate),'duration_s':float(duration),
                'spike_count':int(count),'firing_rate_hz':float(count/duration),
                'recording_start_s':float(selected['recording_sweep_start_s']+begin/rate),
                'recording_end_s':float(selected['recording_sweep_start_s']+end/rate),
                'first_sample_index':int(begin),'stop_sample_index':int(end),
                'bin_width_samples':selected['bin_width_samples']})
        sweep_rows.append({'channel':selected['channel'],'sweep':selected['sweep'],
            'channel_name':selected['channel_name'],'unit':selected['unit'],
            'spike_count':len(accepted_here),'sampled_duration_s':selected['sampled_duration_s'],
            'firing_rate_hz':float(len(accepted_here)/selected['sampled_duration_s']),
            'first_sample_index':first,'stop_sample_index':stop,'sampling_rate_hz':rate,
            'refractory_samples':selected['refractory_samples'],'bin_width_samples':selected['bin_width_samples'],
            'candidate_count':candidate_count,'refractory_rejected':rejected,
            'left_boundary_excursions':left,'right_boundary_excursions':right,
            'spanning_both_boundaries':both,'boundary_excursions_excluded':distinct_boundary})
        selection_account.append({**selected,'accepted_events':len(accepted_here),
            'completed_candidates':candidate_count,'refractory_rejected':rejected,
            'left_boundary_excursions':left,'right_boundary_excursions':right,
            'spanning_both_boundaries':both,'boundary_excursions_excluded':distinct_boundary,
            'effective_refractory_ms':selected['refractory_samples']/rate*1000,
            'effective_bin_width_s':selected['bin_width_samples']/rate})
    pooled=[]
    for channel in plan['channels']:
        rows=[row for row in sweep_rows if row['channel']==channel+1]
        count=sum(r['spike_count'] for r in rows);duration=sum(r['sampled_duration_s'] for r in rows)
        pooled.append({'channel':channel+1,'channel_name':rows[0]['channel_name'],'unit':rows[0]['unit'],
            'spike_count':count,'sampled_duration_s':duration,'firing_rate_hz':float(count/duration),
            'selected_sweeps':len(rows)})
    warnings=[str(w) for w in getattr(recording,'warnings',[]) if 'event detection' not in str(w).casefold()]
    warnings += [
        'Detector version '+DETECTOR_VERSION+': upward threshold excursions in unfiltered raw voltage; candidate threshold events are not independently validated action potentials or sorted units.',
        'The threshold, refractory interval and bin width are explicit settings. No threshold optimization, filtering, smoothing, baseline correction or source-sample deletion is performed.',
        'Left-boundary already-above excursions and incomplete right-boundary excursions are excluded and counted; this can reduce counts in short selected windows.',
        'Refractory rejection uses crossing-to-crossing sample distance from the last accepted candidate and resets at each sweep.',
        'Firing-rate exposure is selected sample count divided by sampling rate; acquisition gaps are excluded from exposure. Bins count accepted crossings, with the final partial bin using its actual duration.',
        'Waveform samples, detected events and sweeps are not assumed to be independent biological replicates. No inferential statistical test is performed.']
    source_hash=str(getattr(recording,'source_hash','unavailable'))
    steps=[{'step':1,'operation':'read_raw_voltage','source_sha256':source_hash,
            'resolution':'full acquired samples','sample_modification':'none'},
        {'step':2,'operation':'voltage_unit_interpretation','channels':[
            {'channel':s['channel'],'unit':s['unit'],'factor_to_mv':s['factor_to_mv']}
            for i,s in enumerate(selections) if not any(p['channel']==s['channel'] for p in selections[:i])]},
        {'step':3,'operation':'threshold_excursion_detection','detector_version':DETECTOR_VERSION,
            'detector_method':DETECTOR_METHOD,'threshold_mv':threshold,
            'crossing':'first sample at or above threshold preceded by a below-threshold sample',
            'completion':'first subsequent sample below threshold','peak':'earliest maximal raw value inside completed excursion',
            'boundary_policy':'exclude left-boundary already-above and incomplete right-boundary excursions'},
        {'step':4,'operation':'refractory_acceptance','requested_refractory_ms':plan['detector']['refractory_ms'],
            'rule':'crossing distance >= ceil(requested_ms * sampling_rate_hz / 1000) from last accepted crossing; reset each sweep'},
        {'step':5,'operation':'sample_count_rate_binning','requested_bin_width_s':plan['bin_width_s'],
            'rule':'ceil(width_s * sampling_rate_hz) samples; align first selected sample; count accepted crossings; retain partial final bin',
            'selections':deepcopy(selection_account)},
        {'step':6,'operation':'pool_by_channel','rule':'sum accepted counts / sum sampled durations across selected sweeps; never pool channels or acquisition gaps'}]
    accounting={'selected_channel_samples':sum(s['stop_sample_index']-s['first_sample_index'] for s in selections),
        'selected_channels':len(plan['channels']),'selected_sweeps':len(plan['sweeps']),
        'completed_candidates':len(candidates),'accepted_events':len(accepted),
        'refractory_rejected':sum(r['refractory_rejected'] for r in sweep_rows),
        'left_boundary_excursions':sum(r['left_boundary_excursions'] for r in sweep_rows),
        'right_boundary_excursions':sum(r['right_boundary_excursions'] for r in sweep_rows),
        'spanning_both_boundaries':sum(r['spanning_both_boundaries'] for r in sweep_rows),
        'boundary_excursions_excluded':sum(r['boundary_excursions_excluded'] for r in sweep_rows),
        'rate_bin_rows':len(bin_rows),'selections':selection_account,
        'sampled_duration_note':'Per-channel exposure only; channel durations are never summed into a shared biological denominator.',
        'original_recording_preserved':True,'signal_filtering_applied':False,'inferential_analysis':False}
    summary=(f"Detected {len(accepted):,} accepted upward-threshold events from {len(candidates):,} completed candidates "
        f"across {len(plan['channels'])} voltage channel(s) and {len(plan['sweeps'])} sweep(s), "
        f"using threshold {threshold:g} mV, refractory interval {plan['detector']['refractory_ms']:g} ms, "
        f"and requested rate-bin width {plan['bin_width_s']:g} s.\n")
    summary+='\n'.join(f"Channel {row['channel']}, sweep {row['sweep']}: {row['spike_count']:,} events / {row['sampled_duration_s']:.6g} s = {row['firing_rate_hz']:.6g} detected events/s." for row in sweep_rows[:8])
    if len(sweep_rows)>8:
        summary+=f'\nShowing the first 8 of {len(sweep_rows)} channel/sweep measurements here; all measurements are retained in Results and exports.'
    summary+='\n'+'\n'.join(f"Channel {row['channel']}, pooled across {row['selected_sweeps']} selected sweep(s): {row['spike_count']:,} events / {row['sampled_duration_s']:.6g} s = {row['firing_rate_hz']:.6g} detected events/s." for row in pooled)
    summary+='\nRates use full-resolution selected sampled durations, not display-reduced trace points or acquisition gaps. Boundary-excursion exclusions and refractory rejections are recorded in Results. No inferential test was performed.'
    return {'method':'spikes','plan':plan,'summary':summary,
        'detector_version':DETECTOR_VERSION,'detector_method':DETECTOR_METHOD,'source_sha256':source_hash,
        'events':accepted,'candidates':candidates,'processing_steps':steps,
        'tables':[{'title':'Firing rate by sweep','columns':SWEEP_COLUMNS,'rows':sweep_rows},
                  {'title':'Pooled firing rate by channel','columns':POOLED_COLUMNS,'rows':pooled},
                  {'title':'Binned firing rate','columns':BIN_COLUMNS,'rows':bin_rows},
                  {'title':'Detected spikes','columns':EVENT_COLUMNS,'rows':deepcopy(accepted)}],
        'warnings':list(dict.fromkeys(warnings)),'spike_accounting':accounting}
