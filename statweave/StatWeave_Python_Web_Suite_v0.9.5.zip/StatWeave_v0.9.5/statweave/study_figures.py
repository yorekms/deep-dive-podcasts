"""Publication figures from recorded, deterministic study execution results.

This module never opens a source file, aggregates observations or fits a model.
The execution adapter supplies trial/subject values, means, SD and slopes; the
renderer preserves those quantities and their units. Recovery is a distinct
panel even when its gas concentration matches baseline.
"""
from __future__ import annotations

from collections import defaultdict
from copy import deepcopy
import math
import textwrap

import matplotlib as mpl
from matplotlib.backends.backend_agg import FigureCanvasAgg
from matplotlib.figure import Figure
from matplotlib.lines import Line2D
from matplotlib.ticker import MaxNLocator
import numpy as np

from .figures import RC, PALETTES, _style, _serialized_render, _assert_not_clipped


_MARKERS = ('o', 's', '^', 'D', 'v', 'P')
_LINES = ('-', '--', '-.', ':', (0, (5, 1)), (0, (3, 1, 1, 1)))
_PHASES = {'baseline', 'exposure', 'recovery'}


def _finite(value, label):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ValueError(f'The stored {label} must be a finite number. Rerun the reviewed analysis.')
    return float(value)


def _text(value, label, limit=240):
    if not isinstance(value, str) or not value.strip() or len(value) > limit or '\x00' in value:
        raise ValueError(f'The stored {label} is missing or invalid. Rerun the reviewed analysis.')
    return value


def _rows(data, name):
    rows = data.get(name, [])
    if not isinstance(rows, list) or len(rows) > 10_000 or any(not isinstance(r, dict) for r in rows):
        raise ValueError(f'The stored {name} is not a supported plotting table.')
    return rows


def _settings(plan, style):
    settings = _style(plan or {}, style)
    if settings['font_size'] < 8.5:
        raise ValueError('Study figures require text of at least 8.5 pt at final size.')
    return settings


def _validated(result):
    if not isinstance(result, dict) or result.get('method') != 'study_execution':
        raise ValueError('A study figure requires a stored study execution result.')
    data = result.get('plot_data')
    if not isinstance(data, dict):
        raise ValueError('The study result has no recorded plotting values.')
    endpoint = data.get('endpoint')
    if not isinstance(endpoint, dict):
        raise ValueError('The study result has no recorded endpoint definition.')
    for field in ('column', 'label', 'unit', 'calibration_class'):
        _text(endpoint.get(field), 'endpoint ' + field)
    recipe = result.get('recipe', {})
    options = recipe.get('options', {}) if isinstance(recipe, dict) else {}
    pooling = data.get('pooling', options.get('pooling'))
    if pooling not in {'equal_within_subject', 'separate'}:
        raise ValueError('The study result has no supported trial aggregation definition.')
    normalization = data.get('normalization', options.get('normalization', 'none'))
    if normalization not in {'none', 'fold_baseline', 'percent_baseline', 'percent_change'}:
        raise ValueError('The stored normalization definition is unsupported.')
    points = _rows(data, 'subject_rows' if pooling == 'equal_within_subject' else 'trial_rows')
    if not points:
        raise ValueError('The study result has no recorded subject/trial points to plot.')
    groups = list(dict.fromkeys(_text(row.get('group'), 'group') for row in points))
    if len(groups) > len(_MARKERS):
        raise ValueError('This figure supports up to six groups. Retain the full results and use separate reviewed figures for additional groups.')
    seen = set()
    for row in points:
        subject = _text(row.get('subject'), 'subject')
        identity = (subject,) if pooling == 'equal_within_subject' else (subject, _text(row.get('session'), 'session'))
        phase = row.get('phase')
        if phase not in _PHASES:
            raise ValueError('The stored point has an unsupported protocol phase.')
        dose = _finite(row.get('co2_percent'), 'CO2 concentration')
        _finite(row.get('value'), 'endpoint value')
        # Baseline and exposure at the same x are distinct epochs. The renderer
        # must not merge them or invent a vertical concentration-response link.
        key = identity + (('recovery' if phase == 'recovery' else 'curve'), dose)
        if key in seen:
            raise ValueError('Distinct recorded epochs share a plotted concentration for the same unit. Review their dose/phase assignments; the figure will not silently merge them.')
        seen.add(key)
    group_rows = _rows(data, 'group_rows') if pooling == 'equal_within_subject' else []
    for row in group_rows:
        if row.get('group') not in groups or row.get('phase') not in _PHASES:
            raise ValueError('A stored group summary does not match the plotted groups/phases.')
        _finite(row.get('co2_percent'), 'group concentration')
        _finite(row.get('mean'), 'group mean')
        n = row.get('n_subjects')
        if type(n) is not int or n < 1:
            raise ValueError('A stored group summary needs its actual subject count.')
        sd = row.get('sd')
        if sd is not None and (_finite(sd, 'group SD') < 0 or n < 2):
            raise ValueError('A stored group SD must be nonnegative and based on at least two subjects.')
    slopes = _rows(data, 'slopes')
    slope_subjects = set()
    for row in slopes:
        subject = _text(row.get('subject'), 'slope subject')
        if row.get('group') not in groups or subject in slope_subjects:
            raise ValueError('The stored slope table has duplicate subjects or unmatched groups.')
        _finite(row.get('slope'), 'subject slope')
        slope_subjects.add(subject)
    slope_groups = _rows(data, 'slope_group_rows')
    for row in slope_groups:
        if row.get('group') not in groups:
            raise ValueError('A stored slope summary has an unmatched group.')
        _finite(row.get('mean'), 'slope mean')
        n = row.get('n_subjects')
        if type(n) is not int or n < 1:
            raise ValueError('A slope summary needs its actual subject count.')
        if row.get('sd') is not None and (_finite(row['sd'], 'slope SD') < 0 or n < 2):
            raise ValueError('A slope SD needs at least two subjects and a nonnegative value.')
    if pooling == 'separate' and slopes:
        raise ValueError('Subject slopes cannot be plotted as if separate trials were independent subjects.')
    return data, endpoint, pooling, normalization, points, group_rows, slopes, slope_groups, groups


def _quantity_label(endpoint, normalization):
    if normalization == 'fold_baseline':
        return endpoint['label'], 'fold baseline'
    if normalization == 'percent_baseline':
        return endpoint['label'], '% baseline'
    if normalization == 'percent_change':
        return endpoint['label'], '% change from baseline'
    return endpoint['label'], endpoint['unit']


def _wrap(text, width=26):
    return '\n'.join(textwrap.fill(line, width=width, break_long_words=True, break_on_hyphens=False)
                     for line in str(text).split('\n'))


def _series(points, pooling):
    values = defaultdict(list)
    for row in points:
        identity = (row['group'], row['subject'])
        if pooling == 'separate':
            identity += (row['session'],)
        values[identity].append(row)
    return values


def _group_n_label(group, summaries):
    counts = sorted({row['n_subjects'] for row in summaries if row['group'] == group})
    if not counts:
        return _wrap(group, 22)
    count = str(counts[0]) if len(counts) == 1 else f'{counts[0]}–{counts[-1]}'
    return _wrap(group, 22) + f' (n = {count} subjects)'


def _axes(ax, size):
    ax.spines[['top', 'right']].set_visible(False)
    ax.tick_params(axis='both', labelsize=size, width=.65, length=3)
    ax.yaxis.set_major_locator(MaxNLocator(nbins=5, min_n_ticks=3))
    ax.xaxis.set_major_locator(MaxNLocator(nbins=5, min_n_ticks=2))
    ax.set_axisbelow(True)
    ax.grid(False)


def _range_margin(values):
    low, high = min(values), max(values)
    spread = high - low
    return (low - (spread or max(abs(low), 1.)) * .12,
            high + (spread or max(abs(high), 1.)) * .12)


def _check_figure_text(fig):
    _assert_not_clipped(fig)
    renderer = fig.canvas.get_renderer()
    texts = list(fig.texts)
    for legend in fig.legends:
        texts.extend(legend.get_texts())
    for ax in fig.axes:
        texts.extend(ax.texts)
    for text in texts:
        if not text.get_visible() or not text.get_text():
            continue
        box = text.get_window_extent(renderer)
        if box.x0 < -1 or box.y0 < -1 or box.x1 > fig.bbox.width + 1 or box.y1 > fig.bbox.height + 1:
            raise ValueError('A study figure label extends outside the fixed page. Increase width/height or shorten the label.')
    for axis in fig.axes:
        if not getattr(axis,'_statweave_categorical_x',False):continue
        ticks=[text.get_window_extent(renderer) for text in axis.get_xticklabels()
               if text.get_visible() and text.get_text()]
        for i,first in enumerate(ticks):
            for second in ticks[i+1:]:
                if min(first.x1,second.x1)-max(first.x0,second.x0)>1 and min(first.y1,second.y1)-max(first.y0,second.y0)>1:
                    raise ValueError('Study figure category labels overlap. Increase figure width/height or use shorter explicit display labels before exporting.')


def _update_grid_margin(fig,grid,left):
    grid.update(left=left)
    # OO Figures have no pyplot manager; GridSpec.update does not reposition
    # their existing axes automatically.
    for axis in fig.axes:
        axis.set_position(axis.get_subplotspec().get_position(fig))


def _report_results(result):
    measures=result.get('measures')
    if result.get('method')!='study_execution' or not isinstance(measures,list):
        raise ValueError('A measure-report figure requires a recorded outcome inventory.')
    available=[]
    for measure in measures:
        if not isinstance(measure,dict):
            raise ValueError('The measure-report inventory is invalid.')
        if measure.get('status')=='executed':
            item=measure.get('result')
            _validated(item)
            available.append(item)
    if not available:
        raise ValueError('No measure passed the execution requirements. Review the outcome inventory; no empty or fabricated scientific plot was generated.')
    return available


def _report_spec(result,plan,style):
    available=_report_results(result);settings=_settings(plan,style)
    has_sd=any(row.get('sd') is not None and row.get('n_subjects',0)>=2
               for item in available for row in _validated(item)[5])
    group_order=[]
    for item in available:
        for group in _validated(item)[-1]:
            if group not in group_order:group_order.append(group)
    return {
        'claim':'Available source measures are shown as separate endpoint-specific response previews.',
        'audience':'expert','visual_form':'small_multiples',
        'metric':{'name':'Available pleth measures','unit':'endpoint-specific units; see each panel',
                  'direction':'neutral','aggregation':'Recorded per-endpoint execution results',
                  'denominator':'subjects; trials remain repeated observations','scale':'linear'},
        'data_source':{'path_or_identifier':'stored measure report results',
                       'checksum':str(result.get('recipe_sha256','')),
                       'notes':f'Overview shows the first {min(4,len(available))} of {len(available)} executed measures; complete individual figures, recovery panels and inventory are exported separately.'},
        'series_order':group_order,'ordering_rationale':'semantic_group',
        'uncertainty':{'available':True,'type':'standard_deviation' if settings['ci'] and has_sd else 'raw_points',
                       'note':'Recorded subject-level SD where supplied; no inferred independent trial/breath intervals.'},
        'target':{'medium':'paper','width':settings['width_mm'],'height':settings['height_mm'],
                  'unit':'mm','minimum_text_size_pt':settings['font_size'],'background':'white'},
        'output_formats':['svg','pdf','png'],
        'caption_requirements':['sample','estimator','uncertainty','exclusions'],
    }


def _report_figure(study,result,plan,style):
    available=_report_results(result);preview=available[:4];settings=_settings(plan,style)
    if len(preview)>1 and settings['width_mm']<150:
        raise ValueError('A multi-measure overview needs at least 150 mm width to keep units readable. Individual measure figures are available separately.')
    if len(preview)>2 and settings['height_mm']<100:
        raise ValueError('A four-measure overview needs at least 100 mm height to keep labels readable.')
    size=settings['font_size'];groups=[]
    for item in available:
        for group in _validated(item)[-1]:
            if group not in groups:groups.append(group)
    if len(groups)>len(_MARKERS):
        raise ValueError('This overview supports up to six groups; retain the full results and use separate reviewed figures for additional groups.')
    palette=PALETTES[settings['palette']]
    encoding={g:{'color':palette[min(i,len(palette)-1)],'marker':_MARKERS[i],'ls':_LINES[i]} for i,g in enumerate(groups)}
    with mpl.rc_context({**RC,'font.size':size,'text.parse_math':False,'axes.labelsize':size,
                         'xtick.labelsize':size,'ytick.labelsize':size}):
        fig=Figure(figsize=(settings['width_mm']/25.4,settings['height_mm']/25.4),dpi=120,facecolor='white');FigureCanvasAgg(fig)
        rows=2 if len(preview)>2 else 1;cols=2 if len(preview)>1 else 1
        grid=fig.add_gridspec(rows,cols,left=.14,right=.975,top=.77,bottom=.17,
                             wspace=.6,hspace=1.05)
        for i,item in enumerate(preview):
            data,endpoint,pooling,normalization,points,summaries,_,_,_= _validated(item)
            if pooling=='separate' and not settings['show_points']:
                raise ValueError('Separate-trial figures require recorded points; no independent group mean is available to substitute.')
            ax=fig.add_subplot(grid[i//cols,i%cols]);_axes(ax,size)
            _,unit=_quantity_label(endpoint,normalization)
            ax.set_title(_wrap(endpoint['label'],30),loc='left',fontsize=size,pad=7)
            ax.set_ylabel(_wrap(unit,22),labelpad=5)
            ax.set_xlabel('Inspired CO₂ (%)',labelpad=4)
            current=[r for r in points if r['phase']!='recovery']
            if not current:
                raise ValueError('A report endpoint lacks baseline/exposure points; review the recorded recipe.')
            doses=sorted({r['co2_percent'] for r in current});ax.set_xlim(*_range_margin(doses))
            if len(doses)<=6:ax.set_xticks(doses)
            ax.yaxis.set_major_locator(MaxNLocator(nbins=3,min_n_ticks=2))
            for identity,values in _series(current,pooling).items():
                values=sorted(values,key=lambda r:r['co2_percent']);sty=encoding[identity[0]]
                if settings['show_points']:
                    ax.plot([r['co2_percent'] for r in values],[r['value'] for r in values],
                            color=sty['color'],linestyle=sty['ls'],marker=sty['marker'],
                            markerfacecolor='white',markeredgewidth=.65,markersize=3.7,
                            linewidth=.7,alpha=.65,label='_recorded_subject' if pooling=='equal_within_subject' else '_recorded_trial')
            for group in groups:
                values=sorted([r for r in summaries if r['group']==group and r['phase']!='recovery'],key=lambda r:r['co2_percent'])
                if not values:continue
                if len({r['co2_percent'] for r in values})!=len(values):
                    raise ValueError('Distinct group epochs share a concentration. Review the recipe rather than merging phases in the overview.')
                sty=encoding[group]
                ax.plot([r['co2_percent'] for r in values],[r['mean'] for r in values],
                        color=sty['color'],linestyle=sty['ls'],marker=sty['marker'],
                        markeredgecolor='white',markeredgewidth=.4,markersize=4.3,
                        linewidth=1.5,label='_recorded_group_mean',zorder=4)
                valid=[r for r in values if r.get('sd') is not None and r['n_subjects']>=2]
                if settings['ci'] and valid:
                    ax.errorbar([r['co2_percent'] for r in valid],[r['mean'] for r in valid],
                                yerr=[r['sd'] for r in valid],fmt='none',ecolor=sty['color'],
                                elinewidth=.75,capsize=2,capthick=.75,zorder=3)
        first_summaries=_validated(available[0])[5]
        handles=[Line2D([],[],color=encoding[g]['color'],linestyle=encoding[g]['ls'],
                        marker=encoding[g]['marker'],markersize=4.5,linewidth=1.4,
                        label=_group_n_label(g,first_summaries)) for g in groups]
        fig.legend(handles=handles,loc='upper left',bbox_to_anchor=(.14,.915),frameon=False,
                   fontsize=size,ncol=min(3,len(groups)),borderaxespad=0)
        fig.text(.14,.98,_wrap(settings.get('title','Available pleth measures'),95),ha='left',va='top',fontsize=size+1,fontweight='semibold')
        any_summary=any(_validated(item)[5] for item in preview)
        summary_note=('mean ± SD' if settings['ci'] else 'means; intervals hidden') if any_summary else 'separate trials'
        foot=f'Overview: {len(preview)} of {len(available)} measures; {summary_note} · full figures and inventory in export'
        fig.text(.14,.035,_wrap(foot,95),ha='left',va='bottom',fontsize=size,color='#404040')
        fig._statweave_style=deepcopy(settings);fig._statweave_visual_spec=_report_spec(result,plan,style)
        fig._statweave_caption=figure_caption(study,result,plan,style)
        fig.canvas.draw()
        renderer=fig.canvas.get_renderer()
        margin=min(ax.yaxis.label.get_window_extent(renderer).x0 for ax in fig.axes)
        if margin<5:
            _update_grid_margin(fig,grid,grid.left+(7-margin)/fig.bbox.width);fig.canvas.draw()
        _check_figure_text(fig)
        return fig


def visual_spec(study, result, plan=None, style=None):
    """Return the evidence/geometry specification used by this renderer."""
    if isinstance(result,dict) and result.get('report') is True:
        return _report_spec(result,plan,style)
    data, endpoint, pooling, normalization, points, summaries, slopes, _, groups = _validated(result)
    settings = _settings(plan, style)
    label, unit = _quantity_label(endpoint, normalization)
    has_sd=any(row.get('sd') is not None and row.get('n_subjects',0)>=2 for row in summaries)
    return {
        'claim': f'{label} is shown across the reviewed inspired CO2 conditions, with recovery kept separate.',
        'audience': 'expert',
        'visual_form': 'small_multiples' if slopes or any(r['phase'] == 'recovery' for r in points) else 'line',
        'metric': {'name': label, 'unit': unit, 'direction': 'neutral', 'scale': 'linear',
                   'aggregation': 'Recorded subject means after the reviewed trial rule' if pooling == 'equal_within_subject' else 'Recorded separate-trial values',
                   'denominator': 'subjects; trials remain repeated observations'},
        'data_source': {'path_or_identifier': 'stored execution result.plot_data',
                        'checksum': str(result.get('recipe_sha256', '')),
                        'immutable_fields': ['endpoint', 'normalization', 'pooling', 'subject_rows', 'trial_rows', 'group_rows', 'slopes'],
                        'notes': 'No source read, aggregation, model fitting or uncertainty calculation occurs in the figure layer.'},
        'focal_series': groups[0],
        'required_baselines': ['reviewed baseline phase'] if any(row['phase']=='baseline' for row in points) else [],
        'series_order': groups, 'ordering_rationale': 'semantic_group',
        'uncertainty': {'available': bool(summaries),
                        'type': 'standard_deviation' if has_sd and settings['ci'] else 'raw_points',
                        'level': None, 'sample_or_seed_count': None,
                        'note': 'Recorded group mean ± sample SD across subjects where n >=2; never SEM or a confidence interval.' if has_sd and settings['ci'] else 'No interval bars; recorded subject/trial values remain visible unless points are explicitly disabled.'},
        'target': {'medium': 'paper', 'width': settings['width_mm'], 'height': settings['height_mm'],
                   'unit': 'mm', 'minimum_text_size_pt': settings['font_size'], 'background': 'white'},
        'annotations': [], 'selected_reference_ids': ['OAI-VIS-012', 'OAI-VIS-013', 'OAI-VIS-015'],
        'output_formats': ['svg', 'pdf', 'png'],
        'caption_requirements': ['sample', 'estimator', 'uncertainty', 'exclusions'],
    }


@_serialized_render
def make_figure(study, result, plan=None, style=None):
    """Render recorded results at the requested physical size, without inference."""
    if isinstance(result,dict) and result.get('report') is True:
        return _report_figure(study,result,plan,style)
    data, endpoint, pooling, normalization, points, summaries, slopes, slope_groups, groups = _validated(result)
    settings = _settings(plan, style)
    if pooling == 'separate' and not settings['show_points']:
        raise ValueError('Separate-trial figures require their recorded points; no independent group summary is available to substitute.')
    recovery = [r for r in points if r['phase'] == 'recovery']
    main = [r for r in points if r['phase'] != 'recovery']
    if not main:
        raise ValueError('The reviewed result has no baseline/exposure points for a CO2 response figure.')
    panel_count = 1 + bool(recovery) + bool(slopes)
    if settings['width_mm'] < (150 if panel_count == 3 else 115 if panel_count == 2 else 60):
        raise ValueError('Increase study figure width to at least ' + ('150' if panel_count == 3 else '115') + ' mm to retain readable panels and units.')
    size = settings['font_size']
    label, unit = _quantity_label(endpoint, normalization)
    y_label = _wrap(label, 25) + '\n(' + _wrap(unit, 25) + ')'
    palette = PALETTES[settings['palette']]
    styles = {group: {'color': palette[min(i, len(palette)-1)], 'marker': _MARKERS[i], 'ls': _LINES[i]}
              for i, group in enumerate(groups)}
    with mpl.rc_context({**RC, 'font.size': size, 'text.parse_math': False,
                         'axes.labelsize': size, 'xtick.labelsize': size, 'ytick.labelsize': size}):
        fig = Figure(figsize=(settings['width_mm']/25.4, settings['height_mm']/25.4), dpi=120, facecolor='white')
        FigureCanvasAgg(fig)
        # Fixed outer margins preserve dimensions; captions live in a separate file.
        ratios = [2.1] + ([.85] if recovery else []) + ([1.25] if slopes else [])
        grid = fig.add_gridspec(1, panel_count, width_ratios=ratios,
                               left=.125 if panel_count > 1 else .13, right=.975,
                               top=.77-.05*max(0,math.ceil(len(groups)/2)-1),
                               bottom=.22, wspace=.52 if slopes else .28)
        ax = fig.add_subplot(grid[0, 0]);_axes(ax, size)
        ax.set_title('CO₂ response', loc='left', fontsize=size+.5, pad=10)
        ax.set_xlabel(settings.get('xlabel', 'Inspired CO₂ (%)'), labelpad=6)
        ax.set_ylabel(settings.get('ylabel', y_label), labelpad=7)
        doses = sorted({r['co2_percent'] for r in main})
        ax.set_xticks(doses if len(doses) <= 8 else ax.get_xticks())
        ax.set_xlim(*_range_margin(doses))
        for identity, rows in _series(main, pooling).items():
            rows = sorted(rows, key=lambda r: r['co2_percent'])
            encoding = styles[identity[0]]
            if settings['show_points']:
                ax.plot([r['co2_percent'] for r in rows], [r['value'] for r in rows],
                        color=encoding['color'], linestyle=encoding['ls'], linewidth=.8,
                        marker=encoding['marker'], markersize=4.3, markerfacecolor='white',
                        markeredgewidth=.8, alpha=.72 if len(points) < 50 else .42,
                        label='_recorded_subject' if pooling == 'equal_within_subject' else '_recorded_trial',
                        zorder=2)
        # Only already calculated means/SD enter these artist arrays.
        for group in groups:
            rows = sorted([r for r in summaries if r['group'] == group and r['phase'] != 'recovery'],
                          key=lambda r: r['co2_percent'])
            if not rows:
                continue
            if len({r['co2_percent'] for r in rows}) != len(rows):
                raise ValueError('Distinct group epochs share a concentration. Review the recipe rather than merging phases in the figure.')
            encoding = styles[group]
            ax.plot([r['co2_percent'] for r in rows], [r['mean'] for r in rows],
                    color=encoding['color'], linestyle=encoding['ls'], linewidth=1.6,
                    marker=encoding['marker'], markersize=5, markeredgecolor='white', markeredgewidth=.5,
                    label='_recorded_group_mean', zorder=4)
            if settings['ci']:
                valid = [r for r in rows if r['sd'] is not None and r['n_subjects'] >= 2]
                if valid:
                    ax.errorbar([r['co2_percent'] for r in valid], [r['mean'] for r in valid],
                                yerr=[r['sd'] for r in valid], fmt='none', ecolor=encoding['color'],
                                elinewidth=.8, capsize=2.5, capthick=.8, zorder=3)
        column = 1
        if recovery:
            rec = fig.add_subplot(grid[0, column], sharey=ax);column += 1;_axes(rec, size)
            rec.set_title('Recovery', loc='left', fontsize=size+.5, pad=10)
            rec.tick_params(axis='y', labelleft=False)
            rec.spines['left'].set_visible(False)
            rec.tick_params(axis='y', left=False)
            rec_doses = sorted({r['co2_percent'] for r in recovery})
            positions = {dose: i for i, dose in enumerate(rec_doses)}
            rec.set_xticks(list(positions.values()), [f'{dose:g}%' for dose in rec_doses])
            rec._statweave_categorical_x=True
            rec.set_xlabel('Inspired CO₂', labelpad=6)
            offsets = {group: (i-(len(groups)-1)/2)*.14 for i, group in enumerate(groups)}
            if settings['show_points']:
                for row in recovery:
                    encoding = styles[row['group']]
                    rec.plot(positions[row['co2_percent']]+offsets[row['group']], row['value'],
                             linestyle='none', marker=encoding['marker'], color=encoding['color'],
                             markersize=4.5, markerfacecolor='white', markeredgewidth=.8, alpha=.75, zorder=2)
            for row in [r for r in summaries if r['phase'] == 'recovery']:
                encoding = styles[row['group']]
                x = positions[row['co2_percent']]+offsets[row['group']]
                rec.plot(x,row['mean'],marker=encoding['marker'],linestyle='none',color=encoding['color'],
                         markersize=5,markeredgecolor='white',markeredgewidth=.5,zorder=4)
                if settings['ci'] and row['sd'] is not None and row['n_subjects'] >= 2:
                    rec.errorbar(x,row['mean'],yerr=row['sd'],fmt='none',ecolor=encoding['color'],
                                 elinewidth=.8,capsize=2.5,capthick=.8,zorder=3)
            rec.set_xlim(-.5, len(rec_doses)-.5)
        if slopes:
            slope_ax = fig.add_subplot(grid[0, column]);_axes(slope_ax, size)
            slope_ax.set_title('Subject slopes', loc='left', fontsize=size+.5, pad=10)
            slope_unit = unit + '\nper %-point CO₂'
            slope_ax.set_ylabel(_wrap('Response slope', 20)+'\n('+_wrap(slope_unit, 22)+')',labelpad=7)
            for i, group in enumerate(groups):
                encoding = styles[group]
                rows = sorted([r for r in slopes if r['group'] == group], key=lambda r:r['subject'])
                if settings['show_points']:
                    offsets = np.linspace(-.12,.12,len(rows)) if len(rows)>1 else [0.]
                    slope_ax.plot([i+float(offset) for offset in offsets],[r['slope'] for r in rows],
                                  linestyle='none',marker=encoding['marker'],markersize=5,
                                  markerfacecolor='white',markeredgecolor=encoding['color'],markeredgewidth=1.,
                                  label='_recorded_subject_slope',zorder=3)
                summary = [r for r in slope_groups if r['group'] == group]
                for row in summary:
                    slope_ax.plot([i-.22,i+.22],[row['mean'],row['mean']],color=encoding['color'],linewidth=1.6,zorder=4)
                    if settings['ci'] and row.get('sd') is not None and row['n_subjects']>=2:
                        slope_ax.errorbar(i,row['mean'],yerr=row['sd'],fmt='none',ecolor=encoding['color'],
                                          elinewidth=.8,capsize=2.5,capthick=.8,zorder=2)
            slope_ax.set_xlim(-.5,len(groups)-.5)
            slope_ax.set_xticks(range(len(groups)),[_wrap(g,12) for g in groups])
            slope_ax._statweave_categorical_x=True
            if len(groups)>=3:
                slope_ax.set_xticklabels([_wrap(g,20) for g in groups],rotation=90,ha='center',va='top')
            slope_ax.axhline(0,color='#D8D8D4',linewidth=.6,zorder=0)
        legend_handles = [Line2D([],[],color=styles[g]['color'],linestyle=styles[g]['ls'],
                                 marker=styles[g]['marker'],markersize=4.5,linewidth=1.4,
                                 label=_group_n_label(g,summaries)) for g in groups]
        fig.legend(handles=legend_handles,loc='upper left',bbox_to_anchor=(.12,.92),
                   frameon=False,fontsize=size,ncol=min(len(groups),2),handlelength=2.2,
                   columnspacing=1.4,borderaxespad=0)
        title = settings.get('title', endpoint['label']+' across inspired CO₂')
        fig.text(.125,.98,_wrap(title,95),ha='left',va='top',fontsize=size+1.,fontweight='semibold')
        has_sd=any(row.get('sd') is not None and row.get('n_subjects',0)>=2 for row in summaries)
        note = ('Subject means; group mean ± SD' if has_sd and settings['ci'] else
                'Subject means; group means' if summaries else 'Separate trials; repeated observations')
        if not settings['show_points']:
            note += '; individual points hidden by request'
        fig.text(.125,.065,_wrap(note,100),ha='left',va='bottom',fontsize=size,color='#404040')
        fig._statweave_style = deepcopy(settings)
        fig._statweave_visual_spec = visual_spec(study,result,plan,style)
        fig._statweave_caption = figure_caption(study,result,plan,style)
        fig.canvas.draw()
        # Reserve enough physical margin for a multiline quantity/unit label;
        # never rescue a long scientific label by shrinking the font.
        for _ in range(3):
            bounds=ax.yaxis.label.get_window_extent(fig.canvas.get_renderer())
            if bounds.x0 >= 5:break
            _update_grid_margin(fig,grid,grid.left+(7-bounds.x0)/fig.bbox.width)
            fig.canvas.draw()
        _check_figure_text(fig)
        return fig


def figure_caption(study, result, plan=None, style=None):
    if isinstance(result,dict) and result.get('report') is True:
        available=_report_results(result);settings=_settings(plan,style)
        shown=min(4,len(available));blocked=sum(m.get('status')!='executed' for m in result['measures'])
        return (f'Measure-report overview showing the first {shown} of {len(available)} executed endpoints in inventory order. '
                'Each panel retains its own source quantity and units; quantities with different scales are not directly interchangeable. '
                'Only reviewed baseline/exposure points are shown in this overview; recovery remains separate in each complete individual measure figure. '
                'Thin trajectories and open symbols show recorded subject values after the trial rule, or recorded separate trials where selected. '
                +('Group markers and error bars show stored subject means ± sample SD where available; SD is not SEM or a confidence interval. ' if settings['ci'] else 'Group markers show stored means; interval display was disabled. ')
                +f'{blocked} unavailable or blocked endpoint(s) remain in the exported inventory with their reasons. '
                'Complete individual figures, per-endpoint captions, descriptive tables, source row identities and processing steps are included in the analysis export. '
                'Syringe-equivalent/raw/proxy quantities retain their source interpretation and are not promoted to calibrated physiological outcomes. '
                f'Figure size: {settings["width_mm"]:g} × {settings["height_mm"]:g} mm.')
    data, endpoint, pooling, normalization, points, summaries, slopes, _, groups = _validated(result)
    settings = _settings(plan, style)
    subjects = len({r['subject'] for r in points})
    label, unit = _quantity_label(endpoint,normalization)
    caption = f'{label} ({unit}) across the explicitly reviewed inspired CO₂ conditions. '
    if pooling == 'equal_within_subject':
        caption += f'Each thin trajectory shows one of {subjects} subjects after the recorded equal-trial aggregation; group markers show recorded arithmetic means of subject values. '
        if settings['ci']:
            caption += 'Error bars show the recorded sample SD across subjects where n ≥ 2; they are not SEM, confidence intervals or credible intervals. '
        else:
            caption += 'Interval display was disabled; no confidence or credible intervals are shown. '
    else:
        trials = len({(r['subject'],r['session']) for r in points})
        caption += f'Each trajectory represents one of {trials} separate trials from {subjects} subjects; trials and breaths are not treated as independent subjects, and no group interval is drawn. '
    if normalization != 'none':
        order = data.get('normalization_order',result.get('recipe',{}).get('options',{}).get('normalization_order','recorded in recipe'))
        caption += f'Normalization: {normalization}; order: {order}. The raw source quantity is {endpoint["label"]} ({endpoint["unit"]}). '
    if any(r['phase']=='recovery' for r in points):
        caption += 'Recovery is shown in a separate categorical panel, not merged with baseline or connected into the concentration-response series. Recovery group offsets separate symbols and have no quantitative meaning. '
    if slopes:
        fit = result.get('recipe',{}).get('options',{}).get('fit_doses',[])
        fit_text = ', '.join(f'{value:g}%' for value in fit) if fit else 'the recipe’s explicit dose range'
        caption += f'The slope panel shows stored per-subject ordinary least-squares slopes with a free intercept over {fit_text}; horizontal marks show recorded group mean slopes. Slope units are {unit} per percentage point inspired CO₂. Horizontal dot offsets are independent of slope values and have no quantitative meaning. '
    if 'syringe' in endpoint['column'].casefold() or 'syringe' in endpoint['calibration_class'].casefold():
        caption += 'Syringe-equivalent quantities retain their exported source scale; they are not thermobarometrically corrected physiological tidal volume, ventilation or calibrated HCVR. '
    if endpoint['column']=='RR_bpm' and slopes:
        caption += 'Frequency slopes are a respiratory-frequency response component, not minute-ventilation HCVR. '
    if 'penh' in endpoint['column'].casefold():
        caption += 'This exported PenH/legacy waveform-derived measure does not by itself establish airway resistance. '
    if isinstance(endpoint.get('caution'),str) and endpoint['caution'].strip():
        caption += endpoint['caution'].strip()+' '
    if not settings['show_points']:
        caption += 'Individual-point display was explicitly disabled; the recorded observations remain in the exported result tables. '
    accounting=result.get('row_accounting',{})
    caption += (f'Summary-window accounting: {accounting.get("total","unavailable")} total, '
                f'{accounting.get("used","unavailable")} used, {accounting.get("omitted","unavailable")} explicitly omitted. '
                'Physical row identities and reasons remain in the execution ledger; raw files are unchanged. '
                f'Figure size: {settings["width_mm"]:g} × {settings["height_mm"]:g} mm.')
    return caption
