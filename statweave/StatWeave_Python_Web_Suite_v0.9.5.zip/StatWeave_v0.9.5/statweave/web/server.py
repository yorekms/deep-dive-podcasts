"""FastAPI multi-user web server for the StatWeave Contributor Workbench.

Security & Scientific Invariants:
- Every Session runs with allow_host_paths=False inside an isolated per-user
  workspace (<data_dir>/workspaces/<user_id>), preventing host path traversal.
- Server-only OpenAI credentials never leave backend memory; raw spreadsheets
  never enter LLM prompts (only closed ApiToolbox schema & saved summaries).
- Every mutation acquires a per-project RLock, and Matplotlib rendering runs
  under a dedicated Agg render lock for thread safety.
- Uploaded OOXML archives pass zip_guard + macro inspection before import.
"""
from __future__ import annotations

from collections import OrderedDict
from copy import deepcopy
import hmac
import io
import json
import os
from pathlib import Path
import re
import shutil
import tempfile
import threading
from typing import Any, Callable
import zipfile

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt  # noqa: E402
import openpyxl  # noqa: E402

from fastapi import Depends, FastAPI, File, Form, HTTPException, Query, Request, Response, UploadFile  # noqa: E402
from fastapi.middleware.cors import CORSMiddleware  # noqa: E402
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, PlainTextResponse, RedirectResponse  # noqa: E402
from fastapi.staticfiles import StaticFiles  # noqa: E402
from pydantic import BaseModel, Field  # noqa: E402

from .. import __version__  # noqa: E402
from ..api_provider import OpenAIPlanner  # noqa: E402
from ..api_tools import inspect_data, safe_text  # noqa: E402
from ..figures import export_figure, figure_caption, make_figure  # noqa: E402
from ..planner import PLOTS, STYLE_KEYS  # noqa: E402
from ..scrubber import inspect_ooxml_workbook, zip_guard  # noqa: E402
from ..session import Session  # noqa: E402
from .config import WebConfig  # noqa: E402
from .corpus import (  # noqa: E402
    build_and_save_contribution_case,
    build_corpus_archive_bytes,
    capture_session_trajectory,
    scrub_contributor_identity_in_cases,
)
from .oauth import (  # noqa: E402
    OAuthError,
    exchange_github_code,
    exchange_orcid_code,
    github_authorize_url,
    orcid_authorize_url,
    render_popup_callback_html,
)
from .store import QuotaExceededError, WebStore  # noqa: E402

COOKIE_NAME = 'statweave_session'
STATIC_DIR = Path(__file__).resolve().parent / 'static'
ALLOWED_UPLOAD_SUFFIXES = {'.xlsx', '.xls', '.csv', '.tsv', '.txt', '.ods'}
MAX_CACHED_SESSIONS = 128

_FIGURE_RENDER_LOCK = threading.Lock()


# --- Request Schemas ---

class InviteLoginRequest(BaseModel):
    display_name: str = Field(min_length=2, max_length=120)
    invite_code: str = Field(default='', max_length=128)
    handle_or_orcid: str = Field(default='', max_length=120)
    affiliation: str = Field(default='', max_length=200)
    allow_private_evaluation: bool = False
    allow_model_training: bool = False
    allow_public_example_library: bool = False


class ConsentUpdateRequest(BaseModel):
    allow_private_evaluation: bool
    allow_model_training: bool
    allow_public_example_library: bool = False
    affiliation: str = Field(default='', max_length=200)


class DemoProjectRequest(BaseModel):
    kind: str = Field(default='clampflow', pattern='^(two_group|paired|clampflow|timecourse|survival)$')


class PasteProjectRequest(BaseModel):
    text: str = Field(min_length=3, max_length=500_000)
    title: str = Field(default='Pasted Table', max_length=120)


class SheetSwitchRequest(BaseModel):
    sheet: str = Field(min_length=1, max_length=120)


class ChatTurnRequest(BaseModel):
    message: str = Field(min_length=1, max_length=8_000)
    mode: str = Field(default='auto', pattern='^(auto|openai|offline)$')
    auto_execute: bool = False


class ChatStartRequest(BaseModel):
    message: str = Field(min_length=1, max_length=8_000)
    mode: str = Field(default='auto', pattern='^(auto|openai|offline)$')
    auto_execute: bool = True
    title: str = Field(default='Chat Working Sheet', max_length=120)


class GoogleSheetImportRequest(BaseModel):
    url: str = Field(min_length=8, max_length=2_000)
    title: str = Field(default='', max_length=120)


class RDatasetRequest(BaseModel):
    dataset_id: str = Field(min_length=2, max_length=120)


def _try_parse_chat_raw_numbers(message: str) -> dict[str, list[float]] | None:
    """Deterministic fallback parser for raw numbers typed in chat (e.g., 'Control: 12, 14, 15 vs Drug: 22, 25, 24')."""
    pattern = re.compile(
        r'([A-Za-z][A-Za-z0-9_ +/-]{0,30}?)\s*[:=]\s*([-+]?\d+(?:\.\d+)?(?:\s*[,;\s]\s*[-+]?\d+(?:\.\d+)?)+)'
    )
    groups: dict[str, list[float]] = {}
    for match in pattern.finditer(message):
        label = re.sub(r'^(?:vs\.?|versus|and)\s+', '', match.group(1).strip(), flags=re.I).strip() or f'Group_{len(groups) + 1}'
        nums = [float(x) for x in re.findall(r'[-+]?\d+(?:\.\d+)?', match.group(2))]
        if len(nums) >= 2:
            groups[label[:40]] = nums
    if len(groups) >= 1 and sum(len(v) for v in groups.values()) >= 3:
        return groups
    return None


class ProposalApproveRequest(BaseModel):
    proposal_id: str | None = Field(default=None, max_length=64)


class FigureStyleRequest(BaseModel):
    plot: str | None = Field(default=None, max_length=32)
    style: dict[str, Any] = Field(default_factory=dict)


class ApplyCardRequest(BaseModel):
    prep_ops: list[dict[str, Any]] = Field(default_factory=list, max_length=8)
    plan: dict[str, Any] | None = None
    style: dict[str, Any] | None = None


class FeedbackRequest(BaseModel):
    rating: str = Field(pattern='^(up|down)$')
    note: str = Field(default='', max_length=1_000)


class ContributeCaseRequest(BaseModel):
    title: str = Field(default='', max_length=180)
    summary: str = Field(default='', max_length=2_000)
    scientific_question: str = Field(default='', max_length=500)
    human_subjects_category: str = Field(default='non_human_or_in_vitro', max_length=64)
    allow_public_example_library: bool | None = None


def _build_synthetic_clampflow_workbook(target: Path) -> Path:
    wb = openpyxl.Workbook()
    ws1 = wb.active
    ws1.title = '1_Master_Wide'
    ws1.append(['Cell_ID', 'Animal_ID', 'Group', 'RMP_mV', 'Rin_MOhms', 'Rheobase_pA', 'AP_Peak_mV', 'APD50_ms', 'MaxFiringRate_Hz'])
    rows = [
        ('C01', 'M1', 'Vehicle', -68.4, 182.0, 90.0, 83.2, 1.18, 28.0),
        ('C02', 'M1', 'Vehicle', -67.1, 176.5, 95.0, 81.9, 1.21, 26.5),
        ('C03', 'M2', 'Vehicle', -69.2, 190.2, 85.0, 84.5, 1.15, 29.0),
        ('C04', 'M2', 'Vehicle', -68.0, 184.1, 90.0, 82.8, 1.19, 27.5),
        ('C05', 'M3', 'Vehicle', -66.8, 171.0, 100.0, 80.4, 1.24, 25.0),
        ('C06', 'M4', 'Drug_X', -61.5, 228.4, 55.0, 92.6, 0.91, 44.0),
        ('C07', 'M4', 'Drug_X', -60.8, 235.0, 50.0, 94.1, 0.88, 46.5),
        ('C08', 'M5', 'Drug_X', -62.1, 219.5, 60.0, 91.2, 0.94, 41.0),
        ('C09', 'M5', 'Drug_X', -60.2, 241.0, 45.0, 95.3, 0.86, 48.0),
        ('C10', 'M6', 'Drug_X', -61.9, 225.8, 55.0, 92.0, 0.92, 43.0),
    ]
    for r in rows:
        ws1.append(list(r))

    ws2 = wb.create_sheet('2_PerSweep_LONG')
    ws2.append(['Cell_ID', 'Animal_ID', 'Group', 'Sweep', 'Step_pA', 'AP_Peak_mV', 'Upstroke_Vs'])
    for cell_id, animal_id, grp, _rmp, _rin, _rheo, base_peak, _apd, _fr in rows:
        for sw, step in ((1, 100), (2, 150), (3, 200)):
            ws2.append([
                cell_id, animal_id, grp, sw, step,
                round(base_peak + (sw - 2) * 0.9, 2),
                round((135.0 if grp == 'Vehicle' else 178.0) + sw * 3.5, 2),
            ])

    for tab in ('3_PerSweep_WIDE', '4_Master_LONG', '5_ISI_Matrix', '6_Phase_Data'):
        ws = wb.create_sheet(tab)
        ws.append(['Cell_ID', 'Group', 'Note'])
        ws.append(['C01', 'Vehicle', f'Synthetic {tab} summary'])

    wb.save(target)
    return target


def create_app(
    config: WebConfig | None = None,
    model_factory: Callable[[WebConfig], Any] | None = None,
    oauth_transport: Any = None,
    r2_transport: Any = None,
) -> FastAPI:
    cfg = config or WebConfig.from_env()
    cfg.data_dir.mkdir(parents=True, exist_ok=True)
    (cfg.data_dir / 'workspaces').mkdir(parents=True, exist_ok=True)
    (cfg.data_dir / 'corpus').mkdir(parents=True, exist_ok=True)

    store = WebStore(cfg.data_dir / 'statweave_web.sqlite3', cfg.session_secret)

    app = FastAPI(
        title='StatWeave Contributor Workbench API',
        version=__version__,
        docs_url='/api/docs',
        redoc_url=None,
    )
    app.state.config = cfg
    app.state.store = store
    app.state.model_factory = model_factory
    app.state.oauth_transport = oauth_transport
    app.state.r2_transport = r2_transport
    app.state.cache_lock = threading.Lock()
    app.state.session_cache: OrderedDict[tuple[str, str], tuple[threading.RLock, Session]] = OrderedDict()

    app.add_middleware(
        CORSMiddleware,
        allow_origins=list(cfg.allowed_origins),
        allow_credentials=True,
        allow_methods=['GET', 'POST', 'OPTIONS'],
        allow_headers=['Authorization', 'Content-Type'],
    )

    @app.middleware('http')
    async def security_headers(request: Request, call_next):
        response = await call_next(request)
        response.headers['X-Content-Type-Options'] = 'nosniff'
        response.headers['Referrer-Policy'] = 'strict-origin-when-cross-origin'
        ancestors = ' '.join(dict.fromkeys(["'self'", 'https://*.carrd.co', 'https://carrd.co', *cfg.allowed_origins]))
        response.headers['Content-Security-Policy'] = f'frame-ancestors {ancestors};'
        return response

    if STATIC_DIR.is_dir():
        app.mount('/static', StaticFiles(directory=str(STATIC_DIR)), name='static')

    # --- Helpers ---

    def _user_workspace(user_id: str) -> Path:
        root = (cfg.data_dir / 'workspaces').resolve()
        ws = (root / user_id).resolve()
        if not ws.is_relative_to(root):
            raise HTTPException(status_code=400, detail='Invalid user workspace.')
        ws.mkdir(parents=True, exist_ok=True)
        return ws

    def _put_cached_session(user_id: str, project_id: str, session: Session) -> tuple[threading.RLock, Session]:
        with app.state.cache_lock:
            key = (user_id, project_id)
            if key in app.state.session_cache:
                lock, _ = app.state.session_cache.pop(key)
            else:
                lock = threading.RLock()
            app.state.session_cache[key] = (lock, session)
            while len(app.state.session_cache) > MAX_CACHED_SESSIONS:
                app.state.session_cache.popitem(last=False)
            return lock, session

    def _load_user_session(user_id: str, project_id: str) -> tuple[dict, threading.RLock, Session]:
        meta = store.get_user_project(project_id, user_id)
        if not meta:
            raise HTTPException(status_code=404, detail='Project not found.')
        ws = _user_workspace(user_id)
        proj_dir = (ws / meta['project_dir_rel']).resolve()
        if not proj_dir.is_relative_to(ws) or not (proj_dir / 'project.json').is_file():
            raise HTTPException(status_code=404, detail='Project files are unavailable.')

        key = (user_id, project_id)
        with app.state.cache_lock:
            cached = app.state.session_cache.get(key)
            if cached is not None:
                app.state.session_cache.move_to_end(key)
                return meta, cached[0], cached[1]

        sess = Session(ws, allow_host_paths=False)
        sess.style['dpi'] = 300
        sess.defer_figure_validation = True
        sess.open_project(proj_dir, recover=True)
        lock, sess = _put_cached_session(user_id, project_id, sess)
        return meta, lock, sess

    def _extract_token(request: Request) -> str | None:
        auth = request.headers.get('Authorization', '')
        if auth.lower().startswith('bearer '):
            return auth[7:].strip()
        cookie_tok = request.cookies.get(COOKIE_NAME)
        return cookie_tok.strip() if cookie_tok else None

    def _set_auth_cookie(response: Response, token: str) -> None:
        secure = cfg.public_base_url.startswith('https://')
        response.set_cookie(
            key=COOKIE_NAME,
            value=token,
            max_age=cfg.session_ttl_seconds,
            httponly=True,
            secure=secure,
            samesite='none' if secure else 'lax',
            path='/',
        )
        if secure and 'set-cookie' in response.headers:
            raw_hdrs = response.headers.getlist('set-cookie')
            del response.headers['set-cookie']
            for hdr in raw_hdrs:
                if hdr.startswith(f'{COOKIE_NAME}=') and 'partitioned' not in hdr.lower():
                    hdr = f'{hdr}; Partitioned'
                response.headers.append('set-cookie', hdr)

    def get_current_user(request: Request) -> dict:
        tok = _extract_token(request)
        user = store.verify_session_token(tok)
        if not user:
            raise HTTPException(status_code=401, detail='Sign in with ORCID, GitHub, or a Lab Invite Code to continue.')
        return user

    def get_consented_user(user: dict = Depends(get_current_user)) -> dict:
        if not user['permissions']['contributor_ready']:
            raise HTTPException(
                status_code=403,
                detail='Accept the StatWeave Contributor Beta terms (deidentified evaluation & training consent) before analyzing data.',
            )
        return user

    def require_admin(request: Request) -> None:
        if not cfg.admin_token:
            raise HTTPException(status_code=503, detail='Maintainer admin API is disabled (STATWEAVE_ADMIN_TOKEN not set).')
        tok = _extract_token(request) or ''
        if not hmac.compare_digest(tok, cfg.admin_token):
            raise HTTPException(status_code=403, detail='Invalid maintainer admin token.')

    def _render_svg_preview(session: Session) -> tuple[str | None, str | None]:
        if session.dataset is None or session.result is None:
            return None, None
        with _FIGURE_RENDER_LOCK:
            fig = None
            try:
                fig = make_figure(session.dataset, session.result, session.plan, session.style)
                buf = io.StringIO()
                fig.savefig(buf, format='svg', bbox_inches='tight', facecolor='white')
                caption = figure_caption(session.dataset, session.result, session.plan, session.style)
                return buf.getvalue(), caption
            except Exception as err:
                return None, f'Figure preview needs adjustment: {safe_text(str(err), 300)}'
            finally:
                if fig is not None:
                    plt.close(fig)

    def _serialize_workspace(user: dict, meta: dict, session: Session) -> dict:
        ds = session.dataset
        schema = inspect_data(session) if ds is not None else {}
        preview_rows = []
        columns = []
        row_numbers = []
        if ds is not None and hasattr(ds, 'df'):
            columns = [str(c) for c in ds.df.columns]
            sub = ds.df.iloc[:150]
            row_numbers = [int(r) for r in ds.row_numbers[:150]]
            for _, row in sub.iterrows():
                preview_rows.append([None if (v is None or (isinstance(v, float) and v != v)) else str(v) if not isinstance(v, (int, float, bool)) else v for v in row.tolist()])

        svg_markup, caption = _render_svg_preview(session)
        api_prop = session.context.get('api_proposal')
        pending_summary = None
        if api_prop:
            pending_summary = {
                'proposal_id': api_prop.get('proposal_id'),
                'kind': api_prop.get('kind'),
                'preview': api_prop.get('preview'),
            }

        audit_tail = []
        if session.project_dir and (session.project_dir / 'history.jsonl').is_file():
            lines = (session.project_dir / 'history.jsonl').read_text(encoding='utf-8').splitlines()[-40:]
            for ln in lines:
                try:
                    ev = json.loads(ln)
                    audit_tail.append({
                        'time_utc': ev.get('time_utc'),
                        'type': ev.get('type'),
                        'hash_prefix': str(ev.get('hash', ''))[:12],
                    })
                except Exception:
                    continue

        visible_sheets = list(getattr(ds, 'sheets', []))
        if ds is not None and getattr(ds, 'source_path', None) and Path(ds.source_path).suffix.lower() in {'.xlsx', '.xlsm'}:
            hidden_set = set(inspect_ooxml_workbook(ds.source_path).get('hidden_sheets') or ())
            if hidden_set:
                visible_sheets = [s for s in visible_sheets if s not in hidden_set]

        from ..explore import build_spreadsheet_overview
        spreadsheet_overview = build_spreadsheet_overview(ds)

        return {
            'project': meta,
            'schema': schema,
            'spreadsheet_overview': spreadsheet_overview,
            'source': {
                'filename': Path(ds.source_path).name if ds and getattr(ds, 'source_path', None) else meta['title'],
                'sha256': getattr(ds, 'source_hash', meta['source_sha256']),
                'is_clampflow': bool(getattr(ds, 'is_clampflow', False)),
                'sheets': visible_sheets,
                'active_sheet': getattr(ds, 'sheet', None),
                'row_count': int(len(ds.df)) if ds is not None and hasattr(ds, 'df') else 0,
                'column_count': len(columns),
                'warnings': list(getattr(ds, 'warnings', [])),
            },
            'preview_table': {
                'columns': columns,
                'row_numbers': row_numbers,
                'rows': preview_rows,
                'truncated': bool(ds is not None and hasattr(ds, 'df') and len(ds.df) > 150),
            },
            'conversation': [
                {'role': m.get('role', 'assistant'), 'text': safe_text(str(m.get('text', '')), 12000)}
                for m in session.conversation[-60:]
            ],
            'pending_proposal': pending_summary,
            'working_sheets': list(session.context.get('working_sheets') or []),
            'plan': session.plan,
            'style': session.style,
            'result': session.result,
            'figure_svg': svg_markup,
            'figure_caption': caption,
            'audit_events': audit_tail,
            'quota': store.usage_status(
                user['user_id'],
                cfg.daily_turn_limit,
                cfg.monthly_turn_limit,
                cfg.daily_token_limit,
            ),
        }

    def _build_openai_model() -> Any:
        if app.state.model_factory is not None:
            return app.state.model_factory(cfg)
        if not cfg.openai_enabled:
            return None
        from ..api_provider import DEFAULT_MODEL, OpenAIError
        from .browser_runtime import _is_model_unavailable_error
        if cfg.is_gemini_key:
            from ..gemini_provider import GEMINI_DEFAULT_MODEL, GeminiPlanner
            primary_g = cfg.openai_model if cfg.openai_model.startswith(('gemini-', 'gemma-')) else GEMINI_DEFAULT_MODEL
            candidates = list(dict.fromkeys([primary_g, 'gemini-4-hydrogen', 'gemini-4-argon', 'gemini-3.5-flash-lite']))

            def _make_single(model_name: str) -> Any:
                return GeminiPlanner(
                    credential_resolver=cfg.resolve_openai_key,
                    model=model_name,
                    timeout=cfg.openai_timeout,
                )
        else:
            candidates = list(dict.fromkeys([cfg.openai_model, DEFAULT_MODEL, 'gpt-4.1-mini', 'gpt-4o-mini']))

            def _make_single(model_name: str) -> Any:
                return OpenAIPlanner(
                    credential_resolver=cfg.resolve_openai_key,
                    model=model_name,
                    timeout=cfg.openai_timeout,
                )

        class _ServerFallbackPlanner:
            provider = 'gemini' if cfg.is_gemini_key else 'openai'
            supports_tools = True
            cancelled = False

            def __init__(self) -> None:
                self.model = candidates[0]

            def converse(self, text: str, toolbox: Any, dialogue: Any = None, context: Any = None) -> dict[str, Any]:
                last_err: Exception | None = None
                for idx, cand in enumerate(candidates):
                    inner = _make_single(cand)
                    try:
                        out = inner.converse(text, toolbox, dialogue=dialogue, context=context)
                        self.model = inner.model
                        return out
                    except OpenAIError as err:
                        last_err = err
                        ran_tools = bool(getattr(toolbox, 'tool_names', None))
                        if not ran_tools and idx + 1 < len(candidates) and _is_model_unavailable_error(str(err)):
                            continue
                        raise
                assert last_err is not None
                raise last_err

            def check_connection(self) -> dict[str, Any]:
                last_err: Exception | None = None
                for idx, cand in enumerate(candidates):
                    inner = _make_single(cand)
                    try:
                        out = inner.check_connection()
                        self.model = inner.model
                        return out
                    except OpenAIError as err:
                        last_err = err
                        if idx + 1 < len(candidates) and _is_model_unavailable_error(str(err)):
                            continue
                        raise
                assert last_err is not None
                raise last_err

        return _ServerFallbackPlanner()

    # --- Public & Portal Routes ---

    @app.get('/healthz')
    def healthz():
        return {
            'status': 'ok',
            'version': __version__,
            'openai_configured': cfg.openai_enabled,
            'github_oauth_enabled': cfg.github_enabled,
            'orcid_oauth_enabled': cfg.orcid_enabled,
            'ephemeral_secret_warning': cfg.ephemeral_secret_warning,
        }

    @app.get('/', response_class=HTMLResponse)
    @app.get('/app', response_class=HTMLResponse)
    def serve_workbench():
        index_file = STATIC_DIR / 'index.html'
        if not index_file.is_file():
            return HTMLResponse('<h1>StatWeave Web Workbench</h1><p>Static bundle missing.</p>', status_code=500)
        return HTMLResponse(index_file.read_text(encoding='utf-8'))

    @app.get('/portal/statweave-portal.js')
    def serve_carrd_portal_script():
        template_file = STATIC_DIR / 'statweave-portal.js'
        raw = template_file.read_text(encoding='utf-8')
        rendered = (
            raw.replace('__STATWEAVE_PUBLIC_BASE_URL__', cfg.public_base_url)
            .replace('__STATWEAVE_CARRD_URL__', cfg.carrd_portal_url)
            .replace('__CLAMPFLOW_CARRD_URL__', cfg.clampflow_portal_url)
        )
        return Response(content=rendered, media_type='application/javascript; charset=utf-8')

    # --- Auth & Consent Routes ---

    @app.get('/api/auth/config')
    def auth_config():
        return cfg.public_auth_config()

    @app.post('/api/auth/invite')
    def auth_invite_login(body: InviteLoginRequest, response: Response):
        auth_cfg = cfg.public_auth_config()
        if not auth_cfg['invite_login_enabled']:
            raise HTTPException(status_code=403, detail='Direct invite login is disabled; sign in with ORCID or GitHub.')
        if cfg.invite_code:
            if not hmac.compare_digest(body.invite_code.strip(), cfg.invite_code):
                raise HTTPException(status_code=403, detail='Invalid lab invite code.')
        if not (body.allow_private_evaluation and body.allow_model_training):
            raise HTTPException(
                status_code=400,
                detail='Check the Contributor Beta consent box (private evaluation & model training) to sign in.',
            )
        subj_seed = (body.handle_or_orcid.strip() or body.display_name.strip()).lower()
        subj_hash = hmac.new(cfg.session_secret.encode('utf-8'), subj_seed.encode('utf-8'), 'sha256').hexdigest()[:24]
        user = store.upsert_user(
            auth_provider='invite',
            provider_subject=subj_hash,
            display_name=body.display_name,
            handle_or_orcid=body.handle_or_orcid or None,
            affiliation=body.affiliation or None,
            allow_private_evaluation=True,
            allow_model_training=True,
            allow_public_example_library=body.allow_public_example_library,
        )
        tok = store.create_session_token(user['user_id'], cfg.session_ttl_seconds)
        _set_auth_cookie(response, tok)
        return {'token': tok, 'user': user}

    @app.get('/api/auth/github/start')
    def github_start(popup: bool = Query(default=False), invite_code: str = Query(default='')):
        if not cfg.github_enabled:
            raise HTTPException(status_code=400, detail='GitHub OAuth is not configured on this server.')
        invite_ok = True
        if cfg.invite_code and cfg.require_invite_code:
            if not hmac.compare_digest(invite_code.strip(), cfg.invite_code):
                raise HTTPException(status_code=403, detail='Enter a valid lab invite code before starting OAuth.')
        state = store.create_oauth_state('github', popup=popup, invite_verified=invite_ok)
        return RedirectResponse(github_authorize_url(cfg, state), status_code=302)

    @app.get('/api/auth/github/callback')
    def github_callback(code: str = Query(default=''), state: str = Query(default='')):
        st = store.consume_oauth_state(state, 'github')
        if not st or not code:
            raise HTTPException(status_code=400, detail='OAuth state expired or invalid. Try signing in again.')
        try:
            prof = exchange_github_code(cfg, code, transport=app.state.oauth_transport)
        except OAuthError as err:
            raise HTTPException(status_code=400, detail=str(err)) from None
        user = store.upsert_user(**prof)
        tok = store.create_session_token(user['user_id'], cfg.session_ttl_seconds)
        if st['popup']:
            resp = HTMLResponse(render_popup_callback_html(tok, user, cfg.allowed_origins, f'{cfg.public_base_url}/app'))
        else:
            resp = RedirectResponse(f'{cfg.public_base_url}/app', status_code=302)
        _set_auth_cookie(resp, tok)
        return resp

    @app.get('/api/auth/orcid/start')
    def orcid_start(popup: bool = Query(default=False), invite_code: str = Query(default='')):
        if not cfg.orcid_enabled:
            raise HTTPException(status_code=400, detail='ORCID OAuth is not configured on this server.')
        invite_ok = True
        if cfg.invite_code and cfg.require_invite_code:
            if not hmac.compare_digest(invite_code.strip(), cfg.invite_code):
                raise HTTPException(status_code=403, detail='Enter a valid lab invite code before starting OAuth.')
        state = store.create_oauth_state('orcid', popup=popup, invite_verified=invite_ok)
        return RedirectResponse(orcid_authorize_url(cfg, state), status_code=302)

    @app.get('/api/auth/orcid/callback')
    def orcid_callback(code: str = Query(default=''), state: str = Query(default='')):
        st = store.consume_oauth_state(state, 'orcid')
        if not st or not code:
            raise HTTPException(status_code=400, detail='OAuth state expired or invalid. Try signing in again.')
        try:
            prof = exchange_orcid_code(cfg, code, transport=app.state.oauth_transport)
        except OAuthError as err:
            raise HTTPException(status_code=400, detail=str(err)) from None
        user = store.upsert_user(**prof)
        tok = store.create_session_token(user['user_id'], cfg.session_ttl_seconds)
        if st['popup']:
            resp = HTMLResponse(render_popup_callback_html(tok, user, cfg.allowed_origins, f'{cfg.public_base_url}/app'))
        else:
            resp = RedirectResponse(f'{cfg.public_base_url}/app', status_code=302)
        _set_auth_cookie(resp, tok)
        return resp

    @app.get('/api/auth/me')
    def auth_me(user: dict = Depends(get_current_user)):
        return {
            'user': user,
            'quota': store.usage_status(
                user['user_id'],
                cfg.daily_turn_limit,
                cfg.monthly_turn_limit,
                cfg.daily_token_limit,
            ),
            'config': cfg.public_auth_config(),
        }

    @app.post('/api/auth/consent')
    def auth_consent(body: ConsentUpdateRequest, user: dict = Depends(get_current_user)):
        try:
            updated = store.update_consent(
                user_id=user['user_id'],
                allow_private_evaluation=body.allow_private_evaluation,
                allow_model_training=body.allow_model_training,
                allow_public_example_library=body.allow_public_example_library,
                affiliation=body.affiliation or None,
            )
        except ValueError as err:
            raise HTTPException(status_code=400, detail=str(err)) from None
        return {'user': updated}

    @app.post('/api/auth/logout')
    def auth_logout(request: Request, response: Response):
        tok = _extract_token(request)
        store.revoke_session_token(tok)
        response.delete_cookie(COOKIE_NAME, path='/')
        return {'status': 'logged_out'}

    # --- Project Creation & Intake ---

    @app.get('/api/projects')
    def list_projects(user: dict = Depends(get_consented_user)):
        return {
            'projects': store.list_user_projects(user['user_id']),
            'quota': store.usage_status(
                user['user_id'],
                cfg.daily_turn_limit,
                cfg.monthly_turn_limit,
                cfg.daily_token_limit,
            ),
        }

    def _enforce_project_limit(user_id: str) -> None:
        if store.count_user_projects(user_id) >= cfg.max_projects_per_user:
            raise HTTPException(
                status_code=429,
                detail=f'Maximum saved workspace limit ({cfg.max_projects_per_user}) reached for this account.',
            )

    @app.post('/api/projects/demo')
    def create_demo_project(body: DemoProjectRequest, user: dict = Depends(get_consented_user)):
        _enforce_project_limit(user['user_id'])
        ws = _user_workspace(user['user_id'])
        sess = Session(ws, allow_host_paths=False)
        sess.style['dpi'] = 300
        sess.defer_figure_validation = True

        repo_examples = Path(__file__).resolve().parents[2] / 'examples'
        with tempfile.TemporaryDirectory(dir=ws) as tmp_str:
            tmp_dir = Path(tmp_str)
            if body.kind == 'clampflow':
                demo_path = _build_synthetic_clampflow_workbook(tmp_dir / 'Synthetic_ClampFlow_Compiled.xlsx')
                title = 'Synthetic ClampFlow 6-Tab AP Sheet'
            elif body.kind == 'timecourse':
                demo_path = tmp_dir / 'Wt_v_KO_time_demo.xlsx'
                wb_tc = openpyxl.Workbook()
                ws_tc = wb_tc.active
                ws_tc.title = 'Sheet1'
                ws_tc.append([None, 'Wt-1', 'Wt-2', 'Wt-3', 'Ko-1', 'Ko-2', 'Ko-3'])
                ws_tc.append(['2026-01-01', 14.8, 15.6, 14.9, 14.5, 15.1, 14.7])
                ws_tc.append(['2026-01-02', 15.2, 16.0, 15.4, 21.8, 23.4, 22.1])
                ws_tc.append(['2026-01-03', 15.5, 15.9, 15.1, 29.4, 31.2, 28.9])
                ws_tc.append(['2026-01-04', 15.0, 16.2, 15.3, 36.1, 38.5, 35.8])
                wb_tc.save(demo_path)
                title = 'Synthetic WT vs KO Timecourse'
            elif body.kind == 'paired':
                src_ex = repo_examples / 'paired_measurements.csv'
                demo_path = tmp_dir / 'paired_measurements.csv'
                if src_ex.is_file():
                    shutil.copyfile(src_ex, demo_path)
                else:
                    demo_path.write_text('Before,After\n12.4,18.1\n11.9,17.5\n13.1,19.4\n12.0,16.8\n12.7,18.9\n', encoding='utf-8')
                title = 'Synthetic Paired Before/After Table'
            elif body.kind == 'survival':
                demo_path = tmp_dir / 'Preclinical_Survival_Cohort.csv'
                surv_lines = [
                    'Subject_ID,Group,Time_Days,Event_Status',
                    'S01,Vehicle,18,1', 'S02,Vehicle,24,1', 'S03,Vehicle,29,1', 'S04,Vehicle,34,0',
                    'S05,Vehicle,38,1', 'S06,Vehicle,42,1', 'S07,Vehicle,47,1', 'S08,Vehicle,53,1',
                    'S09,Vehicle,59,1', 'S10,Vehicle,64,0', 'S11,Vehicle,68,1', 'S12,Vehicle,74,1',
                    'S13,Vehicle,81,1', 'S14,Vehicle,89,1', 'S15,Vehicle,96,1', 'S16,Vehicle,112,0',
                    'S17,Drug_X,36,1', 'S18,Drug_X,49,0', 'S19,Drug_X,58,1', 'S20,Drug_X,71,1',
                    'S21,Drug_X,84,0', 'S22,Drug_X,95,1', 'S23,Drug_X,108,1', 'S24,Drug_X,119,0',
                    'S25,Drug_X,128,1', 'S26,Drug_X,142,1', 'S27,Drug_X,155,0', 'S28,Drug_X,164,1',
                    'S29,Drug_X,180,0', 'S30,Drug_X,180,0', 'S31,Drug_X,180,0', 'S32,Drug_X,180,0',
                ]
                demo_path.write_text('\n'.join(surv_lines) + '\n', encoding='utf-8')
                title = 'Synthetic Kaplan–Meier Survival Study'
            else:
                src_ex = repo_examples / 'independent_groups.csv'
                demo_path = tmp_dir / 'independent_groups.csv'
                if src_ex.is_file():
                    shutil.copyfile(src_ex, demo_path)
                else:
                    demo_path.write_text('Treatment,Score\nControl,10.2\nControl,11.4\nControl,10.8\nDrug,16.5\nDrug,17.9\nDrug,17.1\n', encoding='utf-8')
                title = 'Synthetic 2-Group Comparison'

            ds = sess.import_file(demo_path)
            sess.context['synthetic_demo'] = True
            from ..explore import build_spreadsheet_welcome_message
            msg = build_spreadsheet_welcome_message(ds, source_label=demo_path.name)
            sess.conversation.append({'role': 'assistant', 'text': 'Synthetic demonstration dataset.\n\n' + msg})
            sess.save()

        detected = 'clampflow_6tab' if getattr(ds, 'is_clampflow', False) else 'table'
        rel = str(sess.project_dir.relative_to(ws))
        meta = store.register_project(user['user_id'], rel, title, detected, ds.source_hash)
        _put_cached_session(user['user_id'], meta['project_id'], sess)
        return _serialize_workspace(user, meta, sess)

    @app.get('/api/r_datasets')
    def list_r_learning_datasets(user: dict = Depends(get_consented_user)):
        from ..r_learning_set import list_r_datasets
        items = list_r_datasets()
        return {'count': len(items), 'datasets': items}

    @app.post('/api/projects/r_dataset')
    def create_r_dataset_project(body: RDatasetRequest, user: dict = Depends(get_consented_user)):
        from ..explore import build_spreadsheet_welcome_message
        from ..r_learning_set import get_r_dataset_entry

        _enforce_project_limit(user['user_id'])
        try:
            entry = get_r_dataset_entry(body.dataset_id)
        except KeyError as err:
            raise HTTPException(status_code=404, detail=safe_text(str(err), 300)) from None

        ws = _user_workspace(user['user_id'])
        sess = Session(ws, allow_host_paths=False)
        sess.style['dpi'] = 300
        sess.defer_figure_validation = True

        with tempfile.TemporaryDirectory(dir=ws) as tmp_str:
            csv_path = Path(tmp_str) / f"{entry['id']}.csv"
            csv_path.write_text(entry['csv'], encoding='utf-8')
            ds = sess.import_file(csv_path)
            sess.context['r_learning_dataset'] = {
                'id': entry['id'],
                'r_ref': entry['r_ref'],
                'archetype': entry['archetype'],
                'title': entry['title'],
            }
            msg = build_spreadsheet_welcome_message(ds, source_label=f"{entry['r_ref']} ({entry['id']}.csv)")
            prompts_md = '\n'.join(f'- *"{p}"*' for p in (entry.get('sample_prompts') or [])[:2])
            header = (
                f"**📚 R Repository Learning Set — `{entry['r_ref']}`**\n"
                f"{entry['title']} · *{entry['archetype']}* (numerically cross-verified against R `Rscript` to `< 1e-12`).\n\n"
            )
            extra = f"\n\n**Try asking in chat:**\n{prompts_md}" if prompts_md else ''
            sess.conversation.append({'role': 'assistant', 'text': header + msg + extra})
            sess.save()

        title = f"R: {entry['r_ref']} — {entry['title']}"[:120]
        rel = str(sess.project_dir.relative_to(ws))
        meta = store.register_project(user['user_id'], rel, title, 'r_learning_set', ds.source_hash)
        _put_cached_session(user['user_id'], meta['project_id'], sess)
        return _serialize_workspace(user, meta, sess)

    def _import_google_sheet_project(url: str, title: str, user: dict) -> dict:
        from ..working_sheets import fetch_google_sheet_xlsx, parse_google_sheets_url
        _enforce_project_limit(user['user_id'])
        try:
            doc_id, gid_str = parse_google_sheets_url(url)
            fetcher = getattr(app.state, 'gsheet_fetcher', None) or fetch_google_sheet_xlsx
            fetched = fetcher(url, max_bytes=cfg.max_upload_bytes)
            xlsx_bytes = fetched[0] if isinstance(fetched, tuple) else fetched
        except ValueError as err:
            raise HTTPException(status_code=400, detail=safe_text(str(err), 600)) from None

        ws = _user_workspace(user['user_id'])
        slug = ''.join(c if c.isalnum() or c in '-_' else '_' for c in (title.strip() or f'google_sheet_{doc_id[:10]}'))[:60] or 'google_sheet'
        with tempfile.TemporaryDirectory(dir=ws) as tmp_str:
            staged = Path(tmp_str) / f'{slug}.xlsx'
            staged.write_bytes(xlsx_bytes)
            max_expanded = min(128 * 1024 * 1024, max(4 * 1024 * 1024, len(xlsx_bytes) * 200))
            try:
                zip_guard(staged, max_uncompressed_bytes=max_expanded)
            except ValueError as err:
                raise HTTPException(status_code=400, detail=safe_text(str(err), 500)) from None
            info = inspect_ooxml_workbook(staged)
            if info.get('has_vba_macros'):
                raise HTTPException(status_code=400, detail='Workbooks containing embedded VBA macros are rejected.')

            target_sheet = None
            if gid_str and gid_str.isdigit():
                try:
                    wb_meta = openpyxl.load_workbook(staged, read_only=True, data_only=True)
                    try:
                        for ws_obj in wb_meta.worksheets:
                            if getattr(ws_obj, 'sheet_state', 'visible') == 'visible' and getattr(getattr(ws_obj, 'sheet_properties', None), 'sheetId', None) == int(gid_str):
                                target_sheet = ws_obj.title
                                break
                    finally:
                        wb_meta.close()
                except Exception:
                    target_sheet = None

            sess = Session(ws, allow_host_paths=False)
            sess.style['dpi'] = 300
            sess.defer_figure_validation = True
            try:
                ds = sess.import_file(staged, sheet=target_sheet)
            except ValueError as err:
                raise HTTPException(status_code=400, detail=safe_text(str(err), 600)) from None
            sess.context['origin'] = 'google_sheets_import'
            from ..explore import build_spreadsheet_welcome_message
            msg = build_spreadsheet_welcome_message(ds, source_label=f'{slug}.xlsx')
            sess.conversation.append({'role': 'assistant', 'text': 'Imported from Google Sheets.\n\n' + msg})
            sess.save()

        detected = 'clampflow_6tab' if getattr(ds, 'is_clampflow', False) else 'google_sheet'
        rel = str(sess.project_dir.relative_to(ws))
        clean_title = (title.strip() or f'Google Sheet ({ds.sheet or doc_id[:8]})')[:120]
        meta = store.register_project(user['user_id'], rel, clean_title, detected, ds.source_hash)
        _put_cached_session(user['user_id'], meta['project_id'], sess)
        capture_session_trajectory(
            cfg, store, user, meta, sess, 'google_sheet_import',
            figure_lock=_FIGURE_RENDER_LOCK, r2_transport=app.state.r2_transport,
        )
        return _serialize_workspace(user, meta, sess)

    @app.post('/api/projects/gsheet')
    def import_google_sheet_route(body: GoogleSheetImportRequest, user: dict = Depends(get_consented_user)):
        return _import_google_sheet_project(body.url, body.title, user)

    @app.post('/api/projects/paste')
    def create_pasted_project(body: PasteProjectRequest, user: dict = Depends(get_consented_user)):
        stripped = body.text.strip()
        if stripped.startswith('https://docs.google.com/spreadsheets/') and '\n' not in stripped and ' ' not in stripped:
            return _import_google_sheet_project(stripped, body.title if body.title != 'Pasted Table' else '', user)
        _enforce_project_limit(user['user_id'])
        if len(body.text) > cfg.max_paste_chars:
            raise HTTPException(status_code=413, detail=f'Pasted table exceeds {cfg.max_paste_chars:,} characters.')
        ws = _user_workspace(user['user_id'])
        sess = Session(ws, allow_host_paths=False)
        sess.style['dpi'] = 300
        sess.defer_figure_validation = True
        try:
            paste_name = f"{(body.title or 'pasted_table').strip()[:80]}.tsv"
            ds = sess.import_pasted_table(body.text, name=paste_name)
        except ValueError as err:
            raise HTTPException(status_code=400, detail=safe_text(str(err), 600)) from None
        from ..explore import build_spreadsheet_welcome_message
        msg = build_spreadsheet_welcome_message(ds, source_label=paste_name)
        sess.conversation.append({'role': 'assistant', 'text': msg})
        sess.save()

        rel = str(sess.project_dir.relative_to(ws))
        clean_title = (body.title or 'Pasted Table').strip()[:120]
        meta = store.register_project(user['user_id'], rel, clean_title, 'pasted_table', ds.source_hash)
        _put_cached_session(user['user_id'], meta['project_id'], sess)
        capture_session_trajectory(
            cfg, store, user, meta, sess, 'paste_import',
            figure_lock=_FIGURE_RENDER_LOCK, r2_transport=app.state.r2_transport,
        )
        return _serialize_workspace(user, meta, sess)

    @app.post('/api/projects/upload')
    async def upload_project_file(
        file: UploadFile = File(...),
        sheet: str = Form(default=''),
        user: dict = Depends(get_consented_user),
    ):
        _enforce_project_limit(user['user_id'])
        raw_name = Path(file.filename or 'dataset.csv').name
        ext = Path(raw_name).suffix.lower()
        if ext == '.xlsm':
            raise HTTPException(
                status_code=400,
                detail='Macro-enabled .xlsm workbooks are blocked on the web server for safety. Save as standard .xlsx or .csv first.',
            )
        if ext not in ALLOWED_UPLOAD_SUFFIXES:
            raise HTTPException(
                status_code=400,
                detail=f'Unsupported file type {ext!r}. Upload .xlsx, .csv, .tsv, .txt, or .ods (raw .abf files use ClampFlow or desktop StatWeave).',
            )

        ws = _user_workspace(user['user_id'])
        with tempfile.TemporaryDirectory(dir=ws) as tmp_str:
            staged = Path(tmp_str) / raw_name
            total = 0
            with staged.open('wb') as out_handle:
                while True:
                    chunk = await file.read(65536)
                    if not chunk:
                        break
                    total += len(chunk)
                    if total > cfg.max_upload_bytes:
                        raise HTTPException(
                            status_code=413,
                            detail=f'File exceeds the {cfg.max_upload_bytes // (1024 * 1024)} MiB upload limit.',
                        )
                    out_handle.write(chunk)
            if total == 0:
                raise HTTPException(status_code=400, detail='Uploaded file is empty.')

            if ext in {'.xlsx', '.ods'}:
                max_expanded = min(128 * 1024 * 1024, max(4 * 1024 * 1024, total * 200))
                try:
                    zip_guard(staged, max_uncompressed_bytes=max_expanded)
                except ValueError as err:
                    raise HTTPException(status_code=400, detail=safe_text(str(err), 500)) from None
                info = inspect_ooxml_workbook(staged)
                if info.get('has_vba_macros'):
                    raise HTTPException(status_code=400, detail='Workbooks containing embedded VBA macros are rejected.')

            sess = Session(ws, allow_host_paths=False)
            sess.style['dpi'] = 300
            sess.defer_figure_validation = True
            try:
                ds = sess.import_file(staged, sheet=sheet.strip() or None)
            except ValueError as err:
                raise HTTPException(status_code=400, detail=safe_text(str(err), 600)) from None

            from ..explore import build_spreadsheet_welcome_message
            msg = build_spreadsheet_welcome_message(ds, source_label=raw_name)
            sess.conversation.append({'role': 'assistant', 'text': msg})
            sess.save()

        detected = 'clampflow_6tab' if getattr(ds, 'is_clampflow', False) else 'table'
        rel = str(sess.project_dir.relative_to(ws))
        clean_title = Path(ds.source_path).name
        meta = store.register_project(user['user_id'], rel, clean_title, detected, ds.source_hash)
        _put_cached_session(user['user_id'], meta['project_id'], sess)
        capture_session_trajectory(
            cfg, store, user, meta, sess, 'file_upload',
            figure_lock=_FIGURE_RENDER_LOCK, r2_transport=app.state.r2_transport,
        )
        return _serialize_workspace(user, meta, sess)

    # --- Active Project Operations ---

    @app.get('/api/projects/{project_id}')
    def get_project(project_id: str, user: dict = Depends(get_consented_user)):
        meta, lock, sess = _load_user_session(user['user_id'], project_id)
        with lock:
            return _serialize_workspace(user, meta, sess)

    @app.get('/api/projects/{project_id}/explore')
    def explore_project_figures(project_id: str, user: dict = Depends(get_consented_user)):
        _meta, lock, sess = _load_user_session(user['user_id'], project_id)
        from ..explore import build_exploratory_gallery
        with lock:
            with _FIGURE_RENDER_LOCK:
                return build_exploratory_gallery(sess)

    @app.post('/api/projects/{project_id}/apply_card')
    def apply_project_card(
        project_id: str,
        body: ApplyCardRequest,
        user: dict = Depends(get_consented_user),
    ):
        meta, lock, sess = _load_user_session(user['user_id'], project_id)
        from ..explore import apply_exploratory_card
        with lock:
            try:
                with _FIGURE_RENDER_LOCK:
                    apply_exploratory_card(sess, body.prep_ops, body.plan, body.style)
            except ValueError as err:
                raise HTTPException(status_code=400, detail=safe_text(str(err), 600)) from None
            store.touch_project(project_id, user['user_id'])
            capture_session_trajectory(
                cfg, store, user, meta, sess, 'apply_card',
                figure_lock=_FIGURE_RENDER_LOCK, r2_transport=app.state.r2_transport,
            )
            return _serialize_workspace(user, meta, sess)

    @app.post('/api/projects/{project_id}/sheet')
    def switch_project_sheet(
        project_id: str,
        body: SheetSwitchRequest,
        user: dict = Depends(get_consented_user),
    ):
        meta, lock, sess = _load_user_session(user['user_id'], project_id)
        with lock:
            if (
                sess.dataset is not None
                and getattr(sess.dataset, 'source_path', None)
                and Path(sess.dataset.source_path).suffix.lower() in {'.xlsx', '.xlsm'}
            ):
                hidden_set = set(inspect_ooxml_workbook(sess.dataset.source_path).get('hidden_sheets') or ())
                if body.sheet in hidden_set:
                    raise HTTPException(
                        status_code=400,
                        detail='Hidden worksheets are excluded in the web workbench for privacy; unhide the tab in Excel first if needed.',
                    )
            try:
                user_text = f'Switch to worksheet "{body.sheet}".'
                sess.conversation.append({'role': 'user', 'text': user_text})
                sess._event('instruction', {'text': user_text, 'interpreter': 'web worksheet selector'})
                sess.select_sheet(body.sheet, reply=True)
            except ValueError as err:
                raise HTTPException(status_code=400, detail=safe_text(str(err), 500)) from None
            store.touch_project(project_id, user['user_id'])
            capture_session_trajectory(
                cfg, store, user, meta, sess, 'sheet_switch',
                figure_lock=_FIGURE_RENDER_LOCK, r2_transport=app.state.r2_transport,
            )
            return _serialize_workspace(user, meta, sess)

    @app.post('/api/projects/chat_start')
    def chat_start_project(
        body: ChatStartRequest,
        user: dict = Depends(get_consented_user),
    ):
        stripped = body.message.strip()
        if stripped.startswith('https://docs.google.com/spreadsheets/') and '\n' not in stripped and ' ' not in stripped:
            return _import_google_sheet_project(stripped, body.title, user)

        _enforce_project_limit(user['user_id'])
        ws = _user_workspace(user['user_id'])
        sess = Session(ws, allow_host_paths=False)
        sess.style['dpi'] = 300
        sess.defer_figure_validation = True

        parsed_groups = _try_parse_chat_raw_numbers(body.message)
        if parsed_groups:
            lines = ['Group\tValue']
            for grp_label, vals in parsed_groups.items():
                safe_grp = grp_label.replace('\t', ' ').replace('\n', ' ')
                for val in vals:
                    lines.append(f'{safe_grp}\t{val:g}')
            seed_tsv = '\n'.join(lines) + '\n'
            seed_name = '0_Raw_Chat_Numbers.tsv'
        else:
            seed_tsv = (
                'Chat_Intake\tStatus\n'
                'Raw_Input_In_Chat\tBuild_Working_Sheet\n'
                'Raw_Input_In_Chat\tReady\n'
            )
            seed_name = '0_Raw_Chat_Intake.tsv'

        ds = sess.import_pasted_table(seed_tsv, name=seed_name)
        sess.context['origin'] = 'chat_raw_numbers'
        sess.save()

        clean_title = (body.title or 'Chat Working Sheet').strip()[:120]
        rel = str(sess.project_dir.relative_to(ws))
        meta = store.register_project(user['user_id'], rel, clean_title, 'chat_working_sheet', ds.source_hash)
        _put_cached_session(user['user_id'], meta['project_id'], sess)

        return chat_project_turn(
            meta['project_id'],
            ChatTurnRequest(message=body.message, mode=body.mode, auto_execute=body.auto_execute),
            user=user,
        )

    @app.post('/api/projects/{project_id}/chat')
    def chat_project_turn(
        project_id: str,
        body: ChatTurnRequest,
        user: dict = Depends(get_consented_user),
    ):
        meta, lock, sess = _load_user_session(user['user_id'], project_id)
        with lock:
            want_openai = body.mode in {'auto', 'openai'}
            model = None
            if want_openai:
                candidate_model = _build_openai_model()
                if candidate_model is not None:
                    try:
                        store.assert_openai_quota(
                            user['user_id'],
                            cfg.daily_turn_limit,
                            cfg.monthly_turn_limit,
                            cfg.daily_token_limit,
                        )
                    except QuotaExceededError as qerr:
                        raise HTTPException(status_code=429, detail=str(qerr)) from None
                    model = candidate_model
                elif body.mode == 'openai' or not cfg.allow_offline_fallback:
                    raise HTTPException(
                        status_code=503,
                        detail='Hosted OpenAI conversation is not configured on this server yet.',
                    )

            # Preserve seamless web chat approval even if the server restarted between turns
            pending_pre = sess.context.get('api_proposal')
            if (
                isinstance(pending_pre, dict)
                and getattr(sess, '_api_conversation_token', None) is None
                and pending_pre.get('token')
            ):
                from ..api_tools import state_digest
                if pending_pre.get('base_digest') == state_digest(sess):
                    sess._api_conversation_token = pending_pre['token']

            events_before = 0
            if sess.project_dir and (sess.project_dir / 'history.jsonl').is_file():
                events_before = len((sess.project_dir / 'history.jsonl').read_text(encoding='utf-8').splitlines())

            prev_auto = getattr(sess, 'auto_execute_proposals', False)
            sess.auto_execute_proposals = bool(body.auto_execute)
            try:
                reply = sess.command(body.message, model=model)
            finally:
                sess.auto_execute_proposals = prev_auto

            # Extract any recorded OpenAI/Gemini usage from newly appended audit lines
            if model is not None and sess.project_dir and (sess.project_dir / 'history.jsonl').is_file():
                new_lines = (sess.project_dir / 'history.jsonl').read_text(encoding='utf-8').splitlines()[events_before:]
                for ln in new_lines:
                    try:
                        ev = json.loads(ln)
                        if ev.get('type') == 'api_conversation':
                            usage = (ev.get('payload') or {}).get('usage') or {}
                            store.record_usage(
                                user['user_id'],
                                project_id,
                                str(getattr(model, 'provider', 'openai')),
                                str(getattr(model, 'model', cfg.openai_model)),
                                usage,
                            )
                    except Exception:
                        continue

            store.touch_project(project_id, user['user_id'])
            capture_session_trajectory(
                cfg, store, user, meta, sess, 'chat_turn',
                figure_lock=_FIGURE_RENDER_LOCK, r2_transport=app.state.r2_transport,
            )
            payload = _serialize_workspace(user, meta, sess)
            payload['reply_message'] = reply.get('message', '')
            payload['open_explore_gallery'] = bool(reply.get('explore_gallery', False))
            return payload

    @app.post('/api/projects/{project_id}/proposal/approve')
    def approve_project_proposal(
        project_id: str,
        body: ProposalApproveRequest,
        user: dict = Depends(get_consented_user),
    ):
        meta, lock, sess = _load_user_session(user['user_id'], project_id)
        with lock:
            pending = sess.context.get('api_proposal')
            if pending and body.proposal_id and body.proposal_id != pending.get('proposal_id'):
                raise HTTPException(status_code=409, detail='The displayed proposal ID is out of date; review the latest proposal.')
            # Allow seamless approval across stateless worker restarts ONLY when
            # the client supplies the exact displayed proposal_id matching saved state.
            if (
                pending
                and body.proposal_id
                and body.proposal_id == pending.get('proposal_id')
                and getattr(sess, '_api_conversation_token', None) is None
                and pending.get('token')
            ):
                sess._api_conversation_token = pending['token']

            try:
                reply = sess.approve_proposal()
            except ValueError as err:
                raise HTTPException(status_code=400, detail=safe_text(str(err), 600)) from None
            store.touch_project(project_id, user['user_id'])
            capture_session_trajectory(
                cfg, store, user, meta, sess, 'proposal_approved',
                figure_lock=_FIGURE_RENDER_LOCK, r2_transport=app.state.r2_transport,
            )
            payload = _serialize_workspace(user, meta, sess)
            payload['reply_message'] = reply.get('message', '')
            payload['open_explore_gallery'] = bool(reply.get('explore_gallery', False))
            return payload

    @app.post('/api/projects/{project_id}/proposal/dismiss')
    def dismiss_project_proposal(
        project_id: str,
        user: dict = Depends(get_consented_user),
    ):
        meta, lock, sess = _load_user_session(user['user_id'], project_id)
        with lock:
            reply = sess.dismiss_proposal()
            store.touch_project(project_id, user['user_id'])
            capture_session_trajectory(
                cfg, store, user, meta, sess, 'proposal_dismissed',
                figure_lock=_FIGURE_RENDER_LOCK, r2_transport=app.state.r2_transport,
            )
            payload = _serialize_workspace(user, meta, sess)
            payload['reply_message'] = reply.get('message', '')
            payload['open_explore_gallery'] = bool(reply.get('explore_gallery', False))
            return payload

    @app.post('/api/projects/{project_id}/style')
    def update_project_style(
        project_id: str,
        body: FigureStyleRequest,
        user: dict = Depends(get_consented_user),
    ):
        meta, lock, sess = _load_user_session(user['user_id'], project_id)
        with lock:
            if sess.dataset is None or sess.result is None:
                raise HTTPException(status_code=400, detail='Run an analysis first before styling the figure.')
            new_plan = deepcopy(sess.plan or {})
            if body.plot is not None:
                if body.plot not in PLOTS:
                    raise HTTPException(status_code=400, detail=f'Unsupported plot type {body.plot!r}.')
                new_plan['plot'] = body.plot
            clean_style = deepcopy(sess.style)
            for k, v in (body.style or {}).items():
                if k not in STYLE_KEYS:
                    raise HTTPException(status_code=400, detail=f'Unsupported style field {k!r}.')
                if v is None:
                    clean_style.pop(k, None)
                else:
                    clean_style[k] = v

            with _FIGURE_RENDER_LOCK:
                fig = None
                try:
                    fig = make_figure(sess.dataset, sess.result, new_plan, clean_style)
                except ValueError as err:
                    raise HTTPException(status_code=400, detail=safe_text(str(err), 500)) from None
                finally:
                    if fig is not None:
                        plt.close(fig)

            sess.plan = new_plan
            sess.style = clean_style
            if not sess.is_study and isinstance(sess.result, dict):
                sess.result['plan'] = deepcopy(new_plan)
            sess._event('web_figure_style_changed', {
                'plot': new_plan.get('plot'),
                'style': clean_style,
                'calculations_performed': False,
            })
            sess.save()
            store.touch_project(project_id, user['user_id'])
            capture_session_trajectory(
                cfg, store, user, meta, sess, 'figure_style_bar',
                figure_lock=_FIGURE_RENDER_LOCK, r2_transport=app.state.r2_transport,
            )
            return _serialize_workspace(user, meta, sess)

    @app.get('/api/projects/{project_id}/figure.{fmt}')
    def download_project_figure(
        project_id: str,
        fmt: str,
        user: dict = Depends(get_consented_user),
    ):
        fmt_clean = fmt.lower().strip()
        if fmt_clean not in {'svg', 'png', 'pdf'}:
            raise HTTPException(status_code=400, detail='Supported formats: svg, png, pdf.')
        meta, lock, sess = _load_user_session(user['user_id'], project_id)
        with lock:
            if sess.dataset is None or sess.result is None:
                raise HTTPException(status_code=400, detail='No completed figure is available in this project yet.')
            with _FIGURE_RENDER_LOCK:
                fig = None
                try:
                    fig = make_figure(sess.dataset, sess.result, sess.plan, sess.style)
                    buf = io.BytesIO()
                    dpi = 600 if fmt_clean == 'png' else int(sess.style.get('dpi', 300))
                    fig.savefig(buf, format=fmt_clean, dpi=dpi, bbox_inches='tight', facecolor='white')
                    data_bytes = buf.getvalue()
                finally:
                    if fig is not None:
                        plt.close(fig)

        media = {
            'svg': 'image/svg+xml',
            'png': 'image/png',
            'pdf': 'application/pdf',
        }[fmt_clean]
        safe_slug = ''.join(c if c.isalnum() or c in '-_' else '_' for c in Path(meta['title']).stem)[:40] or 'statweave_figure'
        return Response(
            content=data_bytes,
            media_type=media,
            headers={'Content-Disposition': f'attachment; filename="{safe_slug}.{fmt_clean}"'},
        )

    @app.get('/api/projects/{project_id}/workbook.xlsx')
    def download_project_working_workbook(
        project_id: str,
        user: dict = Depends(get_consented_user),
    ):
        from ..working_sheets import build_multi_tab_export_xlsx
        meta, lock, sess = _load_user_session(user['user_id'], project_id)
        with lock:
            if sess.dataset is None or sess.is_study or sess.is_large_table or sess.is_recording:
                raise HTTPException(status_code=400, detail='Working workbook export is available for tabular projects.')
            xlsx_bytes = build_multi_tab_export_xlsx(sess)

        safe_slug = ''.join(c if c.isalnum() or c in '-_' else '_' for c in Path(meta['title']).stem)[:40] or 'statweave_workbook'
        return Response(
            content=xlsx_bytes,
            media_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            headers={'Content-Disposition': f'attachment; filename="{safe_slug}_working_sheets.xlsx"'},
        )

    @app.get('/api/projects/{project_id}/export.zip')
    def download_project_export_zip(
        project_id: str,
        user: dict = Depends(get_consented_user),
    ):
        meta, lock, sess = _load_user_session(user['user_id'], project_id)
        with lock:
            if sess.dataset is None or sess.result is None:
                raise HTTPException(status_code=400, detail='Complete an analysis before exporting a reproducibility package.')
            with _FIGURE_RENDER_LOCK:
                exported = sess.export_bundle()
            archive_path = Path(exported['archive']).resolve()
            ws = _user_workspace(user['user_id'])
            if not archive_path.is_relative_to(ws) or not archive_path.is_file():
                raise HTTPException(status_code=500, detail='Export archive was not created cleanly.')
            zip_bytes = archive_path.read_bytes()
            capture_session_trajectory(
                cfg, store, user, meta, sess, 'export_bundle',
                figure_lock=_FIGURE_RENDER_LOCK, r2_transport=app.state.r2_transport,
            )

        safe_slug = ''.join(c if c.isalnum() or c in '-_' else '_' for c in Path(meta['title']).stem)[:40] or 'statweave_export'
        return Response(
            content=zip_bytes,
            media_type='application/zip',
            headers={'Content-Disposition': f'attachment; filename="{safe_slug}_reproducible.zip"'},
        )

    @app.post('/api/projects/{project_id}/feedback')
    def submit_project_feedback(
        project_id: str,
        body: FeedbackRequest,
        user: dict = Depends(get_consented_user),
    ):
        meta, lock, sess = _load_user_session(user['user_id'], project_id)
        with lock:
            sess._event('contributor_feedback', {'rating': body.rating, 'note': safe_text(body.note, 1000)})
            sess.save()
            doc = capture_session_trajectory(
                cfg, store, user, meta, sess, 'user_feedback',
                figure_lock=_FIGURE_RENDER_LOCK,
                feedback_rating=body.rating,
                feedback_note=body.note,
                r2_transport=app.state.r2_transport,
            )
        return {'status': 'recorded', 'trajectory_id': doc['trajectory_id'] if doc else None}

    @app.post('/api/projects/{project_id}/contribute')
    def submit_contribution_case(
        project_id: str,
        body: ContributeCaseRequest,
        user: dict = Depends(get_consented_user),
    ):
        meta, lock, sess = _load_user_session(user['user_id'], project_id)
        with lock:
            try:
                case_doc = build_and_save_contribution_case(
                    cfg,
                    store,
                    user,
                    meta,
                    sess,
                    metadata=body.model_dump(),
                    figure_lock=_FIGURE_RENDER_LOCK,
                    r2_transport=app.state.r2_transport,
                )
            except ValueError as err:
                raise HTTPException(status_code=400, detail=safe_text(str(err), 600)) from None
        return {
            'status': 'submitted_private_quarantine',
            'case_id': case_doc['case_id'],
            'visibility_state': case_doc['permissions']['visibility_state'],
            'study_cluster_id': case_doc['study_cluster_id'],
            'case': case_doc,
        }

    # --- Contributor Self-Service, Withdrawal & Anonymization ---

    @app.get('/api/me/contributions')
    def my_contributions(user: dict = Depends(get_current_user)):
        return store.list_user_contributions(user['user_id'])

    @app.get('/api/me/export.zip')
    def export_my_contributions(user: dict = Depends(get_current_user)):
        listing = store.list_user_contributions(user['user_id'])
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, 'w', compression=zipfile.ZIP_DEFLATED) as zf:
            zf.writestr('account_summary.json', json.dumps({'user': user, **listing}, indent=2))
            for item in listing['contribution_cases']:
                cdir = (cfg.data_dir / item['bundle_rel_path']).resolve()
                if cdir.is_relative_to(cfg.data_dir.resolve()) and cdir.is_dir():
                    for fpath in sorted(cdir.rglob('*')):
                        if fpath.is_file():
                            zf.write(fpath, arcname=f"cases/{item['case_id']}/{fpath.relative_to(cdir)}")
        return Response(
            content=buf.getvalue(),
            media_type='application/zip',
            headers={'Content-Disposition': 'attachment; filename="statweave_my_contributions.zip"'},
        )

    @app.post('/api/me/withdraw-public/{case_id}')
    def withdraw_public_case(case_id: str, user: dict = Depends(get_current_user)):
        updated = store.withdraw_public_showcase(user['user_id'], case_id)
        if not updated:
            raise HTTPException(status_code=404, detail='Contribution case not found.')
        scrub_contributor_identity_in_cases(
            cfg.data_dir,
            [updated['bundle_rel_path']],
            anonymize_identity=False,
            config=cfg,
            transport=app.state.r2_transport,
        )
        return {'status': 'public_showcase_withdrawn', 'case': updated}

    @app.post('/api/me/anonymize')
    def anonymize_my_account(response: Response, user: dict = Depends(get_current_user)):
        with app.state.cache_lock:
            stale_keys = [k for k in app.state.session_cache if k[0] == user['user_id']]
            for k in stale_keys:
                app.state.session_cache.pop(k, None)
        case_paths = store.anonymize_account(user['user_id'])
        scrub_contributor_identity_in_cases(
            cfg.data_dir,
            case_paths,
            config=cfg,
            transport=app.state.r2_transport,
        )
        response.delete_cookie(COOKIE_NAME, path='/')
        return {
            'status': 'account_anonymized',
            'policy': (
                'OAuth identity, name, and handle have been unlinked and any optional public '
                'showcase has been delisted. Deidentified training and evaluation trajectories '
                'remain retained per Contributor Beta terms.'
            ),
        }

    # --- Maintainer Admin Routes ---

    @app.get('/api/admin/summary', dependencies=[Depends(require_admin)])
    def admin_summary():
        return store.admin_summary()

    @app.get('/api/admin/corpus.zip', dependencies=[Depends(require_admin)])
    def admin_download_corpus():
        data_bytes = build_corpus_archive_bytes(cfg.data_dir, 'corpus')
        return Response(
            content=data_bytes,
            media_type='application/zip',
            headers={'Content-Disposition': 'attachment; filename="statweave_learning_corpus.zip"'},
        )

    return app
