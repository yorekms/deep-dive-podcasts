"""CLI entry point: python -m statweave.web"""
from __future__ import annotations

import argparse
import os
from pathlib import Path

import uvicorn


def main() -> int:
    parser = argparse.ArgumentParser(description='StatWeave Web Workbench & Contributor API')
    parser.add_argument('--host', default=os.environ.get('HOST', '0.0.0.0'))
    parser.add_argument('--port', type=int, default=int(os.environ.get('PORT', '8000')))
    parser.add_argument('--data-dir', default=os.environ.get('STATWEAVE_DATA_DIR', ''))
    parser.add_argument('--reload', action='store_true')
    args = parser.parse_args()
    if args.data_dir:
        os.environ['STATWEAVE_DATA_DIR'] = str(Path(args.data_dir).expanduser().resolve())
    uvicorn.run(
        'statweave.web.server:create_app',
        factory=True,
        host=args.host,
        port=args.port,
        reload=args.reload,
    )
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
