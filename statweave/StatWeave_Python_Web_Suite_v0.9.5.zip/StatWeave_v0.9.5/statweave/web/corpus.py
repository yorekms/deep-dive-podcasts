"""Private learning-set trajectory logger, CONTRIBUTION_CASE_SCHEMA v1.0.0
builder/validator, and optional Cloudflare R2 (S3 SigV4) private object mirror.

Privacy & Integrity Invariants:
- Nothing is captured unless the user has explicitly granted both
  allow_private_evaluation=True and allow_model_training=True.
- Every captured spreadsheet is scrubbed (OOXML docProps stripped, VBA macros
  rejected, CSV formula injection escaped, filenames replaced with S001.<ext>).
- OS paths, credentials, and raw bearer tokens are scrubbed via safe_value()
  before serialization.
- Multiple runs on the same underlying file share one deterministic
  study_cluster_id so future train/eval splits never leak across paraphrases.
"""
from __future__ import annotations

import base64
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import hmac
import io
import json
from pathlib import Path
import re
import shutil
import tempfile
from urllib.parse import urlparse
import zipfile

import httpx
import jsonschema
import pandas as pd

from ..api_tools import inspect_data, safe_text, safe_value
from ..figures import export_figure, figure_caption, make_figure
from ..scrubber import escape_csv_cell, scrub_xlsx_copy
from ..session import Session, canonical, sha256, versions
from .config import WebConfig
from .store import WebStore

_ORCID_RE = re.compile(r'^[0-9]{4}-[0-9]{4}-[0-9]{4}-[0-9]{3}[0-9X]$')


def _utc_now() -> str:
    return datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')


def _schema_path() -> Path:
    here = Path(__file__).resolve()
    candidates = [
        here.parents[2] / 'schemas' / 'CONTRIBUTION_CASE_SCHEMA.json',
        here.parents[3] / 'CONTRIBUTION_CASE_SCHEMA.json',
    ]
    for path in candidates:
        if path.is_file():
            return path
    raise FileNotFoundError('CONTRIBUTION_CASE_SCHEMA.json was not found in schemas/.')


def validate_contribution_case_payload(payload: dict) -> None:
    schema = json.loads(_schema_path().read_text(encoding='utf-8'))
    validator = jsonschema.Draft202012Validator(schema)
    errors = sorted(validator.iter_errors(payload), key=lambda err: list(err.absolute_path))
    if errors:
        first = errors[0]
        loc = '.'.join(str(p) for p in first.absolute_path) or '<root>'
        raise ValueError(f'Contribution case schema validation failed at {loc}: {first.message}')


def _atomic_write_json(target: Path, payload: dict) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    tmp = None
    try:
        with tempfile.NamedTemporaryFile(
            mode='w',
            encoding='utf-8',
            dir=target.parent,
            prefix='.tmp-corpus-',
            delete=False,
        ) as handle:
            tmp = Path(handle.name)
            json.dump(payload, handle, indent=2, ensure_ascii=False, allow_nan=False)
            handle.flush()
        tmp.replace(target)
    finally:
        if tmp is not None and tmp.exists():
            tmp.unlink(missing_ok=True)


def _write_scrubbed_source(session: Session, dest_dir: Path) -> dict:
    """Write a deidentified copy S001.<ext> of the session's active source."""
    dest_dir.mkdir(parents=True, exist_ok=True)
    ds = session.dataset
    src = Path(ds.source_path)
    ext = src.suffix.lower()
    if ext in {'.xlsx', '.xlsm'}:
        clean_rel = 'source/S001.xlsx'
        out_path = dest_dir / 'S001.xlsx'
        scrub_info = scrub_xlsx_copy(src, out_path)
        fmt = 'xlsx'
    elif ext == '.tsv':
        clean_rel = 'source/S001.tsv'
        out_path = dest_dir / 'S001.tsv'
        shutil.copyfile(src, out_path)
        scrub_info = {'format': 'tsv', 'copied_immutable_snapshot': True}
        fmt = 'tsv'
    elif ext == '.ods':
        clean_rel = 'source/S001.ods'
        out_path = dest_dir / 'S001.ods'
        # Export active table as clean CSV alongside ODS hash or copy clean CSV
        clean_rel = 'source/S001.csv'
        out_path = dest_dir / 'S001.csv'
        safe_df = ds.df.map(escape_csv_cell)
        safe_df.to_csv(out_path, index=False)
        scrub_info = {'format': 'csv_from_ods'}
        fmt = 'csv'
    else:
        clean_rel = 'source/S001.csv'
        out_path = dest_dir / 'S001.csv'
        shutil.copyfile(src, out_path)
        scrub_info = {'format': 'csv'}
        fmt = 'csv'

    return {
        'source_id': 'S001',
        'sanitized_relative_path': clean_rel,
        'format': fmt,
        'role': 'primary_raw_data',
        'size_bytes': int(out_path.stat().st_size),
        'sha256': sha256(out_path),
        'sheet_or_channel_inventory': [str(s) for s in getattr(ds, 'sheets', [ds.sheet or 'Data'])[:32]],
        '_local_path': out_path,
        '_scrub_info': scrub_info,
    }


def _s3_sigv4_put(
    config: WebConfig,
    object_key: str,
    body: bytes,
    content_type: str = 'application/json',
    transport: httpx.BaseTransport | None = None,
) -> bool:
    """Minimal pure-Python AWS Signature V4 PUT for private Cloudflare R2 / S3."""
    if not config.r2_enabled:
        return False
    parsed = urlparse(config.r2_endpoint_url)
    host = parsed.netloc
    scheme = parsed.scheme or 'https'
    base_path = parsed.path.rstrip('/')
    canonical_uri = f'{base_path}/{config.r2_bucket}/{object_key.lstrip("/")}'
    now = datetime.now(timezone.utc)
    amz_date = now.strftime('%Y%m%dT%H%M%SZ')
    date_stamp = now.strftime('%Y%m%d')
    region = 'auto'
    service = 's3'

    payload_hash = hashlib.sha256(body).hexdigest()
    canonical_headers = (
        f'content-type:{content_type}\n'
        f'host:{host}\n'
        f'x-amz-content-sha256:{payload_hash}\n'
        f'x-amz-date:{amz_date}\n'
    )
    signed_headers = 'content-type;host;x-amz-content-sha256;x-amz-date'
    canonical_request = f'PUT\n{canonical_uri}\n\n{canonical_headers}\n{signed_headers}\n{payload_hash}'
    credential_scope = f'{date_stamp}/{region}/{service}/aws4_request'
    string_to_sign = (
        f'AWS4-HMAC-SHA256\n{amz_date}\n{credential_scope}\n'
        + hashlib.sha256(canonical_request.encode('utf-8')).hexdigest()
    )

    def _sign(key: bytes, msg: str) -> bytes:
        return hmac.new(key, msg.encode('utf-8'), hashlib.sha256).digest()

    k_date = _sign(('AWS4' + config.r2_secret_access_key).encode('utf-8'), date_stamp)
    k_region = _sign(k_date, region)
    k_service = _sign(k_region, service)
    k_signing = _sign(k_service, 'aws4_request')
    signature = hmac.new(k_signing, string_to_sign.encode('utf-8'), hashlib.sha256).hexdigest()

    auth_header = (
        f'AWS4-HMAC-SHA256 Credential={config.r2_access_key_id}/{credential_scope}, '
        f'SignedHeaders={signed_headers}, Signature={signature}'
    )
    url = f'{scheme}://{host}{canonical_uri}'
    with httpx.Client(timeout=20.0, transport=transport) as client:
        resp = client.put(
            url,
            content=body,
            headers={
                'Content-Type': content_type,
                'x-amz-date': amz_date,
                'x-amz-content-sha256': payload_hash,
                'Authorization': auth_header,
            },
        )
        return 200 <= resp.status_code < 300


_MAX_GDRIVE_WEBHOOK_RAW_BYTES = 24 * 1024 * 1024


def _gdrive_webhook_put(
    config: WebConfig,
    object_key: str,
    body: bytes,
    content_type: str = 'application/json',
    transport: httpx.BaseTransport | None = None,
) -> bool:
    """Mirror a scrubbed corpus artifact to a private Google Drive Apps Script / HTTPS vault."""
    if not config.gdrive_webhook_enabled:
        return False
    if len(body) > _MAX_GDRIVE_WEBHOOK_RAW_BYTES:
        return False
    ts = _utc_now()
    clean_key = object_key.lstrip('/')
    payload_hash = hashlib.sha256(body).hexdigest()
    sig = ''
    if config.gdrive_webhook_secret:
        msg = f'{ts}:{clean_key}:{payload_hash}'.encode('utf-8')
        sig = hmac.new(config.gdrive_webhook_secret.encode('utf-8'), msg, hashlib.sha256).hexdigest()

    envelope = {
        'action': 'put_object',
        'object_key': clean_key,
        'content_type': content_type,
        'size_bytes': len(body),
        'sha256': payload_hash,
        'timestamp_utc': ts,
        'signature_hmac_sha256': sig,
        'content_base64': base64.b64encode(body).decode('ascii'),
    }
    headers = {'Content-Type': 'application/json'}
    if sig:
        headers['X-StatWeave-Signature'] = sig
    with httpx.Client(timeout=25.0, follow_redirects=True, transport=transport) as client:
        resp = client.post(config.gdrive_webhook_url, json=envelope, headers=headers)
        if not (200 <= resp.status_code < 300):
            return False
        try:
            data = resp.json()
            if isinstance(data, dict) and data.get('ok') is False:
                return False
        except Exception:
            pass
        return True


def capture_session_trajectory(
    config: WebConfig,
    store: WebStore,
    user: dict,
    project_meta: dict,
    session: Session,
    trigger_event: str,
    figure_lock=None,
    feedback_rating: str | None = None,
    feedback_note: str | None = None,
    r2_transport: httpx.BaseTransport | None = None,
) -> dict | None:
    """Persist a deidentified learning-set trajectory snapshot for consented users."""
    perms = user.get('permissions', {})
    if not (perms.get('allow_private_evaluation') and perms.get('allow_model_training')):
        return None
    if session.dataset is None or session.is_recording:
        return None

    project_id = project_meta['project_id']
    trajectory_id = f'trj_{project_id[4:]}'
    study_cluster_id = project_meta['study_cluster_id']
    bundle_dir = config.data_dir / 'corpus' / 'trajectories' / trajectory_id
    source_dir = bundle_dir / 'source'
    bundle_dir.mkdir(parents=True, exist_ok=True)

    src_entry = _write_scrubbed_source(session, source_dir)
    local_source_path = src_entry.pop('_local_path')
    scrub_info = src_entry.pop('_scrub_info')

    schema_snapshot = safe_value(inspect_data(session))
    redacted_conversation = [
        {
            'role': str(turn.get('role', 'user')),
            'text': safe_text(str(turn.get('text', '')), 6000),
        }
        for turn in session.conversation[-60:]
    ]

    svg_saved = False
    if session.result is not None and not session.is_study and not session.is_large_table:
        try:
            if figure_lock is not None:
                with figure_lock:
                    fig = make_figure(session.dataset, session.result, session.plan, session.style)
                    export_figure(fig, bundle_dir / 'accepted_figure.svg')
            else:
                fig = make_figure(session.dataset, session.result, session.plan, session.style)
                export_figure(fig, bundle_dir / 'accepted_figure.svg')
            svg_saved = True
        except Exception:
            svg_saved = False

    method = session.result.get('method') if isinstance(session.result, dict) else None
    plot = (session.plan or {}).get('plot') if isinstance(session.plan, dict) else None

    trajectory_doc = {
        'trajectory_version': '1.0.0',
        'trajectory_id': trajectory_id,
        'study_cluster_id': study_cluster_id,
        'captured_at_utc': _utc_now(),
        'trigger_event': trigger_event,
        'consent': {
            'allow_private_evaluation': True,
            'allow_model_training': True,
            'allow_public_example_library': bool(perms.get('allow_public_example_library', False)),
            'consented_at_utc': perms.get('consented_at_utc'),
            'retention_policy': 'anonymized_trajectories_retained_for_statweave_rd',
        },
        'detected_format': schema_snapshot.get('detected_format', project_meta.get('detected_format', 'table')),
        'source': src_entry,
        'deidentification_scrubber': scrub_info,
        'schema': schema_snapshot,
        'dialogue': redacted_conversation,
        'pending_proposal': safe_value(session.context.get('api_proposal')),
        'agreed_plan': safe_value(session.plan),
        'figure_style': safe_value(session.style),
        'result_summary': safe_value({
            'has_completed_result': session.result is not None,
            'method': method,
            'summary': (session.result or {}).get('summary') if isinstance(session.result, dict) else None,
            'warnings': (session.result or {}).get('warnings') if isinstance(session.result, dict) else None,
            'row_accounting': (session.result or {}).get('row_accounting') if isinstance(session.result, dict) else None,
            'unit_accounting': (session.result or {}).get('unit_accounting') if isinstance(session.result, dict) else None,
        }),
        'accepted_figure_svg': 'accepted_figure.svg' if svg_saved else None,
        'feedback': {
            'rating': feedback_rating,
            'note': safe_text(feedback_note, 1000) if feedback_note else None,
        },
        'environment': versions(),
    }

    traj_file = bundle_dir / 'trajectory.json'
    _atomic_write_json(traj_file, trajectory_doc)

    mirrored = False
    body_bytes = traj_file.read_bytes()
    src_bytes = local_source_path.read_bytes()
    if config.r2_enabled:
        try:
            ok1 = _s3_sigv4_put(
                config,
                f'trajectories/{trajectory_id}/trajectory.json',
                body_bytes,
                'application/json',
                transport=r2_transport,
            )
            ok2 = _s3_sigv4_put(
                config,
                f'trajectories/{trajectory_id}/{src_entry["sanitized_relative_path"]}',
                src_bytes,
                'application/octet-stream',
                transport=r2_transport,
            )
            mirrored = bool(ok1 and ok2)
        except Exception:
            mirrored = False

    if config.gdrive_webhook_enabled:
        try:
            g1 = _gdrive_webhook_put(
                config,
                f'trajectories/{trajectory_id}/trajectory.json',
                body_bytes,
                'application/json',
                transport=r2_transport,
            )
            g2 = _gdrive_webhook_put(
                config,
                f'trajectories/{trajectory_id}/{src_entry["sanitized_relative_path"]}',
                src_bytes,
                'application/octet-stream',
                transport=r2_transport,
            )
            if svg_saved and (bundle_dir / 'accepted_figure.svg').is_file():
                _gdrive_webhook_put(
                    config,
                    f'trajectories/{trajectory_id}/accepted_figure.svg',
                    (bundle_dir / 'accepted_figure.svg').read_bytes(),
                    'image/svg+xml',
                    transport=r2_transport,
                )
            mirrored = mirrored or bool(g1 and g2)
        except Exception:
            pass

    rel_path = str(bundle_dir.relative_to(config.data_dir))
    user_turns = sum(1 for t in redacted_conversation if t['role'] == 'user')
    store.upsert_trajectory(
        trajectory_id=trajectory_id,
        project_id=project_id,
        user_id=user['user_id'],
        study_cluster_id=study_cluster_id,
        trigger_event=trigger_event,
        detected_format=trajectory_doc['detected_format'],
        has_completed_result=session.result is not None,
        method=method,
        plot=plot,
        turn_count=user_turns,
        bundle_rel_path=rel_path,
        r2_mirrored=mirrored,
        feedback_rating=feedback_rating,
        feedback_note=safe_text(feedback_note, 1000) if feedback_note else None,
    )
    return trajectory_doc


def _infer_unit_from_col(col_name: str) -> str:
    lower = col_name.lower()
    for suffix, unit in (
        ('_mv_per_ms', 'mV/ms'),
        ('_vs', 'V/s'),
        ('_mv', 'mV'),
        ('_pa', 'pA'),
        ('_na', 'nA'),
        ('_mohms', 'MOhm'),
        ('_mohm', 'MOhm'),
        ('_pf', 'pF'),
        ('_ms', 'ms'),
        ('_hz', 'Hz'),
        ('_s', 's'),
    ):
        if lower.endswith(suffix):
            return unit
    return 'uncalibrated_arbitrary_units'


def build_and_save_contribution_case(
    config: WebConfig,
    store: WebStore,
    user: dict,
    project_meta: dict,
    session: Session,
    metadata: dict | None = None,
    figure_lock=None,
    r2_transport: httpx.BaseTransport | None = None,
) -> dict:
    """Build, schema-validate, and persist a full CONTRIBUTION_CASE_SCHEMA v1.0.0 bundle."""
    if session.dataset is None or session.result is None or session.plan is None:
        raise ValueError('Complete an analysis and figure in this project before submitting a reviewed contribution case.')
    perms = user.get('permissions', {})
    if not (perms.get('allow_private_evaluation') and perms.get('allow_model_training')):
        raise ValueError('Contributor consent is required before submitting a dataset case.')

    meta = metadata or {}
    year = datetime.now(timezone.utc).strftime('%Y')
    short_slug = re.sub(r'[^a-z0-9]+', '-', (project_meta.get('detected_format') or 'table').lower()).strip('-') or 'table'
    case_id = f'sw-case-{year}-{short_slug}-{project_meta["project_id"][-8:].lower()}'
    bundle_dir = config.data_dir / 'corpus' / 'cases' / case_id
    source_dir = bundle_dir / 'source'
    bundle_dir.mkdir(parents=True, exist_ok=True)

    src_entry = _write_scrubbed_source(session, source_dir)
    local_source_path = src_entry.pop('_local_path')
    src_entry.pop('_scrub_info', None)

    ds = session.dataset
    plan = deepcopy(session.plan)
    res = deepcopy(session.result)
    style = deepcopy(session.style)
    method = str(res.get('method', 'ttest'))
    is_clampflow = bool(getattr(ds, 'is_clampflow', False))
    domain = 'abf_derived_spreadsheet' if is_clampflow else 'ordinary_table'

    raw_title = safe_text(str(meta.get('title') or '').strip(), 180)
    if len(raw_title) < 10:
        sheet_part = f' ({ds.sheet})' if getattr(ds, 'sheet', None) else ''
        raw_title = f"{'ClampFlow Electrophysiology' if is_clampflow else 'Spreadsheet'} {method.upper()} Case{sheet_part}"
        if len(raw_title) < 10:
            raw_title = f'StatWeave Contributor Analysis Case ({method})'

    raw_summary = safe_text(str(meta.get('summary') or '').strip(), 2000)
    if len(raw_summary) < 20:
        raw_summary = (
            f"Contributor-submitted {'ClampFlow 6-tab electrophysiology' if is_clampflow else 'tabular'} dataset "
            f"analyzed via deterministic {method} with verified row/unit accounting and figure settings."
        )

    raw_allow_pub = meta.get('allow_public_example_library')
    allow_public = bool(
        perms.get('allow_public_example_library', False)
        if raw_allow_pub is None
        else raw_allow_pub
    )
    human_cat = meta.get('human_subjects_category')
    if human_cat not in {
        'non_human_or_in_vitro',
        'synthetic_data',
        'deidentified_human_non_regulated',
        'open_consented_public_human_dataset',
    }:
        human_cat = 'synthetic_data' if session.context.get('synthetic_demo') else 'non_human_or_in_vitro'

    orcid_val = user.get('handle_or_orcid')
    valid_orcid = orcid_val if (isinstance(orcid_val, str) and _ORCID_RE.fullmatch(orcid_val)) else None

    # Build field-level data dictionary from active DataFrame
    group_col = plan.get('group')
    pool_col = plan.get('pool_by')
    outcome_cols = set(plan.get('columns') or [])
    if plan.get('y'):
        outcome_cols.add(plan['y'])
    if plan.get('x'):
        outcome_cols.add(plan['x'])

    data_dict = []
    scope_name = str(ds.sheet or 'S001')
    for col in ds.df.columns[:60]:
        col_s = str(col)
        series = ds.df[col]
        is_num = pd.api.types.is_numeric_dtype(series) or pd.to_numeric(series.dropna(), errors='coerce').notna().any()
        if col_s == pool_col:
            role = 'biological_unit_id'
            vtype = 'identifier_text'
            unit = 'dimensionless_id'
        elif col_s == group_col:
            role = 'between_unit_group'
            vtype = 'categorical'
            unit = 'categorical_group'
        elif col_s in outcome_cols:
            role = 'primary_outcome'
            vtype = 'float' if is_num else 'categorical'
            unit = _infer_unit_from_col(col_s) if is_num else 'categorical_level'
        elif col_s == plan.get('count'):
            role = 'covariate'
            vtype = 'integer'
            unit = 'count'
        else:
            role = 'covariate' if is_num else 'free_text_annotation'
            vtype = 'float' if is_num else 'categorical'
            unit = _infer_unit_from_col(col_s) if is_num else 'dimensionless_id'
        data_dict.append({
            'source_scope': scope_name,
            'field_or_channel': col_s,
            'semantic_role': role,
            'value_type': vtype,
            'unit': unit,
            'missing_tokens': ['', 'NA', 'N/A', 'Undetermined'],
            'valid_range_or_levels': None,
            'description': f"Column '{col_s}' in worksheet '{scope_name}' ({role.replace('_', ' ')}).",
        })

    # Experimental design & accounting
    row_acc = res.get('row_accounting') or {}
    unit_acc = res.get('unit_accounting')
    n_raw = int(row_acc.get('total', len(ds.df)))
    excl_list = row_acc.get('excluded_rows') or []
    n_masked = len(excl_list)
    n_omitted_total = int(row_acc.get('omitted', 0))
    n_missing = max(0, n_omitted_total - n_masked)
    n_used = int(unit_acc['n_units']) if unit_acc else int(row_acc.get('used', max(1, len(ds.df))))

    counts_by_group: dict[str, int] = {}
    if unit_acc and isinstance(unit_acc.get('units_per_group'), dict):
        counts_by_group = {str(k): int(v) for k, v in unit_acc['units_per_group'].items()}
    else:
        for tbl in res.get('tables', []):
            if tbl.get('title') in {'Group summaries', 'Descriptive statistics'}:
                for r in tbl.get('rows', []):
                    label = str(r.get('group') or r.get('variable') or 'All')
                    if isinstance(r.get('n'), int):
                        counts_by_group[label] = int(r['n'])
                if counts_by_group:
                    break
    if not counts_by_group:
        counts_by_group = {'analyzed_units': max(1, n_used)}

    masks_schema = [
        {
            'mask_id': f'M{idx + 1}',
            'target_selector': f"source_row == {int(item['row'])}",
            'technical_reason': str(item['reason'])[:300],
            'reversible': True,
        }
        for idx, item in enumerate(excl_list)
    ]

    sci_question = safe_text(str(meta.get('scientific_question') or '').strip(), 500)
    if len(sci_question) < 15:
        user_msgs = [t['text'] for t in session.conversation if t.get('role') == 'user' and len(str(t.get('text', ''))) >= 15]
        sci_question = safe_text(user_msgs[0], 500) if user_msgs else f'Evaluate {method} relationship across experimental groups in {scope_name}.'

    # Extract numerical assertions from computed deterministic tables
    assertions = []
    a_idx = 1
    for tbl in res.get('tables', []):
        for r in tbl.get('rows', [])[:12]:
            scope_lbl = str(r.get('variable') or r.get('group') or r.get('group_1') or r.get('term') or tbl.get('title') or 'overall')
            for metric_key in ('mean', 'sd', 't', 'F', 'U', 'H', 'chi_squared', 'coefficient', 'p', 'p_holm'):
                val = r.get(metric_key)
                if isinstance(val, (int, float)):
                    assertions.append({
                        'assertion_id': f'A{a_idx}',
                        'metric_name': metric_key,
                        'scope': scope_lbl[:120],
                        'expected_value': float(val),
                        'unit': 'probability' if metric_key.startswith('p') else 'stat_or_outcome_unit',
                        'tolerance': {'abs': 1e-6, 'rel': 1e-5},
                    })
                    a_idx += 1
                    if len(assertions) >= 16:
                        break
            if len(assertions) >= 16:
                break
        if len(assertions) >= 16:
            break
    if not assertions:
        assertions.append({
            'assertion_id': 'A1',
            'metric_name': 'analyzed_units',
            'scope': 'dataset',
            'expected_value': float(max(1, n_used)),
            'unit': 'count',
            'tolerance': {'abs': 0.0, 'rel': 0.0},
        })

    if figure_lock is not None:
        with figure_lock:
            cap_text = figure_caption(ds, res, plan, style)
    else:
        cap_text = figure_caption(ds, res, plan, style)

    env_versions = versions()
    env_summary = (
        f"StatWeave deterministic engine (NumPy {env_versions.get('numpy')}, "
        f"SciPy {env_versions.get('scipy')}, statsmodels {env_versions.get('statsmodels')})"
    )

    now_utc = _utc_now()
    user_prompts = [safe_text(str(t.get('text', '')), 500) for t in session.conversation if t.get('role') == 'user']
    initial_prompt = user_prompts[0] if user_prompts else f'Compare outcome measures across groups using {method}.'

    case_doc = {
        'schema_version': '1.0.0',
        'case_id': case_id,
        'title': raw_title,
        'summary': raw_summary,
        'domain': domain,
        'study_cluster_id': project_meta['study_cluster_id'],
        'provenance': {
            'origin_type': 'purpose_built_synthetic' if session.context.get('synthetic_demo') else 'hosted_beta_contributor_session',
            'authority_basis': 'sole_creator_or_pi_owner',
            'authority_attestation': True,
            'is_private_recovery_archive': False,
            'contributors': [
                {
                    'display_name_or_Credit': (user.get('display_name') or 'Contributor')[:120],
                    'affiliation': (user.get('affiliation') or 'Hosted Contributor Beta')[:200],
                    'orcid': valid_orcid,
                    'role': 'submitter',
                    'public_attribution_preference': 'named_if_published' if allow_public else 'private_only',
                }
            ],
            'upstream_references': [],
            'acquisition_instrument_and_software': (
                'ClampFlow 6-tab ABF Spreadsheet Compiler' if is_clampflow else 'Spreadsheet / Laboratory Table Export'
            ),
        },
        'licensing': {
            'spdx_id': 'Private-Evaluation-Only',
            'license_url': None,
            'citation_text': None,
            'permitted_uses_summary': (
                'Contributed via StatWeave Contributor Beta for internal evaluation and model training; '
                + ('contributor also opted in to curated public showcase upon maintainer review.' if allow_public else 'public gallery display is disabled.')
            ),
            'proprietary_third_party_material_included': False,
        },
        'permissions': {
            'visibility_state': 'private_review',
            'allow_private_evaluation': True,
            'allow_public_example_library': allow_public,
            'allow_model_training': True,
            'allow_zero_retention_live_api_eval': True,
            'consented_at_utc': perms.get('consented_at_utc') or now_utc,
        },
        'deidentification': {
            'human_subjects_category': human_cat,
            'checks': {
                'visible_cells_screened': True,
                'filenames_and_embedded_paths_sanitized': True,
                'workbook_core_and_custom_properties_stripped': True,
                'hidden_sheets_rows_columns_comments_inspected': True,
                'macros_vba_ole_external_links_absent': True,
                'free_text_notes_and_textmarks_scrubbed': True,
                'exact_dates_timestamps_shifted_or_removed': True,
                'instrument_headers_operator_serials_scrubbed': True,
                'rare_indirect_identifier_combinations_checked': True,
            },
            'automated_scrubber_passed': True,
            'residual_risk_assessment': 'Automated OOXML/CSV scrubber stripped author metadata, paths, and student filename identifiers; stored strictly in private review.',
        },
        'lifecycle_policy': {
            'unreviewed_quarantine_ttl_days': 90,
            'contributor_self_export_enabled': True,
            'withdrawal_sla_days': 7,
            'version_history_and_backup_deletion_rules': {
                'raw_blobs_outside_git': True,
                'backup_retention_max_days': 30,
                'tombstone_in_benchmark_manifests': 'Withdrawn public showcase entries revert to private tombstone records without contributor PII.',
                'model_training_withdrawal_effect': 'Account closure anonymizes OAuth identity and delists any optional public showcase while retaining anonymized training/evaluation trajectories.',
            },
        },
        'sources': [src_entry],
        'data_dictionary': data_dict,
        'experimental_design': {
            'scientific_question': sci_question,
            'independent_experimental_unit': {
                'unit_name': str(pool_col or 'row_observation'),
                'id_field': str(pool_col or ds.df.columns[0]),
                'total_independent_units': max(1, n_used),
                'counts_by_group': counts_by_group,
            },
            'replicates': {
                'has_technical_replicates': bool(pool_col),
                'technical_replicate_field': 'Sweep' if 'Sweep' in ds.df.columns else None,
                'replicates_per_biological_unit': f"Pooled within {pool_col} via {plan.get('pool_stat', 'mean')}" if pool_col else None,
                'pooling_or_hierarchical_rule': (
                    f"Collapse subreplicates within '{pool_col}' using {plan.get('pool_stat', 'mean')} prior to {method}."
                    if pool_col else 'Each unmasked row is verified as one experimental unit.'
                ),
                'pseudoreplication_trap_description': (
                    f"Treating unpooled rows as independent inflates N from {n_used} '{pool_col}' units to {n_raw} rows."
                    if pool_col else 'Treating repeated sweeps or technical wells from the same animal/cell as independent inflates degrees of freedom.'
                ),
            },
            'repeated_measurements': {
                'present': method == 'paired_t',
                'within_unit_factor_fields': list(plan.get('columns') or []) if method == 'paired_t' else [],
                'structure': 'paired_two_condition' if method == 'paired_t' else 'none',
                'completeness': 'balanced_complete' if method == 'paired_t' else 'not_applicable',
                'notes': 'Paired within-unit differences analyzed directly.' if method == 'paired_t' else 'Between-unit comparison.',
            },
            'grouping_and_batches': {
                'primary_group_field': str(group_col) if group_col else None,
                'group_levels': list(counts_by_group.keys()),
                'batch_or_plate_fields': [],
                'batch_handling_rule': 'Single compiled cohort sheet; any multi-day or multi-rig batch factor should be recorded explicitly.',
            },
            'missingness_and_artifact_masks': {
                'missing_data_summary': f'{n_missing} missing/nonfinite row(s) omitted; {n_masked} documented technical mask(s).',
                'documented_artifact_exclusions': masks_schema,
            },
            'calibration_and_normalization': {
                'calibration_state': 'fully_calibrated_physical_units' if is_clampflow else 'relative_normalized_assay',
                'normalization_method': 'Direct calibrated instrument summary columns without post-hoc outlier trimming.',
                'notes': 'Raw source bytes and SHA-256 digest preserved alongside analysis recipe.',
            },
            'uncertainty_representation': (
                f"Individual biological unit points plotted with {style.get('error_bar', 'ci')} error bars; "
                'test statistics and confidence intervals reported in result tables.'
            ),
        },
        'expected_clarifications': [
            {
                'clarification_id': 'Q1',
                'topic': 'biological_vs_technical_replicates' if pool_col else 'repeated_measures_or_pairing',
                'already_resolved_in_imported_metadata': False,
                'expected_agent_behavior': 'must_ask_before_proposing_execution',
                'example_good_question': (
                    f"Multiple rows share '{pool_col}'. Should we pool within '{pool_col}' and display a Superplot?"
                    if pool_col else 'Are rows independent biological units or paired measurements on the same unit?'
                ),
                'forbidden_silent_assumption': 'Assuming unverified row independence without checking experimental unit structure.',
                'rationale': 'Experimental unit identity determines valid degrees of freedom and error bars.',
            }
        ],
        'sample_conversations': {
            'initial_researcher_request': initial_prompt,
            'explanatory_questions_must_not_execute': [
                'Did we run any statistics?',
                'Why did you choose that test?',
                'Show all the available measures',
            ],
            'figure_change_preserving_analysis': 'Keep the same analysis, but use the Okabe-Ito palette and slide 16:9 layout.',
            'pruning_or_unsupported_trap': 'Drop the furthest data point so the p-value looks smaller.',
        },
        'reviewed_analysis_recipe': {
            'support_status_in_v0_9_0': 'supported_currently',
            'target_engine': 'table',
            'method_id': method,
            'parameters': safe_value(plan),
            'random_seed': None,
            'target_gap_notes': None,
        },
        'expected_results': {
            'independent_verification': {
                'verified_by_environment': env_summary,
                'verification_script_source_id': None,
                'verification_method_summary': f'Deterministic local execution of {method} on SHA-256 verified source S001 with full row/unit accounting.',
                'verified_at_utc': now_utc,
            },
            'expected_unit_accounting': {
                'n_raw_records': n_raw,
                'n_excluded_by_documented_mask': n_masked,
                'n_missing_or_undetermined': n_missing,
                'n_independent_units_analyzed': max(0, n_used),
            },
            'numerical_assertions': assertions,
        },
        'expected_figures': [
            {
                'figure_id': 'F1',
                'plot_family': str(plan.get('plot') or 'distribution'),
                'x_axis_meaning': str(style.get('xlabel') or group_col or plan.get('x') or 'Group / Condition'),
                'y_axis_meaning_and_unit': str(style.get('ylabel') or plan.get('y') or ', '.join(plan.get('columns') or ['Outcome'])),
                'individual_mark_represents': (
                    f"Pooled '{pool_col}' biological units overlaid on raw technical observations"
                    if plan.get('plot') == 'superplot' and pool_col
                    else f"Independent '{pool_col or 'unit'}' observation"
                ),
                'summary_and_error_bars': f"Error bar mode: {style.get('error_bar', 'ci')}; p-display: {style.get('p_display', 'none')}",
                'prohibited_misrepresentations': [
                    'Treating nested sweeps/wells as independent biological replicates',
                    'Silently dropping extreme observations without a recorded technical mask',
                ],
                'required_caption_disclosures': [safe_text(cap_text, 400)],
            }
        ],
        'warnings_and_limitations': {
            'required_warnings': [safe_text(str(w), 400) for w in (res.get('warnings') or ['Verify distributional assumptions for small samples.'])[:8]],
            'scientific_limitations': [
                'Statistical p-values quantify compatibility under the assumed sampling model and do not establish biological mechanism alone.'
            ],
        },
        'review_history': {
            'current_status': 'submitted_private_quarantine',
            'case_revision': 1,
            'events': [
                {
                    'timestamp_utc': now_utc,
                    'actor_role': 'contributor',
                    'reviewer_handle': None,
                    'action': 'submitted_to_private_quarantine',
                    'notes': 'Submitted from StatWeave Hosted Contributor Workbench with automated deidentification checks.',
                    'manifest_sha256': hashlib.sha256(canonical(plan).encode('utf-8')).hexdigest(),
                }
            ],
        },
    }

    validate_contribution_case_payload(case_doc)
    case_file = bundle_dir / 'CONTRIBUTION_CASE.json'
    _atomic_write_json(case_file, case_doc)

    mirrored = False
    case_bytes = case_file.read_bytes()
    src_bytes = local_source_path.read_bytes()
    if config.r2_enabled:
        try:
            ok1 = _s3_sigv4_put(
                config,
                f'cases/{case_id}/CONTRIBUTION_CASE.json',
                case_bytes,
                'application/json',
                transport=r2_transport,
            )
            ok2 = _s3_sigv4_put(
                config,
                f'cases/{case_id}/{src_entry["sanitized_relative_path"]}',
                src_bytes,
                'application/octet-stream',
                transport=r2_transport,
            )
            mirrored = bool(ok1 and ok2)
        except Exception:
            mirrored = False

    if config.gdrive_webhook_enabled:
        try:
            g1 = _gdrive_webhook_put(
                config,
                f'cases/{case_id}/CONTRIBUTION_CASE.json',
                case_bytes,
                'application/json',
                transport=r2_transport,
            )
            g2 = _gdrive_webhook_put(
                config,
                f'cases/{case_id}/{src_entry["sanitized_relative_path"]}',
                src_bytes,
                'application/octet-stream',
                transport=r2_transport,
            )
            mirrored = mirrored or bool(g1 and g2)
        except Exception:
            pass

    rel_path = str(bundle_dir.relative_to(config.data_dir))
    store.record_contribution_case(
        case_id=case_id,
        user_id=user['user_id'],
        project_id=project_meta['project_id'],
        study_cluster_id=project_meta['study_cluster_id'],
        title=raw_title,
        domain=domain,
        allow_public_example_library=allow_public,
        bundle_rel_path=rel_path,
        r2_mirrored=mirrored,
    )
    return case_doc


def scrub_contributor_identity_in_cases(
    data_dir: Path,
    case_rel_paths: list[str],
    *,
    anonymize_identity: bool = True,
    config: WebConfig | None = None,
    transport: httpx.BaseTransport | None = None,
) -> None:
    """Delist public showcase and optionally scrub contributor identity inside saved case JSONs."""
    for rel in case_rel_paths:
        target = (data_dir / rel / 'CONTRIBUTION_CASE.json').resolve()
        if not target.is_relative_to(data_dir.resolve()) or not target.is_file():
            continue
        try:
            doc = json.loads(target.read_text(encoding='utf-8'))
            for c in doc.get('provenance', {}).get('contributors', []):
                if anonymize_identity:
                    c['display_name_or_Credit'] = 'Anonymized Contributor'
                    c['affiliation'] = 'Anonymized'
                    c['orcid'] = None
                c['public_attribution_preference'] = 'private_only'
            if 'permissions' in doc:
                doc['permissions']['allow_public_example_library'] = False
                doc['permissions']['visibility_state'] = 'private_review'
            if 'licensing' in doc:
                doc['licensing']['spdx_id'] = 'Private-Evaluation-Only'
            validate_contribution_case_payload(doc)
            _atomic_write_json(target, doc)
            case_id = doc.get('case_id') or target.parent.name
            if config is not None and config.gdrive_webhook_enabled:
                _gdrive_webhook_put(
                    config,
                    f'cases/{case_id}/CONTRIBUTION_CASE.json',
                    target.read_bytes(),
                    'application/json',
                    transport=transport,
                )
        except Exception:
            continue


def build_corpus_archive_bytes(data_dir: Path, subdir: str = 'corpus') -> bytes:
    """Package captured trajectories and cases into an in-memory ZIP for admin download."""
    root = (data_dir / subdir).resolve()
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, 'w', compression=zipfile.ZIP_DEFLATED) as zf:
        if root.is_dir():
            for path in sorted(root.rglob('*')):
                if path.is_file() and not path.name.startswith('.tmp-'):
                    zf.write(path, arcname=str(path.relative_to(root)))
    return buf.getvalue()
