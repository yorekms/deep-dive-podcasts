"""StatWeave hosted contributor workbench and learning-set API."""
from __future__ import annotations

from .config import WebConfig

try:
    from .server import create_app
except ImportError:  # pragma: no cover - Pyodide browser runtime without FastAPI
    create_app = None  # type: ignore[assignment]

__all__ = ['WebConfig', 'create_app']
