"""ORCID and GitHub OAuth 2.0 flows + popup postMessage callback bridge.

Supports both full-screen standalone browser redirects and popup sign-in from
embedded Carrd.co iframes (avoiding third-party cookie blocking and OAuth
X-Frame-Options restrictions).
"""
from __future__ import annotations

import html
import json
import re
from urllib.parse import urlencode

import httpx

from .config import WebConfig

_ORCID_ID_RE = re.compile(r'^[0-9]{4}-[0-9]{4}-[0-9]{4}-[0-9]{3}[0-9X]$')


class OAuthError(ValueError):
    """Sanitized OAuth verification error."""


def github_authorize_url(config: WebConfig, state: str) -> str:
    if not config.github_enabled:
        raise OAuthError('GitHub OAuth is not configured on this server.')
    redirect_uri = f'{config.public_base_url}/api/auth/github/callback'
    query = urlencode({
        'client_id': config.github_client_id,
        'redirect_uri': redirect_uri,
        'scope': 'read:user',
        'state': state,
    })
    return f'https://github.com/login/oauth/authorize?{query}'


def orcid_authorize_url(config: WebConfig, state: str) -> str:
    if not config.orcid_enabled:
        raise OAuthError('ORCID OAuth is not configured on this server.')
    redirect_uri = f'{config.public_base_url}/api/auth/orcid/callback'
    query = urlencode({
        'client_id': config.orcid_client_id,
        'response_type': 'code',
        'scope': '/authenticate',
        'redirect_uri': redirect_uri,
        'state': state,
    })
    return f'{config.orcid_base_url}/oauth/authorize?{query}'


def exchange_github_code(
    config: WebConfig,
    code: str,
    transport: httpx.BaseTransport | None = None,
) -> dict:
    if not config.github_enabled:
        raise OAuthError('GitHub OAuth is not configured on this server.')
    redirect_uri = f'{config.public_base_url}/api/auth/github/callback'
    with httpx.Client(timeout=15.0, transport=transport) as client:
        tok_resp = client.post(
            'https://github.com/login/oauth/access_token',
            headers={'Accept': 'application/json'},
            data={
                'client_id': config.github_client_id,
                'client_secret': config.github_client_secret,
                'code': code,
                'redirect_uri': redirect_uri,
            },
        )
        if tok_resp.status_code != 200:
            raise OAuthError('GitHub token exchange failed.')
        tok_data = tok_resp.json()
        access_token = tok_data.get('access_token')
        if not access_token or not isinstance(access_token, str):
            raise OAuthError('GitHub did not return an access token.')

        user_resp = client.get(
            'https://api.github.com/user',
            headers={
                'Authorization': f'Bearer {access_token}',
                'Accept': 'application/vnd.github+json',
                'User-Agent': 'StatWeave-Web-OAuth/1.0',
            },
        )
        if user_resp.status_code != 200:
            raise OAuthError('GitHub profile lookup failed.')
        profile = user_resp.json()

    gh_id = str(profile.get('id') or '').strip()
    login = str(profile.get('login') or '').strip()
    if not gh_id or not login:
        raise OAuthError('GitHub profile was incomplete.')
    name = str(profile.get('name') or login).strip()
    company = str(profile.get('company') or '').strip() or None
    return {
        'auth_provider': 'github',
        'provider_subject': gh_id,
        'display_name': name[:120],
        'handle_or_orcid': f'@{login}'[:120],
        'affiliation': company,
    }


def exchange_orcid_code(
    config: WebConfig,
    code: str,
    transport: httpx.BaseTransport | None = None,
) -> dict:
    if not config.orcid_enabled:
        raise OAuthError('ORCID OAuth is not configured on this server.')
    redirect_uri = f'{config.public_base_url}/api/auth/orcid/callback'
    with httpx.Client(timeout=15.0, transport=transport) as client:
        tok_resp = client.post(
            f'{config.orcid_base_url}/oauth/token',
            headers={'Accept': 'application/json'},
            data={
                'client_id': config.orcid_client_id,
                'client_secret': config.orcid_client_secret,
                'grant_type': 'authorization_code',
                'code': code,
                'redirect_uri': redirect_uri,
            },
        )
        if tok_resp.status_code != 200:
            raise OAuthError('ORCID token exchange failed.')
        data = tok_resp.json()

    orcid = str(data.get('orcid') or '').strip()
    if not _ORCID_ID_RE.fullmatch(orcid):
        raise OAuthError('ORCID did not return a valid 16-digit ORCID iD.')
    name = str(data.get('name') or f'ORCID {orcid}').strip()
    return {
        'auth_provider': 'orcid',
        'provider_subject': orcid,
        'display_name': name[:120],
        'handle_or_orcid': orcid,
        'affiliation': None,
    }


def render_popup_callback_html(
    session_token: str,
    user: dict,
    allowed_origins: tuple[str, ...],
    fallback_url: str = '/app',
) -> str:
    """Self-closing popup page that posts the session token to the opener frame."""
    payload = json.dumps({
        'type': 'statweave_oauth_complete',
        'token': session_token,
        'user': user,
    })
    origins_js = json.dumps(list(allowed_origins))
    safe_fallback = html.escape(fallback_url, quote=True)
    safe_name = html.escape(user.get('display_name', 'Contributor'))
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <title>Signed in to StatWeave</title>
  <style>
    body {{
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      background: #0b1120; color: #f1f5f9; display: flex; align-items: center;
      justify-content: center; min-height: 100vh; margin: 0; text-align: center;
    }}
    .card {{
      background: #131c31; border: 1px solid rgba(16,185,129,0.45);
      border-radius: 16px; padding: 28px 32px; max-width: 420px;
    }}
    a {{ color: #34d399; font-weight: 700; }}
  </style>
</head>
<body>
  <div class="card">
    <h2 style="margin:0 0 8px 0;">Signed in as {safe_name}</h2>
    <p style="color:#cbd5e1;font-size:14px;margin:0 0 16px 0;">
      Returning to your StatWeave workbench&hellip;
    </p>
    <p style="font-size:12px;"><a href="{safe_fallback}">Continue to workbench</a></p>
  </div>
  <script>
    (function () {{
      var msg = {payload};
      var origins = {origins_js};
      try {{
        sessionStorage.setItem('statweave_session_token', msg.token);
      }} catch (e) {{}}
      if (window.opener && !window.opener.closed) {{
        for (var i = 0; i < origins.length; i++) {{
          try {{ window.opener.postMessage(msg, origins[i]); }} catch (e) {{}}
        }}
        try {{ window.opener.postMessage(msg, window.location.origin); }} catch (e) {{}}
        setTimeout(function () {{ window.close(); }}, 250);
      }} else {{
        window.location.replace({json.dumps(fallback_url)});
      }}
    }})();
  </script>
</body>
</html>"""
