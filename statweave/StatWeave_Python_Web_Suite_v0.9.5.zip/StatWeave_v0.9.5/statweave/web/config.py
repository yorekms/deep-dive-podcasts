"""Server-only configuration for the hosted StatWeave contributor beta.

Secrets (OpenAI API keys, OAuth client secrets, session HMAC secrets, admin
tokens, and R2 credentials) are read strictly from environment variables or
test-time overrides, hidden from repr(), and never serialized to client JSON.
"""
from __future__ import annotations

from dataclasses import dataclass, field
import os
from pathlib import Path
import secrets

from ..provider_settings import validate_api_model


def _env_bool(name: str, default: bool) -> bool:
    raw = os.environ.get(name)
    if raw is None or not raw.strip():
        return default
    return raw.strip().lower() in {'1', 'true', 'yes', 'on'}


def _env_int(name: str, default: int, minimum: int = 1, maximum: int = 100_000_000) -> int:
    raw = os.environ.get(name)
    if raw is None or not raw.strip():
        return default
    try:
        val = int(raw.strip())
    except ValueError:
        return default
    return max(minimum, min(maximum, val))


def _split_origins(raw: str) -> tuple[str, ...]:
    items = []
    for part in (raw or '').split(','):
        cleaned = part.strip().rstrip('/')
        if cleaned and cleaned not in items:
            items.append(cleaned)
    return tuple(items)


def sanitize_api_key(raw: str) -> str:
    """Clean common copy/paste artifacts (quotes, env assignments, Bearer prefix, control chars, double-paste)."""
    if not isinstance(raw, str):
        return ''
    s = raw.strip()
    # Strip surrounding quotes/backticks
    while len(s) >= 2 and s[0] == s[-1] and s[0] in {'"', "'", '`'}:
        s = s[1:-1].strip()
    # Strip accidental env var assignment prefix (e.g. OPENAI_API_KEY=sk-...)
    for prefix in (
        'STATWEAVE_BETA_OPENAI_API_KEY=',
        'OPENAI_API_KEY=',
        'GEMINI_API_KEY=',
        'GOOGLE_API_KEY=',
        'Authorization:',
        'authorization:',
    ):
        if s.startswith(prefix):
            s = s[len(prefix):].strip()
    if s.lower().startswith('bearer '):
        s = s[7:].strip()
    while len(s) >= 2 and s[0] == s[-1] and s[0] in {'"', "'", '`'}:
        s = s[1:-1].strip()
    # Remove invisible control characters / spaces / wrapped newlines inside pasted key
    s = ''.join(ch for ch in s if 33 <= ord(ch) <= 126)
    # Detect accidental exact double-paste in masked password boxes (e.g. sk-abc...sk-abc...)
    if len(s) >= 40 and len(s) % 2 == 0:
        half = len(s) // 2
        if s[:half] == s[half:]:
            s = s[:half]
    return s


@dataclass
class WebConfig:
    data_dir: Path = field(default_factory=lambda: Path('./web_data').resolve())
    public_base_url: str = 'http://127.0.0.1:8000'
    carrd_portal_url: str = 'https://my-statweave.carrd.co'
    clampflow_portal_url: str = 'https://my-clampflow.carrd.co'
    allowed_origins: tuple[str, ...] = (
        'https://my-statweave.carrd.co',
        'https://my-clampflow.carrd.co',
        'https://carrd.co',
        'https://yorekms.github.io',
        'https://colab.research.google.com',
        'http://127.0.0.1:8000',
        'http://localhost:8000',
    )

    # Secrets — repr=False prevents accidental logging
    session_secret: str = field(default_factory=lambda: secrets.token_hex(32), repr=False)
    ephemeral_secret_warning: bool = False
    beta_openai_api_key: str = field(default='', repr=False)
    openai_model: str = 'gpt-4.1-mini'
    openai_timeout: int = 90
    allow_offline_fallback: bool = True

    # OAuth & Invite configuration
    github_client_id: str = ''
    github_client_secret: str = field(default='', repr=False)
    orcid_client_id: str = ''
    orcid_client_secret: str = field(default='', repr=False)
    orcid_sandbox: bool = False

    invite_code: str = field(default='', repr=False)
    require_invite_code: bool = False
    allow_invite_login: bool = True

    admin_token: str = field(default='', repr=False)

    # Spend & resource budgets
    daily_turn_limit: int = 40
    monthly_turn_limit: int = 500
    daily_token_limit: int = 150_000
    max_upload_bytes: int = 32 * 1024 * 1024
    max_paste_chars: int = 500_000
    max_projects_per_user: int = 50
    session_ttl_seconds: int = 14 * 24 * 3600

    # Optional Cloudflare R2 / S3-compatible private corpus mirror
    r2_endpoint_url: str = ''
    r2_bucket: str = ''
    r2_access_key_id: str = field(default='', repr=False)
    r2_secret_access_key: str = field(default='', repr=False)

    # Optional Private Google Drive Vault Bridge (Apps Script / HTTPS webhook)
    gdrive_webhook_url: str = ''
    gdrive_webhook_secret: str = field(default='', repr=False)

    @classmethod
    def from_env(cls) -> 'WebConfig':
        raw_data_dir = (
            os.environ.get('STATWEAVE_DATA_DIR', '').strip()
            or os.environ.get('STATWEAVE_WEB_DATA_DIR', '').strip()
            or './web_data'
        )
        data_dir = Path(raw_data_dir).expanduser().resolve()
        raw_secret = os.environ.get('STATWEAVE_SESSION_SECRET', '').strip()
        ephemeral = False
        if len(raw_secret) < 32:
            raw_secret = secrets.token_hex(32)
            ephemeral = True

        # Separate owner-funded beta user key from any dev/eval key (supports OpenAI sk-... and Gemini AIza...)
        raw_key = (
            os.environ.get('STATWEAVE_BETA_OPENAI_API_KEY', '').strip()
            or os.environ.get('OPENAI_API_KEY', '').strip()
            or os.environ.get('GEMINI_API_KEY', '').strip()
            or os.environ.get('GOOGLE_API_KEY', '').strip()
        )
        beta_key = sanitize_api_key(raw_key)
        default_m = 'gemini-4-hydrogen' if beta_key.startswith('AIza') else 'gpt-4.1-mini'
        raw_model = os.environ.get('STATWEAVE_OPENAI_MODEL', '').strip() or default_m
        model = raw_model if raw_model.startswith(('gemini-', 'gemma-')) else validate_api_model(raw_model)

        public_base = (os.environ.get('STATWEAVE_PUBLIC_BASE_URL', '') or 'http://127.0.0.1:8000').strip().rstrip('/')
        carrd_url = (os.environ.get('STATWEAVE_CARRD_URL', '') or 'https://my-statweave.carrd.co').strip().rstrip('/')
        clampflow_url = (os.environ.get('STATWEAVE_CLAMPFLOW_URL', '') or 'https://my-clampflow.carrd.co').strip().rstrip('/')

        default_origins = ','.join(filter(None, [
            carrd_url,
            clampflow_url,
            'https://carrd.co',
            'https://yorekms.github.io',
            'https://colab.research.google.com',
            public_base,
            'http://127.0.0.1:8000',
            'http://localhost:8000',
        ]))
        origins = _split_origins(os.environ.get('STATWEAVE_ALLOWED_ORIGINS', default_origins))

        invite = os.environ.get('STATWEAVE_INVITE_CODE', '').strip()
        allow_invite = _env_bool('STATWEAVE_ALLOW_INVITE_LOGIN', True)

        return cls(
            data_dir=data_dir,
            public_base_url=public_base,
            carrd_portal_url=carrd_url,
            clampflow_portal_url=clampflow_url,
            allowed_origins=origins,
            session_secret=raw_secret,
            ephemeral_secret_warning=ephemeral,
            beta_openai_api_key=beta_key,
            openai_model=model,
            openai_timeout=_env_int('STATWEAVE_OPENAI_TIMEOUT', 90, 5, 120),
            allow_offline_fallback=_env_bool('STATWEAVE_ALLOW_OFFLINE_FALLBACK', True),
            github_client_id=os.environ.get('STATWEAVE_GITHUB_CLIENT_ID', '').strip(),
            github_client_secret=os.environ.get('STATWEAVE_GITHUB_CLIENT_SECRET', '').strip(),
            orcid_client_id=os.environ.get('STATWEAVE_ORCID_CLIENT_ID', '').strip(),
            orcid_client_secret=os.environ.get('STATWEAVE_ORCID_CLIENT_SECRET', '').strip(),
            orcid_sandbox=_env_bool('STATWEAVE_ORCID_SANDBOX', False),
            invite_code=invite,
            require_invite_code=_env_bool('STATWEAVE_REQUIRE_INVITE_CODE', False),
            allow_invite_login=allow_invite,
            admin_token=os.environ.get('STATWEAVE_ADMIN_TOKEN', '').strip(),
            daily_turn_limit=_env_int('STATWEAVE_DAILY_TURN_LIMIT', 40, 1, 10_000),
            monthly_turn_limit=_env_int('STATWEAVE_MONTHLY_TURN_LIMIT', 500, 1, 100_000),
            daily_token_limit=_env_int('STATWEAVE_DAILY_TOKEN_LIMIT', 150_000, 1_000, 50_000_000),
            max_upload_bytes=_env_int('STATWEAVE_MAX_UPLOAD_BYTES', 32 * 1024 * 1024, 65_536, 128 * 1024 * 1024),
            max_paste_chars=_env_int('STATWEAVE_MAX_PASTE_CHARS', 500_000, 1_000, 5_000_000),
            max_projects_per_user=_env_int('STATWEAVE_MAX_PROJECTS_PER_USER', 50, 1, 1_000),
            session_ttl_seconds=_env_int('STATWEAVE_SESSION_TTL_SECONDS', 14 * 24 * 3600, 300, 90 * 24 * 3600),
            r2_endpoint_url=os.environ.get('STATWEAVE_R2_ENDPOINT_URL', '').strip().rstrip('/'),
            r2_bucket=os.environ.get('STATWEAVE_R2_BUCKET', '').strip(),
            r2_access_key_id=os.environ.get('STATWEAVE_R2_ACCESS_KEY_ID', '').strip(),
            r2_secret_access_key=os.environ.get('STATWEAVE_R2_SECRET_ACCESS_KEY', '').strip(),
            gdrive_webhook_url=os.environ.get('STATWEAVE_GDRIVE_WEBHOOK_URL', '').strip(),
            gdrive_webhook_secret=os.environ.get('STATWEAVE_GDRIVE_WEBHOOK_SECRET', '').strip(),
        )

    @property
    def github_enabled(self) -> bool:
        return bool(self.github_client_id and self.github_client_secret)

    @property
    def orcid_enabled(self) -> bool:
        return bool(self.orcid_client_id and self.orcid_client_secret)

    @property
    def openai_enabled(self) -> bool:
        return bool(self.beta_openai_api_key)

    @property
    def is_gemini_key(self) -> bool:
        return bool(self.beta_openai_api_key and sanitize_api_key(self.beta_openai_api_key).startswith('AIza'))

    def resolve_openai_key(self) -> str:
        cleaned = sanitize_api_key(self.beta_openai_api_key)
        if not cleaned:
            raise ValueError('No server API key is configured.')
        return cleaned

    @property
    def r2_enabled(self) -> bool:
        return bool(self.r2_endpoint_url and self.r2_bucket and self.r2_access_key_id and self.r2_secret_access_key)

    @property
    def gdrive_webhook_enabled(self) -> bool:
        return bool(self.gdrive_webhook_url and self.gdrive_webhook_url.startswith(('https://', 'http://127.0.0.1', 'http://localhost')))

    @property
    def orcid_base_url(self) -> str:
        return 'https://sandbox.orcid.org' if self.orcid_sandbox else 'https://orcid.org'

    def public_auth_config(self) -> dict:
        """Safe non-secret capabilities payload for the browser UI."""
        invite_open = self.allow_invite_login and (
            bool(self.invite_code) or (not self.github_enabled and not self.orcid_enabled)
        )
        return {
            'github_oauth_enabled': self.github_enabled,
            'orcid_oauth_enabled': self.orcid_enabled,
            'invite_login_enabled': invite_open,
            'invite_code_required': bool(self.invite_code) and (self.require_invite_code or invite_open),
            'demo_guest_invite_available': self.allow_invite_login and not self.invite_code and not self.github_enabled and not self.orcid_enabled,
            'openai_configured': self.openai_enabled,
            'llm_provider': ('gemini' if self.is_gemini_key else 'openai') if self.openai_enabled else None,
            'openai_model': self.openai_model if self.openai_enabled else None,
            'offline_fallback_enabled': self.allow_offline_fallback,
            'carrd_portal_url': self.carrd_portal_url,
            'clampflow_portal_url': self.clampflow_portal_url,
            'gdrive_mirror_enabled': self.gdrive_webhook_enabled,
            'quotas': {
                'daily_turn_limit': self.daily_turn_limit,
                'monthly_turn_limit': self.monthly_turn_limit,
                'daily_token_limit': self.daily_token_limit,
                'max_upload_mb': round(self.max_upload_bytes / (1024 * 1024), 1),
            },
        }
