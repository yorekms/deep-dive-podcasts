"""SQLite WAL backing store for users, sessions, quotas, projects, and corpus index.

Design invariants:
- Raw session tokens are never stored; only SHA-256 digests are persisted.
- Every project lookup requires matching (project_id, user_id) AND resolves
  strictly inside that user's isolated workspace directory.
- Account anonymization ("Keep Training" policy) unlinks OAuth identity/display
  metadata and delists any optional public showcase while preserving already-
  contributed anonymized training trajectories.
"""
from __future__ import annotations

from contextlib import contextmanager
from datetime import datetime, timezone
import hashlib
import hmac
import json
from pathlib import Path
import secrets
import sqlite3
from typing import Any
import uuid


def _utc_now() -> str:
    return datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')


def _utc_day_month() -> tuple[str, str]:
    now = datetime.now(timezone.utc)
    return now.strftime('%Y-%m-%d'), now.strftime('%Y-%m')


def _sha256_text(value: str) -> str:
    return hashlib.sha256(value.encode('utf-8')).hexdigest()


class QuotaExceededError(ValueError):
    """Raised when a user reaches their daily or monthly OpenAI turn/token cap."""


class WebStore:
    def __init__(self, db_path: Path, session_secret: str):
        self.db_path = Path(db_path).resolve()
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._secret = session_secret.encode('utf-8')
        self._init_schema()

    @contextmanager
    def _connect(self):
        conn = sqlite3.connect(str(self.db_path), timeout=15.0)
        conn.row_factory = sqlite3.Row
        try:
            conn.execute('PRAGMA journal_mode=WAL;')
            conn.execute('PRAGMA synchronous=NORMAL;')
            conn.execute('PRAGMA foreign_keys=ON;')
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def _init_schema(self) -> None:
        with self._connect() as conn:
            conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS users (
                    user_id TEXT PRIMARY KEY,
                    auth_provider TEXT NOT NULL,
                    provider_subject TEXT NOT NULL,
                    display_name TEXT NOT NULL,
                    handle_or_orcid TEXT,
                    affiliation TEXT,
                    allow_private_evaluation INTEGER NOT NULL DEFAULT 0,
                    allow_model_training INTEGER NOT NULL DEFAULT 0,
                    allow_public_example_library INTEGER NOT NULL DEFAULT 0,
                    consented_at_utc TEXT,
                    anonymized_at_utc TEXT,
                    created_at_utc TEXT NOT NULL,
                    UNIQUE(auth_provider, provider_subject)
                );

                CREATE TABLE IF NOT EXISTS oauth_states (
                    state TEXT PRIMARY KEY,
                    provider TEXT NOT NULL,
                    popup INTEGER NOT NULL DEFAULT 0,
                    invite_verified INTEGER NOT NULL DEFAULT 0,
                    expires_epoch REAL NOT NULL
                );

                CREATE TABLE IF NOT EXISTS auth_sessions (
                    token_sha256 TEXT PRIMARY KEY,
                    user_id TEXT NOT NULL REFERENCES users(user_id),
                    expires_epoch REAL NOT NULL,
                    revoked_at_utc TEXT,
                    created_at_utc TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS web_projects (
                    project_id TEXT PRIMARY KEY,
                    user_id TEXT NOT NULL REFERENCES users(user_id),
                    project_dir_rel TEXT NOT NULL,
                    title TEXT NOT NULL,
                    detected_format TEXT NOT NULL,
                    source_sha256 TEXT NOT NULL,
                    study_cluster_id TEXT NOT NULL,
                    created_at_utc TEXT NOT NULL,
                    updated_at_utc TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_web_projects_user ON web_projects(user_id, updated_at_utc DESC);

                CREATE TABLE IF NOT EXISTS usage_ledger (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id TEXT NOT NULL REFERENCES users(user_id),
                    project_id TEXT,
                    day_utc TEXT NOT NULL,
                    month_utc TEXT NOT NULL,
                    provider TEXT NOT NULL,
                    model TEXT NOT NULL,
                    input_tokens INTEGER NOT NULL DEFAULT 0,
                    output_tokens INTEGER NOT NULL DEFAULT 0,
                    total_tokens INTEGER NOT NULL DEFAULT 0,
                    created_at_utc TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_usage_user_day ON usage_ledger(user_id, day_utc);
                CREATE INDEX IF NOT EXISTS idx_usage_user_month ON usage_ledger(user_id, month_utc);

                CREATE TABLE IF NOT EXISTS captured_trajectories (
                    trajectory_id TEXT PRIMARY KEY,
                    project_id TEXT NOT NULL,
                    user_id TEXT NOT NULL,
                    study_cluster_id TEXT NOT NULL,
                    trigger_event TEXT NOT NULL,
                    detected_format TEXT NOT NULL,
                    has_completed_result INTEGER NOT NULL DEFAULT 0,
                    method TEXT,
                    plot TEXT,
                    turn_count INTEGER NOT NULL DEFAULT 0,
                    feedback_rating TEXT,
                    feedback_note TEXT,
                    bundle_rel_path TEXT NOT NULL,
                    r2_mirrored INTEGER NOT NULL DEFAULT 0,
                    created_at_utc TEXT NOT NULL,
                    updated_at_utc TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS contribution_cases (
                    case_id TEXT PRIMARY KEY,
                    user_id TEXT NOT NULL,
                    project_id TEXT NOT NULL,
                    study_cluster_id TEXT NOT NULL,
                    title TEXT NOT NULL,
                    domain TEXT NOT NULL,
                    visibility_state TEXT NOT NULL DEFAULT 'private_review',
                    allow_private_evaluation INTEGER NOT NULL DEFAULT 1,
                    allow_model_training INTEGER NOT NULL DEFAULT 1,
                    allow_public_example_library INTEGER NOT NULL DEFAULT 0,
                    bundle_rel_path TEXT NOT NULL,
                    r2_mirrored INTEGER NOT NULL DEFAULT 0,
                    created_at_utc TEXT NOT NULL,
                    updated_at_utc TEXT NOT NULL
                );
                """
            )

    def study_cluster_for(self, user_id: str, source_sha256: str) -> str:
        """Deterministic leak-free cluster key across repeated runs of the same source."""
        digest = hmac.new(
            self._secret,
            f'cluster:{user_id}:{source_sha256}'.encode('utf-8'),
            hashlib.sha256,
        ).hexdigest()[:16]
        return f'sw-cluster-{digest}'

    # --- OAuth CSRF States ---

    def create_oauth_state(self, provider: str, popup: bool, invite_verified: bool, ttl_seconds: int = 600) -> str:
        now_ts = datetime.now(timezone.utc).timestamp()
        state = secrets.token_urlsafe(24)
        with self._connect() as conn:
            conn.execute('DELETE FROM oauth_states WHERE expires_epoch < ?', (now_ts,))
            conn.execute(
                'INSERT INTO oauth_states (state, provider, popup, invite_verified, expires_epoch) VALUES (?, ?, ?, ?, ?)',
                (state, provider, int(bool(popup)), int(bool(invite_verified)), now_ts + ttl_seconds),
            )
        return state

    def consume_oauth_state(self, state: str, provider: str) -> dict | None:
        if not state or not isinstance(state, str):
            return None
        now_ts = datetime.now(timezone.utc).timestamp()
        with self._connect() as conn:
            row = conn.execute(
                'SELECT state, provider, popup, invite_verified, expires_epoch FROM oauth_states WHERE state = ? AND provider = ?',
                (state, provider),
            ).fetchone()
            conn.execute('DELETE FROM oauth_states WHERE state = ? OR expires_epoch < ?', (state, now_ts))
            if not row or float(row['expires_epoch']) < now_ts:
                return None
            return {
                'popup': bool(row['popup']),
                'invite_verified': bool(row['invite_verified']),
            }

    # --- Users & Consent ---

    def upsert_user(
        self,
        auth_provider: str,
        provider_subject: str,
        display_name: str,
        handle_or_orcid: str | None = None,
        affiliation: str | None = None,
        allow_private_evaluation: bool = False,
        allow_model_training: bool = False,
        allow_public_example_library: bool = False,
    ) -> dict:
        now = _utc_now()
        clean_name = (display_name or 'Research Contributor').strip()[:120]
        clean_handle = (handle_or_orcid or '').strip()[:120] or None
        clean_affil = (affiliation or '').strip()[:200] or None
        consented = now if (allow_private_evaluation and allow_model_training) else None

        with self._connect() as conn:
            existing = conn.execute(
                'SELECT * FROM users WHERE auth_provider = ? AND provider_subject = ?',
                (auth_provider, provider_subject),
            ).fetchone()
            if existing:
                user_id = existing['user_id']
                new_priv = int(bool(existing['allow_private_evaluation']) or allow_private_evaluation)
                new_train = int(bool(existing['allow_model_training']) or allow_model_training)
                new_pub = int(allow_public_example_library if allow_public_example_library else bool(existing['allow_public_example_library']))
                new_consented = existing['consented_at_utc'] or (now if (new_priv and new_train) else None)
                conn.execute(
                    """
                    UPDATE users
                    SET display_name = ?, handle_or_orcid = COALESCE(?, handle_or_orcid),
                        affiliation = COALESCE(?, affiliation),
                        allow_private_evaluation = ?, allow_model_training = ?,
                        allow_public_example_library = ?, consented_at_utc = ?
                    WHERE user_id = ?
                    """,
                    (clean_name, clean_handle, clean_affil, new_priv, new_train, new_pub, new_consented, user_id),
                )
            else:
                user_id = f'usr_{uuid.uuid4().hex[:16]}'
                conn.execute(
                    """
                    INSERT INTO users (
                        user_id, auth_provider, provider_subject, display_name,
                        handle_or_orcid, affiliation, allow_private_evaluation,
                        allow_model_training, allow_public_example_library,
                        consented_at_utc, created_at_utc
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        user_id,
                        auth_provider,
                        provider_subject,
                        clean_name,
                        clean_handle,
                        clean_affil,
                        int(bool(allow_private_evaluation)),
                        int(bool(allow_model_training)),
                        int(bool(allow_public_example_library)),
                        consented,
                        now,
                    ),
                )
            row = conn.execute('SELECT * FROM users WHERE user_id = ?', (user_id,)).fetchone()
            return self._user_dict(row)

    def update_consent(
        self,
        user_id: str,
        allow_private_evaluation: bool,
        allow_model_training: bool,
        allow_public_example_library: bool = False,
        affiliation: str | None = None,
    ) -> dict:
        if not (allow_private_evaluation and allow_model_training):
            raise ValueError(
                'The owner-funded StatWeave Contributor Beta requires consent to deidentified '
                'private evaluation and model-training contribution. To analyze data without '
                'contributing, run the local StatWeave desktop app with offline commands or your own key.'
            )
        now = _utc_now()
        clean_affil = (affiliation or '').strip()[:200] or None
        with self._connect() as conn:
            conn.execute(
                """
                UPDATE users
                SET allow_private_evaluation = 1,
                    allow_model_training = 1,
                    allow_public_example_library = ?,
                    affiliation = COALESCE(?, affiliation),
                    consented_at_utc = COALESCE(consented_at_utc, ?)
                WHERE user_id = ? AND anonymized_at_utc IS NULL
                """,
                (int(bool(allow_public_example_library)), clean_affil, now, user_id),
            )
            row = conn.execute('SELECT * FROM users WHERE user_id = ?', (user_id,)).fetchone()
            if not row:
                raise ValueError('User account not found.')
            return self._user_dict(row)

    def get_user(self, user_id: str) -> dict | None:
        with self._connect() as conn:
            row = conn.execute('SELECT * FROM users WHERE user_id = ?', (user_id,)).fetchone()
            return self._user_dict(row) if row else None

    @staticmethod
    def _user_dict(row: sqlite3.Row) -> dict:
        has_consent = bool(row['allow_private_evaluation']) and bool(row['allow_model_training'])
        return {
            'user_id': row['user_id'],
            'auth_provider': row['auth_provider'],
            'display_name': row['display_name'],
            'handle_or_orcid': row['handle_or_orcid'],
            'affiliation': row['affiliation'],
            'permissions': {
                'allow_private_evaluation': bool(row['allow_private_evaluation']),
                'allow_model_training': bool(row['allow_model_training']),
                'allow_public_example_library': bool(row['allow_public_example_library']),
                'consented_at_utc': row['consented_at_utc'],
                'contributor_ready': has_consent,
            },
            'anonymized_at_utc': row['anonymized_at_utc'],
            'created_at_utc': row['created_at_utc'],
        }

    # --- Sessions ---

    def create_session_token(self, user_id: str, ttl_seconds: int) -> str:
        raw_token = f'sws_{secrets.token_urlsafe(32)}'
        sig = hmac.new(self._secret, raw_token.encode('utf-8'), hashlib.sha256).hexdigest()[:24]
        signed = f'{raw_token}.{sig}'
        token_hash = _sha256_text(signed)
        expires = datetime.now(timezone.utc).timestamp() + ttl_seconds
        with self._connect() as conn:
            conn.execute(
                'INSERT INTO auth_sessions (token_sha256, user_id, expires_epoch, created_at_utc) VALUES (?, ?, ?, ?)',
                (token_hash, user_id, expires, _utc_now()),
            )
        return signed

    def verify_session_token(self, signed_token: str | None) -> dict | None:
        if not signed_token or '.' not in signed_token or len(signed_token) > 200:
            return None
        raw_token, sig = signed_token.rsplit('.', 1)
        expected = hmac.new(self._secret, raw_token.encode('utf-8'), hashlib.sha256).hexdigest()[:24]
        if not hmac.compare_digest(sig, expected):
            return None
        token_hash = _sha256_text(signed_token)
        now_ts = datetime.now(timezone.utc).timestamp()
        with self._connect() as conn:
            row = conn.execute(
                """
                SELECT u.*
                FROM auth_sessions s
                JOIN users u ON u.user_id = s.user_id
                WHERE s.token_sha256 = ?
                  AND s.revoked_at_utc IS NULL
                  AND s.expires_epoch > ?
                  AND u.anonymized_at_utc IS NULL
                """,
                (token_hash, now_ts),
            ).fetchone()
            return self._user_dict(row) if row else None

    def revoke_session_token(self, signed_token: str | None) -> None:
        if not signed_token:
            return
        token_hash = _sha256_text(signed_token)
        with self._connect() as conn:
            conn.execute(
                'UPDATE auth_sessions SET revoked_at_utc = ? WHERE token_sha256 = ?',
                (_utc_now(), token_hash),
            )

    # --- Quotas & Usage ---

    def usage_status(self, user_id: str, daily_turns: int, monthly_turns: int, daily_tokens: int) -> dict:
        day_utc, month_utc = _utc_day_month()
        with self._connect() as conn:
            day_row = conn.execute(
                """
                SELECT COUNT(*) AS turns, COALESCE(SUM(total_tokens), 0) AS tokens
                FROM usage_ledger
                WHERE user_id = ? AND day_utc = ? AND provider IN ('openai', 'gemini')
                """,
                (user_id, day_utc),
            ).fetchone()
            month_row = conn.execute(
                """
                SELECT COUNT(*) AS turns, COALESCE(SUM(total_tokens), 0) AS tokens
                FROM usage_ledger
                WHERE user_id = ? AND month_utc = ? AND provider IN ('openai', 'gemini')
                """,
                (user_id, month_utc),
            ).fetchone()
        used_day_turns = int(day_row['turns'])
        used_day_tokens = int(day_row['tokens'])
        used_month_turns = int(month_row['turns'])
        return {
            'day_utc': day_utc,
            'month_utc': month_utc,
            'daily_turns_used': used_day_turns,
            'daily_turn_limit': daily_turns,
            'daily_turns_remaining': max(0, daily_turns - used_day_turns),
            'daily_tokens_used': used_day_tokens,
            'daily_token_limit': daily_tokens,
            'monthly_turns_used': used_month_turns,
            'monthly_turn_limit': monthly_turns,
            'monthly_turns_remaining': max(0, monthly_turns - used_month_turns),
        }

    def assert_openai_quota(self, user_id: str, daily_turns: int, monthly_turns: int, daily_tokens: int) -> dict:
        status = self.usage_status(user_id, daily_turns, monthly_turns, daily_tokens)
        if status['daily_turns_used'] >= daily_turns:
            raise QuotaExceededError(
                f"Daily hosted AI turn limit reached ({daily_turns} turns/UTC day). "
                "Your projects, figures, worksheet tabs, style presets, and exports remain fully usable."
            )
        if status['monthly_turns_used'] >= monthly_turns:
            raise QuotaExceededError(
                f"Monthly hosted AI turn limit reached ({monthly_turns} turns/UTC month). "
                "Your saved results, style controls, and reproducible ZIP exports remain available."
            )
        if status['daily_tokens_used'] >= daily_tokens:
            raise QuotaExceededError(
                f"Daily hosted AI token budget reached ({daily_tokens:,} tokens/UTC day). "
                "You can still approve proposals, adjust figure presets/colors, and export your results."
            )
        return status

    def record_usage(
        self,
        user_id: str,
        project_id: str | None,
        provider: str,
        model: str,
        usage: dict | None = None,
    ) -> None:
        day_utc, month_utc = _utc_day_month()
        u = usage or {}
        in_tok = max(0, int(u.get('input_tokens', 0) or 0))
        out_tok = max(0, int(u.get('output_tokens', 0) or 0))
        tot_tok = max(in_tok + out_tok, int(u.get('total_tokens', 0) or 0))
        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO usage_ledger (
                    user_id, project_id, day_utc, month_utc, provider, model,
                    input_tokens, output_tokens, total_tokens, created_at_utc
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (user_id, project_id, day_utc, month_utc, provider, model[:100], in_tok, out_tok, tot_tok, _utc_now()),
            )

    # --- Isolated User Projects ---

    def count_user_projects(self, user_id: str) -> int:
        with self._connect() as conn:
            row = conn.execute('SELECT COUNT(*) AS n FROM web_projects WHERE user_id = ?', (user_id,)).fetchone()
            return int(row['n'])

    def register_project(
        self,
        user_id: str,
        project_dir_rel: str,
        title: str,
        detected_format: str,
        source_sha256: str,
    ) -> dict:
        project_id = f'prj_{uuid.uuid4().hex[:16]}'
        now = _utc_now()
        cluster_id = self.study_cluster_for(user_id, source_sha256)
        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO web_projects (
                    project_id, user_id, project_dir_rel, title, detected_format,
                    source_sha256, study_cluster_id, created_at_utc, updated_at_utc
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (project_id, user_id, project_dir_rel, title[:160], detected_format[:64], source_sha256, cluster_id, now, now),
            )
            row = conn.execute('SELECT * FROM web_projects WHERE project_id = ?', (project_id,)).fetchone()
            return dict(row)

    def touch_project(self, project_id: str, user_id: str, title: str | None = None) -> None:
        now = _utc_now()
        with self._connect() as conn:
            if title:
                conn.execute(
                    'UPDATE web_projects SET updated_at_utc = ?, title = ? WHERE project_id = ? AND user_id = ?',
                    (now, title[:160], project_id, user_id),
                )
            else:
                conn.execute(
                    'UPDATE web_projects SET updated_at_utc = ? WHERE project_id = ? AND user_id = ?',
                    (now, project_id, user_id),
                )

    def get_user_project(self, project_id: str, user_id: str) -> dict | None:
        with self._connect() as conn:
            row = conn.execute(
                'SELECT * FROM web_projects WHERE project_id = ? AND user_id = ?',
                (project_id, user_id),
            ).fetchone()
            return dict(row) if row else None

    def list_user_projects(self, user_id: str) -> list[dict]:
        with self._connect() as conn:
            rows = conn.execute(
                """
                SELECT project_id, title, detected_format, source_sha256, study_cluster_id,
                       created_at_utc, updated_at_utc
                FROM web_projects
                WHERE user_id = ?
                ORDER BY updated_at_utc DESC
                LIMIT 100
                """,
                (user_id,),
            ).fetchall()
            return [dict(r) for r in rows]

    # --- Learning-Set Trajectory & Contribution Case Index ---

    def upsert_trajectory(
        self,
        trajectory_id: str,
        project_id: str,
        user_id: str,
        study_cluster_id: str,
        trigger_event: str,
        detected_format: str,
        has_completed_result: bool,
        method: str | None,
        plot: str | None,
        turn_count: int,
        bundle_rel_path: str,
        r2_mirrored: bool = False,
        feedback_rating: str | None = None,
        feedback_note: str | None = None,
    ) -> None:
        now = _utc_now()
        with self._connect() as conn:
            existing = conn.execute(
                'SELECT trajectory_id FROM captured_trajectories WHERE trajectory_id = ?',
                (trajectory_id,),
            ).fetchone()
            if existing:
                conn.execute(
                    """
                    UPDATE captured_trajectories
                    SET trigger_event = ?, detected_format = ?, has_completed_result = ?,
                        method = ?, plot = ?, turn_count = ?, bundle_rel_path = ?,
                        r2_mirrored = MAX(r2_mirrored, ?),
                        feedback_rating = COALESCE(?, feedback_rating),
                        feedback_note = COALESCE(?, feedback_note),
                        updated_at_utc = ?
                    WHERE trajectory_id = ?
                    """,
                    (
                        trigger_event,
                        detected_format,
                        int(bool(has_completed_result)),
                        method,
                        plot,
                        int(turn_count),
                        bundle_rel_path,
                        int(bool(r2_mirrored)),
                        feedback_rating,
                        feedback_note,
                        now,
                        trajectory_id,
                    ),
                )
            else:
                conn.execute(
                    """
                    INSERT INTO captured_trajectories (
                        trajectory_id, project_id, user_id, study_cluster_id,
                        trigger_event, detected_format, has_completed_result,
                        method, plot, turn_count, feedback_rating, feedback_note,
                        bundle_rel_path, r2_mirrored, created_at_utc, updated_at_utc
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        trajectory_id,
                        project_id,
                        user_id,
                        study_cluster_id,
                        trigger_event,
                        detected_format,
                        int(bool(has_completed_result)),
                        method,
                        plot,
                        int(turn_count),
                        feedback_rating,
                        feedback_note,
                        bundle_rel_path,
                        int(bool(r2_mirrored)),
                        now,
                        now,
                    ),
                )

    def record_contribution_case(
        self,
        case_id: str,
        user_id: str,
        project_id: str,
        study_cluster_id: str,
        title: str,
        domain: str,
        allow_public_example_library: bool,
        bundle_rel_path: str,
        r2_mirrored: bool = False,
    ) -> dict:
        now = _utc_now()
        with self._connect() as conn:
            conn.execute(
                """
                INSERT OR REPLACE INTO contribution_cases (
                    case_id, user_id, project_id, study_cluster_id, title, domain,
                    visibility_state, allow_private_evaluation, allow_model_training,
                    allow_public_example_library, bundle_rel_path, r2_mirrored,
                    created_at_utc, updated_at_utc
                ) VALUES (?, ?, ?, ?, ?, ?, 'private_review', 1, 1, ?, ?, ?, ?, ?)
                """,
                (
                    case_id,
                    user_id,
                    project_id,
                    study_cluster_id,
                    title[:180],
                    domain,
                    int(bool(allow_public_example_library)),
                    bundle_rel_path,
                    int(bool(r2_mirrored)),
                    now,
                    now,
                ),
            )
            row = conn.execute('SELECT * FROM contribution_cases WHERE case_id = ?', (case_id,)).fetchone()
            return dict(row)

    def withdraw_public_showcase(self, user_id: str, case_id: str) -> dict | None:
        now = _utc_now()
        with self._connect() as conn:
            row = conn.execute(
                'SELECT * FROM contribution_cases WHERE case_id = ? AND user_id = ?',
                (case_id, user_id),
            ).fetchone()
            if not row:
                return None
            conn.execute(
                """
                UPDATE contribution_cases
                SET allow_public_example_library = 0,
                    visibility_state = 'private_review',
                    updated_at_utc = ?
                WHERE case_id = ? AND user_id = ?
                """,
                (now, case_id, user_id),
            )
            updated = conn.execute('SELECT * FROM contribution_cases WHERE case_id = ?', (case_id,)).fetchone()
            return dict(updated)

    def list_user_contributions(self, user_id: str) -> dict:
        with self._connect() as conn:
            trajs = [
                dict(r)
                for r in conn.execute(
                    """
                    SELECT trajectory_id, project_id, study_cluster_id, detected_format,
                           has_completed_result, method, plot, turn_count,
                           feedback_rating, feedback_note, created_at_utc, updated_at_utc
                    FROM captured_trajectories
                    WHERE user_id = ?
                    ORDER BY updated_at_utc DESC
                    """,
                    (user_id,),
                ).fetchall()
            ]
            cases = [
                dict(r)
                for r in conn.execute(
                    """
                    SELECT case_id, project_id, study_cluster_id, title, domain,
                           visibility_state, allow_private_evaluation, allow_model_training,
                           allow_public_example_library, bundle_rel_path, created_at_utc, updated_at_utc
                    FROM contribution_cases
                    WHERE user_id = ?
                    ORDER BY updated_at_utc DESC
                    """,
                    (user_id,),
                ).fetchall()
            ]
        return {'trajectories': trajs, 'contribution_cases': cases}

    def anonymize_account(self, user_id: str) -> list[str]:
        """Unlink OAuth identity & delist public showcase while retaining anonymized training corpus."""
        now = _utc_now()
        tombstone_subject = f'anonymized:{uuid.uuid4().hex}'
        with self._connect() as conn:
            case_paths = [
                r['bundle_rel_path']
                for r in conn.execute(
                    'SELECT bundle_rel_path FROM contribution_cases WHERE user_id = ?',
                    (user_id,),
                ).fetchall()
            ]
            conn.execute(
                'UPDATE auth_sessions SET revoked_at_utc = ? WHERE user_id = ?',
                (now, user_id),
            )
            conn.execute(
                """
                UPDATE users
                SET auth_provider = 'anonymized',
                    provider_subject = ?,
                    display_name = 'Anonymized Contributor',
                    handle_or_orcid = NULL,
                    affiliation = NULL,
                    allow_public_example_library = 0,
                    anonymized_at_utc = ?
                WHERE user_id = ?
                """,
                (tombstone_subject, now, user_id),
            )
            conn.execute(
                """
                UPDATE contribution_cases
                SET allow_public_example_library = 0,
                    visibility_state = 'private_review',
                    updated_at_utc = ?
                WHERE user_id = ?
                """,
                (now, user_id),
            )
            return case_paths

    # --- Maintainer Admin Summaries ---

    def admin_summary(self) -> dict:
        with self._connect() as conn:
            n_users = conn.execute('SELECT COUNT(*) AS n FROM users').fetchone()['n']
            n_projects = conn.execute('SELECT COUNT(*) AS n FROM web_projects').fetchone()['n']
            n_trajs = conn.execute('SELECT COUNT(*) AS n FROM captured_trajectories').fetchone()['n']
            n_cases = conn.execute('SELECT COUNT(*) AS n FROM contribution_cases').fetchone()['n']
            tok_row = conn.execute(
                "SELECT COUNT(*) AS turns, COALESCE(SUM(total_tokens), 0) AS tokens FROM usage_ledger WHERE provider IN ('openai', 'gemini')"
            ).fetchone()
            recent_trajs = [
                dict(r)
                for r in conn.execute(
                    """
                    SELECT trajectory_id, study_cluster_id, detected_format,
                           has_completed_result, method, plot, turn_count,
                           feedback_rating, feedback_note, bundle_rel_path, updated_at_utc
                    FROM captured_trajectories
                    ORDER BY updated_at_utc DESC
                    LIMIT 100
                    """
                ).fetchall()
            ]
            recent_cases = [
                dict(r)
                for r in conn.execute(
                    """
                    SELECT case_id, study_cluster_id, title, domain,
                           visibility_state, allow_public_example_library,
                           bundle_rel_path, updated_at_utc
                    FROM contribution_cases
                    ORDER BY updated_at_utc DESC
                    LIMIT 100
                    """
                ).fetchall()
            ]
        return {
            'users_count': int(n_users),
            'projects_count': int(n_projects),
            'trajectories_count': int(n_trajs),
            'contribution_cases_count': int(n_cases),
            'openai_turns_total': int(tok_row['turns']),
            'openai_tokens_total': int(tok_row['tokens']),
            'recent_trajectories': recent_trajs,
            'recent_contribution_cases': recent_cases,
        }
