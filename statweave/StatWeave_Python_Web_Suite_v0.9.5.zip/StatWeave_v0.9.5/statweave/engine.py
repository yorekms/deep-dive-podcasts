"""Explicit, local statistical routines. No test selection or row deletion by significance."""
from __future__ import annotations

import copy
import math
import re
import warnings as pywarnings

import numpy as np
import pandas as pd
from scipy import stats
from statsmodels.duration.hazard_regression import PHReg
from statsmodels.duration.survfunc import SurvfuncRight, survdiff
from statsmodels.regression.linear_model import OLS
from statsmodels.tools.tools import add_constant

from .data import Dataset

METHODS = {
    "describe",
    "ttest",
    "paired_t",
    "anova",
    "two_way_anova",
    "timecourse_compare",
    "survival",
    "kruskal",
    "mannwhitney",
    "pearson",
    "spearman",
    "regression",
    "chi2",
    "batch_compare",
}

MISSING_TOKENS = {
    "na",
    "n/a",
    "#n/a",
    "nan",
    "null",
    "none",
    "missing",
    "undetermined",
    ".",
}

_PRUNING_REASON_RE = re.compile(
    r"\b(?:outlier\w*|significan\w*|p[ -]?values?|p\s*[<=>]|tighter|cleaner|anomal\w*|best\s+result|improve\s+p|p[ -]?hack\w*)\b",
    re.I,
)
_UNIT_COLUMN_RE = re.compile(
    r"^(?:(?:animal|mouse|mice|rat|donor|patient|subject|litter|participant|person|cage)(?:[_\s-]*id)?|(?:cell|neuron|slice|recording)[_\s-]*id)$",
    re.I,
)
_COUNT_COLUMN_RE = re.compile(
    r"^(?:count|counts|freq|frequency|n|total|cases|observations|weight|weights)$",
    re.I,
)


def _safe(value):
    if isinstance(value, dict):
        return {str(k): _safe(v) for k, v in value.items()}
    if isinstance(value, (tuple, list, np.ndarray)):
        return [_safe(v) for v in value]
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.bool_,)):
        return bool(value)
    if isinstance(value, (np.floating, float)):
        return float(value) if np.isfinite(value) else None
    if value is None or isinstance(value, (str, int, bool)):
        return value
    return str(value)


def _table(title, rows, columns=None):
    return {"title": title, "columns": columns or (list(rows[0]) if rows else []), "rows": _safe(rows)}


def _blank(v):
    if v is None or (isinstance(v, str) and not v.strip()):
        return True
    try:
        return bool(pd.isna(v))
    except (TypeError, ValueError):
        return False


def _is_missing_token(v) -> bool:
    return isinstance(v, str) and v.strip().casefold() in MISSING_TOKENS


def _column(ds, name, role):
    if not isinstance(name, str) or not name.strip():
        raise ValueError(f"Choose a column for {role}.")
    if name in ds.df.columns:
        return name
    matches = [c for c in ds.df.columns if c.casefold() == name.casefold()]
    if len(matches) == 1:
        return matches[0]
    if len(matches) > 1:
        raise ValueError(f"Column '{name}' is ambiguous; use its exact name.")
    raise ValueError(f"Column '{name}' was not found for {role}. Available columns: {', '.join(ds.df.columns)}")


def _excluded_mask(ds: Dataset, plan: dict) -> tuple[np.ndarray, list[str], list[dict]]:
    raw_exclusions = plan.get("excluded_rows")
    n = len(ds.df)
    allowed = np.ones(n, dtype=bool)
    reasons = [""] * n
    if not raw_exclusions:
        plan.pop("excluded_rows", None)
        return allowed, reasons, []
    if not isinstance(raw_exclusions, list) or len(raw_exclusions) > 500:
        raise ValueError("excluded_rows must be a list of at most 500 explicit {row, reason} entries.")
    row_to_idx = {int(r): idx for idx, r in enumerate(ds.row_numbers)}
    normalized = []
    seen = set()
    for entry in raw_exclusions:
        if not isinstance(entry, dict):
            raise ValueError("Each excluded row entry must provide 'row' and 'reason'.")
        row_num = entry.get("row")
        reason = entry.get("reason", "")
        if isinstance(row_num, bool) or not isinstance(row_num, int) or row_num not in row_to_idx:
            raise ValueError(f"Source row {row_num!r} does not exist in this sheet (valid rows: {ds.row_numbers[0]}–{ds.row_numbers[-1]}).")
        if not isinstance(reason, str) or not reason.strip() or len(reason.strip()) > 500:
            raise ValueError(f"Source row {row_num}: provide a brief technical or protocol reason (1–500 characters) for masking a row.")
        clean_reason = reason.strip()
        if _PRUNING_REASON_RE.search(clean_reason):
            raise ValueError(
                "Row exclusions require a technical, experimental, or protocol reason "
                "(for example seal loss, equipment fault, or contamination), not outlier or significance-based pruning."
            )
        if row_num in seen:
            continue
        seen.add(row_num)
        idx = row_to_idx[row_num]
        allowed[idx] = False
        reasons[idx] = f"Excluded row ({clean_reason})"
        normalized.append({"row": row_num, "reason": clean_reason})
    normalized.sort(key=lambda item: item["row"])
    plan["excluded_rows"] = normalized
    return allowed, reasons, normalized


def _numeric(ds, col):
    raw = ds.df[col]
    blank_mask = raw.map(_blank)
    token_mask = raw.map(_is_missing_token)
    missing = blank_mask | token_mask
    converted = pd.to_numeric(raw.where(~missing, np.nan), errors="coerce")
    invalid = ~missing & converted.isna()
    if invalid.any():
        examples = [f"row {ds.row_numbers[i]}: {raw.iloc[i]!r}" for i in np.flatnonzero(invalid.to_numpy())[:8]]
        raise ValueError(
            f"'{col}' contains nonnumeric entries ({'; '.join(examples)}). "
            f"Correct these cells or explicitly mark them as missing before analysis. "
            f"If '{col}' is a categorical group or timepoint/factor column, pass it via group='{col}' "
            f"(or x='{col}' with method='timecourse_compare' / 'two_way_anova' / plot='timecourse'), not as a numeric measurement column."
        )
    array = converted.to_numpy(dtype=float, na_value=np.nan)
    finite = np.isfinite(array)
    reasons = []
    for i in range(len(raw)):
        if blank_mask.iloc[i]:
            reasons.append(f"Missing value in '{col}'")
        elif token_mask.iloc[i]:
            reasons.append(f"Missing token {str(raw.iloc[i]).strip()!r} in '{col}'")
        elif not finite[i]:
            reasons.append(f"Nonfinite value in '{col}'")
        else:
            reasons.append("")
    return array, finite, reasons


def _format_cat_value(v) -> str:
    if hasattr(v, "strftime"):
        try:
            if getattr(v, "hour", 0) == 0 and getattr(v, "minute", 0) == 0 and getattr(v, "second", 0) == 0:
                return v.strftime("%Y-%m-%d")
            return v.strftime("%Y-%m-%d %H:%M")
        except Exception:
            pass
    s = str(v).strip() if isinstance(v, str) else str(v)
    return re.sub(r"^(\d{4}-\d{2}-\d{2})\s+00:00:00(?:\.0+)?$", r"\1", s)


def _sort_strata_naturally(levels: list[str]) -> list[str]:
    """Preserve sheet order for text/date labels, but sort purely numeric discrete strata ascending."""
    if len(levels) < 2:
        return list(levels)
    parsed: list[tuple[float, int, str]] = []
    for idx, lv in enumerate(levels):
        try:
            fv = float(str(lv).strip())
            if not math.isfinite(fv):
                return list(levels)
            parsed.append((fv, idx, lv))
        except (TypeError, ValueError):
            return list(levels)
    return [item[2] for item in sorted(parsed, key=lambda t: (t[0], t[1]))]


def _categorical(ds, col):
    values, valid, reasons = [], [], []
    for v in ds.df[col]:
        missing = _blank(v)
        nonfinite = isinstance(v, (float, np.floating)) and not np.isfinite(v)
        valid.append(not missing and not nonfinite)
        values.append(None if missing or nonfinite else _format_cat_value(v))
        reasons.append(f"Missing value in '{col}'" if missing else f"Nonfinite value in '{col}'" if nonfinite else "")
    return np.asarray(values, dtype=object), np.asarray(valid, dtype=bool), reasons


def _account(ds, mask, reason_lists, by_variable=None, excluded_rows=None):
    mask = np.asarray(mask, dtype=bool)
    omitted = []
    for i in np.flatnonzero(~mask):
        reason = "; ".join(dict.fromkeys(r[i] for r in reason_lists if r[i]))
        omitted.append({"row": ds.row_numbers[i], "reason": reason or "Required values are unavailable"})
    out = {"total": len(ds.df), "used": int(mask.sum()), "omitted": int((~mask).sum()), "omitted_rows": omitted}
    if by_variable is not None:
        out["by_variable"] = by_variable
    if excluded_rows:
        out["excluded_rows"] = list(excluded_rows)
    return out


def _var_account(ds, name, valid, reasons):
    return {"variable": name, "used": int(valid.sum()), "omitted": int((~valid).sum()), "omitted_rows": [{"row": ds.row_numbers[i], "reason": reasons[i]} for i in np.flatnonzero(~valid)]}


def _summary(name, values, with_ci=False):
    a = np.asarray(values, dtype=float)
    n = len(a)
    if not n:
        return {"variable": name, "n": 0, "mean": None, "sd": None, "sem": None, "median": None, "q1": None, "q3": None, "min": None, "max": None, "ci_low": None, "ci_high": None}
    mean = float(np.mean(a))
    if n > 1:
        scale = float(np.max(np.abs(a))) or 1.0
        sd = float(np.std((a - mean) / scale, ddof=1) * scale)
        sem = float(sd / np.sqrt(n))
    else:
        sd = None
        sem = None
    half = float(stats.t.ppf(.975, n - 1) * sem) if sem is not None and with_ci else None
    return {
        "variable": name,
        "n": n,
        "mean": mean,
        "sd": sd,
        "sem": sem,
        "median": float(np.median(a)),
        "q1": float(np.quantile(a, .25)),
        "q3": float(np.quantile(a, .75)),
        "min": float(a.min()),
        "max": float(a.max()),
        "ci_low": mean - half if half is not None else None,
        "ci_high": mean + half if half is not None else None,
    }


def _finish(ds, plan, method, summary, tables, warnings, accounting, extra=None):
    if accounting.get("excluded_rows"):
        n_excl = len(accounting["excluded_rows"])
        warnings.append(f"{n_excl} source row(s) were explicitly masked with recorded technical reasons; raw source values remain intact and masks are reversible.")
    if accounting["omitted"]:
        warnings.append(f"{accounting['omitted']} of {accounting['total']} source rows were omitted; each is listed in row accounting.")
    payload = {
        "method": method,
        "summary": summary,
        "tables": tables,
        "warnings": list(dict.fromkeys(warnings)),
        "row_accounting": accounting,
        "plan": plan,
    }
    if extra:
        payload.update(extra)
    return _safe(payload)


def _require_independent(plan):
    if plan.get("design") != "independent":
        raise ValueError("Confirm that observations are independent before this analysis (design='independent'). Repeated measurements and technical replicates must not be treated as independent units.")


def _check_unpooled_replicates(ds: Dataset, plan: dict, mask: np.ndarray, used_columns: set[str]) -> None:
    if plan.get("design") != "independent" or plan.get("pool_by") or plan.get("allow_replicate_rows"):
        return
    n_used = int(np.sum(mask))
    if n_used < 3:
        return
    for col in ds.df.columns:
        if col in used_columns:
            continue
        if not _UNIT_COLUMN_RE.match(col.strip()):
            continue
        vals, vmask, _ = _categorical(ds, col)
        active = mask & vmask
        n_active = int(np.sum(active))
        if n_active < 3:
            continue
        distinct = list(dict.fromkeys(vals[active]))
        if 1 <= len(distinct) < n_active:
            raise ValueError(
                f"Column '{col}' contains repeated unit identifiers ({n_active} rows across {len(distinct)} distinct '{col}' units). "
                f"Treating repeated sweeps, cells, or timepoints from the same '{col}' as independent inflates sample size (pseudoreplication). "
                f"Pool within '{col}' first (pool_by='{col}'), use method='timecourse_compare' or 'two_way_anova' with x='<Timepoint>' if rows represent longitudinal timepoints, "
                f"use a paired design if comparing two conditions within '{col}', "
                f"or set allow_replicate_rows=True only if each row is genuinely an independent experimental unit."
            )


def _wide_columns(ds, plan):
    cols = plan.get("columns")
    if cols is None:
        return None
    if not isinstance(cols, list) or not cols:
        raise ValueError("Choose a nonempty list of numeric columns.")
    resolved = [_column(ds, c, "numeric values") for c in cols]
    if len(set(resolved)) != len(resolved):
        raise ValueError("A column was selected more than once. Choose each column once.")
    return resolved


def _pool_grouped_units(
    ds: Dataset,
    values: np.ndarray,
    vy: np.ndarray,
    ry: list[str],
    labels: np.ndarray,
    vg: np.ndarray,
    rg: list[str],
    unit_col: str,
    pool_stat: str,
    allowed: np.ndarray,
    r_excl: list[str],
):
    if pool_stat not in {"mean", "median"}:
        raise ValueError("pool_stat must be 'mean' or 'median'.")
    units, vu, ru = _categorical(ds, unit_col)
    mask = vy & vg & vu & allowed
    names = list(dict.fromkeys(labels[vg & allowed]))
    unit_group: dict[str, str] = {}
    buckets: dict[tuple[str, str], list[tuple[int, float]]] = {}
    for idx in np.flatnonzero(mask):
        u = str(units[idx])
        g = str(labels[idx])
        if u in unit_group and unit_group[u] != g:
            raise ValueError(
                f"Unit '{u}' in '{unit_col}' appears in multiple groups ('{unit_group[u]}' and '{g}'). "
                "Use a paired or within-subject design rather than independent-groups pooling."
            )
        unit_group[u] = g
        buckets.setdefault((g, u), []).append((int(ds.row_numbers[idx]), float(values[idx])))

    arrays = []
    unit_rows = []
    units_per_group = {}
    for name in names:
        grp_vals = []
        for (g, u), items in buckets.items():
            if g != name:
                continue
            raw_vals = [v for _, v in items]
            pooled_val = float(np.mean(raw_vals)) if pool_stat == "mean" else float(np.median(raw_vals))
            grp_vals.append(pooled_val)
            unit_rows.append({
                "unit": u,
                "group": g,
                "n_subreplicates": len(raw_vals),
                "value": pooled_val,
                "source_rows": [r for r, _ in items],
                "raw_values": raw_vals,
            })
        arrays.append(np.asarray(grp_vals, dtype=float))
        units_per_group[str(name)] = len(grp_vals)

    unit_accounting = {
        "unit_column": unit_col,
        "pool_stat": pool_stat,
        "n_raw_observations": int(mask.sum()),
        "n_units": len(unit_rows),
        "units_per_group": units_per_group,
        "unit_rows": unit_rows,
    }
    return names, arrays, mask, [ry, rg, ru, r_excl], unit_accounting


def _describe(ds, plan, warnings):
    allowed, r_excl, excluded = _excluded_mask(ds, plan)
    group = _column(ds, plan["group"], "group labels") if plan.get("group") else None
    pool_by = _column(ds, plan["pool_by"], "unit identifiers") if plan.get("pool_by") else None
    subj_col = _column(ds, plan["subject"], "subject identifiers") if plan.get("subject") else None
    pool_stat = plan.get("pool_stat", "mean")
    if pool_by:
        plan["pool_by"] = pool_by
        plan["pool_stat"] = pool_stat
    if subj_col:
        plan["subject"] = subj_col

    stratum_col: str | None = None
    cols = _wide_columns(ds, plan)
    if cols is None:
        if plan.get("x") is not None and plan.get("y") is not None:
            x_cand = _column(ds, plan["x"], "horizontal variable")
            y_cand = _column(ds, plan["y"], "descriptive values")
            raw_x = ds.df[x_cand]
            non_miss_x = ~(raw_x.map(_blank) | raw_x.map(_is_missing_token))
            conv_x = pd.to_numeric(raw_x.where(non_miss_x, np.nan), errors="coerce")
            x_is_cat = bool((non_miss_x & conv_x.isna()).any())
            if x_is_cat or plan.get("plot") in {"timecourse", "spaghetti", "grouped_bar", "grouped_box"}:
                stratum_col = x_cand
                plan["x"] = x_cand
                plan["y"] = y_cand
                cols = [y_cand]
            else:
                cols = list(dict.fromkeys([y_cand, x_cand]))
        else:
            explicit = [c for c in [plan.get("y"), plan.get("x")] if c is not None]
            if explicit:
                cols = list(dict.fromkeys(_column(ds, c, "descriptive values") for c in explicit))
            else:
                cols = []
                for c in ds.df.columns:
                    if c in {group, pool_by, subj_col}:
                        continue
                    raw = ds.df[c]
                    non_missing = ~(raw.map(_blank) | raw.map(_is_missing_token))
                    converted = pd.to_numeric(raw.where(non_missing, np.nan), errors="coerce")
                    if converted.notna().any() and not (non_missing & converted.isna()).any():
                        cols.append(c)
    elif plan.get("x") is not None and plan.get("plot") in {"timecourse", "spaghetti"}:
        stratum_col = _column(ds, plan["x"], "horizontal axis / timepoint")
        plan["x"] = stratum_col

    if not cols:
        raise ValueError("No numeric columns were found. Choose numeric data or check the header row.")
    plan["columns"] = cols
    rows, by_var, masks, reasons = [], [], [], [r_excl]
    if group:
        plan["group"] = group
        labels, vg, rg = _categorical(ds, group)
        names = list(dict.fromkeys(labels[vg & allowed]))
        if not names:
            raise ValueError("No nonmissing group labels were found.")
        reasons.append(rg)
    extra = {}
    for c in cols:
        arr, mask_num, reason_num = _numeric(ds, c)
        mask = mask_num & allowed
        reason = ["; ".join(v for v in (r_excl[i], reason_num[i]) if v) for i in range(len(mask))]
        if group and pool_by and c != pool_by and group != pool_by:
            names_p, arrays_p, mask_p, r_lists, unit_acc = _pool_grouped_units(
                ds, arr, mask_num, reason_num, labels, vg, rg, pool_by, pool_stat, allowed, r_excl
            )
            mask = mask_p
            reason = ["; ".join(dict.fromkeys(rl[i] for rl in r_lists if rl[i])) for i in range(len(mask))]
            for name, u_arr in zip(names_p, arrays_p):
                row = _summary(c, u_arr, with_ci=plan.get("design") == "independent")
                row["group"] = name
                row["missing_or_nonfinite"] = int(((vg & allowed & (labels == name)) & ~mask).sum())
                rows.append(row)
            if len(cols) == 1:
                extra["unit_accounting"] = unit_acc
        elif group:
            mask = mask & vg
            reason = ["; ".join(v for v in (reason[i], rg[i]) if v) for i in range(len(mask))]
            for name in names:
                selected = vg & allowed & (labels == name)
                row = _summary(c, arr[mask & selected], with_ci=plan.get("design") == "independent")
                row["group"] = name
                row["missing_or_nonfinite"] = int((selected & ~mask).sum())
                rows.append(row)
        else:
            row = _summary(c, arr[mask], with_ci=plan.get("design") == "independent")
            row["missing_or_nonfinite"] = int((~mask).sum())
            rows.append(row)
        by_var.append(_var_account(ds, c, mask, reason))
        masks.append(mask)
        reasons.append(reason)
    overall_mask = np.logical_or.reduce(masks)
    used_cols_set = set(cols) | ({group} if group else set()) | ({stratum_col} if stratum_col else set()) | ({subj_col} if subj_col else set())
    if stratum_col is None:
        _check_unpooled_replicates(ds, plan, overall_mask, used_cols_set)
    accounting = _account(ds, overall_mask, reasons, by_var, excluded)
    if any(x["omitted"] for x in by_var):
        warnings.append("Descriptive statistics use available values separately for each column; per-variable omissions are listed in row accounting.")
    if plan.get("design") != "independent":
        warnings.append("Experimental units have not been confirmed independent; mean confidence intervals are not calculated.")

    tables = [_table("Descriptive statistics", rows)]
    if stratum_col and len(cols) == 1:
        s_labels, vs, _ = _categorical(ds, stratum_col)
        s_names = _sort_strata_naturally(list(dict.fromkeys(s_labels[vs & allowed])))
        arr_c, mask_c, _ = _numeric(ds, cols[0])
        stratum_rows = []
        for s_name in s_names:
            s_sel = vs & allowed & (s_labels == s_name)
            if group:
                for g_name in names:
                    cell_mask = s_sel & vg & (labels == g_name) & mask_c
                    s_row = _summary(cols[0], arr_c[cell_mask], with_ci=plan.get("design") == "independent")
                    s_row = {"stratum": str(s_name), "group": str(g_name), **s_row}
                    stratum_rows.append(s_row)
            else:
                cell_mask = s_sel & mask_c
                s_row = _summary(cols[0], arr_c[cell_mask], with_ci=plan.get("design") == "independent")
                s_row = {"stratum": str(s_name), **s_row}
                stratum_rows.append(s_row)
        if stratum_rows:
            tables.append(_table("Descriptive statistics by stratum", stratum_rows))

    unit_phrase = f" pooled by {pool_by} ({pool_stat})" if (group and pool_by) else ""
    stratum_phrase = f" across {stratum_col}" if stratum_col else ""
    summary = f"Descriptive statistics for {len(cols)} numeric column(s){' by ' + group if group else ''}{stratum_phrase}{unit_phrase}, using available finite values in each column."
    return _finish(ds, plan, "describe", summary, tables, warnings, accounting, extra=extra or None)


def _groups(ds, plan):
    allowed, r_excl, excluded = _excluded_mask(ds, plan)
    cols = _wide_columns(ds, plan)
    if cols is not None:
        if plan.get("pool_by"):
            raise ValueError("Within-unit pooling (pool_by) requires long-format data with outcome ('y'), group ('group'), and unit ('pool_by') columns.")
        plan["columns"] = cols
        arrays, masks, reasons, by_var = [], [], [r_excl], []
        for c in cols:
            arr, mask_num, reason_num = _numeric(ds, c)
            mask = mask_num & allowed
            reason = ["; ".join(v for v in (r_excl[i], reason_num[i]) if v) for i in range(len(mask))]
            arrays.append(arr[mask])
            masks.append(mask)
            reasons.append(reason)
            by_var.append(_var_account(ds, c, mask, reason))
        overall = np.logical_or.reduce(masks)
        _check_unpooled_replicates(ds, plan, overall, set(cols))
        return cols, arrays, _account(ds, overall, reasons, by_var, excluded), None
    y = _column(ds, plan.get("y") or plan.get("x"), "the numeric outcome")
    group = _column(ds, plan.get("group"), "group labels")
    if y == group:
        raise ValueError("The outcome and group labels must be different columns.")
    plan.update(y=y, group=group)
    values, vy, ry = _numeric(ds, y)
    labels, vg, rg = _categorical(ds, group)
    if plan.get("pool_by"):
        unit_col = _column(ds, plan["pool_by"], "biological/cluster unit identifier")
        if unit_col in {y, group}:
            raise ValueError("The unit column (pool_by) must be distinct from the outcome and group columns.")
        pool_stat = plan.get("pool_stat", "mean")
        plan["pool_by"] = unit_col
        plan["pool_stat"] = pool_stat
        names, arrays, mask, r_lists, unit_acc = _pool_grouped_units(
            ds, values, vy, ry, labels, vg, rg, unit_col, pool_stat, allowed, r_excl
        )
        return names, arrays, _account(ds, mask, r_lists, excluded_rows=excluded), unit_acc
    mask = vy & vg & allowed
    _check_unpooled_replicates(ds, plan, mask, {y, group})
    # Keep groups with missing outcomes visible, so a whole group is never silently dropped.
    names = list(dict.fromkeys(labels[vg & allowed]))
    arrays = [values[mask & (labels == name)] for name in names]
    return names, arrays, _account(ds, mask, [r_excl, ry, rg], excluded_rows=excluded), None


def _scale_welch(a: np.ndarray, b: np.ndarray):
    n1, n2 = len(a), len(b)
    m1, m2 = float(np.mean(a)), float(np.mean(b))
    scale = max(float(np.max(np.abs(a))), float(np.max(np.abs(b))), 1.0)
    sa = (a - m1) / scale
    sb = (b - m2) / scale
    sv1, sv2 = float(np.var(sa, ddof=1)), float(np.var(sb, ddof=1))
    sse2 = sv1 / n1 + sv2 / n2
    if sse2 <= 0:
        raise ValueError("A Welch t-test cannot estimate uncertainty because both groups have zero variance.")
    df = sse2 ** 2 / ((sv1 / n1) ** 2 / (n1 - 1) + (sv2 / n2) ** 2 / (n2 - 1))
    diff_scaled = float(np.mean(a / scale) - np.mean(b / scale))
    t = diff_scaled / math.sqrt(sse2)
    p = float(2 * stats.t.sf(abs(t), df))
    se_orig = math.sqrt(sse2) * scale
    difference = m1 - m2
    half = float(stats.t.ppf(.975, df) * se_orig)
    spooled = math.sqrt(((n1 - 1) * sv1 + (n2 - 1) * sv2) / (n1 + n2 - 2))
    d = diff_scaled / spooled if spooled > 0 else None
    return t, df, p, difference, half, d


def _scale_anova(arrays: list[np.ndarray]):
    all_values = np.concatenate(arrays)
    scale = float(np.max(np.abs(all_values))) or 1.0
    scaled_arrays = [a / scale for a in arrays]
    all_scaled = np.concatenate(scaled_arrays)
    grand = float(np.mean(all_scaled))
    ssb = sum(len(sa) * (float(np.mean(sa)) - grand) ** 2 for sa in scaled_arrays)
    ssw = sum(float(np.sum((sa - np.mean(sa)) ** 2)) for sa in scaled_arrays)
    if ssw <= 0:
        raise ValueError("ANOVA cannot estimate residual variation: within-group variance is zero.")
    df1, df2 = len(arrays) - 1, len(all_values) - len(arrays)
    f = (ssb / df1) / (ssw / df2)
    p = float(stats.f.sf(f, df1, df2))
    eta = ssb / (ssb + ssw)
    return f, df1, df2, p, eta


def _group_test(ds, plan, method, warnings):
    _require_independent(plan)
    names, arrays, accounting, unit_acc = _groups(ds, plan)
    required = 2 if method in {"ttest", "mannwhitney"} else None
    if (required and len(names) != required) or (not required and len(names) < 2):
        raise ValueError(f"{method} requires {'exactly two' if required else 'at least two'} groups; {len(names)} were found.")
    minimum = 2 if method in {"ttest", "anova"} else 1
    unit_word = f"distinct '{unit_acc['unit_column']}' unit(s)" if unit_acc else "finite observation(s)"
    for name, values in zip(names, arrays):
        if len(values) < minimum:
            raise ValueError(f"Group '{name}' has {len(values)} {unit_word}; {method} requires at least {minimum} per group.")
    table_rows = [_summary(str(name), a, with_ci=method in {"ttest", "anova"}) for name, a in zip(names, arrays)]
    tables = [_table("Group summaries", table_rows)]
    if unit_acc is not None:
        tables.append(
            _table(
                "Biological unit summaries",
                [
                    {
                        "unit": r["unit"],
                        "group": r["group"],
                        "n_subreplicates": r["n_subreplicates"],
                        "value": r["value"],
                    }
                    for r in unit_acc["unit_rows"]
                ],
            )
        )
        warnings.append(
            f"Nested observations ({unit_acc['n_raw_observations']} rows) were pooled within {unit_acc['n_units']} "
            f"distinct '{unit_acc['unit_column']}' unit(s) using {unit_acc['pool_stat']} before group inference to prevent pseudoreplication."
        )
    if "by_variable" in accounting and any(v["omitted"] for v in accounting["by_variable"]):
        warnings.append("Wide-format groups use available values per column; partial-row omissions are enumerated under by_variable.")
    if method == "ttest":
        a, b = arrays
        t, df, p, difference, half, d = _scale_welch(a, b)
        tables.append(_table("Welch t-test", [{"group_1": names[0], "group_2": names[1], "t": t, "df": df, "p": p, "mean_difference": difference, "ci_low": difference - half, "ci_high": difference + half, "cohens_d_pooled": d}]))
        warnings.append("The confidence interval is the Welch 95% interval for mean(group 1) minus mean(group 2). Cohen's d uses the pooled sample SD and is descriptive under unequal variances.")
        summary = f"Welch independent-samples t-test: t({df:.3g}) = {t:.4g}, p = {p:.4g}; mean difference ({names[0]} − {names[1]}) = {difference:.4g}, 95% CI [{difference-half:.4g}, {difference+half:.4g}]."
    elif method == "mannwhitney":
        a, b = arrays
        if np.unique(np.concatenate([a, b])).size < 2:
            raise ValueError("Mann–Whitney U cannot compare groups when all observations are identical.")
        result = stats.mannwhitneyu(a, b, alternative="two-sided", method="auto")
        if not math.isfinite(float(result.pvalue)):
            raise ValueError("Mann–Whitney U p-value is undefined for these degenerate ranks.")
        effect = 2 * float(result.statistic) / (len(a) * len(b)) - 1
        tables.append(_table("Mann–Whitney U", [{"group_1": names[0], "group_2": names[1], "U": result.statistic, "p": result.pvalue, "rank_biserial": effect}]))
        warnings.append("Two-sided Mann–Whitney U uses SciPy's automatic exact/asymptotic choice. It tests a distributional comparison; a median-shift interpretation needs additional shape assumptions. Rank-biserial sign is positive when group 1 tends to be larger.")
        summary = f"Mann–Whitney U = {result.statistic:.4g}, two-sided p = {result.pvalue:.4g}; rank-biserial effect = {effect:.4g}."
    elif method == "anova":
        f, df1, df2, p, eta = _scale_anova(arrays)
        tables.append(_table("One-way ANOVA", [{"F": f, "df_between": df1, "df_within": df2, "p": p, "eta_squared": eta}]))
        warnings.append("Classical one-way ANOVA assumes independent observations, approximately normal residuals, and a common variance. No automatic post-hoc comparisons or multiplicity correction were performed.")
        summary = f"One-way ANOVA: F({df1}, {df2}) = {f:.4g}, p = {p:.4g}; eta-squared = {eta:.4g}."
    else:
        if np.unique(np.concatenate(arrays)).size < 2:
            raise ValueError("Kruskal–Wallis cannot compare groups when all values are identical.")
        result = stats.kruskal(*arrays)
        n, k = sum(map(len, arrays)), len(arrays)
        effect = max(0., (float(result.statistic) - k + 1) / (n - k)) if n > k else None
        tables.append(_table("Kruskal–Wallis", [{"H": result.statistic, "df": k - 1, "p": result.pvalue, "eta_squared_H": effect}]))
        warnings.append("Kruskal–Wallis compares rank distributions, with a tie correction and asymptotic p-value. A location-only interpretation needs comparable distribution shapes. No pairwise post-hoc tests were performed.")
        warnings.append("The reported rank-based eta-squared estimate is max(0, (H − k + 1) / (N − k)); it is unavailable when N equals k.")
        if min(map(len, arrays)) < 5:
            warnings.append("At least one group has fewer than five observations; the asymptotic Kruskal–Wallis p-value may be unreliable.")
        summary = f"Kruskal–Wallis H({k-1}) = {result.statistic:.4g}, p = {result.pvalue:.4g}."
    if unit_acc is not None:
        summary += f" (Pooled {unit_acc['n_raw_observations']} observations into {unit_acc['n_units']} '{unit_acc['unit_column']}' {unit_acc['pool_stat']}s.)"
    extra = {"unit_accounting": unit_acc} if unit_acc is not None else None
    return _finish(ds, plan, method, summary, tables, warnings, accounting, extra=extra)


def _holm_adjust(p_values: list[float | None]) -> list[float | None]:
    indexed = [(idx, p) for idx, p in enumerate(p_values) if p is not None and math.isfinite(p)]
    m = len(indexed)
    out: list[float | None] = [None] * len(p_values)
    if not m:
        return out
    ordered = sorted(indexed, key=lambda item: item[1])
    running_max = 0.0
    for rank, (orig_idx, p) in enumerate(ordered):
        adj = min(1.0, p * (m - rank))
        running_max = max(running_max, adj)
        out[orig_idx] = running_max
    return out


def _batch_compare(ds: Dataset, plan: dict, warnings: list[str]) -> dict:
    _require_independent(plan)
    allowed, r_excl, excluded = _excluded_mask(ds, plan)
    group = _column(ds, plan.get("group"), "group labels")
    cols = _wide_columns(ds, plan)
    if not cols or len(cols) < 2:
        raise ValueError("batch_compare requires at least two numeric outcome columns in 'columns' and a 'group' column.")
    if len(cols) > 12:
        raise ValueError("batch_compare supports at most 12 outcome columns per figure/table panel.")
    if group in cols:
        raise ValueError("The group column cannot also be listed as an outcome column.")
    pool_by = _column(ds, plan["pool_by"], "biological/cluster unit identifier") if plan.get("pool_by") else None
    if pool_by and (pool_by == group or pool_by in cols):
        raise ValueError("The unit column (pool_by) must be distinct from the group and outcome columns.")
    pool_stat = plan.get("pool_stat", "mean")
    plan["group"] = group
    plan["columns"] = cols
    if pool_by:
        plan["pool_by"] = pool_by
        plan["pool_stat"] = pool_stat

    labels, vg, rg = _categorical(ds, group)
    group_names = list(dict.fromkeys(labels[vg & allowed]))
    if len(group_names) < 2:
        raise ValueError(f"batch_compare requires at least two groups in '{group}'; {len(group_names)} were found.")

    nonparametric = bool(plan.get("nonparametric", False))
    requested_test = plan.get("test")
    if requested_test is None:
        if len(group_names) == 2:
            test_name = "mannwhitney" if nonparametric else "ttest"
        else:
            test_name = "kruskal" if nonparametric else "anova"
    else:
        if requested_test not in {"ttest", "mannwhitney", "anova", "kruskal"}:
            raise ValueError("batch_compare 'test' must be 'ttest', 'mannwhitney', 'anova', or 'kruskal'.")
        if requested_test in {"ttest", "mannwhitney"} and len(group_names) != 2:
            raise ValueError(f"{requested_test} requires exactly two groups; {len(group_names)} were found.")
        test_name = requested_test
    plan["test"] = test_name

    summary_rows = []
    comparison_rows = []
    by_var = []
    masks = []
    reason_lists = [r_excl, rg]
    unit_acc_by_var = {}

    for col in cols:
        arr, vy, ry = _numeric(ds, col)
        if pool_by:
            names, arrays, mask, r_lists, unit_acc = _pool_grouped_units(
                ds, arr, vy, ry, labels, vg, rg, pool_by, pool_stat, allowed, r_excl
            )
            unit_acc_by_var[col] = unit_acc
            reason = ["; ".join(dict.fromkeys(rl[i] for rl in r_lists if rl[i])) for i in range(len(mask))]
        else:
            mask = vy & vg & allowed
            _check_unpooled_replicates(ds, plan, mask, set(cols) | {group})
            names = group_names
            arrays = [arr[mask & (labels == g)] for g in names]
            reason = ["; ".join(v for v in (r_excl[i], ry[i], rg[i]) if v) for i in range(len(mask))]
        masks.append(mask)
        reason_lists.append(reason)
        by_var.append(_var_account(ds, col, mask, reason))

        minimum = 2 if test_name in {"ttest", "anova"} else 1
        for g_name, g_arr in zip(names, arrays):
            if len(g_arr) < minimum:
                raise ValueError(f"Column '{col}', group '{g_name}' has {len(g_arr)} observation(s); {test_name} requires at least {minimum}.")
            s_row = _summary(col, g_arr, with_ci=test_name in {"ttest", "anova"})
            s_row["group"] = g_name
            summary_rows.append(s_row)

        if test_name == "ttest":
            t_val, df_val, p_val, diff, half, d_val = _scale_welch(arrays[0], arrays[1])
            comparison_rows.append({
                "variable": col, "test": "Welch t-test", "group_1": names[0], "group_2": names[1],
                "statistic": t_val, "df": df_val, "p_unadjusted": p_val, "p_holm": None,
                "mean_difference": diff, "ci_low": diff - half, "ci_high": diff + half,
                "effect_size": d_val, "effect_type": "cohens_d_pooled",
            })
        elif test_name == "mannwhitney":
            if np.unique(np.concatenate(arrays)).size < 2:
                raise ValueError(f"Column '{col}' has identical values across groups; Mann–Whitney U is undefined.")
            res = stats.mannwhitneyu(arrays[0], arrays[1], alternative="two-sided", method="auto")
            rb = 2 * float(res.statistic) / (len(arrays[0]) * len(arrays[1])) - 1
            comparison_rows.append({
                "variable": col, "test": "Mann–Whitney U", "group_1": names[0], "group_2": names[1],
                "statistic": float(res.statistic), "df": None, "p_unadjusted": float(res.pvalue), "p_holm": None,
                "effect_size": rb, "effect_type": "rank_biserial",
            })
        elif test_name == "anova":
            f_val, df1, df2, p_val, eta = _scale_anova(arrays)
            comparison_rows.append({
                "variable": col, "test": "One-way ANOVA", "statistic": f_val,
                "df": f"{df1}, {df2}", "p_unadjusted": p_val, "p_holm": None,
                "effect_size": eta, "effect_type": "eta_squared",
            })
        else:
            if np.unique(np.concatenate(arrays)).size < 2:
                raise ValueError(f"Column '{col}' has identical values across groups; Kruskal–Wallis is undefined.")
            res = stats.kruskal(*arrays)
            n_tot, k_grp = sum(map(len, arrays)), len(arrays)
            eff = max(0., (float(res.statistic) - k_grp + 1) / (n_tot - k_grp)) if n_tot > k_grp else None
            comparison_rows.append({
                "variable": col, "test": "Kruskal–Wallis", "statistic": float(res.statistic),
                "df": k_grp - 1, "p_unadjusted": float(res.pvalue), "p_holm": None,
                "effect_size": eff, "effect_type": "eta_squared_H",
            })

    adjusted = _holm_adjust([row["p_unadjusted"] for row in comparison_rows])
    for row, p_adj in zip(comparison_rows, adjusted):
        row["p_holm"] = p_adj

    overall_mask = np.logical_or.reduce(masks)
    accounting = _account(ds, overall_mask, reason_lists, by_var, excluded)
    warnings.append(
        f"Batch comparison across {len(cols)} endpoints includes step-down Holm–Bonferroni multiplicity-adjusted p-values (p_holm) alongside unadjusted p-values."
    )
    if pool_by:
        warnings.append(
            f"Each endpoint was pooled within '{pool_by}' ({pool_stat}) prior to group testing so nested observations are not treated as independent units."
        )
    parts = [f"{r['variable']}: p = {r['p_unadjusted']:.4g} (Holm {r['p_holm']:.4g})" for r in comparison_rows]
    summary = f"Batch {comparison_rows[0]['test']} across {len(cols)} measures by {group}" + (f" (pooled by {pool_by})" if pool_by else "") + ": " + "; ".join(parts) + "."
    tables = [
        _table("Batch group summaries", summary_rows),
        _table("Batch comparisons", comparison_rows),
    ]
    extra = {"batch_unit_accounting": unit_acc_by_var} if unit_acc_by_var else None
    return _finish(ds, plan, "batch_compare", summary, tables, warnings, accounting, extra=extra)


def _paired(ds, plan, warnings):
    if plan.get("design") != "paired":
        raise ValueError("Confirm the paired design before a paired t-test (design='paired'). Each pair must represent the same independent experimental unit.")
    allowed, r_excl, excluded = _excluded_mask(ds, plan)
    pair_rows = []
    if plan.get("subject") and plan.get("group"):
        subject = _column(ds, plan.get("subject"), "subject identifiers")
        group = _column(ds, plan.get("group"), "the two measurement conditions")
        y = _column(ds, plan.get("y") or plan.get("x"), "the numeric outcome")
        if len({subject, group, y}) != 3:
            raise ValueError("Subject, group, and numeric outcome must be three different columns for long-format paired data.")
        plan.update(subject=subject, group=group, y=y)
        subjects, vs, rs = _categorical(ds, subject)
        groups, vg, rg = _categorical(ds, group)
        values, vy, ry = _numeric(ds, y)
        names = list(dict.fromkeys(groups[vg & allowed]))
        if len(names) != 2:
            raise ValueError(f"Long-format paired data require exactly two groups; {len(names)} were found.")
        lookup = {}
        for i in np.flatnonzero(vs & vg & allowed):
            key = (subjects[i], groups[i])
            if key in lookup:
                raise ValueError(f"Subject '{subjects[i]}' has duplicate rows in group '{groups[i]}' (source rows {ds.row_numbers[lookup[key]]} and {ds.row_numbers[i]}). Resolve technical replicates or use a model that represents them.")
            lookup[key] = i
        mask = np.zeros(len(ds.df), dtype=bool)
        unmatched_reason = [""] * len(ds.df)
        for subj in dict.fromkeys(subjects[vs & allowed]):
            ia, ib = lookup.get((subj, names[0])), lookup.get((subj, names[1]))
            if ia is not None and ib is not None and vy[ia] and vy[ib]:
                mask[[ia, ib]] = True
                pair_rows.append({"subject": subj, "x": values[ia], "y": values[ib], "x_row": ds.row_numbers[ia], "y_row": ds.row_numbers[ib]})
            else:
                for i in np.flatnonzero(vs & allowed & (subjects == subj)):
                    unmatched_reason[i] = f"No complete pair for subject '{subj}' across '{names[0]}' and '{names[1]}'"
        accounting = _account(ds, mask, [r_excl, rs, rg, ry, unmatched_reason], excluded_rows=excluded)
        a = np.asarray([r["x"] for r in pair_rows])
        b = np.asarray([r["y"] for r in pair_rows])
    else:
        cols = _wide_columns(ds, plan)
        if cols is not None:
            if len(cols) != 2:
                raise ValueError("A wide-format paired t-test requires exactly two numeric columns.")
            x, y = cols
        else:
            x = _column(ds, plan.get("x"), "the first paired measurement")
            y = _column(ds, plan.get("y"), "the second paired measurement")
        if x == y:
            raise ValueError("Choose two different columns for paired measurements.")
        plan.update(x=x, y=y)
        values_x, vx, rx = _numeric(ds, x)
        values_y, vy, ry = _numeric(ds, y)
        mask = vx & vy & allowed
        accounting = _account(ds, mask, [r_excl, rx, ry], excluded_rows=excluded)
        a, b, names = values_x[mask], values_y[mask], [x, y]
        for i in np.flatnonzero(mask):
            pair_rows.append({"subject": str(ds.row_numbers[i]), "x": values_x[i], "y": values_y[i], "x_row": ds.row_numbers[i], "y_row": ds.row_numbers[i]})
    n = len(a)
    if n < 2:
        raise ValueError(f"A paired t-test needs at least two complete pairs; {n} were found.")
    diff = a - b
    scale = float(np.max(np.abs(diff))) or 1.0
    mean = float(np.mean(diff))
    sd = float(np.std((diff - mean) / scale, ddof=1) * scale)
    if sd <= 0:
        raise ValueError("All paired differences are identical; the paired t-test cannot estimate their uncertainty.")
    se = sd / np.sqrt(n)
    t, df = mean / se, n - 1
    p = float(2 * stats.t.sf(abs(t), df))
    half = float(stats.t.ppf(.975, df) * se)
    accounting["pairs"] = n
    warnings.append("The paired t-test assumes pairs are independent experimental units and their differences are approximately normal. The 95% confidence interval describes the mean paired difference. Individual-condition intervals are not calculated for this repeated design.")
    tables = [
        _table("Paired condition summaries", [_summary(str(names[0]), a), _summary(str(names[1]), b)]),
        _table("Paired t-test", [{"condition_1": names[0], "condition_2": names[1], "pairs": n, "t": t, "df": df, "p": p, "mean_difference": mean, "ci_low": mean - half, "ci_high": mean + half, "cohens_dz": mean / sd}]),
        _table("Paired observations", pair_rows),
    ]
    summary = f"Paired t-test on {n} complete pairs: t({df}) = {t:.4g}, p = {p:.4g}; mean paired difference ({names[0]} − {names[1]}) = {mean:.4g}, 95% CI [{mean-half:.4g}, {mean+half:.4g}]."
    return _finish(ds, plan, "paired_t", summary, tables, warnings, accounting)


def _xy(ds, plan):
    allowed, r_excl, excluded = _excluded_mask(ds, plan)
    x = _column(ds, plan.get("x"), "the x variable")
    y = _column(ds, plan.get("y"), "the y variable")
    if x == y:
        raise ValueError("Choose two different columns for x and y.")
    plan.update(x=x, y=y)
    a, va, ra = _numeric(ds, x)
    b, vb, rb = _numeric(ds, y)
    mask = va & vb & allowed
    _check_unpooled_replicates(ds, plan, mask, {x, y})
    return a[mask], b[mask], _account(ds, mask, [r_excl, ra, rb], excluded_rows=excluded)


def _association(ds, plan, method, warnings):
    _require_independent(plan)
    a, b, accounting = _xy(ds, plan)
    n = len(a)
    if n < 3:
        raise ValueError(f"{method} requires at least three complete observations; {n} were found.")
    if np.ptp(a) == 0:
        raise ValueError("The x variable has no variation; this analysis is undefined.")
    if method != "regression" and np.ptp(b) == 0:
        raise ValueError("The y variable has no variation; correlation is undefined.")
    tables = [_table("Variable summaries", [_summary(plan["x"], a, True), _summary(plan["y"], b, True)])]
    if method == "regression":
        if np.ptp(b) == 0:
            const_y = float(b[0])
            rows = [
                {"term": "Intercept", "estimate": const_y, "standard_error": 0.0, "t": None, "p": None, "ci_low": const_y, "ci_high": const_y},
                {"term": plan["x"], "estimate": 0.0, "standard_error": 0.0, "t": None, "p": None, "ci_low": 0.0, "ci_high": 0.0},
            ]
            fit = {"n": n, "r_squared": None, "adjusted_r_squared": None, "df_residual": float(n - 2), "residual_sd": 0.0}
            tables.extend([_table("OLS coefficients", rows), _table("OLS model fit", [fit])])
            warnings.append("OLS assumes independent errors and a correctly specified linear mean relation; conventional coefficient intervals also assume homoscedastic errors. Residual diagnostics and confounding assessment remain the analyst's responsibility. Association does not establish causation.")
            warnings.append("The outcome is constant; R-squared and t-statistics are undefined and are reported as unavailable.")
            summary = f"Ordinary least squares: {plan['y']} = {const_y:.4g} + 0 × {plan['x']}; n = {n} (constant outcome; slope p is undefined)."
        else:
            with pywarnings.catch_warnings():
                pywarnings.simplefilter("ignore", RuntimeWarning)
                model = OLS(b, add_constant(a, has_constant="add")).fit()
                intervals = model.conf_int(alpha=.05)
                rows = [{"term": term, "estimate": model.params[i], "standard_error": model.bse[i], "t": model.tvalues[i], "p": model.pvalues[i], "ci_low": intervals[i, 0], "ci_high": intervals[i, 1]} for i, term in enumerate(["Intercept", plan["x"]])]
                fit = {"n": n, "r_squared": model.rsquared, "adjusted_r_squared": model.rsquared_adj, "df_residual": model.df_resid, "residual_sd": np.sqrt(model.mse_resid)}
            tables.extend([_table("OLS coefficients", rows), _table("OLS model fit", [fit])])
            warnings.append("OLS assumes independent errors and a correctly specified linear mean relation; conventional coefficient intervals also assume homoscedastic errors. Residual diagnostics and confounding assessment remain the analyst's responsibility. Association does not establish causation.")
            summary = f"Ordinary least squares: {plan['y']} = {model.params[0]:.4g} + {model.params[1]:.4g} × {plan['x']}; n = {n}, slope p = {model.pvalues[1]:.4g}."
    else:
        result = stats.pearsonr(a, b) if method == "pearson" else stats.spearmanr(a, b)
        r, p = float(result.statistic), float(result.pvalue)
        lo = hi = None
        if method == "pearson" and n > 3:
            if abs(r) >= 1:
                lo = hi = r
            else:
                z = np.arctanh(r)
                half = stats.norm.ppf(.975) / np.sqrt(n - 3)
                lo, hi = np.tanh(z - half), np.tanh(z + half)
        tables.append(_table("Correlation", [{"x": plan["x"], "y": plan["y"], "n": n, "coefficient": r, "p": p, "ci_low": lo, "ci_high": hi}]))
        if method == "pearson":
            warnings.append("Pearson correlation measures linear association; its conventional p-value and Fisher-transform 95% interval rely on independent observations and distributional assumptions. Correlation does not establish causation.")
            if n <= 3:
                warnings.append("A finite Fisher-transform confidence interval needs more than three complete observations; no correlation interval was calculated.")
        else:
            warnings.append("Spearman correlation uses ranks with averaged ties and an asymptotic two-sided p-value. No confidence interval is estimated in this version. Correlation does not establish causation.")
            if n < 500:
                warnings.append("For this sample size, a permutation procedure may be preferable to Spearman's asymptotic p-value; a permutation test is not implemented in this version.")
        summary = f"{'Pearson r' if method == 'pearson' else 'Spearman rho'} = {r:.4g}, two-sided p = {p:.4g}, n = {n} complete observations."
    return _finish(ds, plan, method, summary, tables, warnings, accounting)


def _chi2(ds, plan, warnings):
    _require_independent(plan)
    allowed, r_excl, excluded = _excluded_mask(ds, plan)
    x = _column(ds, plan.get("x"), "the first categorical variable")
    y = _column(ds, plan.get("y") or plan.get("group"), "the second categorical variable")
    if x == y:
        raise ValueError("Choose two different categorical columns.")
    plan.update(x=x, y=y)
    a, va, ra = _categorical(ds, x)
    b, vb, rb = _categorical(ds, y)
    weight_col_spec = plan.get("count") or plan.get("weight")
    if weight_col_spec:
        count_col = _column(ds, weight_col_spec, "pre-aggregated cell counts")
        if count_col in {x, y}:
            raise ValueError("The count column must be distinct from both categorical columns.")
        plan["count"] = count_col
        plan.pop("weight", None)
        w_vals, vw, rw = _numeric(ds, count_col)
        mask = va & vb & vw & allowed
        if not mask.any():
            raise ValueError("No complete weighted categorical cells were found.")
        active_w = w_vals[mask]
        if np.any(active_w < 0) or not np.all(np.isclose(active_w, np.round(active_w), atol=1e-9)):
            raise ValueError(f"Count column '{count_col}' must contain nonnegative whole-number counts for a chi-square contingency test.")
        int_w = np.round(active_w).astype(int)
        if int(int_w.sum()) <= 0:
            raise ValueError(f"Count column '{count_col}' sums to zero.")
        counts = pd.crosstab(pd.Series(a[mask], name=x), pd.Series(b[mask], name=y), values=int_w, aggfunc="sum").fillna(0).astype(int)
        reason_lists = [r_excl, ra, rb, rw]
        n = int(counts.to_numpy().sum())
    else:
        mask = va & vb & allowed
        if not mask.any():
            raise ValueError("No complete categorical observations were found.")
        _check_unpooled_replicates(ds, plan, mask, {x, y})
        counts = pd.crosstab(pd.Series(a[mask], name=x), pd.Series(b[mask], name=y))
        if (counts.to_numpy() <= 1).all():
            for cand in ds.df.columns:
                if cand in {x, y} or not _COUNT_COLUMN_RE.match(cand.strip()):
                    continue
                raw = ds.df[cand]
                non_missing = ~(raw.map(_blank) | raw.map(_is_missing_token))
                conv = pd.to_numeric(raw.where(non_missing, np.nan), errors="coerce")
                if conv.notna().any() and not (non_missing & conv.isna()).any() and (conv.dropna() > 1).any():
                    raise ValueError(
                        f"Every ({x}, {y}) combination appears at most once while column '{cand}' contains numeric counts. "
                        f"Specify count='{cand}' (for example 'chi-square of {x} by {y} weighted by {cand}') so pre-aggregated cell counts are tested rather than row counts."
                    )
        reason_lists = [r_excl, ra, rb]
        n = int(mask.sum())

    if len(counts.index) > 200 or len(counts.columns) > 200:
        raise ValueError("A categorical variable has more than 200 levels. Check whether an identifier or continuous measurement was selected.")
    if min(counts.shape) < 2:
        raise ValueError("A chi-square independence test requires at least two observed categories in each variable.")
    if np.any(counts.sum(axis=0) == 0) or np.any(counts.sum(axis=1) == 0):
        raise ValueError("At least one category row or column has a total count of zero; chi-square expected frequencies are undefined.")
    chi, p, df, expected = stats.chi2_contingency(counts.to_numpy(), correction=False)
    effect = np.sqrt(chi / (n * min(counts.shape[0] - 1, counts.shape[1] - 1)))
    labels = [str(c) for c in counts.columns]
    # Prefix category fields to avoid collision with the first row-label field.
    fields = [f"{y}: {c}" for c in labels]
    observed_rows = [{"category": str(index), **{field: int(counts.iloc[i, j]) for j, field in enumerate(fields)}} for i, index in enumerate(counts.index)]
    expected_rows = [{"category": str(index), **{field: float(expected[i, j]) for j, field in enumerate(fields)}} for i, index in enumerate(counts.index)]
    tables = [
        _table("Chi-square independence test", [{"chi_squared": chi, "df": df, "p": p, "n": n, "cramers_v": effect, "expected_cells_below_5": int((expected < 5).sum())}]),
        _table("Observed counts", observed_rows),
        _table("Expected counts", expected_rows),
    ]
    if weight_col_spec:
        warnings.append(f"Pearson's chi-square independence test was computed from pre-aggregated integer counts in '{plan['count']}' (total n = {n}) without Yates correction.")
    else:
        warnings.append("Pearson's chi-square independence test is calculated without Yates correction. Input rows are individual independent observations unless an explicit count column is specified.")
    if (expected < 5).any():
        warnings.append("Some expected cell counts are below five; the chi-square approximation may be unreliable. Review an exact or simulation-based alternative; no automatic replacement test was run.")
    summary = f"Pearson chi-square({df}) = {chi:.4g}, p = {p:.4g}; Cramér's V = {effect:.4g}, n = {n}."
    return _finish(ds, plan, "chi2", summary, tables, warnings, _account(ds, mask, reason_lists, excluded_rows=excluded))


def _per_stratum_tests(
    strata: np.ndarray,
    stratum_order: list[str],
    labels: np.ndarray,
    group_names: list[str],
    values: np.ndarray,
    mask: np.ndarray,
    test_name: str,
) -> tuple[list[dict], list[dict]]:
    """Compute per-stratum (e.g. per-timepoint) group summaries and Holm-adjusted comparisons."""
    summary_rows: list[dict] = []
    comp_rows: list[dict] = []
    with_ci = test_name in {"ttest", "anova"}
    minimum = 2 if test_name in {"ttest", "anova"} else 1

    for s_name in stratum_order:
        s_mask = mask & (strata == s_name)
        arrays = [values[s_mask & (labels == g_name)] for g_name in group_names]
        for g_name, g_arr in zip(group_names, arrays):
            s_row = _summary(str(g_name), g_arr, with_ci=with_ci)
            summary_rows.append({
                "stratum": str(s_name),
                "group": str(g_name),
                **{k: v for k, v in s_row.items() if k != "variable"},
            })

        if any(len(g_arr) < minimum for g_arr in arrays):
            comp_rows.append({
                "stratum": str(s_name),
                "test": test_name,
                "group_1": group_names[0],
                "group_2": group_names[1] if len(group_names) == 2 else None,
                "statistic": None,
                "df": None,
                "p_unadjusted": None,
                "p_holm": None,
                "mean_difference": None,
                "effect_size": None,
                "effect_type": None,
                "note": f"Insufficient observations (< {minimum}) in at least one group at this stratum",
            })
            continue

        try:
            if test_name == "ttest":
                t_val, df_val, p_val, diff, half, d_val = _scale_welch(arrays[0], arrays[1])
                comp_rows.append({
                    "stratum": str(s_name),
                    "test": "Welch t-test",
                    "group_1": group_names[0],
                    "group_2": group_names[1],
                    "statistic": t_val,
                    "df": df_val,
                    "p_unadjusted": p_val,
                    "p_holm": None,
                    "mean_difference": diff,
                    "ci_low": diff - half,
                    "ci_high": diff + half,
                    "effect_size": d_val,
                    "effect_type": "cohens_d_pooled",
                })
            elif test_name == "mannwhitney":
                if np.unique(np.concatenate(arrays)).size < 2:
                    raise ValueError("constant values")
                res = stats.mannwhitneyu(arrays[0], arrays[1], alternative="two-sided", method="auto")
                rb = 2 * float(res.statistic) / (len(arrays[0]) * len(arrays[1])) - 1
                comp_rows.append({
                    "stratum": str(s_name),
                    "test": "Mann–Whitney U",
                    "group_1": group_names[0],
                    "group_2": group_names[1],
                    "statistic": float(res.statistic),
                    "df": None,
                    "p_unadjusted": float(res.pvalue),
                    "p_holm": None,
                    "mean_difference": float(np.median(arrays[0]) - np.median(arrays[1])),
                    "effect_size": rb,
                    "effect_type": "rank_biserial",
                })
            elif test_name == "anova":
                f_val, df1, df2, p_val, eta = _scale_anova(arrays)
                comp_rows.append({
                    "stratum": str(s_name),
                    "test": "One-way ANOVA",
                    "statistic": f_val,
                    "df": f"{df1}, {df2}",
                    "p_unadjusted": p_val,
                    "p_holm": None,
                    "effect_size": eta,
                    "effect_type": "eta_squared",
                })
            else:
                if np.unique(np.concatenate(arrays)).size < 2:
                    raise ValueError("constant values")
                res = stats.kruskal(*arrays)
                n_tot, k_grp = sum(map(len, arrays)), len(arrays)
                eff = max(0.0, (float(res.statistic) - k_grp + 1) / (n_tot - k_grp)) if n_tot > k_grp else None
                comp_rows.append({
                    "stratum": str(s_name),
                    "test": "Kruskal–Wallis",
                    "statistic": float(res.statistic),
                    "df": k_grp - 1,
                    "p_unadjusted": float(res.pvalue),
                    "p_holm": None,
                    "effect_size": eff,
                    "effect_type": "eta_squared_H",
                })
        except ValueError:
            comp_rows.append({
                "stratum": str(s_name),
                "test": test_name,
                "group_1": group_names[0],
                "group_2": group_names[1] if len(group_names) == 2 else None,
                "statistic": None,
                "df": None,
                "p_unadjusted": None,
                "p_holm": None,
                "mean_difference": None,
                "effect_size": None,
                "effect_type": None,
                "note": "Zero variance or constant values at this stratum (e.g. normalized baseline)",
            })

    adjusted = _holm_adjust([r.get("p_unadjusted") for r in comp_rows])
    for r, p_adj in zip(comp_rows, adjusted):
        r["p_holm"] = p_adj
    return summary_rows, comp_rows


def _note_longitudinal_units(ds: Dataset, mask: np.ndarray, strata: np.ndarray, stratum_order: list[str], used_cols: set[str], warnings: list[str], x_name: str) -> None:
    for col in ds.df.columns:
        if col in used_cols or not _UNIT_COLUMN_RE.match(col.strip()):
            continue
        u_vals, v_u, _ = _categorical(ds, col)
        active = mask & v_u
        if int(active.sum()) < 3:
            continue
        # Check if duplicate subreplicates exist WITHIN a single stratum
        dup_within = False
        for s_name in stratum_order:
            sub_u = u_vals[active & (strata == s_name)]
            if len(sub_u) > len(set(sub_u)):
                dup_within = True
                break
        if dup_within:
            raise ValueError(
                f"Column '{col}' has multiple observations for the same unit within a single '{x_name}' stratum. "
                f"Pool technical subreplicates per ('{col}', '{x_name}') first via build_working_sheet(op='aggregate_units')."
            )
        n_units = len(set(u_vals[active]))
        if n_units < int(active.sum()):
            warnings.append(
                f"Longitudinal note: {int(active.sum())} observations come from {n_units} distinct '{col}' units tracked across '{x_name}'. "
                f"Groups are compared at each '{x_name}' with step-down Holm–Bonferroni multiplicity adjustment; cross-timepoint within-subject correlation is not modeled as a random effect."
            )


def _timecourse_compare(ds: Dataset, plan: dict, warnings: list[str]) -> dict:
    if plan.get("design") not in {"independent", "paired"}:
        raise ValueError(
            "Confirm the study design before timecourse comparison (design='independent' when groups contain distinct biological subjects, or design='paired' for repeated tracking)."
        )
    allowed, r_excl, excluded = _excluded_mask(ds, plan)
    x = _column(ds, plan.get("x"), "the timepoint or horizontal factor ('x')")
    y = _column(ds, plan.get("y"), "the numeric outcome ('y')")
    group = _column(ds, plan.get("group"), "group labels ('group')")
    if len({x, y, group}) != 3:
        raise ValueError("Timecourse comparison requires distinct columns for 'x' (timepoint), 'y' (numeric outcome), and 'group'.")
    subj_col = _column(ds, plan["subject"], "subject identifiers") if plan.get("subject") else None
    plan.update(x=x, y=y, group=group)
    if subj_col:
        plan["subject"] = subj_col

    strata, vx, rx = _categorical(ds, x)
    labels, vg, rg = _categorical(ds, group)
    values, vy, ry = _numeric(ds, y)
    mask = vx & vg & vy & allowed

    stratum_order = _sort_strata_naturally(list(dict.fromkeys(strata[vx & allowed])))
    group_names = list(dict.fromkeys(labels[vg & allowed]))
    if len(stratum_order) < 2:
        raise ValueError(f"timecourse_compare requires at least 2 timepoints/levels in '{x}'; {len(stratum_order)} found.")
    if len(group_names) < 2:
        raise ValueError(f"timecourse_compare requires at least 2 groups in '{group}'; {len(group_names)} found.")

    _note_longitudinal_units(ds, mask, strata, stratum_order, {x, y, group} | ({subj_col} if subj_col else set()), warnings, x)

    nonparametric = bool(plan.get("nonparametric", False))
    requested_test = plan.get("test")
    if requested_test is None:
        test_name = ("mannwhitney" if nonparametric else "ttest") if len(group_names) == 2 else ("kruskal" if nonparametric else "anova")
    else:
        if requested_test not in {"ttest", "mannwhitney", "anova", "kruskal"}:
            raise ValueError("timecourse_compare 'test' must be 'ttest', 'mannwhitney', 'anova', or 'kruskal'.")
        if requested_test in {"ttest", "mannwhitney"} and len(group_names) != 2:
            raise ValueError(f"{requested_test} requires exactly two groups; {len(group_names)} were found.")
        test_name = requested_test
    plan["test"] = test_name

    summary_rows, comp_rows = _per_stratum_tests(strata, stratum_order, labels, group_names, values, mask, test_name)
    valid_comps = [r for r in comp_rows if r.get("p_unadjusted") is not None]
    if not valid_comps:
        raise ValueError(
            f"No '{x}' timepoints had sufficient variance and sample size in each '{group}' group to run {test_name}."
        )

    warnings.append(
        f"Per-timepoint comparisons across {len(stratum_order)} '{x}' levels report both unadjusted p-values and step-down Holm–Bonferroni multiplicity-adjusted p-values (p_holm)."
    )
    parts = [
        f"{r['stratum']}: p = {r['p_unadjusted']:.4g} (Holm {r['p_holm']:.4g})"
        if r.get("p_unadjusted") is not None
        else f"{r['stratum']}: n/a ({r.get('note', 'constant')})"
        for r in comp_rows
    ]
    summary = f"Per-timepoint {valid_comps[0]['test']} of {y} by {group} across {len(stratum_order)} {x} levels: " + "; ".join(parts) + "."
    tables = [
        _table("Timepoint group summaries", summary_rows),
        _table("Timepoint comparisons", comp_rows),
    ]
    return _finish(ds, plan, "timecourse_compare", summary, tables, warnings, _account(ds, mask, [r_excl, rx, rg, ry], excluded_rows=excluded))


def _ols_sse_rank(X_mat: np.ndarray, y_vec: np.ndarray) -> tuple[float, int]:
    coef, _, rank, _ = np.linalg.lstsq(X_mat, y_vec, rcond=None)
    resid = y_vec - X_mat @ coef
    return float(np.sum(resid ** 2)), int(rank)


def _two_way_anova(ds: Dataset, plan: dict, warnings: list[str]) -> dict:
    if plan.get("design") not in {"independent", "paired"}:
        raise ValueError(
            "Confirm the study design before two-way ANOVA (design='independent' for separate biological units per group, or design='paired' when tracking longitudinal timepoints)."
        )
    allowed, r_excl, excluded = _excluded_mask(ds, plan)
    x = _column(ds, plan.get("x"), "second factor / timepoint ('x')")
    y = _column(ds, plan.get("y"), "the numeric outcome ('y')")
    group = _column(ds, plan.get("group"), "group factor ('group')")
    if len({x, y, group}) != 3:
        raise ValueError("Two-way ANOVA requires distinct columns for 'group', 'x' (second factor/timepoint), and 'y' (numeric outcome).")
    subj_col = _column(ds, plan["subject"], "subject identifiers") if plan.get("subject") else None
    plan.update(x=x, y=y, group=group)
    if subj_col:
        plan["subject"] = subj_col

    strata, vx, rx = _categorical(ds, x)
    labels, vg, rg = _categorical(ds, group)
    values, vy, ry = _numeric(ds, y)
    mask = vx & vg & vy & allowed

    stratum_order = _sort_strata_naturally(list(dict.fromkeys(strata[vx & allowed])))
    group_names = list(dict.fromkeys(labels[vg & allowed]))
    if len(group_names) < 2 or len(stratum_order) < 2:
        raise ValueError(
            f"Two-way ANOVA requires at least 2 levels in '{group}' (found {len(group_names)}) and at least 2 levels in '{x}' (found {len(stratum_order)})."
        )

    _note_longitudinal_units(ds, mask, strata, stratum_order, {x, y, group} | ({subj_col} if subj_col else set()), warnings, x)

    y_use = values[mask]
    g_use = labels[mask]
    x_use = strata[mask]
    n = len(y_use)
    if n < len(group_names) + len(stratum_order):
        raise ValueError("Two-way ANOVA requires replication beyond the number of factor levels.")

    scale = float(np.max(np.abs(y_use))) or 1.0
    y_s = y_use / scale
    ones = np.ones((n, 1), dtype=float)
    D_a = np.column_stack([(g_use == g_lvl).astype(float) for g_lvl in group_names[1:]])
    D_b = np.column_stack([(x_use == s_lvl).astype(float) for s_lvl in stratum_order[1:]])
    D_ab = np.column_stack([D_a[:, i] * D_b[:, j] for i in range(D_a.shape[1]) for j in range(D_b.shape[1])])

    sse_a, r_a = _ols_sse_rank(np.hstack([ones, D_a]), y_s)
    sse_b, r_b = _ols_sse_rank(np.hstack([ones, D_b]), y_s)
    sse_add, r_add = _ols_sse_rank(np.hstack([ones, D_a, D_b]), y_s)
    sse_full, r_full = _ols_sse_rank(np.hstack([ones, D_a, D_b, D_ab]), y_s)

    df_res = n - r_full
    additive_only = False
    if df_res < 1:
        df_res_add = n - r_add
        if df_res_add >= 1 and sse_add > 1e-30:
            additive_only = True
            df_res = df_res_add
            sse_resid = sse_add
        else:
            raise ValueError("Two-way ANOVA cannot estimate residual variance: within-cell residual degrees of freedom or variance is zero.")
    elif sse_full <= 1e-30:
        raise ValueError("Two-way ANOVA cannot estimate residual variance: within-cell residual degrees of freedom or variance is zero.")
    else:
        sse_resid = sse_full

    ms_res_s = sse_resid / df_res
    scale2 = scale ** 2
    anova_rows = []
    effects_spec = [
        (group, max(0.0, sse_b - sse_add), max(1, r_add - r_b)),
        (x, max(0.0, sse_a - sse_add), max(1, r_add - r_a)),
    ]
    df_int = r_full - r_add
    if not additive_only and df_int >= 1:
        effects_spec.append((f"{group} × {x}", max(0.0, sse_add - sse_full), df_int))

    summary_bits = []
    for source_lbl, ss_s, df_eff in effects_spec:
        ms_s = ss_s / df_eff
        f_val = ms_s / ms_res_s
        p_val = float(stats.f.sf(f_val, df_eff, df_res))
        p_eta2 = ss_s / (ss_s + sse_resid) if (ss_s + sse_resid) > 0 else 0.0
        anova_rows.append({
            "source": source_lbl,
            "ss": ss_s * scale2,
            "df": df_eff,
            "ms": ms_s * scale2,
            "F": f_val,
            "p": p_val,
            "partial_eta_squared": p_eta2,
        })
        summary_bits.append(f"{source_lbl}: F({df_eff}, {df_res}) = {f_val:.4g}, p = {p_val:.4g}")

    anova_rows.append({
        "source": "Residual",
        "ss": sse_resid * scale2,
        "df": df_res,
        "ms": ms_res_s * scale2,
        "F": None,
        "p": None,
        "partial_eta_squared": None,
    })

    simple_test = "ttest" if len(group_names) == 2 else "anova"
    cell_rows, comp_rows = _per_stratum_tests(strata, stratum_order, labels, group_names, values, mask, simple_test)
    if additive_only:
        warnings.append(
            f"Unreplicated two-way / block design (1 observation per '{group}' × '{x}' cell): fitted additive Type II main-effects ANOVA ({group} + {x}) without an interaction term."
        )
        model_lbl = f"{group} + {x}"
    else:
        warnings.append(
            f"Two-way factorial ANOVA uses Type II sum of squares across '{group}' and '{x}' with ordinary least-squares residuals, accompanied by Holm–Bonferroni adjusted simple-effect comparisons at each '{x}' level."
        )
        model_lbl = f"{group} × {x}"
    summary = f"Two-way ANOVA of {y} by {model_lbl} (n = {n}): " + "; ".join(summary_bits) + "."
    tables = [
        _table("Two-way ANOVA", anova_rows),
        _table("Timepoint group summaries", cell_rows),
        _table("Timepoint comparisons", comp_rows),
    ]
    return _finish(ds, plan, "two_way_anova", summary, tables, warnings, _account(ds, mask, [r_excl, rx, rg, ry], excluded_rows=excluded))


def _parse_survival_series(raw_series: pd.Series, event_col: str) -> tuple[np.ndarray, np.ndarray, list[str], str | None]:
    """Parse right-censored event indicator Series into {0, 1} with explicit coding provenance."""
    n_rows = len(raw_series)
    ev = np.zeros(n_rows, dtype=int)
    valid = np.zeros(n_rows, dtype=bool)
    reasons = [""] * n_rows

    parsed_nums: list[tuple[int, float]] = []
    text_tokens: list[tuple[int, str]] = []

    true_tokens = {"1", "true", "t", "yes", "y", "event", "dead", "deceased", "died", "relapse", "relapsed", "progressed", "failure"}
    false_tokens = {"0", "false", "f", "no", "n", "censored", "censor", "alive", "living", "surviving", "event-free"}

    for idx, val in enumerate(raw_series.tolist()):
        if _blank(val) or _is_missing_token(val):
            reasons[idx] = f"Missing event indicator in '{event_col}'"
            continue
        if isinstance(val, (bool, np.bool_)):
            ev[idx] = 1 if bool(val) else 0
            valid[idx] = True
            continue
        try:
            fv = float(val)
            if math.isfinite(fv) and abs(fv - round(fv)) < 1e-9:
                parsed_nums.append((idx, float(round(fv))))
                continue
        except (TypeError, ValueError):
            pass
        tok = str(val).strip().casefold()
        text_tokens.append((idx, tok))

    coding_note: str | None = None
    if parsed_nums and not text_tokens:
        uniq = sorted({int(v) for _, v in parsed_nums})
        if set(uniq).issubset({0, 1}):
            for idx, fv in parsed_nums:
                ev[idx] = int(fv)
                valid[idx] = True
        elif set(uniq) == {1, 2}:
            coding_note = (
                f"Event column '{event_col}' uses R survival 1/2 coding (1 = right-censored, 2 = event); "
                "mapped 2 → event (1) and 1 → censored (0)."
            )
            for idx, fv in parsed_nums:
                ev[idx] = 1 if int(fv) == 2 else 0
                valid[idx] = True
        else:
            raise ValueError(
                f"Survival event indicator '{event_col}' must encode binary censoring/event status "
                f"(0 = censored, 1 = event; or R 1 = censored, 2 = event), found values {uniq[:8]}."
            )
    else:
        for idx, fv in parsed_nums:
            iv = int(fv)
            if iv in (0, 1):
                ev[idx] = iv
                valid[idx] = True
            else:
                reasons[idx] = f"Unsupported event code {fv!r} in '{event_col}'"
        for idx, tok in text_tokens:
            if tok in true_tokens:
                ev[idx] = 1
                valid[idx] = True
            elif tok in false_tokens:
                ev[idx] = 0
                valid[idx] = True
            else:
                reasons[idx] = f"Unrecognized event status {tok!r} in '{event_col}'"
        if not valid.any():
            raise ValueError(
                f"Could not parse binary event/censoring status from '{event_col}'. "
                "Use 0/1 (0 = censored, 1 = event), 1/2, or explicit 'censored'/'event' labels."
            )

    return ev, valid, reasons, coding_note


def _parse_survival_events(ds: Dataset, event_col: str) -> tuple[np.ndarray, np.ndarray, list[str], str | None]:
    """Parse right-censored event indicator column into {0, 1} with explicit coding provenance."""
    return _parse_survival_series(ds.df[event_col], event_col)


def _km_loglog_ci(surv_prob: np.ndarray, surv_se: np.ndarray, alpha: float = 0.05) -> tuple[np.ndarray, np.ndarray]:
    """Compute R-compatible log(-log S(t)) 95% pointwise confidence bounds clipped to [0, 1]."""
    z = float(stats.norm.ppf(1.0 - alpha / 2.0))
    lo = np.full_like(surv_prob, np.nan, dtype=float)
    hi = np.full_like(surv_prob, np.nan, dtype=float)
    for i, (s, se) in enumerate(zip(surv_prob, surv_se)):
        if not math.isfinite(s):
            continue
        if s <= 0.0:
            lo[i], hi[i] = 0.0, 0.0
        elif s >= 1.0 or not math.isfinite(se) or se <= 0.0:
            lo[i], hi[i] = float(s), float(s)
        else:
            denom = s * abs(math.log(s))
            if denom <= 0:
                lo[i], hi[i] = float(s), float(s)
            else:
                theta = math.exp(z * se / denom)
                lo[i] = float(np.clip(s ** theta, 0.0, 1.0))
                hi[i] = float(np.clip(s ** (1.0 / theta), 0.0, 1.0))
    return lo, hi


def _survival(ds: Dataset, plan: dict, warnings: list[str]) -> dict:
    """Kaplan–Meier right-censored survival estimation, Mantel–Cox log-rank test, and Cox PH hazard ratio."""
    _require_independent(plan)
    allowed, r_excl, excluded = _excluded_mask(ds, plan)

    cols_hint = plan.get("columns")
    if not plan.get("x") and not plan.get("y") and isinstance(cols_hint, list) and len(cols_hint) >= 2:
        plan["x"], plan["y"] = cols_hint[0], cols_hint[1]

    time_col = _column(ds, plan.get("x"), "the survival follow-up time")
    event_col = _column(ds, plan.get("y"), "the binary event/censoring indicator")
    if time_col == event_col:
        raise ValueError("Choose distinct columns for survival time (x) and event/censoring indicator (y).")
    plan.update(x=time_col, y=event_col)

    times, vt, rt = _numeric(ds, time_col)
    neg_mask = vt & (times < 0)
    if neg_mask.any():
        for idx in np.flatnonzero(neg_mask):
            vt[idx] = False
            rt[idx] = f"Negative survival time ({times[idx]:g}) in '{time_col}'"

    events, ve, re_ev, coding_note = _parse_survival_events(ds, event_col)
    if coding_note:
        warnings.append(coding_note)

    group_spec = plan.get("group")
    if group_spec:
        group_col = _column(ds, group_spec, "the survival grouping factor")
        if group_col in {time_col, event_col}:
            raise ValueError("The survival grouping factor must be distinct from time and event columns.")
        plan["group"] = group_col
        g_labels, vg, rg = _categorical(ds, group_col)
        mask = vt & ve & vg & allowed
        reason_lists = [r_excl, rt, re_ev, rg]
        used_cols = {time_col, event_col, group_col}
    else:
        group_col = None
        g_labels = np.array(["All subjects"] * len(ds.df), dtype=object)
        mask = vt & ve & allowed
        reason_lists = [r_excl, rt, re_ev]
        used_cols = {time_col, event_col}

    _check_unpooled_replicates(ds, plan, mask, used_cols)
    n_total = int(mask.sum())
    if n_total < 3:
        raise ValueError(f"Survival analysis requires at least three complete (time, event) observations; {n_total} were found.")

    active_times = times[mask]
    active_events = events[mask]
    active_groups = g_labels[mask]
    total_events = int(active_events.sum())
    if total_events < 1:
        raise ValueError(f"Zero events were observed in '{event_col}' across the {n_total} active rows; log-rank and median survival are undefined.")

    if group_col:
        raw_order = list(dict.fromkeys(str(g) for g in active_groups))
        group_names = _sort_strata_naturally(raw_order)
        if len(group_names) < 2:
            raise ValueError(f"Survival comparison across '{group_col}' requires at least two observed groups; found {group_names}.")
        if len(group_names) > 12:
            raise ValueError(f"Grouping column '{group_col}' has {len(group_names)} levels; choose a categorical factor with 2–12 groups.")
    else:
        group_names = ["All subjects"]

    # Compute expected events per group under Mantel-Cox hypergeometric null
    expected_by_group: dict[str, float | None] = {g: None for g in group_names}
    if len(group_names) >= 2:
        uniq_event_times = np.sort(np.unique(active_times[active_events == 1]))
        exp_acc = {g: 0.0 for g in group_names}
        for t_ev in uniq_event_times:
            at_risk = active_times >= t_ev
            n_r = int(at_risk.sum())
            d_t = int(((active_times == t_ev) & (active_events == 1)).sum())
            if n_r > 0 and d_t > 0:
                for g in group_names:
                    n_rg = int((at_risk & (active_groups == g)).sum())
                    exp_acc[g] += d_t * (n_rg / n_r)
        expected_by_group = exp_acc

    km_summary_rows: list[dict] = []
    km_curve_rows: list[dict] = []
    t_horizon = float(np.max(active_times))

    for g in group_names:
        g_mask = active_groups == g
        gt = active_times[g_mask]
        ge = active_events[g_mask]
        n_g = int(len(gt))
        ev_g = int(ge.sum())
        cens_g = n_g - ev_g
        if n_g < 1:
            continue

        with pywarnings.catch_warnings():
            pywarnings.simplefilter("ignore", RuntimeWarning)
            sf = SurvfuncRight(gt, ge)
            med = float(sf.quantile(0.5))
            try:
                med_lo, med_hi = sf.quantile_ci(0.5)
            except Exception:
                med_lo, med_hi = np.nan, np.nan

        st = np.asarray(sf.surv_times, dtype=float)
        sp = np.asarray(sf.surv_prob, dtype=float)
        se = np.asarray(sf.surv_prob_se, dtype=float)
        nr = np.asarray(sf.n_risk, dtype=int)
        ne = np.asarray(sf.n_events, dtype=int)
        ci_lo, ci_hi = _km_loglog_ci(sp, se)

        # Restricted mean survival time (area under step KM curve up to observed group max follow-up)
        t_knots = np.concatenate(([0.0], st))
        s_prev = np.concatenate(([1.0], sp[:-1])) if len(sp) else np.array([1.0])
        rmst = float(np.sum(np.diff(t_knots) * s_prev[:len(st)])) if len(st) else float(np.max(gt))

        km_summary_rows.append({
            "group": g,
            "n": n_g,
            "events": ev_g,
            "censored": cens_g,
            "expected_events": expected_by_group.get(g),
            "median_survival": med if math.isfinite(med) else None,
            "ci_low": float(med_lo) if math.isfinite(med_lo) else None,
            "ci_high": float(med_hi) if math.isfinite(med_hi) else None,
            "restricted_mean_survival": rmst,
        })

        km_curve_rows.append({
            "group": g,
            "time": 0.0,
            "n_risk": n_g,
            "n_events": 0,
            "survival_prob": 1.0,
            "se": 0.0,
            "ci_low": 1.0,
            "ci_high": 1.0,
        })
        for idx_t in range(len(st)):
            km_curve_rows.append({
                "group": g,
                "time": float(st[idx_t]),
                "n_risk": int(nr[idx_t]),
                "n_events": int(ne[idx_t]),
                "survival_prob": float(sp[idx_t]),
                "se": float(se[idx_t]) if math.isfinite(se[idx_t]) else None,
                "ci_low": float(ci_lo[idx_t]) if math.isfinite(ci_lo[idx_t]) else None,
                "ci_high": float(ci_hi[idx_t]) if math.isfinite(ci_hi[idx_t]) else None,
            })

    tables = [_table("Kaplan–Meier group summaries", km_summary_rows)]

    if len(group_names) >= 2:
        chi2_stat, p_logrank = survdiff(active_times, active_events, active_groups)
        chi2_f = float(chi2_stat)
        p_f = float(p_logrank)
        df_lr = len(group_names) - 1

        lr_row: dict = {
            "test": "Mantel–Cox log-rank",
            "groups": len(group_names),
            "n": n_total,
            "events": total_events,
            "chi_squared": chi2_f,
            "df": df_lr,
            "p": p_f,
        }

        hr_summary_str = ""
        if len(group_names) == 2:
            # Fit Efron-tied univariate Cox proportional hazards matching R survival::coxph
            ref_grp, cmp_grp = group_names[0], group_names[1]
            x_ind = (active_groups == cmp_grp).astype(float)[:, None]
            try:
                with pywarnings.catch_warnings():
                    pywarnings.simplefilter("ignore")
                    cox_res = PHReg(active_times, x_ind, status=active_events, ties="efron").fit()
                beta = float(cox_res.params[0])
                se_b = float(cox_res.bse[0])
                p_cox = float(cox_res.pvalues[0])
                if math.isfinite(beta) and math.isfinite(se_b) and se_b > 0 and abs(beta) < 20:
                    hr = math.exp(beta)
                    hr_lo = math.exp(beta - 1.959963984540054 * se_b)
                    hr_hi = math.exp(beta + 1.959963984540054 * se_b)
                    lr_row.update({
                        "hr_comparison": f"{cmp_grp} vs {ref_grp}",
                        "hazard_ratio": hr,
                        "hr_ci_low": hr_lo,
                        "hr_ci_high": hr_hi,
                        "cox_wald_p": p_cox,
                    })
                    hr_summary_str = f"; Cox HR ({cmp_grp} vs {ref_grp}) = {hr:.4g}, 95% CI [{hr_lo:.4g}, {hr_hi:.4g}]"
            except Exception:
                pass

        tables.append(_table("Log-rank test", [lr_row]))
        warnings.append(
            "Kaplan–Meier survival curves and the Mantel–Cox log-rank test assume independent subjects and non-informative right censoring. "
            "Pointwise 95% survival bands use Greenwood standard errors on the log(-log) scale; median survival 95% intervals use the Brookmeyer–Crowley method."
        )
        summary = (
            f"Kaplan–Meier & Mantel–Cox log-rank test of {time_col} (event: {event_col}) across {group_col} "
            f"(n = {n_total}, events = {total_events}): chi-square({df_lr}) = {chi2_f:.4g}, p = {p_f:.4g}{hr_summary_str}."
        )
    else:
        row0 = km_summary_rows[0]
        med_txt = (
            f"{row0['median_survival']:.4g} (95% CI [{row0['ci_low']:.4g}, {row0['ci_high']:.4g}])"
            if row0.get("median_survival") is not None and row0.get("ci_low") is not None and row0.get("ci_high") is not None
            else f"{row0['median_survival']:.4g}" if row0.get("median_survival") is not None else "not reached"
        )
        warnings.append(
            "Kaplan–Meier survival estimation assumes independent subjects and non-informative right censoring (max observed follow-up "
            f"{t_horizon:.4g})."
        )
        summary = (
            f"Kaplan–Meier survival estimate of {time_col} (event: {event_col}): "
            f"n = {n_total} ({total_events} events, {n_total - total_events} right-censored); median survival = {med_txt}."
        )

    tables.append(_table("Kaplan–Meier curve coordinates", km_curve_rows[:600]))
    return _finish(ds, plan, "survival", summary, tables, warnings, _account(ds, mask, reason_lists, excluded_rows=excluded))


def analyze(dataset: Dataset, plan: dict) -> dict:
    """Execute one explicitly selected analysis; preserve source values and input plan."""
    if not isinstance(plan, dict):
        raise ValueError("The analysis plan must be a dictionary.")
    if not isinstance(dataset, Dataset) or not len(dataset.df):
        raise ValueError("Open a dataset containing observations before analysis.")
    plan = copy.deepcopy(plan)
    method = plan.get("method", "describe")
    if not isinstance(method, str) or method not in METHODS:
        raise ValueError(f"Unsupported statistical method '{method}'. Supported methods: {', '.join(sorted(METHODS))}.")
    plan["method"] = method
    plan["action"] = "analyze"
    if method == "survival":
        default_plot = "survival"
    elif method in {"timecourse_compare", "two_way_anova"}:
        default_plot = "timecourse"
    elif plan.get("pool_by") and method in {"ttest", "anova", "mannwhitney", "kruskal"}:
        default_plot = "superplot"
    elif method == "paired_t":
        default_plot = "paired"
    elif method in {"pearson", "spearman", "regression"}:
        default_plot = "scatter"
    elif method == "chi2":
        default_plot = "heatmap"
    elif method in {"mannwhitney", "kruskal"}:
        default_plot = "box"
    else:
        default_plot = "distribution"
    plan.setdefault("plot", default_plot)
    warnings = list(getattr(dataset, "warnings", []))
    warnings.append("The software does not infer the experimental unit. Confirm the study design, unit of replication, missingness mechanism, and any planned multiple-comparison procedure.")
    if method == "describe":
        return _describe(dataset, plan, warnings)
    if method == "survival":
        return _survival(dataset, plan, warnings)
    if method == "paired_t":
        return _paired(dataset, plan, warnings)
    if method == "timecourse_compare":
        return _timecourse_compare(dataset, plan, warnings)
    if method == "two_way_anova":
        return _two_way_anova(dataset, plan, warnings)
    if method == "batch_compare":
        return _batch_compare(dataset, plan, warnings)
    if method in {"ttest", "anova", "kruskal", "mannwhitney"}:
        return _group_test(dataset, plan, method, warnings)
    if method in {"pearson", "spearman", "regression"}:
        return _association(dataset, plan, method, warnings)
    return _chi2(dataset, plan, warnings)
