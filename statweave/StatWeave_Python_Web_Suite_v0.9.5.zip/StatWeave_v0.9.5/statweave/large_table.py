"""Disk-backed, source-preserving CSV tables and closed descriptive queries.

Every imported source field is VARCHAR. Only blank fields become missing;
literal NA/NaN, leading-zero identifiers and source-provided row fields survive.
Numeric values exist only in explicit derived finite-double expressions. The
fixed record ordinal counts CSV data records, including quoted multiline ones,
not physical lines or biological replicates. Queries use read-only connections,
one thread and a 512 MB DuckDB memory budget; bounded previews/samples are never
the input to full-data summary statistics. No arbitrary SQL is accepted.
"""
from __future__ import annotations

from copy import deepcopy
import codecs
import csv
import hashlib
import json
import math
import os
from pathlib import Path
import re
import shutil
import tempfile
import uuid

import duckdb
import pandas as pd

from .data import _column_names

SCHEMA_VERSION=1
MAX_RECORD_CHARS=16*1024*1024
MAX_COLUMNS=1024
MAX_PREVIEW=200
MAX_SCATTER=5000
MAX_GROUPS=200
MAX_METADATA_BYTES=8*1024*1024
MAX_OUTPUT_BYTES=8*1024*1024
MEMORY_LIMIT='512MB'
METHOD_FIELDS={
    'profile':{'columns'},'count_by':{'groupby'},'find':{'columns','limit','offset'},
    'summary':{'columns'},'histogram':{'x','bins'},'scatter':{'x','y','limit'}}


def _hash(path):
    digest=hashlib.sha256()
    with open(path,'rb') as handle:
        for block in iter(lambda:handle.read(1024*1024),b''):digest.update(block)
    return digest.hexdigest()


def _stat(path):
    s=Path(path).stat()
    return {'size_bytes':s.st_size,'mtime_ns':s.st_mtime_ns,'ctime_ns':s.st_ctime_ns}


def _integer(value,label,minimum=0,maximum=None):
    if type(value) is not int or value<minimum or (maximum is not None and value>maximum):
        raise ValueError(f'{label} must be a whole number from {minimum}'+(f' to {maximum}.' if maximum is not None else ' or greater.'))
    return value


def _finite(value,label):
    if isinstance(value,bool) or not isinstance(value,(str,int,float)):
        raise ValueError(f'{label} must be a finite numeric value.')
    try:result=float(value)
    except (ValueError,OverflowError) as error:raise ValueError(f'{label} must be a finite numeric value.') from error
    if not math.isfinite(result):raise ValueError(f'{label} must be finite; NaN/Inf are not numeric comparison thresholds.')
    return result


def _text(value):
    if value is None:return None
    if not isinstance(value,(str,int,float,bool)) or (isinstance(value,float) and not math.isfinite(value)):
        raise ValueError('Exact-match predicates require a scalar text/number or null, not SQL or structured values.')
    result=str(value)
    if len(result)>MAX_RECORD_CHARS:raise ValueError('A predicate value is too long.')
    return result


def _safe(value):
    if isinstance(value,dict):return {str(k):_safe(v) for k,v in value.items()}
    if isinstance(value,(tuple,list)):return [_safe(v) for v in value]
    if isinstance(value,float) and not math.isfinite(value):return None
    return value


def validate_large_plan(table,plan):
    """Normalize a closed, metadata-only descriptive plan without reading rows."""
    if not isinstance(plan,dict):raise ValueError('A large-table query needs a structured plan.')
    plan=deepcopy(plan);method=plan.get('method','profile')
    if any(not isinstance(k,str) for k in plan):raise ValueError('Large-table plan keys must be text.')
    if plan.get('action','large_analyze')!='large_analyze' or not isinstance(method,str) or method not in METHOD_FIELDS:
        raise ValueError('Unsupported large-table action or method; only closed descriptive queries are available.')
    allowed={'action','method','predicates'}|METHOD_FIELDS[method]
    if set(plan)-allowed:raise ValueError('Unsupported or unused large-table plan fields: '+', '.join(sorted(set(plan)-allowed)))
    available=table.metadata()['columns']
    def column(value):
        if not isinstance(value,str) or value not in available:raise ValueError(f'Unknown source column: {value!r}.')
        return value
    result={'action':'large_analyze','method':method}
    if 'columns' in METHOD_FIELDS[method]:
        names=plan.get('columns',available)
        if not isinstance(names,list) or not names or len(names)>MAX_COLUMNS or any(not isinstance(n,str) for n in names) or len(set(names))!=len(names):raise ValueError('Choose a nonempty unique list of source columns.')
        result['columns']=[column(c) for c in names]
    for key in ['groupby','x','y']:
        if key in METHOD_FIELDS[method]:result[key]=column(plan.get(key))
    if method=='find':result.update(limit=_integer(plan.get('limit',200),'Find limit',1,MAX_PREVIEW),offset=_integer(plan.get('offset',0),'Find offset'))
    if method=='scatter':result['limit']=_integer(plan.get('limit',MAX_SCATTER),'Scatter limit',1,MAX_SCATTER)
    if method=='histogram':result['bins']=_integer(plan.get('bins',40),'Histogram bins',1,200)
    predicates=plan.get('predicates',[])
    if not isinstance(predicates,list) or len(predicates)>100:raise ValueError('Provide at most 100 explicit predicates.')
    result['predicates']=[]
    for item in predicates:
        if not isinstance(item,dict) or set(item)!={'column','op','value'}:raise ValueError('Each predicate needs exactly column, op and value.')
        name=column(item['column']);op=item['op'];value=item['value']
        if not isinstance(op,str) or op not in {'eq','ieq','ne','contains','in','lt','le','gt','ge'}:raise ValueError('Unsupported predicate operator.')
        if op in {'lt','le','gt','ge'}:value=_finite(value,'Numeric predicate threshold')
        elif op=='in':
            if not isinstance(value,list) or len(value)>200:raise ValueError('An in predicate requires a bounded list of at most 200 exact values.')
            value=[_text(v) for v in value]
        else:
            value=_text(value)
            if op in {'contains','ieq'} and value is None:raise ValueError(f'{op} needs explicit text, not null.')
        result['predicates'].append({'column':name,'op':op,'value':value})
    return result


class _LimitedLines:
    def __init__(self,handle):self.handle=handle;self.record_chars=0
    def __iter__(self):return self
    def __next__(self):
        line=self.handle.readline(MAX_RECORD_CHARS+1)
        if not line:raise StopIteration
        self.record_chars+=len(line)
        if self.record_chars>MAX_RECORD_CHARS:raise ValueError('A CSV record exceeds the bounded 16 MiB text limit.')
        return line


def _encoding_and_hash(path):
    utf=codecs.getincrementaldecoder('utf-8-sig')('strict')
    cp=codecs.getincrementaldecoder('cp1252')('strict')
    utf_ok=cp_ok=True;digest=hashlib.sha256()
    with open(path,'rb') as handle:
        for block in iter(lambda:handle.read(1024*1024),b''):
            digest.update(block)
            if b'\x00' in block:raise ValueError('NUL bytes/UTF-16 or binary input are unsupported. Save the table as UTF-8 CSV.')
            if utf_ok:
                try:utf.decode(block)
                except UnicodeDecodeError:utf_ok=False
            if cp_ok:
                try:cp.decode(block)
                except UnicodeDecodeError:cp_ok=False
        if utf_ok:
            try:utf.decode(b'',final=True)
            except UnicodeDecodeError:utf_ok=False
        if cp_ok:
            try:cp.decode(b'',final=True)
            except UnicodeDecodeError:cp_ok=False
    if not utf_ok and not cp_ok:raise ValueError('The text is not valid UTF-8 or Windows-1252. Save it as UTF-8 CSV.')
    return ('utf-8-sig' if utf_ok else 'cp1252'),digest.hexdigest()


def _inspect_csv(path,encoding):
    delimiter='\t' if path.suffix.casefold()=='.tsv' else ','
    warnings=[]
    csv.field_size_limit(MAX_RECORD_CHARS)
    with open(path,'r',encoding=encoding,newline='') as handle:
        if path.suffix.casefold()=='.txt':
            sample=handle.read(65536);handle.seek(0)
            try:delimiter=csv.Sniffer().sniff(sample,delimiters=',\t;|').delimiter
            except csv.Error:pass
        lines=_LimitedLines(handle);reader=csv.reader(lines,delimiter=delimiter,strict=True)
        try:
            header=next(reader)
            if not header or len(header)>MAX_COLUMNS:raise ValueError('CSV needs a nonempty header with at most 1024 columns.')
            header_end=reader.line_num;lines.record_chars=0;count=0
            for row in reader:
                count+=1
                if len(row)!=len(header):raise ValueError(f'CSV data record {count} ending at physical line {reader.line_num} has {len(row)} fields; the header has {len(header)}. No records were skipped or padded.')
                lines.record_chars=0
        except StopIteration:raise ValueError('The CSV is empty.') from None
        except (csv.Error,UnicodeError) as error:raise ValueError(f'Malformed CSV near physical line {reader.line_num}: {error}. No records were skipped.') from error
    names=_column_names(header,warnings)
    if encoding=='cp1252':warnings.append('Source text was validated as Windows-1252 and decoded without changing the original file; verify non-English labels.')
    return header,names,count,delimiter,header_end,warnings


class LargeTable:
    kind='large_table'
    def __init__(self,source_path,database_path,source_hash=None,create=True):
        self.source_path=str(Path(source_path).expanduser().resolve())
        self.database_path=str(Path(database_path).expanduser().resolve())
        self.metadata_path=self.database_path+'.metadata.json'
        self._source=Path(self.source_path);self._database=Path(self.database_path);self._sidecar=Path(self.metadata_path)
        if not self._source.is_file():raise ValueError('The source table does not exist.')
        if self._source.suffix.casefold() not in {'.csv','.tsv','.txt'}:raise ValueError('Large-table mode currently supports local CSV, TSV or delimited TXT files.')
        if self._source==self._database or self._source==self._sidecar:raise ValueError('The cache must have a separate path from the source.')
        self._database.parent.mkdir(parents=True,exist_ok=True)
        self._temp_directory=self._database.parent/'duckdb-temp';self._temp_directory.mkdir(exist_ok=True)
        if create:self._build(source_hash)
        else:self._open(source_hash)
        self.source_hash=self._meta['source_hash'];self.row_count=int(self._meta['row_count'])
        self.columns=list(self._meta['columns']);self.warnings=list(self._meta['warnings'])
        self.record_number_column=self._meta['record_number_column']
        self._mapping={r['name']:r['internal_name'] for r in self._meta['column_name_mappings']}
        self._ordinal=self._meta['internal_record_column']
        self._source_stat=_stat(self._source);self._database_stat=_stat(self._database);self._metadata_stat=_stat(self._sidecar)

    def _connect(self,path=None,read_only=True):
        con=duckdb.connect(str(path or self._database),read_only=read_only,config={
            'memory_limit':MEMORY_LIMIT,'threads':1 if read_only else 4,
            'temp_directory':str(self._temp_directory),'preserve_insertion_order':True,
            'autoinstall_known_extensions':False,'autoload_known_extensions':False})
        # Set the bounded spill directory before disabling external access;
        # DuckDB otherwise disallows configuring that directory at connect.
        if read_only:con.execute('SET enable_external_access=false')
        return con

    def _build(self,expected_hash):
        if self._database.exists() or self._sidecar.exists():raise ValueError('This table cache already exists. Reopen it explicitly; an existing cache is never overwritten.')
        initial=_stat(self._source);encoding,digest=_encoding_and_hash(self._source)
        if expected_hash is not None and digest!=expected_hash:raise ValueError('The supplied source hash does not match the original table.')
        header,names,count,delimiter,header_end,warnings=_inspect_csv(self._source,encoding)
        mapping=[{'position':i+1,'original_name':raw,'name':name,'internal_name':f'c_{i:04d}'} for i,(raw,name) in enumerate(zip(header,names))]
        ordinal='__statweave_record_ordinal'
        while ordinal.casefold() in {name.casefold() for name in names}:ordinal+='_' 
        record_name='source_record_number'
        while record_name.casefold() in {name.casefold() for name in names}:record_name='_'+record_name
        temporary=self._database.parent/f'.building-{uuid.uuid4().hex}.duckdb'
        side_tmp=Path(str(temporary)+'.json')
        try:
            with tempfile.TemporaryDirectory(prefix='.csv-import-',dir=self._database.parent) as staging:
                alias=Path(staging)/'input.csv'
                if encoding=='cp1252':
                    with open(self._source,'r',encoding=encoding,newline='') as src,open(alias,'w',encoding='utf-8',newline='') as dst:
                        shutil.copyfileobj(src,dst,1024*1024)
                else:
                    try:alias.symlink_to(self._source)
                    except OSError:
                        with open(self._source,'rb') as src,open(alias,'wb') as dst:shutil.copyfileobj(src,dst,1024*1024)
                with self._connect(temporary,read_only=False) as con:
                    fields=[r['internal_name'] for r in mapping]
                    # Match Python str.strip's Unicode whitespace convention,
                    # retaining every character in nonblank source spellings.
                    expressions=[f'CASE WHEN regexp_full_match("{name}", \'[\\s\\p{{Z}}\\x{{0085}}\\x{{001c}}-\\x{{001f}}]*\') THEN NULL ELSE "{name}" END AS "{name}"' for name in fields]
                    sql=f'CREATE TABLE source_records AS SELECT row_number() OVER ()::UBIGINT AS "{ordinal}",'+','.join(expressions)+''' FROM read_csv(?,columns=?,header=true,auto_detect=false,delim=?,quote='"',escape='"',strict_mode=true,ignore_errors=false,null_padding=false,parallel=false,nullstr='',allow_quoted_nulls=true,compression='none',max_line_size=16777216,buffer_size=67108864)'''
                    con.execute(sql,[str(alias),{name:'VARCHAR' for name in fields},delimiter])
                    actual=con.execute('SELECT count(*) FROM source_records').fetchone()[0]
                    if actual!=count:raise ValueError('CSV parser record counts disagree; the cache was not accepted.')
                    profiles=self._profiles(con,mapping,'',[])[1]
                    con.execute('CHECKPOINT')
            if _stat(self._source)!=initial:raise ValueError('The source table changed during import; no cache was accepted.')
            warnings+=['Every source field is stored as text; only blank fields become missing. Literal NA/NaN and leading-zero identifiers are preserved.',
                'Record identities are one-based CSV data-record ordinals after the header, not physical line numbers or source-provided SourceRow values.',
                'Scientific meaning and the experimental unit must be specified; rows are not assumed to be independent biological replicates.']
            self._meta={'kind':self.kind,'schema_version':SCHEMA_VERSION,'source_path':self.source_path,'source_hash':digest,
                'source_sha256':digest,'source_size_bytes':initial['size_bytes'],'source_stat_at_import':initial,
                'row_count':count,'rows':count,'columns':names,'dtypes':{name:'VARCHAR' for name in names},'profiles':profiles,
                'column_name_mappings':mapping,'internal_record_column':ordinal,'record_number_column':record_name,
                'csv':{'encoding':encoding,'delimiter':delimiter,'header_record_number':1,'header_physical_start_line':1,'header_physical_end_line':header_end,'strict_mode':True,'ignored_records':0,'padded_records':0},
                'database_sha256':_hash(temporary),'database_size_bytes':temporary.stat().st_size,'duckdb_version':duckdb.__version__,
                'verification_policy':'Full source and checkpointed-cache SHA-256 at build/open/export; cached size/mtime_ns/ctime_ns between queries. No repeated whole-file hashing during an unchanged query.',
                'query_budget':{'memory_limit':MEMORY_LIMIT,'threads':1,'build_threads':4},'warnings':warnings}
            serialized=json.dumps(self._meta,indent=2,allow_nan=False)
            if len(serialized.encode('utf-8'))>MAX_METADATA_BYTES:raise ValueError('The header/profile metadata exceeds the bounded cache metadata limit.')
            side_tmp.write_text(serialized,encoding='utf-8')
            os.replace(temporary,self._database);os.replace(side_tmp,self._sidecar)
        except duckdb.Error as error:raise ValueError(f'The strict CSV cache could not be built: {error}') from error
        finally:
            temporary.unlink(missing_ok=True);side_tmp.unlink(missing_ok=True)
            Path(str(temporary)+'.wal').unlink(missing_ok=True)
        self._metadata_hash=_hash(self._sidecar)

    def _open(self,expected_hash):
        if not self._database.is_file() or not self._sidecar.is_file():raise ValueError('The saved table cache or metadata is missing; reopen cannot silently reimport it.')
        if self._sidecar.stat().st_size>MAX_METADATA_BYTES:raise ValueError('The cache metadata exceeds the supported bound.')
        try:self._meta=json.loads(self._sidecar.read_text(encoding='utf-8'))
        except (ValueError,UnicodeError) as error:raise ValueError('The cache metadata is malformed.') from error
        meta=self._meta
        if not isinstance(meta,dict) or meta.get('schema_version')!=SCHEMA_VERSION or meta.get('kind')!=self.kind:raise ValueError('Unsupported table cache schema.')
        columns=meta.get('columns');mapping=meta.get('column_name_mappings')
        if not isinstance(columns,list) or not columns or len(columns)>MAX_COLUMNS or any(not isinstance(c,str) for c in columns) or len(set(columns))!=len(columns):raise ValueError('The cache column metadata is malformed.')
        if not isinstance(mapping,list) or len(mapping)!=len(columns) or any(not isinstance(r,dict) or r.get('name')!=columns[i] or r.get('internal_name')!=f'c_{i:04d}' or r.get('position')!=i+1 for i,r in enumerate(mapping)):
            raise ValueError('The cache name mapping is malformed.')
        if not isinstance(meta.get('internal_record_column'),str) or not re.fullmatch(r'__statweave_record_ordinal_*',meta['internal_record_column']):raise ValueError('The cache record identity column is malformed.')
        if not isinstance(meta.get('record_number_column'),str) or not re.fullmatch(r'_*source_record_number',meta['record_number_column']):raise ValueError('The cache record display name is malformed.')
        for key in ['source_hash','database_sha256']:
            if not isinstance(meta.get(key),str) or not re.fullmatch(r'[0-9a-f]{64}',meta[key]):raise ValueError('The cache hash manifest is malformed.')
        for key in ['row_count','source_size_bytes','database_size_bytes']:_integer(meta.get(key),'Cache '+key)
        if not isinstance(meta.get('profiles'),dict) or set(meta['profiles'])!=set(columns) or meta.get('dtypes')!={c:'VARCHAR' for c in columns}:raise ValueError('The cache profile metadata is malformed.')
        for profile in meta['profiles'].values():
            if not isinstance(profile,dict):raise ValueError('The cache column profile is malformed.')
            counts=[_integer(profile.get(key),'Cache profile '+key) for key in ['finite_count','nonfinite_count','invalid_count','null_count']]
            if sum(counts)!=meta['row_count']:raise ValueError('The cache profile counts do not account for all records.')
        if not isinstance(meta.get('warnings'),list) or any(not isinstance(w,str) for w in meta['warnings']):raise ValueError('The cache warnings metadata is malformed.')
        digest=expected_hash if expected_hash is not None else _hash(self._source)
        if digest!=self._meta.get('source_hash') or self._source.stat().st_size!=self._meta.get('source_size_bytes'):raise ValueError('The source identity/hash does not match this saved table cache.')
        if _hash(self._database)!=self._meta.get('database_sha256'):raise ValueError('The saved table cache hash differs from its checkpointed manifest.')
        with self._connect() as con:
            actual=con.execute('PRAGMA table_info(source_records)').fetchall()
            expected=[(self._meta['internal_record_column'],'UBIGINT')]+[(r['internal_name'],'VARCHAR') for r in self._meta['column_name_mappings']]
            if [(r[1],r[2]) for r in actual]!=expected:raise ValueError('The saved table schema differs from its manifest.')
            if con.execute('SELECT count(*) FROM source_records').fetchone()[0]!=self._meta['row_count']:raise ValueError('The saved table row count differs from its manifest.')
        self._metadata_hash=_hash(self._sidecar)

    def verify_integrity(self,full=False):
        try:
            current=(_stat(self._source),_stat(self._database),_stat(self._sidecar))
        except OSError as error:raise ValueError('The source or saved table cache is missing.') from error
        previous=(self._source_stat,self._database_stat,self._metadata_stat)
        if full or current[0]!=previous[0]:
            if _hash(self._source)!=self.source_hash:raise ValueError('The original source table changed; analysis stopped.')
        if full or current[1:]!=previous[1:]:
            self.verify_cache()
        self._source_stat,self._database_stat,self._metadata_stat=current
        return True

    def verify_cache(self):
        try:
            if _hash(self._sidecar)!=self._metadata_hash:raise ValueError('The saved cache metadata changed; analysis stopped.')
            if _hash(self._database)!=self._meta['database_sha256']:raise ValueError('The saved table cache changed; analysis stopped.')
        except OSError as error:raise ValueError('The saved cache or metadata is missing.') from error
        return True

    def cache_identity(self):
        self.verify_integrity()
        return {'database_sha256':self._meta['database_sha256'],'metadata_sha256':self._metadata_hash,
            'schema_version':SCHEMA_VERSION,'database_size_bytes':self._meta['database_size_bytes']}

    def metadata(self):return deepcopy(self._meta)

    def model_schema(self):
        return {'input_type':self.kind,'kind':self.kind,'row_count':self.row_count,'columns':list(self.columns),
            'dtypes':deepcopy(self._meta['dtypes']),'profiles':deepcopy(self._meta['profiles']),
            'allowed_methods':list(METHOD_FIELDS),'record_identity':'one-based CSV data-record ordinal; not biological replication',
            'privacy':'Only column names and aggregate type/count profiles are provided; no file paths, raw rows or category values.'}

    def _where(self,predicates):
        terms=[];params=[]
        for item in predicates:
            name='"'+self._mapping[item['column']]+'"';op=item['op'];value=item['value']
            if op in {'lt','le','gt','ge'}:
                expr=f'TRY_CAST({name} AS DOUBLE)';symbol={'lt':'<','le':'<=','gt':'>','ge':'>='}[op]
                terms.append(f'(isfinite({expr}) AND {expr} {symbol} ?)');params.append(value)
            elif op=='in':
                nonnull=[v for v in value if v is not None];pieces=[]
                if nonnull:pieces.append(name+' IN ('+','.join('?' for _ in nonnull)+')');params.extend(nonnull)
                if None in value:pieces.append(name+' IS NULL')
                terms.append('('+' OR '.join(pieces)+')' if pieces else 'FALSE')
            elif value is None:terms.append(name+(' IS NOT NULL' if op=='ne' else ' IS NULL'))
            elif op=='contains':terms.append(f'contains({name}, ?)');params.append(value)
            elif op=='ieq':terms.append(f'lower({name}) = lower(?)');params.append(value)
            else:terms.append(name+(' <> ?' if op=='ne' else ' = ?'));params.append(value)
        return (' WHERE '+' AND '.join(terms) if terms else ''),params

    @staticmethod
    def _profiles(con,mapping,where,params):
        expressions=['count(*)']
        for entry in mapping:
            c='"'+entry['internal_name']+'"';v=f'TRY_CAST({c} AS DOUBLE)'
            expressions += [f'count({c})',f'count({v})',f'count(*) FILTER (WHERE isfinite({v}))']
        data=con.execute('SELECT '+','.join(expressions)+' FROM source_records'+where,params).fetchone()
        total=int(data[0]);profiles={}
        for i,entry in enumerate(mapping):
            nonnull,numeric,finite=map(int,data[1+3*i:4+3*i])
            profiles[entry['name']]={'dtype':'VARCHAR','numeric_compatible':numeric>0 and nonnull==numeric,
                'numeric_compatible_count':numeric,'finite_count':finite,'nonfinite_count':numeric-finite,
                'invalid_count':nonnull-numeric,'null_count':total-nonnull}
        return total,profiles

    def _summaries(self,con,names,where,params):
        mapping=[{'name':name,'internal_name':self._mapping[name]} for name in names]
        total,profiles=self._profiles(con,mapping,where,params);rows=[];overflow=False
        for name in names:
            expr=f'TRY_CAST("{self._mapping[name]}" AS DOUBLE)'
            query=f'SELECT min(v),max(v),avg(v),stddev_samp(v),median(v) FROM (SELECT {expr} AS v FROM source_records{where}) t WHERE isfinite(v)'
            try:values=con.execute(query,params).fetchone()
            except duckdb.OutOfRangeException as error:raise ValueError('Finite values overflowed the requested descriptive aggregate; no zero or finite substitute was reported.') from error
            if any(isinstance(v,float) and not math.isfinite(v) for v in values):overflow=True
            rows.append({'column':name,'selected_rows':total,**profiles[name],**dict(zip(['min','max','mean','sd','median'],values))})
        return total,rows,overflow

    @staticmethod
    def _output_budget(con,sql,params,fields):
        expressions=['coalesce(octet_length(encode("'+name+'")),0)' for name in fields]
        size=con.execute('SELECT coalesce(sum('+('+'.join(expressions) if expressions else '0')+'),0) FROM ('+sql+') bounded_output',params).fetchone()[0]
        if size>MAX_OUTPUT_BYTES:
            raise ValueError('This bounded text result exceeds the 8 MiB output budget. Choose fewer columns, fewer preview rows or narrower predicates; no values were silently truncated.')

    def preview(self,limit=200,offset=0,columns=None,predicates=None):
        plan=validate_large_plan(self,{'method':'find','columns':self.columns if columns is None else columns,
            'limit':limit,'offset':offset,'predicates':[] if predicates is None else predicates})
        self.verify_integrity();where,params=self._where(plan['predicates'])
        selected=','.join('"'+self._mapping[c]+'"' for c in plan['columns'])
        with self._connect() as con:
            sql=f'SELECT "{self._ordinal}",{selected} FROM source_records{where} ORDER BY "{self._ordinal}" LIMIT ? OFFSET ?'
            self._output_budget(con,sql,params+[limit,offset],[self._mapping[c] for c in plan['columns']])
            result=con.execute(sql,params+[limit,offset]).fetchall()
        frame=pd.DataFrame([r[1:] for r in result],columns=plan['columns'],dtype=object)
        frame.index=pd.Index([int(r[0]) for r in result],name=self.record_number_column,dtype='int64')
        return frame

    def execute_plan(self,plan):
        plan=validate_large_plan(self,plan);self.verify_integrity();method=plan['method'];where,params=self._where(plan['predicates'])
        tables=[];warnings=['Derived selections never remove or alter source records. Numeric comparisons/statistics use finite TRY_CAST-to-DOUBLE values; blank, invalid and nonfinite counts are explicit.',
            'Scientific meaning and the experimental unit must be specified; rows are not assumed to be independent biological replicates. No inferential test is performed.']
        account={'source_record_count':self.row_count,'record_number_column':self.record_number_column,'source_records_preserved':True,'inferential_analysis':False}
        with self._connect() as con:
            selected=int(con.execute('SELECT count(*) FROM source_records'+where,params).fetchone()[0]);account['selected_record_count']=selected
            if method=='profile':
                mapping=[{'name':n,'internal_name':self._mapping[n]} for n in plan['columns']]
                _,profiles=self._profiles(con,mapping,where,params)
                data=[{'column':name,**profile} for name,profile in profiles.items()]
                tables.append({'title':'Column profile','columns':['column','dtype','numeric_compatible','numeric_compatible_count','finite_count','nonfinite_count','invalid_count','null_count'],'rows':data})
            elif method=='find':
                fields=','.join('"'+self._mapping[c]+'"' for c in plan['columns'])
                sql=f'SELECT "{self._ordinal}",{fields} FROM source_records{where} ORDER BY "{self._ordinal}" LIMIT ? OFFSET ?'
                self._output_budget(con,sql,params+[plan['limit'],plan['offset']],[self._mapping[c] for c in plan['columns']])
                raw=con.execute(sql,params+[plan['limit'],plan['offset']]).fetchall()
                columns=[self.record_number_column]+plan['columns'];data=[dict(zip(columns,row)) for row in raw]
                tables.append({'title':'Matching records','columns':columns,'rows':data})
                account.update(returned_record_count=len(data),remaining_record_count=max(0,selected-plan['offset']-len(data)),offset=plan['offset'])
                warnings.append('Matching-record output is bounded and ordered by the fixed source data-record ordinal; it is a preview, not a full-table export.')
            elif method=='count_by':
                field='"'+self._mapping[plan['groupby']]+'"'
                grouped=f'SELECT {field} AS value,count(*) AS count FROM source_records{where} GROUP BY {field}'
                groups=int(con.execute('SELECT count(*) FROM ('+grouped+') t',params).fetchone()[0])
                top=grouped+' ORDER BY count DESC,value ASC NULLS LAST LIMIT ?'
                self._output_budget(con,top,params+[MAX_GROUPS],['value'])
                data=[{'value':r[0],'count':int(r[1])} for r in con.execute(top,params+[MAX_GROUPS]).fetchall()]
                account.update(total_group_count=groups,returned_group_count=len(data),remaining_group_count=max(0,groups-len(data)),remaining_record_count=selected-sum(r['count'] for r in data))
                tables.append({'title':'Counts by group','columns':['value','count'],'rows':data})
                warnings.append(f'Counts cover all {selected:,} selected records; at most {MAX_GROUPS} groups are returned. Remaining groups/records are explicitly accounted for.')
            else:
                names=plan['columns'] if method=='summary' else list(dict.fromkeys([plan['x']]+([plan['y']] if method=='scatter' else [])))
                _,stats,overflow=self._summaries(con,names,where,params)
                tables.append({'title':'Numeric summary','columns':['column','selected_rows','finite_count','nonfinite_count','invalid_count','null_count','min','max','mean','sd','median'],'rows':stats})
                if overflow:warnings.append('An aggregate overflowed finite floating-point representation and is unavailable (null); no zero was substituted.')
                if method=='histogram':
                    stat=stats[0];n=stat['finite_count'];minimum=stat['min'];maximum=stat['max'];data=[]
                    if n:
                        bins=plan['bins'] if minimum<maximum else 1
                        if bins==1 and minimum==maximum:
                            delta=max(.5,abs(minimum)*.01);left=minimum-delta;right=maximum+delta
                            if not math.isfinite(left):left=minimum
                            if not math.isfinite(right):right=maximum
                            edges=[left,right]
                        else:edges=[(1-i/bins)*minimum+(i/bins)*maximum for i in range(bins+1)]
                        cases='CASE '+''.join(f'WHEN v < ? THEN {i} ' for i in range(bins-1)) + f'ELSE {bins-1} END' if bins>1 else '0'
                        expr=f'TRY_CAST("{self._mapping[plan["x"]]}" AS DOUBLE)'
                        counts=dict(con.execute(f'SELECT {cases} AS bin,count(*) FROM (SELECT {expr} AS v FROM source_records{where}) t WHERE isfinite(v) GROUP BY bin',edges[1:-1]+params).fetchall())
                        data=[{'bin_index':i,'bin_left':edges[i],'bin_right':edges[i+1],'count':int(counts.get(i,0))} for i in range(bins)]
                    tables.append({'title':'Histogram','columns':['bin_index','bin_left','bin_right','count'],'rows':data})
                    account.update(finite_record_count=n,histogram_record_count=sum(r['count'] for r in data),effective_bin_count=len(data),bin_boundary_rule='left inclusive; right exclusive except final bin inclusive')
                elif method=='scatter':
                    x=f'TRY_CAST("{self._mapping[plan["x"]]}" AS DOUBLE)';y=f'TRY_CAST("{self._mapping[plan["y"]]}" AS DOUBLE)'
                    pair=f'SELECT "{self._ordinal}" AS source_record_number,{x} AS x,{y} AS y FROM source_records{where}'
                    eligible=f'SELECT * FROM ({pair}) q WHERE isfinite(x) AND isfinite(y)'
                    total=int(con.execute('SELECT count(*) FROM ('+eligible+') p',params).fetchone()[0]);limit=min(total,plan['limit'])
                    targets=[1+(i*(total-1))//(limit-1) for i in range(limit)] if limit>1 else ([1] if limit else [])
                    data=[]
                    if targets:
                        numbered='SELECT *,row_number() OVER (ORDER BY source_record_number) AS sample_rank FROM ('+eligible+') p'
                        raw=con.execute('SELECT source_record_number,x,y FROM ('+numbered+') s WHERE sample_rank IN ('+','.join('?' for _ in targets)+') ORDER BY source_record_number',params+targets).fetchall()
                        data=[{'source_record_number':int(r[0]),'x':r[1],'y':r[2]} for r in raw]
                    tables.append({'title':'Scatter sample','columns':['source_record_number','x','y'],'rows':data})
                    account.update(finite_pair_count=total,nonfinite_or_missing_pair_count=selected-total,plotted_record_count=len(data),sampling_method='all finite pairs' if total<=plan['limit'] else 'deterministic evenly spaced ranks among finite pairs ordered by source data-record ordinal')
                    warnings.append(f'Scatter shows {len(data):,} of {total:,} finite pairs; {account["sampling_method"]}. Numeric summaries use every finite selected value, not the plotted sample.')
        account['records_excluded_by_predicates']=self.row_count-selected
        summary=f'{method.replace("_"," ").capitalize()}: {selected:,} of {self.row_count:,} source records selected; all original records remain preserved.'
        if method=='count_by':summary+=f' {account["returned_group_count"]:,} groups returned; {account["remaining_group_count"]:,} groups / {account["remaining_record_count"]:,} records remain outside the bounded group display.'
        if method=='find':summary+=f' {account["returned_record_count"]:,} records returned from offset {plan["offset"]:,}; {account["remaining_record_count"]:,} matching records remain after this page.'
        if method=='scatter':summary+=f' Plot shows {account["plotted_record_count"]:,} of {account["finite_pair_count"]:,} finite pairs; full-data numeric summaries are separate.'
        return _safe({'method':method,'plan':plan,'summary':summary,'tables':tables,'warnings':warnings,
            'large_table_accounting':account,'source_sha256':self.source_hash,
            'processing_steps':[{'operation':'read_only_disk_backed_query','memory_limit':MEMORY_LIMIT,'threads':1,'predicates':plan['predicates'],'source_modification':'none'},
                {'operation':'descriptive_analysis','method':method,'record_accounting':account}]})


def large_result(table,plan):return table.execute_plan(plan)
