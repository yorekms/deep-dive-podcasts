"""Exercise cancellable replies through the native window with a fake local model.

This intentionally tests transport-stage UI control without any live model,
network access, private data or scientific-method claims.
"""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import threading
import time
import traceback

from PySide6.QtCore import QTimer

from .session import canonical,sha256,verify_audit,versions


def schedule(window,app,workspace):
    from . import llm
    output=Path(workspace).resolve()/'ui-conversation-self-test'
    output.mkdir(parents=True,exist_ok=True)
    app.setQuitOnLastWindowClosed(False)
    original_planner=llm.OllamaPlanner
    started=time.monotonic()
    state={'stage':'starting','ticks':0,'deadline':started+12,'checks':[],
           'models':[],'followup_ran':False,'error':None}
    timer=QTimer(app);window._conversation_selftest_timer=timer

    def require(value,message):
        if not value:raise ValueError(message)

    class ControlledPlanner:
        def __init__(self,**options):
            self.model=options['model'];self.activity_callback=None
            self.stopped=threading.Event();self.cancelled=False
            state['models'].append(self)

        def cancel(self):
            self.cancelled=True;self.stopped.set()

        def plan(self,*args,**kwargs):
            if self.activity_callback:self.activity_callback(True)
            try:
                if not self.stopped.wait(4):
                    raise ValueError('The synthetic local-model request did not receive cancellation.')
                raise ValueError('The local discussion was cancelled. Your previous analysis is retained.')
            finally:
                if self.activity_callback:self.activity_callback(False)

    def finish(error=None):
        # Keep the event loop alive until the actual native worker has finished.
        if window.thread is not None and window.thread.isRunning():
            state['error']=error or state['error'] or 'Conversation check could not finish safely'
            for model in state['models']:model.cancel()
            window.close()
            return
        timer.stop();llm.OllamaPlanner=original_planner
        report={'status':'failed' if error else 'passed',
                'scope':'Synthetic CSV; controlled fake local model through Window.send; native reply cancellation, responsive progress and close lifecycle. No model or network.',
                'seconds':time.monotonic()-started,'environment':versions(),
                'checks':state['checks'],'event_loop_ticks':state['ticks']}
        if error:
            report.update(error=str(error),traceback=traceback.format_exc())
        else:
            session=window.session
            session._assert_integrity(full=True)
            project=session.project_dir/'project.json';saved=json.loads(project.read_text())
            head,events=verify_audit(session.project_dir/'history.jsonl',saved['audit_head'])
            last=json.loads((session.project_dir/'history.jsonl').read_text().splitlines()[-1])
            content={key:value for key,value in saved.items() if key!='audit_head'}
            require(last['type']=='state_saved' and last['payload']['state_sha256']==hashlib.sha256(canonical(content).encode()).hexdigest(),
                    'Conversation close left an invalid checkpoint')
            require(saved['result']==state['result'],'Cancellation replaced the saved numerical result')
            require(sha256(state['original'])==state['source_hash'] and sha256(session.dataset.source_path)==state['source_hash'],
                    'A synthetic original or source snapshot changed')
            require(all(model.cancelled for model in state['models']) and len(state['models'])==2,'Both requests were not cancelled')
            require(not state['followup_ran'] and window._after_work is None,'A queued follow-up ran after close')
            require(window.thread is None and not window.isVisible(),'The window did not close after native cleanup')
            report.update(checks=state['checks']+['saved_result_preserved','checkpoint_and_audit_verified',
                'original_and_snapshot_hashes_unchanged','queued_followup_skipped','native_worker_cleanup_before_close'],
                cancelled_replies=len(state['models']),result_unchanged=True,source_unchanged=True,
                worker_cleaned_up=True,window_visible=False,project=str(project),audit_head=head,audit_events=events,
                screenshot=str(output/'reply-waiting.png'))
        (output/'result.json').write_text(json.dumps(report,indent=2,ensure_ascii=False))
        app.exit(1 if error else 0)

    def tick():
        state['ticks']+=1
        try:
            if state['error']:
                finish(state['error']);return
            require(time.monotonic()<state['deadline'],'The bounded native conversation check exceeded twelve seconds')
            if state['stage']=='first_wait':
                require(window.busy,'The controlled model request ended before cancellation')
                if not window.cancel_button.isVisible():return
                if 'shown_at' not in state:
                    state['shown_at']=time.monotonic();state['initial_progress']=window.progress.text()
                    return
                observed=time.monotonic()-state['shown_at']
                if observed<1.1:return
                require('Discussing your question locally' in window.progress.text(),'Discussion status is not visible')
                # A coarse Qt timer may fire just before the whole-second
                # boundary; allow its next tick before judging the visible age.
                if window.progress.text()==state['initial_progress'] and observed<2.2:return
                require(window.progress.text()!=state['initial_progress'],'Elapsed progress did not update while waiting')
                require(window.grab().save(str(output/'reply-waiting.png')),'Could not save the native reply controls')
                state['checks']+=['model_stage_cancel_control_visible','elapsed_progress_updates_while_waiting','native_event_loop_remains_responsive']
                window.cancel_button.click();state['stage']='first_stopping';return
            if state['stage']=='first_stopping':
                if window.busy:return
                require(window.thread is None and window.isVisible(),'Cancel reply closed the window or retained its worker')
                require(window.session.result==state['result'],'Cancel reply replaced the previous numerical result')
                require(not window.cancel_button.isVisible(),'Cancel control remained visible after the request')
                require(any('discussion was cancelled' in message['text'] for message in window.messages),'Cancellation was not explained')
                state['checks'].append('cancel_reply_returns_to_ready_without_closing')
                state['stage']='second_wait'
                window.send('Please discuss another conversational question about my recorded outcomes.')
                return
            if state['stage']=='second_wait':
                require(window.busy,'The second controlled request ended before close')
                if not window.cancel_button.isVisible():return
                window._after_work=lambda:state.update(followup_ran=True)
                require(not window.close(),'A running model worker was destroyed by close')
                require(window._close_requested,'Close request was not remembered')
                require(state['models'][-1].cancelled,'Closing did not cancel the active discussion')
                state['checks'].append('close_requests_model_cancellation')
                state['stage']='closing';return
            if state['stage']=='closing':
                if window.busy or window.isVisible():return
                finish()
        except Exception as error:
            state['error']=str(error) or type(error).__name__
            finish(state['error'])

    try:
        original=output/'synthetic-conversation.csv'
        original.write_text('Subject,Outcome\nA,1.5\nB,2.0\nC,3.25\n')
        state.update(original=original,source_hash=sha256(original))
        window.session.import_file(original)
        window.session.command('describe this data')
        require(window.session.result,'The synthetic previous descriptive result is missing')
        state['result']=deepcopy(window.session.result)
        window.refresh_workspace()
        llm.OllamaPlanner=ControlledPlanner
        window.config={**window.config,'enabled':True,'model':'synthetic-controlled-model'}
        window.update_mode()
        state['stage']='first_wait'
        timer.timeout.connect(tick);timer.start(10)
        window.send('Please talk through what this dataset might tell us before choosing an analysis.')
    except Exception as error:
        state['error']=str(error) or type(error).__name__
        finish(state['error'])
