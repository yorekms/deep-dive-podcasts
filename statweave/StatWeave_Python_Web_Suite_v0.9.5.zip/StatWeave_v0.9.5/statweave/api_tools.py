"""Closed API tools: inspect saved evidence and stage proposals, never execute.

The provider only receives this toolbox, not a Session or a general interpreter.
All previews are prepared on copies; the application commits a later agreement.
"""
from __future__ import annotations

from copy import deepcopy
import hashlib
import json
import math
import re


class ApiToolValidationError(ValueError):
    """A closed application tool rejected a scientific or schema requirement."""


def digest(value):
    from .session import canonical
    return hashlib.sha256(canonical(value).encode()).hexdigest()


_POSIX_ROOTS = r'(?:home|Users|tmp|var|etc|opt|mnt|srv|root|private|Volumes|media|run|proc|dev|usr|workspace)'
_QUOTED_PATH_RE = re.compile(
    r'(["\x27])(?:[A-Za-z]:[\\/]|/' + _POSIX_ROOTS + r'/)[^"\x27\r\n]{1,500}\1'
)
_WIN_PATH_RE = re.compile(r'(?<![A-Za-z0-9_])[A-Za-z]:[\\/][^\s"<>]*')
_POSIX_PATH_RE = re.compile(
    r'(?<![A-Za-z0-9_:+\-)\]/])(?:/' + _POSIX_ROOTS + r'(?:/[^\s"<>]+)*\b|/(?:[A-Za-z0-9_.-]+/)+[^\s"<>]+)'
)


def safe_text(value, limit=8000):
    """Redact accidental credentials and full paths without mangling scientific units."""
    value = str(value)
    value = re.sub(r'\bsk-[A-Za-z0-9_-]{8,}', '[credential omitted]', value)
    value = re.sub(r'(?i)\b(?:authorization\s*:\s*bearer|api[_ -]?key\s*[:=])\s*\S+', '[credential omitted]', value)
    value = _QUOTED_PATH_RE.sub('[filesystem path omitted]', value)
    value = _WIN_PATH_RE.sub('[filesystem path omitted]', value)
    value = _POSIX_PATH_RE.sub('[filesystem path omitted]', value)
    return value[:limit]


def safe_value(value):
    if isinstance(value, str):
        return safe_text(value)
    if isinstance(value, dict):
        return {safe_text(k, 1024): safe_value(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [safe_value(v) for v in value]
    if value is None or type(value) in (int, bool):
        return value
    if type(value) is float:
        return value if math.isfinite(value) else None
    return safe_text(value)


def state_digest(session):
    """Dialogue and proposals are deliberately outside the scientific fingerprint."""
    context = deepcopy(session.context)
    for name in ('api_dialogue', 'api_proposal', 'study_dialogue', 'study_clarification'):
        context.pop(name, None)
    execution = context.get('study_execution', {})
    for name in ('conversation_proposal', 'candidate_recipe', 'approved_digest', 'approved_state_sha256'):
        execution.pop(name, None)
    return digest({'source': getattr(session.dataset, 'source_hash', None),
                   'sheet': getattr(session.dataset, 'sheet', None), 'context': context,
                   'plan': session.plan, 'result': session.result, 'style': session.style,
                   'pending_plan': session.pending_plan})


def _object(properties):
    return {'type': 'object', 'additionalProperties': False,
            'properties': properties, 'required': list(properties)}


def _optional(schema):
    return {'anyOf': [schema, {'type': 'null'}]}


def _style_schema():
    from .llm import _schema
    return _object({key: _optional(value) for key, value in _schema()['properties']['style']['properties'].items()})


def _strip_null(value):
    if isinstance(value, dict):
        return {key: _strip_null(item) for key, item in value.items() if item is not None or key == 'value'}
    if isinstance(value, list):
        return [_strip_null(item) for item in value]
    return value


def _validate(value, schema):
    """Validate the supplied tool schema locally as well as at the provider."""
    if 'anyOf' in schema:
        for choice in schema['anyOf']:
            try:
                _validate(value, choice)
                return
            except ValueError:
                pass
        raise ValueError('A tool parameter has an unsupported value or type.')
    kind = schema.get('type')
    valid = {'object': isinstance(value, dict), 'array': isinstance(value, list),
             'string': isinstance(value, str), 'boolean': type(value) is bool,
             'integer': type(value) is int, 'number': type(value) in (int, float) and math.isfinite(value),
             'null': value is None}
    if not valid.get(kind, False):
        raise ValueError('A tool parameter has an unsupported type.')
    if 'enum' in schema and value not in schema['enum']:
        raise ValueError('That method, column or option is not available.')
    if kind == 'object':
        if set(value) - set(schema['properties']):
            raise ValueError('Unsupported tool fields; no action was staged.')
        # Nullable fields may be omitted by small or mocked providers. OpenAI's
        # strict request schema still declares all fields required.
        for name, child in schema['properties'].items():
            if name not in value:
                if not any(item.get('type') == 'null' for item in child.get('anyOf', [])):
                    raise ValueError('A required tool field is missing: ' + name)
            else:
                _validate(value[name], child)
    if kind == 'array':
        if len(value) > schema.get('maxItems', 2048):
            raise ValueError('Too many tool values.')
        if len(value) < schema.get('minItems', 0):
            raise ValueError('Too few tool values.')
        for item in value:
            _validate(item, schema['items'])
    if kind == 'string' and (len(value) > schema.get('maxLength', 4096) or '\x00' in value):
        raise ValueError('A tool label is too long or invalid.')
    if kind in ('number', 'integer') and (value < schema.get('minimum', -math.inf) or value > schema.get('maximum', math.inf)):
        raise ValueError('A tool number is outside the supported range.')


def _table_column_schema(df):
    import pandas as pd
    from .engine import MISSING_TOKENS
    include_stats = len(df.columns) <= 120
    columns = []
    unit_candidates = []
    n_rows = len(df)
    unit_re = re.compile(r'\b(?:animal|mouse|subject|donor|patient|cell|slice|neuron|unit|id|recording|file)\b|(?:_id|id)$', re.I)
    for col_name in df.columns:
        series = df[col_name]
        entry = {'name': str(col_name), 'dtype': str(series.dtype)}
        if include_stats:
            if pd.api.types.is_numeric_dtype(series):
                valid_mask = series.notna()
                missing_count = int((~valid_mask).sum())
                distinct_count = int(series[valid_mask].nunique(dropna=True))
                numeric_compatible = True
            else:
                text = series.astype(str).str.strip()
                missing_mask = series.isna() | (text == '') | text.str.casefold().isin(MISSING_TOKENS)
                missing_count = int(missing_mask.sum())
                non_missing = series[~missing_mask]
                distinct_count = int(non_missing.astype(str).str.strip().nunique(dropna=True))
                if len(non_missing) == 0:
                    numeric_compatible = False
                else:
                    parsed = pd.to_numeric(non_missing.astype(str).str.replace(',', '', regex=False), errors='coerce')
                    numeric_compatible = bool(parsed.notna().sum() >= max(1, math.ceil(0.5 * len(non_missing))))
            entry.update(missing_count=missing_count, distinct_count=distinct_count, numeric_compatible=numeric_compatible)
            if 0 < distinct_count < n_rows and unit_re.search(str(col_name)):
                unit_candidates.append(str(col_name))
        columns.append(entry)
    return columns, unit_candidates


def inspect_data(session, dataset_override=None):
    active_ds = dataset_override if dataset_override is not None else session.dataset
    if not active_ds:
        return {
            'input_type': 'none',
            'draft_first_mode': bool(getattr(session, 'auto_execute_proposals', False)),
            'instruction': (
                'No spreadsheet is open yet. If the user supplied raw numbers in their message, '
                'call build_working_sheet with op="construct" and constructed_columns to build a working sheet immediately, '
                'then call propose_analysis in this same turn.'
            ),
        }
    if getattr(active_ds, 'kind', None) == 'study':
        manifest = active_ds.manifest()
        sources = manifest.get('sources', [])
        return safe_value({'input_type': 'study', 'source_count': len(sources),
            'sources': [{'source_id': s['source_id'], 'role': s.get('role'),
                         'sheets': [{'name': sh.get('name', sh.get('title')), 'headers': sh.get('headers', sh.get('columns', []))}
                                    for sh in s.get('sheets', []) if isinstance(sh, dict)]}
                        for s in sources[:100]],
            'issue_counts': {'total': len(manifest.get('issues', []))},
            'draft_first_mode': bool(getattr(session, 'auto_execute_proposals', False)),
            'scope': 'Schema only; no raw worksheet rows or original paths.'})
    if getattr(active_ds, 'kind', None) == 'large_table':
        from .llm import _safe_large_schema
        return safe_value({'input_type': 'large_table', **_safe_large_schema(active_ds)})
    if getattr(active_ds, 'kind', None) == 'recording':
        return {'input_type': 'recording', 'scope': 'API recording execution is not implemented; existing offline ABF commands remain available.'}
    ds = active_ds
    columns, unit_candidates = _table_column_schema(ds.df)
    from .working_sheets import detect_replicate_structure, detect_survival_structure
    rep_raw = detect_replicate_structure(ds.df, list(getattr(ds, 'row_numbers', [])))
    surv_raw = detect_survival_structure(ds.df) if not rep_raw.get('detected') else {'detected': False}
    rep_schema = {
        'detected': bool(rep_raw.get('detected')),
        'groups': rep_raw.get('groups', {}),
        'time_col': rep_raw.get('time_col'),
        'suggested_ref_group': rep_raw.get('suggested_ref_group'),
        'is_timecourse': bool(rep_raw.get('is_timecourse')),
    }
    info = {
        'input_type': 'table',
        'row_count': len(ds.df),
        'columns': columns,
        'sheets': [str(s) for s in getattr(ds, 'sheets', [])[:64]],
        'active_sheet': getattr(ds, 'sheet', None),
        'detected_format': 'clampflow_6tab' if getattr(ds, 'is_clampflow', False) else 'table',
        'detected_replicate_groups': rep_schema,
        'detected_survival_structure': surv_raw,
        'candidate_unit_columns': unit_candidates,
        'excluded_row_count': len(session.context.get('excluded_rows', [])),
        'design': session.context.get('design', 'unknown'),
        'draft_first_mode': bool(getattr(session, 'auto_execute_proposals', False)),
        'working_sheets_history': safe_value((session.context.get('working_sheets') or [])[-10:]),
        'scope': 'Column schema only; no raw observation cells.',
    }
    return safe_value(info)


def reviewed_design(session):
    if not session.is_study:
        return {'design': session.context.get('design', 'unknown'), 'instruction': 'Display any proposed independence or pairing assumption for human review before testing.'}
    from .llm import _safe_study_state
    options = session.context.get('study_execution', {}).get('options', {})
    state = _safe_study_state(session.context.get('study_state', {}))
    # Free-form legacy notes may contain pasted rows. They are not part of the
    # typed scientific design supplied to an API provider.
    state.pop('user_supplied_notes', None)
    state.pop('pending_goal_proposal', None)
    return safe_value({'reviewed_state': state,
        'execution_choices': {k: options[k] for k in ('method', 'outcome', 'experimental_unit', 'normalization',
            'normalization_order', 'inference', 'independent_subjects', 'fit_doses') if k in options},
        'reviewed_window_count': len(options.get('windows', [])),
        'source_identity_conflicts': [{'source_id': i.get('source_id'), 'type': i.get('type')}
            for i in session.dataset.manifest().get('issues', []) if i.get('type') in {'subject_conflict', 'session_conflict', 'identity_conflict'}],
        'instruction': 'Keep reviewed choices. Repeated trials are nested within subjects. Proposed changes need visible human agreement. Do not invent units, calibration, groups or independence.'})


def capabilities(session):
    from .figures import (
        FILL_STYLE_MODES, FRAME_STYLE_MODES, PALETTES,
        POINT_STYLE_MODES, PRESETS, THEME_BG_MODES,
    )
    from .planner import METHODS, PLOTS
    from .llm import STYLE_KEYS
    common = {
        'style_fields': sorted(STYLE_KEYS),
        'palettes': sorted(PALETTES),
        'presets': sorted(PRESETS),
        'fill_styles': sorted(FILL_STYLE_MODES),
        'point_styles': sorted(POINT_STYLE_MODES),
        'frame_styles': sorted(FRAME_STYLE_MODES),
        'theme_backgrounds': sorted(THEME_BG_MODES),
        'export_formats': ['pdf', 'svg', 'png'],
        'approval': 'Tools only stage proposals. Never claim execution before the application reports it.',
    }
    if session.is_study:
        from .study_execution import OUTCOMES
        common.update(methods=['report_measures', 'response_curve', 'co2_slopes', 'normalize'],
            measures={name: {'label': v['label'], 'unit': v['unit']} for name, v in OUTCOMES.items()},
            figures=['response and recovery curves with subject values and group SD', 'per-subject CO2 slope figure', 'all-measures overview'],
            inference=['none', 'welch_slopes'],
            unavailable=['mixed effects', 'repeated measures ANOVA', 'Bayesian models', 'pleth box/violin plots', 'automatic physiological volume calibration'],
            intake_scope='API execution currently uses already reviewed protocol windows. Source identity/group mappings can be proposed for review, but a fresh study without window assignments still requires the existing Study/Metadata and offline protocol-review controls. Explain that requirement; do not promise API-only fresh-protocol setup.',
            requirements='Reviewed source mapping, subject experimental unit, trial handling and protocol windows. Welch additionally needs distinct-subject independence and explicit fit doses.')
    elif session.is_large_table:
        from .large_table import METHOD_FIELDS
        common.update(methods=sorted(METHOD_FIELDS), figures=['histogram', 'scatter'],
                      unavailable=['inferential tests on disk-backed data', 'Bayesian models'],
                      requirements='Filters must quote values supplied by the human. Never prune records by significance.')
    else:
        common.update(methods=sorted(METHODS), figures=sorted(PLOTS), unavailable=['Bayesian models', 'mixed effects'],
                      requirements='Choose literal columns. Human must approve pairing/independence. No automatic outlier removal.')
    return common


def saved_results(session, measure=None):
    if not session.result:
        return {'completed': False, 'message': 'No completed numerical result is saved.'}
    result = session.result
    if session.is_study:
        from .study_conversation import statistics_status, _children
        from .study_bridge import result_is_current, computed_summary_lines
        children = _children(session)
        inventory = ([{'measure': m['outcome'], 'label': m.get('label'), 'unit': m.get('unit'), 'status': m['status'], 'reason': m.get('reason', '')}
                      for m in result.get('measures', [])] if result.get('report') else
                     [{'measure': c['plot_data']['endpoint']['column'], 'status': 'executed'} for c in children])
        selected = [c for c in children if c['plot_data']['endpoint']['column'] == measure]
        if measure is not None and not selected:
            raise ValueError('That measure has no completed result. Consult the complete inventory.')
        return safe_value({'completed': True, 'matches_current_choices': result_is_current(session),
            'status': statistics_status(session), 'measure_inventory': inventory,
            'measure_summaries': [{'endpoint': c['plot_data']['endpoint'],
                'verified_summary_statements': computed_summary_lines(c),
                'comparison': c.get('comparison', [])} for c in selected],
            'instruction': 'The inventory covers every measure, not just RR. Request individual measure summaries to discuss their recorded numbers.'})
    if session.is_large_table:
        from .large_reporting import model_aggregate_context
        return safe_value({'completed': True, 'computed_aggregates': model_aggregate_context(result)})
    # Never send fitted values, plotted points, individual pairs, omissions or
    # arbitrary table cells. Only known summary/test numeric fields are exposed.
    allowed = {'variable', 'group', 'groups', 'stratum', 'source', 'n', 'mean', 'sd', 'median', 'q1', 'q3', 'min', 'max',
               'ci_low', 'ci_high', 'statistic', 'df', 'ss', 'ms', 'p', 'p_value', 'p_unadjusted', 'p_holm',
               'method', 'test', 'r', 'rho', 'slope', 'intercept',
               'group_1', 'group_2', 'condition_1', 'condition_2', 'pairs', 't', 'u', 'f', 'h',
               'mean_difference', 'cohens_d_pooled', 'cohens_dz', 'effect_size', 'effect_type',
               'eta_squared', 'partial_eta_squared',
               'cramers_v', 'coefficient', 'term', 'estimate',
               'standard_error', 'r_squared', 'adjusted_r_squared', 'n_observations',
               'events', 'censored', 'expected_events', 'median_survival', 'restricted_mean_survival',
               'chi_squared', 'hr_comparison', 'hazard_ratio', 'hr_ci_low', 'hr_ci_high', 'cox_wald_p'}
    summary_titles = {'Descriptive statistics', 'Descriptive statistics by stratum', 'Group summaries',
                      'Welch t-test', 'Mann–Whitney U', 'One-way ANOVA', 'Kruskal–Wallis',
                      'Paired condition summaries', 'Paired t-test',
                      'Variable summaries', 'OLS coefficients', 'OLS model fit', 'Correlation',
                      'Chi-square independence test', 'Batch group summaries', 'Batch comparisons',
                      'Timepoint group summaries', 'Timepoint comparisons',
                      'Two-way ANOVA', 'Simple-effect comparisons by stratum',
                      'Kaplan–Meier group summaries', 'Log-rank test'}
    tables = []
    for table in result.get('tables', []):
        title = table.get('title', '')
        if title in summary_titles:
            rows = [{key: value for key, value in row.items() if key in allowed}
                    for row in table.get('rows', [])[:100] if isinstance(row, dict)]
            tables.append({'title': title, 'rows': rows})
    out = {'completed': True, 'method': result.get('method'), 'summary': result.get('summary', '')[:2000],
           'summary_tables': tables, 'raw_rows_supplied': False}
    ua = result.get('unit_accounting')
    if isinstance(ua, dict):
        out['unit_accounting'] = {k: ua[k] for k in ('unit_column', 'pool_stat', 'n_raw_observations', 'n_units') if k in ua}
    return safe_value(out)


def _study_preview(session, request):
    from .study_conversation import _preview
    from .study_planner import validate_proposed_action
    from .study_bridge import _execution
    shadow = type('Preview', (), {})()
    shadow.dataset, shadow.context = session.dataset, deepcopy(session.context)
    scientific = {key: value for key, value in request.items() if key not in {'style', 'experimental_unit', 'independent_subjects'}}
    validate_proposed_action(scientific)
    options = _execution(shadow)['options']
    for field in ('experimental_unit', 'independent_subjects'):
        if field in request:
            options[field] = request[field]
    recipe, options, state, message = _preview(shadow, scientific)
    declarations = []
    if 'experimental_unit' in request:
        declarations.append('Experimental unit to confirm: ' + request['experimental_unit'] + '.')
    if 'independent_subjects' in request:
        declarations.append('Distinct-subject independence to confirm: ' + str(request['independent_subjects']) + '. This does not make repeated trials independent.')
    return {'recipe': recipe, 'options': options, 'state': state}, '\n'.join(declarations + [message])


def prepare_proposal(session, kind, request, instruction='', dataset_override=None):
    """Pure preview builder. Its exact validated payload is application-owned."""
    from .llm import _validate_style, validate_plan, validate_large_model_plan
    active_ds = dataset_override if dataset_override is not None else session.dataset
    request = _strip_null(deepcopy(request))
    style = request.pop('style', {})
    if style:
        _validate_style(style)
    payload = {'kind': kind, 'request': request, 'style': style}
    if kind == 'analysis':
        if session.is_study:
            bound, message = _study_preview(session, request)
            payload.update(bound)
        elif session.is_large_table:
            request.update(action='large_analyze', message='Proposed bounded query.')
            plan = validate_large_model_plan(request, session.dataset, session.plan, instruction=instruction)
            plan.pop('message', None)
            payload['plan'] = plan
            message = 'Proposed local disk-backed query:\n' + json.dumps(plan, indent=2, ensure_ascii=False)
        elif active_ds and not session.is_recording:
            if 'excluded_rows' not in request and session.context.get('excluded_rows'):
                request['excluded_rows'] = deepcopy(session.context['excluded_rows'])
            # Auto-normalize wide two-column (x, y) vs columns=[col1, col2]
            m_req = request.get('method')
            if m_req in {'ttest', 'mannwhitney', 'anova', 'kruskal'} and not request.get('group') and not request.get('columns') and request.get('x') and request.get('y'):
                request['columns'] = [request.pop('x'), request.pop('y')]
            elif m_req == 'paired_t' and not request.get('x') and not request.get('y') and isinstance(request.get('columns'), list) and len(request['columns']) == 2:
                request['x'], request['y'] = request['columns'][0], request['columns'][1]
                request.pop('columns', None)
            request.update(action='analyze', message='Proposed local analysis.')
            plan = validate_plan(request, active_ds)
            if plan.get('action') != 'analyze':
                raise ValueError('The table proposal is not an executable analysis.')
            plan.pop('message', None)
            method = plan['method']
            if method != 'describe' and plan.get('design') not in {'independent', 'paired'}:
                raise ValueError('Discuss whether the observations are independent or paired, then display that choice in the analysis proposal.')
            if method == 'paired_t' and not (plan.get('x') and plan.get('y') or plan.get('y') and plan.get('group') and plan.get('subject')):
                raise ValueError('Choose the paired columns or an explicit subject identifier.')
            # Pre-flight dry-run on a copy so missing group/columns or unpooled pseudoreplicates
            # return an immediate actionable tool error to the LLM instead of failing on approval.
            from .engine import analyze
            analyze(active_ds, deepcopy(plan))
            payload['plan'] = plan
            message = 'Proposed local analysis:\n' + json.dumps(plan, indent=2, ensure_ascii=False) + '\nPairing/independence is a scientific assumption for you to confirm. Missing/nonfinite values retain recorded row accounting; no automatic outlier removal.'
        else:
            raise ValueError('Open a table or build a working sheet from raw numbers before proposing this analysis.')
    elif kind == 'figure':
        if not session.result:
            raise ValueError('There is no completed figure to restyle. Include appearance choices in an analysis proposal first.')
        plot = request.get('plot')
        if session.is_study and plot:
            raise ValueError('This pleth adapter supports its recorded response/slope/overview figures; selecting box, dot or violin plots is not implemented.')
        if session.is_large_table and plot:
            raise ValueError('Choose histogram/scatter in a new query proposal; this tool only changes figure appearance.')
        if not style and not plot:
            raise ValueError('Choose an implemented figure setting.')
        message = 'Apply these appearance settings to the saved numerical result: ' + json.dumps({**style, **request}, ensure_ascii=False) + '.'
    elif kind == 'view':
        if not session.is_study or not session.result:
            raise ValueError('Saved-measure views are available for a completed pleth report.')
        measure = request.get('measure')
        if measure is not None:
            saved_results(session, measure)
        message = 'Show the saved ' + (measure or 'all-measures overview') + ' figure. No new statistics will be calculated.'
    elif kind == 'export':
        if not session.result:
            raise ValueError('Complete an agreed analysis before exporting.')
        source_note = ' including an immutable copy of the source file' if request.get('include_source') else ''
        message = f'Export the recorded figures, tables and processing record{source_note}. The application will choose the destination; raw files are preserved.'
    elif kind == 'sheet':
        if not active_ds or session.is_study or session.is_large_table or session.is_recording:
            raise ValueError('Worksheet selection is only available for multi-sheet workbooks.')
        sheet = request.get('sheet')
        sheets = list(getattr(active_ds, 'sheets', []))
        if not sheet or sheet not in sheets:
            raise ValueError('Available sheets: ' + ', '.join(sheets))
        message = f'Switch active worksheet to "{sheet}". Switching worksheets clears the current sheet display while preserving the workbook and audit history.'
    elif kind == 'design':
        if not session.is_study:
            raise ValueError('Source-mapping review is available for multi-file studies.')
        from .study_planner import apply_study_command
        state = deepcopy(session.context['study_state'])
        seen_sources = set()
        requested_groups = {}
        for row in request['mappings']:
            if row['source_id'] in seen_sources:
                raise ValueError('Each source can appear only once in a mapping proposal.')
            seen_sources.add(row['source_id'])
            if row['subject'] in requested_groups and requested_groups[row['subject']] != row['group']:
                raise ValueError('The same subject has conflicting proposed groups. Resolve one group per subject before reviewing the mapping.')
            requested_groups[row['subject']] = row['group']
            for field in ('subject', 'session'):
                state, _ = apply_study_command(session.dataset, state, {'action': 'study_resolve_' + field, 'source_id': row['source_id'], 'value': row[field]})
            state, _ = apply_study_command(session.dataset, state, {'action': 'study_group', 'subjects': [row['subject']], 'group': row['group']})
        if request.get('goal'):
            state, _ = apply_study_command(session.dataset, state, {'action': 'study_goal', 'goal': request['goal']})
        if request.get('pooling'):
            state, _ = apply_study_command(session.dataset, state, {'action': 'study_pooling', 'pooling': request['pooling']})
        state, _ = apply_study_command(session.dataset, state, {'action': 'study_confirm_mapping'})
        payload['state'] = state
        # Group membership belongs to the subject, so a partial change can
        # affect other sources from that subject. Show the entire final roster
        # actually being committed rather than echoing the requested rows.
        roster = [{'source_id': source['source_id'],
                   'subject': state['subject_resolutions'][source['source_id']],
                   'session': state['session_resolutions'][source['source_id']],
                   'group': state['groups'][state['subject_resolutions'][source['source_id']]]}
                  for source in session.dataset.manifest()['sources'] if source.get('role') != 'reference_analysis']
        message = 'Review the proposed source → subject / session / group assignments:\n' + '\n'.join(f"{r['source_id']} → {r['subject']} / {r['session']} / {r['group']}" for r in roster) + '\nStudy goal: ' + str(state.get('goal') or 'not declared') + '\nTrial handling: ' + state['pooling'] + '.\nThese assignments are proposed; agreeing confirms your review. Original metadata and conflicts remain recorded. No statistics will run.'
    else:
        raise ValueError('Unsupported proposal type.')
    if style:
        message += '\nFigure appearance in this same proposal: ' + json.dumps(style, ensure_ascii=False) + '.'
    auto_exec = bool(getattr(session, 'auto_execute_proposals', False)) and kind in {'analysis', 'figure', 'sheet', 'view'} and not session.is_study
    if auto_exec:
        message += (
            '\n\nDraft-first execution active: the application will execute this validated plan and render the figure automatically '
            'as soon as your reply completes. State what is being plotted/tested and any pairing/independence assumption directly; '
            'DO NOT ask the user to reply "confirm" or "proceed" to run it.'
        )
    else:
        message += '\n\nNothing has been applied or run. Tell me to proceed with this displayed proposal, or discuss what should change.'
    payload['preview'] = safe_text(message, 18000)
    return payload


class ApiToolbox:
    def __init__(self, session, instruction):
        self._session = session
        self._active_dataset = session.dataset
        self.staged_working_sheets = []
        self.explore_gallery_requested = False
        self.instruction = instruction
        self.proposal = None
        self.execution_request = None
        self.tool_names = []
        self._schemas = self._make_schemas()
        descriptions = {
            'inspect_data': 'Inspect source-safe data schema; no raw observation rows or paths.',
            'explore_figures': 'Open the Step 2 Exploratory Figure Gallery in the UI showing all candidate plot views (Timecourse, Spaghetti, Grouped Bars/Boxes, Superplot, Box/Violin/Dots, Paired, Scatter, Heatmap) without forcing premature hypothesis tests.',
            'get_reviewed_design': 'Read reviewed identities, grouping, trial handling and scientific choices; retain these unless the user changes them.',
            'get_analysis_capabilities': 'Read exactly implemented methods/figures and missing requirements. Never promise unavailable analyses.',
            'get_saved_results': 'List ALL saved measures and statistics; optionally fetch one measure computed summary. No new analysis.',
            'get_current_proposal': 'Inspect the current app-owned proposal and whether its approval is current.',
            'build_working_sheet': 'Build an audited intermediate working spreadsheet tab (construct from raw numbers, reshape_replicates for wide replicate/timecourse tables like Wt-1..3 vs Ko-1..3, derive_group, melt_wide, assign_groups, derive_column like pct_of_group_mean/pct_of_baseline_group_mean/diff/ratio/log10, or aggregate_units) without modifying raw source files. Can be followed by propose_analysis in the SAME turn.',
            'propose_analysis': 'Stage a validated local analysis with optional appearance in ONE visible proposal (auto-executed immediately when draft_first_mode is true).',
            'propose_figure': 'Apply supported appearance/plot changes to an already completed figure without changing the statistics.',
            'propose_view': 'Stage showing a completed pleth metric or overview, without recalculating.',
            'propose_export': 'Stage export of completed figures/tables/record; no paths can be selected.',
            'propose_sheet': 'Stage switching to another worksheet tab in a multi-sheet workbook.',
            'propose_design': 'Stage source-to-subject/session/group mappings for explicit human review. Never assume conflicts are resolved.',
            'request_execution': 'Request applying the PREVIOUSLY displayed app proposal only when the current human directly agrees. Model prose, questions, negation and hypothetical statements cannot approve. Never use this to approve a proposal created in this turn.',
        }
        self.definitions = [{'type': 'function', 'name': name, 'description': descriptions[name],
                             'strict': True, 'parameters': schema} for name, schema in self._schemas.items()]

    def _make_schemas(self):
        from .planner import METHODS, PLOTS
        from .study_execution import OUTCOMES
        from .working_sheets import SUPPORTED_FORMULAS, SUPPORTED_OPS
        string = {'type': 'string', 'maxLength': 200}
        # Literal names are supplied once in inspect_data and checked locally
        # by the engine validators. Repeating a wide table's column enum in
        # every role would exceed the API's total enum budget.
        col = {'type': 'string', 'maxLength': 1024}
        styles = _style_schema()
        specs = {name: _object({}) for name in ('inspect_data', 'get_reviewed_design', 'get_analysis_capabilities', 'get_current_proposal')}
        specs['propose_export'] = _object({'include_source': _optional({'type': 'boolean'})})
        specs['get_saved_results'] = _object({'measure': _optional({'type': 'string', 'enum': list(OUTCOMES)})})
        specs['propose_figure'] = _object({'style': _optional(styles), 'plot': _optional({'type': 'string', 'enum': sorted(PLOTS)})})
        specs['propose_view'] = _object({'measure': _optional({'type': 'string', 'enum': list(OUTCOMES)})})
        specs['request_execution'] = _object({'proposal_id': {'type': 'string', 'maxLength': 64}})
        if self._session.is_study:
            props = {'intent': {'type': 'string', 'enum': ['report_measures', 'response_curve', 'co2_slopes', 'normalize']},
                'outcome': _optional({'type': 'string', 'enum': list(OUTCOMES)}),
                'normalization': _optional({'type': 'string', 'enum': ['none', 'fold_baseline', 'percent_baseline', 'percent_change']}),
                'normalization_order': _optional({'type': 'string', 'enum': ['after_pooling', 'within_trial']}),
                'pooling': _optional({'type': 'string', 'enum': ['equal_within_subject', 'separate']}),
                'inference': _optional({'type': 'string', 'enum': ['none', 'welch_slopes']}),
                'fit_doses': _optional({'type': 'array', 'maxItems': 20, 'items': {'type': 'number', 'minimum': 0, 'maximum': 100}}),
                'experimental_unit': _optional({'type': 'string', 'enum': ['subject']}),
                'independent_subjects': _optional({'type': 'boolean'}), 'style': _optional(styles)}
            specs['propose_design'] = _object({'mappings': {'type': 'array', 'maxItems': 100, 'items': _object({k: string for k in ('source_id', 'subject', 'session', 'group')})},
                'goal': _optional({'type': 'string', 'maxLength': 2000}), 'pooling': _optional({'type': 'string', 'enum': ['separate', 'equal_within_subject']})})
        elif self._session.is_large_table:
            from .large_table import METHOD_FIELDS
            scalar = {'anyOf': [{'type': 'string', 'maxLength': 4096}, {'type': 'number'}, {'type': 'boolean'}, {'type': 'null'}]}
            props = {'method': {'type': 'string', 'enum': sorted(METHOD_FIELDS)},
                **{k: _optional(col) for k in ('x', 'y', 'groupby')},
                'columns': _optional({'type': 'array', 'items': col, 'maxItems': 2048}),
                **{k: _optional({'type': 'integer', 'minimum': 0, 'maximum': 5000}) for k in ('bins', 'limit', 'offset')},
                'predicates': _optional({'type': 'array', 'maxItems': 32, 'items': _object({'column': col,
                    'op': {'type': 'string', 'enum': ['eq', 'ieq', 'ne', 'contains', 'in', 'lt', 'le', 'gt', 'ge']},
                    'value': {'anyOf': [*scalar['anyOf'], {'type': 'array', 'items': scalar, 'maxItems': 200}]}})}), 'style': _optional(styles)}
        else:
            if not self._session.is_recording:
                specs['explore_figures'] = _object({})
                constructed_col = _object({
                    'name': {'type': 'string', 'maxLength': 120},
                    'values': {'type': 'array', 'maxItems': 2000, 'items': {'type': 'string', 'maxLength': 200}},
                })
                group_range = _object({
                    'label': {'type': 'string', 'maxLength': 120},
                    'start_row': {'type': 'integer', 'minimum': 1, 'maximum': 1000000},
                    'end_row': {'type': 'integer', 'minimum': 1, 'maximum': 1000000},
                })
                rename_pair = _object({
                    'old': {'type': 'string', 'maxLength': 120},
                    'new': {'type': 'string', 'maxLength': 120},
                })
                specs['build_working_sheet'] = _object({
                    'op': {'type': 'string', 'enum': sorted(SUPPORTED_OPS)},
                    'sheet_name': _optional({'type': 'string', 'maxLength': 31}),
                    'constructed_columns': _optional({'type': 'array', 'maxItems': 64, 'items': constructed_col}),
                    'id_cols': _optional({'type': 'array', 'maxItems': 64, 'items': col}),
                    'value_cols': _optional({'type': 'array', 'maxItems': 128, 'items': col}),
                    'var_name': _optional({'type': 'string', 'maxLength': 120}),
                    'value_name': _optional({'type': 'string', 'maxLength': 120}),
                    'new_column': _optional({'type': 'string', 'maxLength': 120}),
                    'formula': _optional({'type': 'string', 'enum': sorted(SUPPORTED_FORMULAS)}),
                    'col_a': _optional(col),
                    'col_b': _optional(col),
                    'group_col': _optional(col),
                    'ref_group': _optional({'type': 'string', 'maxLength': 120}),
                    'scale_factor': _optional({'type': 'number'}),
                    'offset': _optional({'type': 'number'}),
                    'group_ranges': _optional({'type': 'array', 'maxItems': 64, 'items': group_range}),
                    'group_cols': _optional({'type': 'array', 'maxItems': 16, 'items': col}),
                    'agg_stat': _optional({'type': 'string', 'enum': ['mean', 'median', 'count']}),
                    'rename_columns': _optional({'type': 'array', 'maxItems': 64, 'items': rename_pair}),
                })
            if self._session.dataset and not self._session.is_recording and len(getattr(self._session.dataset, 'sheets', [])) > 1:
                specs['propose_sheet'] = _object({'sheet': string})
            excluded_item = _object({
                'row': {'type': 'integer', 'minimum': 2, 'maximum': 10000000},
                'reason': {'type': 'string', 'maxLength': 500},
            })
            props = {'method': {'type': 'string', 'enum': sorted(METHODS)},
                **{k: _optional(col) for k in ('x', 'y', 'group', 'subject', 'pool_by', 'count')},
                'pool_stat': _optional({'type': 'string', 'enum': ['mean', 'median']}),
                'test': _optional({'type': 'string', 'enum': ['ttest', 'mannwhitney', 'anova', 'kruskal']}),
                'nonparametric': _optional({'type': 'boolean'}),
                'excluded_rows': _optional({'type': 'array', 'items': excluded_item, 'maxItems': 200}),
                'columns': _optional({'type': 'array', 'items': col, 'maxItems': 2048}),
                'design': _optional({'type': 'string', 'enum': ['unknown', 'independent', 'paired']}),
                'plot': _optional({'type': 'string', 'enum': sorted(PLOTS)}), 'style': _optional(styles)}
        specs['propose_analysis'] = _object(props)
        return specs

    def call(self, name, arguments):
        try:
            return self._call(name, arguments)
        except ValueError as error:
            # Only errors from this closed application dispatch are eligible
            # for an actionable provider-facing validation explanation.
            raise ApiToolValidationError(safe_text(str(error), 1000)) from None

    def safe_error(self, error):
        return safe_text(str(error), 1000) if isinstance(error, ApiToolValidationError) else None

    def _call(self, name, arguments):
        if name not in self._schemas:
            raise ValueError('Unknown application tool; no action was performed.')
        if name == 'build_working_sheet' and isinstance(arguments, dict) and isinstance(arguments.get('constructed_columns'), list):
            arguments = deepcopy(arguments)
            for c_item in arguments['constructed_columns']:
                if isinstance(c_item, dict) and isinstance(c_item.get('values'), list):
                    c_item['values'] = ['' if v is None else str(v) for v in c_item['values']]
        _validate(arguments, self._schemas[name])
        self.tool_names.append(name)
        values = _strip_null(arguments)
        session = self._session
        if name == 'inspect_data':
            return inspect_data(session, dataset_override=self._active_dataset)
        if name == 'explore_figures':
            self.explore_gallery_requested = True
            if not self._active_dataset or not hasattr(self._active_dataset, 'df'):
                return {'opened_gallery': False, 'message': 'No spreadsheet is open yet.'}
            from .explore import build_exploratory_gallery
            from .r_learning_set import match_learning_set_exemplars
            from types import SimpleNamespace
            shadow_sess = SimpleNamespace(dataset=self._active_dataset, style=getattr(session, 'style', {}))
            gallery = build_exploratory_gallery(shadow_sess)
            ov = gallery.get('overview') or {}
            card_summaries = [
                {
                    'id': c['id'],
                    'badge': c['badge'],
                    'title': c['title'],
                    'subtitle': c['subtitle'],
                    'step3_stat_options': [a['label'] for a in (c.get('recommended_analyses') or [])],
                }
                for c in gallery.get('cards', [])
            ]
            return safe_value({
                'opened_gallery': True,
                'detected_layout': ov.get('detected_layout'),
                'card_count': len(card_summaries),
                'cards': card_summaries,
                'r_learning_set_exemplars': match_learning_set_exemplars(ov),
                'scope': 'Column/plot schema only; no raw observation cells.',
                'instruction': (
                    'The Step 2 Exploratory Figure Gallery is now open in the UI with all candidate SVG figures rendered. '
                    'Summarize the spreadsheet structure and the rendered figure views clearly, and invite the user to click '
                    'any card to inspect/style it or pick a Step 3 statistical test & stars.'
                ),
            })
        if name == 'get_reviewed_design':
            return reviewed_design(session)
        if name == 'get_analysis_capabilities':
            return capabilities(session)
        if name == 'get_saved_results':
            return saved_results(session, values.get('measure'))
        if name == 'get_current_proposal':
            pending = session.context.get('api_proposal')
            return safe_value({'proposal_id': pending.get('proposal_id'), 'preview': pending.get('preview'),
                'kind': pending.get('kind'), 'request': pending.get('request'), 'style': pending.get('style'),
                'current': pending.get('base_digest') == state_digest(session),
                'displayed_this_opening': pending.get('token') == getattr(session, '_api_conversation_token', None)} if pending else {'proposal_id': None})
        if name == 'build_working_sheet':
            if len(self.staged_working_sheets) >= 4:
                raise ValueError('At most 4 intermediate working sheets can be built in a single turn.')
            from .data import Dataset
            from .working_sheets import apply_working_sheet_op
            existing_names = list(getattr(self._active_dataset, 'sheets', []) if self._active_dataset else [])
            if not existing_names and self._active_dataset is not None:
                existing_names = ['0_Raw_Source']
            sheet_name, new_df, summary = apply_working_sheet_op(self._active_dataset, values, existing_sheets=existing_names)
            combined = list(dict.fromkeys(existing_names + [sheet_name]))
            src_path = getattr(self._active_dataset, 'source_path', '') if self._active_dataset else ''
            src_hash = getattr(self._active_dataset, 'source_hash', '') if self._active_dataset else ''
            self._active_dataset = Dataset(
                df=new_df,
                source_path=src_path,
                source_hash=src_hash,
                sheet=sheet_name,
                sheets=combined,
                header_row=0,
            )
            self.staged_working_sheets.append({
                'sheet_name': sheet_name,
                'df': new_df,
                'summary': summary,
                'spec': deepcopy(values),
            })
            # Clear any earlier proposal from before this intermediate sheet was created
            self.proposal = None
            return safe_value({
                'built': True,
                'active_sheet': sheet_name,
                'summary': summary,
                'schema': inspect_data(session, dataset_override=self._active_dataset),
                'next_step': 'You may now call build_working_sheet again for another step OR call propose_analysis in this SAME turn using the columns of this new working sheet.',
            })
        if name == 'request_execution':
            if self.proposal is not None:
                raise ValueError('A proposal cannot approve itself. The human must first see and agree to its preview.')
            pending = session.context.get('api_proposal')
            if not pending or values['proposal_id'] != pending.get('proposal_id'):
                raise ValueError('There is no matching displayed proposal to approve.')
            self.execution_request = {'proposal_id': values['proposal_id']}
            return {'requested': True, 'executed': False, 'instruction': 'Only the application can validate direct human assent and execute after the model returns.'}
        kind = {'propose_analysis': 'analysis', 'propose_figure': 'figure', 'propose_view': 'view',
                'propose_export': 'export', 'propose_sheet': 'sheet', 'propose_design': 'design'}[name]
        if self.execution_request is not None:
            raise ValueError('A turn cannot both revise and approve a proposal.')
        if self.proposal is not None:
            raise ValueError('Stage only one proposal per turn; include figure appearance inside propose_analysis when proposing an analysis.')
        self.proposal = prepare_proposal(session, kind, values, instruction=self.instruction, dataset_override=self._active_dataset)
        auto_exec = bool(getattr(session, 'auto_execute_proposals', False)) and kind in {'analysis', 'figure', 'sheet', 'view'} and not session.is_study
        if auto_exec:
            return {'staged': True, 'auto_execute_on_finish': True, 'preview': self.proposal['preview']}
        return {'staged': True, 'executed': False, 'preview': self.proposal['preview']}
