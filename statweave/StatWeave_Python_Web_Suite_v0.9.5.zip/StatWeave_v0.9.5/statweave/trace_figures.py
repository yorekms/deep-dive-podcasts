"""Read-only ABF trace views with bounded, extrema-preserving display envelopes.

The points produced here are display geometry, never an analytical resampling or
an input to a statistical test. No raw sample is modified or written back.
"""
from __future__ import annotations

from copy import deepcopy
from pathlib import Path
from weakref import WeakKeyDictionary
import math
import numpy as np
import matplotlib as mpl
from matplotlib.figure import Figure
from matplotlib.backends.backend_agg import FigureCanvasAgg
from matplotlib.ticker import MaxNLocator

from .figures import (FIGURE_LOCK, RC, PALETTES, _style, _safe_label,
                      _assert_not_clipped, _serialized_render)

MAX_DISPLAY_POINTS = 4000
MAX_CHANNELS = 4
MAX_SWEEPS = 12
_DISPLAY_CACHE = WeakKeyDictionary()


def _integer_selection(values, available, name, maximum):
    if not isinstance(values, (list, tuple)) or not values:
        raise ValueError(f'Select at least one {name}.')
    if len(values) > maximum:
        raise ValueError(f'This view supports at most {maximum} {name}s; select fewer for a readable figure.')
    if any(isinstance(v, bool) or not isinstance(v, (int, np.integer)) for v in values):
        raise ValueError(f'{name.capitalize()} indices must be integers.')
    if len(set(values)) != len(values):
        raise ValueError(f'A {name} was selected more than once.')
    valid = {int(item['index']) for item in available}
    if any(int(value) not in valid for value in values):
        raise ValueError(f'That {name} is unavailable. Conversation numbering starts at 1.')
    return [int(value) for value in values]


def _number(value, label):
    if isinstance(value, bool) or not isinstance(value, (int, float, np.integer, np.floating)) or not math.isfinite(float(value)):
        raise ValueError(f'{label} must be a finite number of seconds.')
    return float(value)


def _channel(recording, index):
    return next(c for c in recording.channels if int(c['index']) == index)


def _sweep(recording, index):
    return next(s for s in recording.sweeps if int(s['index']) == index)


def validate_trace_plan(recording, plan):
    """Normalize a trace request without reading the recording's sample arrays."""
    if not isinstance(plan, dict):
        raise ValueError('A trace view needs a structured selection.')
    normalized = deepcopy(plan)
    if normalized.get('method', 'trace') != 'trace':
        raise ValueError('Raw recording samples cannot be passed to a spreadsheet statistical test.')
    normalized.update(action='trace', method='trace')
    normalized['channels'] = _integer_selection(normalized.get('channels', [0]), recording.channels, 'channel', MAX_CHANNELS)
    normalized['sweeps'] = _integer_selection(normalized.get('sweeps', [0]), recording.sweeps, 'sweep', MAX_SWEEPS)
    start = _number(normalized.get('start_s', 0), 'Start time')
    if start < 0:
        raise ValueError('Start time cannot be negative.')
    durations = [float(_sweep(recording, i)['duration_s']) for i in normalized['sweeps']]
    if any(not math.isfinite(d) or d <= 0 for d in durations):
        raise ValueError('The selected sweep has no valid duration.')
    end = normalized.get('end_s') if 'end_s' in normalized else min(10.0, min(durations))
    end = None if end is None else _number(end, 'End time')
    if any(start >= d - max(1e-12, d*1e-12) for d in durations):
        raise ValueError('Start time is outside one or more selected sweeps.')
    if end is not None and (end <= start or any(end > d + max(1e-12, d*1e-12) for d in durations)):
        raise ValueError('End time must follow start time and lie within every selected sweep. Use full sweeps or choose a shorter interval.')
    normalized.update(start_s=start, end_s=end)
    reference = normalized.get('time_reference', 'sweep')
    if reference not in ('sweep', 'recording'):
        raise ValueError('Time reference must be sweep or recording.')
    normalized['time_reference'] = reference
    if 'style' in normalized:
        _style(normalized)
    return normalized


def _selection_rows(recording, plan):
    rows=[]
    for channel_index in plan['channels']:
        channel=_channel(recording,channel_index)
        rate=float(channel['sampling_rate_hz'])
        if not math.isfinite(rate) or rate <= 0:
            raise ValueError('The selected channel has no valid sampling rate.')
        for sweep_index in plan['sweeps']:
            sweep=_sweep(recording,sweep_index)
            end=plan['end_s'] if plan['end_s'] is not None else float(sweep['duration_s'])
            first=max(0, int(math.ceil(plan['start_s']*rate - 1e-9)))
            stop=min(int(sweep['sample_count']), int(math.ceil(end*rate - 1e-9)))
            if stop <= first:
                raise ValueError('The selected interval contains no recorded samples.')
            rows.append({'channel':channel_index+1,'channel_name':str(channel['name']),
                'unit':str(channel.get('unit') or 'unavailable'), 'sweep':sweep_index+1,
                'sampling_rate_hz':rate,'start_s':plan['start_s'],'end_s':end,
                'recording_sweep_start_s':float(sweep['start_s']),
                'source_sample_count':stop-first,'first_sample_index':first,'stop_sample_index':stop})
    return rows


def _key(plan):
    return (tuple(plan['channels']),tuple(plan['sweeps']),plan['start_s'],plan['end_s'],plan['time_reference'])


def trace_result(recording, plan):
    """Describe selected recording metadata; do not read or analyze trace values."""
    plan=validate_trace_plan(recording,plan)
    rows=_selection_rows(recording,plan)
    count=sum(row['source_sample_count'] for row in rows)
    full=any(plan['start_s'] != 0 or row['end_s'] < float(_sweep(recording,row['sweep']-1)['duration_s']) for row in rows)
    reference='within-sweep' if plan['time_reference']=='sweep' else 'recording-relative'
    summary=(f"Trace view: {len(plan['channels'])} channel(s), {len(plan['sweeps'])} sweep(s), "
             f"{count:,} selected channel-samples; {reference} display time. "
             'This is a waveform view, not an inferential statistical analysis.')
    warnings=list(getattr(recording,'warnings',[]))
    warnings += ['Channel-sample counts are not numbers of independent biological replicates.',
        'No filtering, baseline correction, event detection, command-waveform reconstruction, or inferential test is applied.']
    if full:
        warnings.append('A viewing interval was selected; the rest of the original recording remains preserved.')
    return {'method':'trace','plan':plan,'summary':summary,
        'tables':[{'title':'Trace selection (channel and sweep numbers start at 1)',
                   'columns':list(rows[0]),'rows':rows}],
        'warnings':list(dict.fromkeys(warnings)),
        'trace_accounting':{'selected_channel_samples':count,'selected_channels':len(plan['channels']),
            'selected_sweeps':len(plan['sweeps']),'time_reference':plan['time_reference'],
            'display_point_budget_per_trace':MAX_DISPLAY_POINTS,
            'original_recording_preserved':True,'inferential_analysis':False}}


def _chunks(recording,channel,sweep,start,end):
    previous=None
    for chunk in recording.iter_window_chunks(channel_index=channel,sweep_index=sweep,
            start_s=start,end_s=end,chunk_samples=65536):
        t=np.asarray(chunk['time_s'],dtype=float)
        y=np.asarray(chunk['values'],dtype=float)
        idx=np.asarray(chunk['sample_indices'])
        if t.ndim!=1 or y.ndim!=1 or idx.ndim!=1 or not(len(t)==len(y)==len(idx)):
            raise ValueError('The recording reader returned inconsistent trace arrays.')
        if not len(t):
            continue
        if not np.isfinite(t).all() or not np.isfinite(idx).all() or np.any(np.diff(t)<=0) or np.any(np.diff(idx)<=0):
            raise ValueError('Recording sample times or indices are invalid or out of order.')
        if previous and (t[0]<=previous[0] or idx[0]<=previous[1]):
            raise ValueError('Recording chunks overlap or are out of chronological order.')
        previous=(t[-1],idx[-1])
        yield t,y,idx


def _scan(recording,channel,sweep,start,end,rate):
    count=finite_count=runs=nonfinite_regions=discontinuities=0
    last_finite=False; last_idx=None; last_time=None; last_invalid=False
    for t,y,idx in _chunks(recording,channel,sweep,start,end):
        finite=np.isfinite(y)
        continuous=np.r_[True,np.diff(idx)==1] & np.r_[True,np.diff(t)<=1.5/rate]
        if last_idx is not None:
            continuous[0]=idx[0]==last_idx+1 and t[0]-last_time<=1.5/rate
        before_finite=np.r_[last_finite,finite[:-1]]
        runs+=int(np.count_nonzero(finite & (~before_finite | ~continuous)))
        discontinuities+=int(np.count_nonzero(~continuous))
        invalid=~finite
        nonfinite_regions+=int(np.count_nonzero(invalid & ~np.r_[last_invalid,invalid[:-1]]))
        count+=len(y);finite_count+=int(finite.sum())
        last_finite=bool(finite[-1]);last_invalid=bool(invalid[-1])
        last_idx,last_time=idx[-1],t[-1]
    if not count:
        raise ValueError('The selected interval contains no recorded samples.')
    if not finite_count:
        raise ValueError('The selected trace contains no finite amplitude samples; choose another channel or interval.')
    return {'source_sample_count':count,'finite_sample_count':finite_count,
        'nonfinite_sample_count':count-finite_count,'finite_runs':runs,
        'gap_regions':nonfinite_regions+discontinuities}


def _display_trace(recording,channel,sweep,start,end,max_points=MAX_DISPLAY_POINTS):
    """Return a bounded preview, retaining source extrema and line discontinuities.

    Two bounded-memory passes count finite runs and then collect extrema. The
    run count reserves space for endpoints and NaN separators before binning.
    Too many gaps fail visibly rather than dropping a gap or joining segments.
    """
    if not isinstance(max_points,int) or isinstance(max_points,bool) or max_points<8:
        raise ValueError('The display point budget must be an integer of at least 8.')
    ch=_channel(recording,channel);rate=float(ch['sampling_rate_hz'])
    summary=_scan(recording,channel,sweep,start,end,rate)
    count=summary['source_sample_count']
    if count <= max_points:
        ts=[];ys=[];previous=None
        for t,y,idx in _chunks(recording,channel,sweep,start,end):
            finite_values=np.where(np.isfinite(y),y,np.nan)
            cuts=np.flatnonzero((np.diff(idx)!=1)|(np.diff(t)>1.5/rate))+1
            for first,last in zip(np.r_[0,cuts],np.r_[cuts,len(t)]):
                if previous and (idx[first]!=previous[1]+1 or t[first]-previous[0]>1.5/rate):
                    ts.append(np.asarray([(previous[0]+t[first])/2]));ys.append(np.asarray([np.nan]))
                ts.append(t[first:last]);ys.append(finite_values[first:last])
                previous=(t[last-1],idx[last-1])
        times=np.concatenate(ts);values=np.concatenate(ys)
        if len(times)>max_points:
            raise ValueError('This interval has too many discontinuities for the bounded preview; choose a shorter interval.')
        return times,values,{**summary,'display_point_count':len(times),'bin_count':0,'reduced':False}
    run_count=summary['finite_runs']
    bins=min(count,max(0,(max_points-5*run_count+3)//2))
    if bins<1:
        raise ValueError('This interval has too many gaps for a faithful bounded preview; select a shorter interval.')
    meta=_selection_rows(recording,{'channels':[channel],'sweeps':[sweep],'start_s':start,'end_s':end,'time_reference':'sweep'})[0]
    first_index=meta['first_sample_index'];span=max(1,meta['stop_sample_index']-first_index)
    points=[];active_bin=None;minimum=maximum=None;last_finite=None
    def append(point):
        if not points or point[0]!=points[-1][0]:
            points.append(point)
    def flush_bin():
        nonlocal minimum,maximum,active_bin
        if minimum is not None:
            for point in sorted([minimum,maximum],key=lambda p:p[0]):append(point)
        minimum=maximum=None;active_bin=None
    def end_run(next_point=None):
        nonlocal last_finite
        flush_bin()
        if last_finite is not None:
            append(last_finite)
            if next_point is not None:
                append(((last_finite[0]+next_point[0])/2,(last_finite[1]+next_point[1])/2,np.nan))
        last_finite=None
    for t,y,idx in _chunks(recording,channel,sweep,start,end):
        finite=np.isfinite(y)
        transitions=np.diff(np.r_[False,finite,False].astype(np.int8))
        starts=np.flatnonzero(transitions==1);stops=np.flatnonzero(transitions==-1)
        for first,last in zip(starts,stops):
            extra=np.flatnonzero((np.diff(idx[first:last])!=1)|(np.diff(t[first:last])>1.5/rate))+first+1
            for begin,finish in zip(np.r_[first,extra],np.r_[extra,last]):
                first_point=(int(idx[begin]),float(t[begin]),float(y[begin]))
                if last_finite is not None and (first_point[0]!=last_finite[0]+1 or first_point[1]-last_finite[1]>1.5/rate):
                    end_run(first_point)
                if last_finite is None:append(first_point)
                bin_ids=np.minimum(bins-1,np.maximum(0,((idx[begin:finish]-first_index)*bins//span).astype(np.int64)))
                changes=np.flatnonzero(np.diff(bin_ids)!=0)+begin+1
                for a,b in zip(np.r_[begin,changes],np.r_[changes,finish]):
                    bin_id=int(bin_ids[a-begin])
                    if active_bin is not None and bin_id!=active_bin:flush_bin()
                    active_bin=bin_id
                    values=y[a:b]
                    i_min=a+int(np.argmin(values));i_max=a+int(np.argmax(values))
                    low=(int(idx[i_min]),float(t[i_min]),float(y[i_min]));high=(int(idx[i_max]),float(t[i_max]),float(y[i_max]))
                    if minimum is None or low[2]<minimum[2]:minimum=low
                    if maximum is None or high[2]>maximum[2]:maximum=high
                last_finite=(int(idx[finish-1]),float(t[finish-1]),float(y[finish-1]))
    end_run()
    if len(points)>max_points:
        raise ValueError('This interval has too many gaps for a faithful bounded preview; select a shorter interval.')
    values=np.asarray([p[2] for p in points]);times=np.asarray([p[1] for p in points])
    return times,values,{**summary,'display_point_count':len(points),'bin_count':int(bins),'reduced':True}


def _caption(recording,plan,settings,display=None):
    rows=_selection_rows(recording,plan)
    channels=', '.join(f'{i+1}: {_channel(recording,i)["name"]} ({_channel(recording,i).get("unit") or "unit unavailable"})' for i in plan['channels'])
    sweeps=', '.join(str(i+1) for i in plan['sweeps'])
    times='each selected full sweep' if plan['end_s'] is None else f'{plan["start_s"]:g}–{plan["end_s"]:g} s within each selected sweep'
    if plan['end_s'] is None and plan['start_s']:
        times=f'{plan["start_s"]:g} s through the end of each selected sweep'
    text=f'ABF waveform view. Channels {channels}; sweeps {sweeps}; {times}. '
    text+='The horizontal axis shows within-sweep time; sweeps are overlaid separately. ' if plan['time_reference']=='sweep' else 'The horizontal axis shows actual recording-relative time, including sweep gaps; separate sweeps are never joined. '
    rates=sorted({row['sampling_rate_hz'] for row in rows})
    text+='Sampling rate'+('s' if len(rates)>1 else '')+': '+', '.join(f'{r:g} Hz' for r in rates)+'. '
    if display is not None:
        raw=sum(d['source_sample_count'] for d in display);shown=sum(d['display_point_count'] for d in display)
        reduced=[d for d in display if d['reduced']]
        text+=f'{raw:,} selected channel-samples; {shown:,} plotted display vertices across {len(display)} separate traces. '
        if reduced:
            text+='Display-only min/max envelopes retain finite extrema in chronological order and finite-run endpoints. '
            text+='Bin counts for reduced traces: '+', '.join(str(d['bin_count']) for d in reduced)+'. '
        else:text+='All selected samples are displayed at full sample resolution. '
        if any(d['gap_regions'] for d in display):
            text+='Nonfinite values or discontinuities are displayed as gaps; finite segments are not connected across them. '
    else:
        text+=f'Planned selection: {sum(row["source_sample_count"] for row in rows):,} channel-samples. '
        if any(row['source_sample_count']>MAX_DISPLAY_POINTS for row in rows):
            text+=f'Traces exceeding {MAX_DISPLAY_POINTS:,} samples use a display-only min/max envelope with at most {MAX_DISPLAY_POINTS:,} vertices per trace; exact bin counts are recorded when rendered. '
        else:text+='Selected traces fit the full-resolution display budget. '
    text+='Display reduction is not analytical resampling and is never used for statistics. No filter, baseline correction, event detection, or inferential test is applied. The original ABF remains unchanged; sample counts do not establish independent biological replicates. '
    text+=f'Figure: {settings["width_mm"]:g} × {settings["height_mm"]:g} mm.'
    return text


def trace_caption(recording,plan,style=None):
    plan=validate_trace_plan(recording,plan);settings=_style(plan,style)
    try:display=_DISPLAY_CACHE.get(recording,{}).get(_key(plan))
    except TypeError:display=None
    return _caption(recording,plan,settings,display)


@_serialized_render
def make_trace_figure(recording,plan,style=None):
    plan=validate_trace_plan(recording,plan);settings=_style(plan,style)
    colors=PALETTES[settings['palette']]
    with mpl.rc_context(dict(RC,**{'font.size':settings['font_size']})):
        fig=Figure(figsize=(settings['width_mm']/25.4,settings['height_mm']/25.4),dpi=150,layout='constrained')
        fig.get_layout_engine().set(w_pad=.10,h_pad=.10,hspace=.10)
        axes=fig.subplots(len(plan['channels']),1,squeeze=False,sharex=True).ravel()
        displays=[]
        for axis,channel in zip(axes,plan['channels']):
            ch=_channel(recording,channel)
            for order,sweep in enumerate(plan['sweeps']):
                time,values,account=_display_trace(recording,channel,sweep,plan['start_s'],plan['end_s'])
                if plan['time_reference']=='recording':time=time+float(_sweep(recording,sweep)['start_s'])
                account.update(channel=channel+1,sweep=sweep+1)
                displays.append(account)
                span=max(1,len(colors)-1)
                line_style='-' if order==0 else ['-','--',':','-.'][((order-1)//span)%4]
                axis.plot(time,values,color=colors[0] if order==0 else colors[1+(order-1)%span],
                    linestyle=line_style,linewidth=.75 if len(plan['sweeps'])<=4 else .6,
                    alpha=1 if order==0 else .78,label=f'Sweep {sweep+1}')
            unit=str(ch.get('unit') or 'unit unavailable')
            label=settings.get('ylabel') or str(ch['name'])
            if f'({unit})' not in label and f'[{unit}]' not in label:label+=f' ({unit})'
            axis.set_ylabel(_safe_label(label,28),fontsize=settings['font_size'])
            axis.tick_params(labelsize=max(8,settings['font_size']-.3))
            axis.yaxis.set_major_locator(MaxNLocator(nbins=4))
            axis.xaxis.set_major_locator(MaxNLocator(nbins=6))
            axis.spines['top'].set_visible(False);axis.spines['right'].set_visible(False)
            axis.margins(x=.01,y=.10)
            if len(plan['channels'])>1:axis.set_title(f'Channel {channel+1}',loc='left',fontsize=settings['font_size'],pad=5)
        title=settings.get('title') or f'{Path(recording.source_path).stem} · ABF trace'
        axes[0].set_title(_safe_label(title,75),loc='left',fontsize=settings['font_size']+1.2,fontweight='semibold',pad=12)
        xlabel=settings.get('xlabel') or ('Time within sweep (s)' if plan['time_reference']=='sweep' else 'Recording time (s)')
        if '(s)' not in xlabel and 'second' not in xlabel.casefold():xlabel+=' (s)'
        axes[-1].set_xlabel(xlabel,fontsize=settings['font_size'])
        bounds=[(plan['start_s']+(float(_sweep(recording,i)['start_s']) if plan['time_reference']=='recording' else 0),
                 (plan['end_s'] if plan['end_s'] is not None else float(_sweep(recording,i)['duration_s']))+
                 (float(_sweep(recording,i)['start_s']) if plan['time_reference']=='recording' else 0)) for i in plan['sweeps']]
        axes[-1].set_xlim(min(b[0] for b in bounds),max(b[1] for b in bounds))
        if len(plan['sweeps'])>1:
            handles,labels=axes[0].get_legend_handles_labels()
            fig.legend(handles,labels,frameon=False,loc='outside lower center',
                fontsize=max(8,settings['font_size']-.7),ncol=min(6,len(plan['sweeps'])))
        try:
            cache=_DISPLAY_CACHE.setdefault(recording,{})
            if len(cache)>12:cache.clear()
            cache[_key(plan)]=deepcopy(displays)
        except TypeError:pass
        fig._statweave_trace_display=displays
        fig._statweave_style=settings
        fig._statweave_trace_plan=plan
        fig._statweave_caption=_caption(recording,plan,settings,displays)
        FigureCanvasAgg(fig).draw()
        _assert_not_clipped(fig)
        return fig
