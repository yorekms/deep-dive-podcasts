"""Source-preserving AP measurements with explicit masks and ordered review.

Automatic candidates come from the unchanged versioned raw-voltage threshold
excursion detector. Artifact masks remove sample-aligned time from derived
analysis only; each included segment is detected separately. Review decisions
retain candidate identity and history. Manual additions require an identifiable
local maximum inside an explicit bounded tolerance and never erase raw samples.

Amplitude is peak minus a local pre-peak median baseline for every event,
regardless of automatic/manual origin. This local baseline is not resting
voltage or a dV/dt threshold measure.
Half-width uses baseline-relative half height and interpolates derived crossing
times only. Incomplete baselines/boundaries produce unavailable measurements and
quality flags while retaining reviewed event counts. ISIs never cross a sweep,
channel or excluded interval. No inferential statistical test is performed.
"""
from __future__ import annotations
from copy import deepcopy
from bisect import bisect_left
from collections import defaultdict
import math
import re
import numpy as np
from .spikes import (spike_result,validate_spike_plan,
    _selections,_ceil_point,MAX_CANDIDATES,MAX_BIN_ROWS,DETECTOR_VERSION,DETECTOR_METHOD)

MEASUREMENT_VERSION='1.0.0'
MAX_REGIONS=1000
MAX_DECISIONS=100000
MAX_MEASUREMENT_SAMPLES=1000000
DEFAULT_MEASUREMENTS={'baseline_window_ms':2.0,'baseline_gap_ms':.5,
    'search_before_ms':5.0,'search_after_ms':10.0,'isi_reference':'peak'}
MEASUREMENT_FIELDS=['baseline_mv','baseline_value','amplitude_mv','half_height_mv',
    'half_width_ms','half_width_left_time_s','half_width_right_time_s','isi_ms',
    'baseline_start_s','baseline_end_s','baseline_first_sample_index','baseline_stop_sample_index',
    'isi_previous_event_id']
AP_COLUMNS=['event_id','channel','sweep','included_segment_id','origin','review_status',
    'decision_reason','auto_accepted','automatic_rejection_reason','crossing_time_s','peak_time_s',
    'recording_crossing_time_s','recording_peak_time_s','peak_value','unit','peak_mv','baseline_value','baseline_mv',
    'amplitude_mv','half_height_mv','half_width_ms','half_width_left_time_s',
    'half_width_right_time_s','baseline_start_s','baseline_end_s','baseline_first_sample_index',
    'baseline_stop_sample_index','isi_ms','isi_previous_event_id','quality_flags',
    'crossing_sample_index','peak_sample_index','included_first_sample_index','included_stop_sample_index']
ISI_COLUMNS=['channel','sweep','included_segment_id','previous_event_id','event_id',
    'previous_peak_time_s','peak_time_s','isi_ms']
RATE_COLUMNS=['channel','sweep','channel_name','unit','spike_count','sampled_duration_s',
    'firing_rate_hz','first_sample_index','stop_sample_index','excluded_sample_count','included_segment_count']
POOL_COLUMNS=['channel','channel_name','unit','spike_count','sampled_duration_s','firing_rate_hz','selected_sweeps']
BIN_COLUMNS=['channel','sweep','included_segment_id','start_s','end_s','duration_s',
    'spike_count','firing_rate_hz','recording_start_s','recording_end_s','first_sample_index','stop_sample_index',
    'bin_width_samples','effective_bin_width_s']


def _safe(value):
    if isinstance(value,np.generic):return _safe(value.item())
    if isinstance(value,dict):return {str(k):_safe(v) for k,v in value.items()}
    if isinstance(value,(list,tuple)):return [_safe(v) for v in value]
    if isinstance(value,float) and not math.isfinite(value):raise ValueError('AP plans/results cannot contain nonfinite values.')
    if value is None or isinstance(value,(str,int,float,bool)):return value
    raise ValueError('AP plans/results contain an unsupported value type.')


def _number(value,label,positive=False,nonnegative=False):
    if isinstance(value,bool) or not isinstance(value,(int,float)) or not math.isfinite(value):
        raise ValueError(f'{label} must be a finite number.')
    if positive and value<=0:raise ValueError(f'{label} must be greater than zero.')
    if nonnegative and value<0:raise ValueError(f'{label} cannot be negative.')
    return float(value)


def _reason(value):
    from .engine import _PRUNING_REASON_RE
    if not isinstance(value,str) or not value.strip() or len(value)>2000:
        raise ValueError('Every exclusion or review decision needs a nonempty reason of at most 2000 characters.')
    cleaned = value.strip()
    if _PRUNING_REASON_RE.search(cleaned):
        raise ValueError('Exclusions and review decisions require a concrete waveform or experimental artifact reason, never statistical outlier pruning or p-value optimization.')
    return cleaned


def _indices(values,selected,label):
    if not isinstance(values,list) or not values or any(type(v) is not int or v not in selected for v in values) or len(set(values))!=len(values):
        raise ValueError(f'{label} must be unique zero-based indices inside the current selection.')
    return values


def _selection_map(recording,plan):
    p={**plan,'method':'spikes','action':'spikes'}
    return {(s['channel_index'],s['sweep_index']):s for s in _selections(recording,p)}


def validate_ap_plan(recording,plan):
    """Metadata-only normalization; review IDs/peaks are checked during analysis."""
    plan=_safe(deepcopy(plan))
    if not isinstance(plan,dict) or plan.get('method','action_potentials')!='action_potentials':
        raise ValueError('AP measurements need an action_potentials plan.')
    # The rate-bin budget applies after explicit masks. The core validator first
    # validates selection/settings with a coarse width, then _segments budgets
    # the requested sample-ceiled width on included time only.
    width=_number(plan.get('bin_width_s',.1),'Rate-bin width in seconds',positive=True)
    coarse=max(width,max(float(s['duration_s']) for s in recording.sweeps))
    base=validate_spike_plan(recording,{**plan,'method':'spikes','action':'spikes','bin_width_s':coarse})
    base['bin_width_s']=width
    base.update(method='action_potentials',action='action_potentials')
    incoming=base.get('measurements',{})
    if not isinstance(incoming,dict) or set(incoming)-set(DEFAULT_MEASUREMENTS):
        raise ValueError('Unsupported AP measurement parameter.')
    measurements={**DEFAULT_MEASUREMENTS,**incoming}
    for key in ['baseline_window_ms','search_before_ms','search_after_ms']:
        measurements[key]=_number(measurements[key],key,positive=True)
    measurements['baseline_gap_ms']=_number(measurements['baseline_gap_ms'],'baseline_gap_ms',nonnegative=True)
    if measurements['isi_reference']!='peak':raise ValueError('Only within-segment peak-to-peak ISIs are implemented.')
    base['measurements']=measurements
    selected=_selection_map(recording,base)
    for spec in selected.values():
        if any(not math.isfinite(measurements[key]*spec['sampling_rate_hz']/1000)
               for key in ['baseline_window_ms','baseline_gap_ms','search_before_ms','search_after_ms']):
            raise ValueError('AP measurement settings exceed supported sample-count arithmetic.')
    regions=base.get('excluded_regions',[])
    if not isinstance(regions,list) or len(regions)>MAX_REGIONS:raise ValueError('Provide a bounded list of excluded regions.')
    normalized=[]
    for region in regions:
        if not isinstance(region,dict) or set(region)-{'start_s','end_s','channels','sweeps','reason'}:
            raise ValueError('An exclusion needs start_s, end_s, channels, sweeps and a reason.')
        start=_number(region.get('start_s'),'Exclusion start',nonnegative=True)
        end=_number(region.get('end_s'),'Exclusion end',positive=True)
        if end<=start:raise ValueError('An excluded region must end after it starts.')
        channels=_indices(region.get('channels',list(base['channels'])),base['channels'],'Exclusion channels')
        sweeps=_indices(region.get('sweeps',list(base['sweeps'])),base['sweeps'],'Exclusion sweeps')
        for ch in channels:
            for sw in sweeps:
                spec=selected[ch,sw];rate=spec['sampling_rate_hz']
                first=_ceil_point(start*rate);stop=_ceil_point(end*rate)
                if start<spec['first_sample_index']/rate-1e-12 or end>spec['stop_sample_index']/rate+1e-12 or first<spec['first_sample_index'] or stop>spec['stop_sample_index']:
                    raise ValueError('An excluded region lies outside the current selected interval; it was not silently clipped.')
                if stop<=first:raise ValueError('An excluded region contains no acquired samples.')
        normalized.append({'start_s':start,'end_s':end,'channels':channels,'sweeps':sweeps,'reason':_reason(region.get('reason'))})
    base['excluded_regions']=normalized
    decisions=base.get('event_decisions',[])
    if not isinstance(decisions,list) or len(decisions)>MAX_DECISIONS:raise ValueError('Provide a bounded ordered list of review decisions.')
    reviewed=[]
    for decision in decisions:
        if not isinstance(decision,dict):raise ValueError('Each event decision must be a structured instruction.')
        operation=decision.get('operation');reason=_reason(decision.get('reason'))
        if operation in ('reject','restore'):
            if set(decision)-{'operation','event_id','reason'} or not isinstance(decision.get('event_id'),str) or not re.fullmatch(r'ch[1-9]\d*-sw[1-9]\d*-p\d+',decision['event_id']):
                raise ValueError('Reject/restore needs an existing stable event_id and a reason.')
            reviewed.append({'operation':operation,'event_id':decision['event_id'],'reason':reason})
        elif operation=='add':
            if set(decision)-{'operation','channel','sweep','time_s','tolerance_ms','reason'}:raise ValueError('Unsupported manual addition field.')
            ch=decision.get('channel');sw=decision.get('sweep')
            if type(ch) is not int or type(sw) is not int or (ch,sw) not in selected:raise ValueError('Manual additions must name a selected zero-based channel and sweep.')
            time=_number(decision.get('time_s'),'Manual event time',nonnegative=True)
            tolerance=_number(decision.get('tolerance_ms'),'Manual peak tolerance',positive=True)
            reviewed.append({'operation':'add','channel':ch,'sweep':sw,'time_s':time,'tolerance_ms':tolerance,'reason':reason})
        else:raise ValueError('Review operations are add, reject or restore.')
    base['event_decisions']=reviewed
    current_hash=str(getattr(recording,'source_hash','unavailable'))
    annotated=bool(normalized or reviewed)
    binding=base.get('review_source_sha256')
    if annotated and binding is not None and binding!=current_hash:
        raise ValueError('The review source hash differs from the current recording. Artifact masks and event decisions cannot transfer silently to another source.')
    base['review_source_sha256']=current_hash if annotated else None
    _segments(recording,base)
    return base


def _segments(recording,plan):
    selected=_selection_map(recording,plan);included=[];excluded=[]
    for key,spec in selected.items():
        rate=spec['sampling_rate_hz'];ranges=[]
        for region in plan['excluded_regions']:
            if key[0] in region['channels'] and key[1] in region['sweeps']:
                ranges.append((_ceil_point(region['start_s']*rate),_ceil_point(region['end_s']*rate),region['reason']))
        merged=[]
        for first,stop,reason in sorted(ranges):
            if merged and first<=merged[-1][1]:
                merged[-1][1]=max(stop,merged[-1][1]);merged[-1][2].append(reason)
            else:merged.append([first,stop,[reason]])
        cursor=spec['first_sample_index']
        for first,stop,reasons in merged:
            if cursor<first:included.append(_segment(spec,cursor,first))
            excluded.append({'channel':spec['channel'],'sweep':spec['sweep'],'first_sample_index':first,
                'stop_sample_index':stop,'start_s':first/rate,'end_s':stop/rate,
                'excluded_sample_count':stop-first,'reasons':list(dict.fromkeys(reasons))})
            cursor=stop
        if cursor<spec['stop_sample_index']:included.append(_segment(spec,cursor,spec['stop_sample_index']))
    if sum((s['stop_sample_index']-s['first_sample_index']+s['bin_width_samples']-1)//s['bin_width_samples'] for s in included)>MAX_BIN_ROWS:
        raise ValueError('Artifact segmentation creates too many rate bins; choose a larger bin width.')
    return selected,included,excluded


def _segment(spec,first,stop):
    rate=spec['sampling_rate_hz']
    return {**spec,'segment_id':f"ch{spec['channel']}-sw{spec['sweep']}-s{first}-e{stop}",
        'first_sample_index':first,'stop_sample_index':stop,'start_s':first/rate,'end_s':stop/rate,
        'sampled_duration_s':(stop-first)/rate}


def _read(recording,ch,sw,first,stop,rate):
    if first<0 or stop<=first or stop-first>MAX_MEASUREMENT_SAMPLES:
        raise ValueError('The requested local waveform window is empty or exceeds the bounded measurement limit.')
    parts=[];expected=first
    for chunk in recording.iter_window_chunks(channel_index=ch,sweep_index=sw,start_s=first/rate,end_s=stop/rate,chunk_samples=65536):
        idx=np.asarray(chunk['sample_indices']);time=np.asarray(chunk['time_s'],dtype=float);values=np.asarray(chunk['values'],dtype=float)
        if idx.ndim!=1 or time.ndim!=1 or values.ndim!=1 or not(len(idx)==len(time)==len(values)):
            raise ValueError('The local waveform reader returned inconsistent arrays.')
        if not len(idx):continue
        if not np.issubdtype(idx.dtype,np.integer) or int(idx[0])!=expected or np.any(np.diff(idx)!=1) or int(idx[-1])>=stop:
            raise ValueError('A local measurement encountered a sample discontinuity.')
        if not np.isfinite(values).all() or not np.allclose(time,idx.astype(float)/rate,rtol=0,atol=max(1e-12,abs(int(idx[-1])/rate)*8*np.finfo(float).eps)):
            raise ValueError('A local measurement encountered nonfinite values or inconsistent timestamps.')
        parts.append(values);expected=int(idx[-1])+1
    if expected!=stop:raise ValueError('The local measurement did not receive every requested sample.')
    return np.concatenate(parts)


def _identity(row):return f"ch{row['channel']}-sw{row['sweep']}-p{row['peak_sample_index']}"


def _candidate(row,segment):
    row=deepcopy(row)
    row.update(event_id=_identity(row),origin='automatic',auto_accepted=bool(row['accepted']),
        automatic_rejection_reason=row['rejection_reason'],
        review_status='automatic_accepted' if row['accepted'] else 'automatic_rejected',
        decision_reason=None,review_history=[],included_segment_id=segment['segment_id'],
        included_first_sample_index=segment['first_sample_index'],included_stop_sample_index=segment['stop_sample_index'])
    for key in MEASUREMENT_FIELDS:row[key]=None
    row['quality_flags']=[]
    return row


def _manual(recording,decision,segments,plan):
    ch,sw=decision['channel'],decision['sweep'];time=decision['time_s'];tolerance=decision['tolerance_ms']/1000
    matches=[s for s in segments if s['channel_index']==ch and s['sweep_index']==sw and
        time-tolerance>=s['start_s']-1e-12 and time+tolerance<=s['end_s']+1e-12]
    if len(matches)!=1:raise ValueError('The full manual peak-search interval must lie inside one included segment; excluded or outside-selection times are not silently clipped.')
    seg=matches[0];rate=seg['sampling_rate_hz']
    first=max(seg['first_sample_index'],_ceil_point((time-tolerance)*rate))
    stop=min(seg['stop_sample_index'],int(math.floor((time+tolerance)*rate+1e-10))+1)
    if stop<=first:raise ValueError('The manual peak-search interval contains no samples.')
    left=max(seg['first_sample_index'],first-1);right=min(seg['stop_sample_index'],stop+1)
    values=_read(recording,ch,sw,left,right,rate)
    search=values[first-left:stop-left];peak=first+int(np.argmax(search));value=float(values[peak-left])
    plateau_left=peak;plateau_right=peak
    while plateau_left>left and values[plateau_left-left-1]==value:plateau_left-=1
    while plateau_right+1<right and values[plateau_right-left+1]==value:plateau_right+=1
    if plateau_left<first or plateau_left==left or plateau_right+1>=right or values[plateau_left-left-1]>=value or values[plateau_right-left+1]>=value:
        raise ValueError('The manual search did not identify a bounded true local maximum. A flat/monotonic trace or a plateau extending outside tolerance is ambiguous; no event was added.')
    peak=plateau_left
    row={'channel':ch+1,'sweep':sw+1,'channel_name':seg['channel_name'],
        'crossing_sample_index':peak,'peak_sample_index':peak,'crossing_time_s':peak/rate,'peak_time_s':peak/rate,
        'recording_crossing_time_s':seg['recording_sweep_start_s']+peak/rate,
        'recording_peak_time_s':seg['recording_sweep_start_s']+peak/rate,
        'peak_value':value,'unit':seg['unit'],'peak_mv':value*seg['factor_to_mv'],
        'threshold_mv':plan['detector']['threshold_mv'],'refractory_samples':seg['refractory_samples'],
        'accepted':True,'rejection_reason':None}
    row=_candidate(row,seg)
    row.update(origin='manual',auto_accepted=None,review_status='manual_added',decision_reason=decision['reason'],
        manual_selection={'requested_time_s':time,'tolerance_ms':decision['tolerance_ms'],
            'search_first_sample_index':first,'search_stop_sample_index':stop,'chosen_peak_sample_index':peak},
        refractory_override=True)
    return row


def _measure(recording,event,segment,neighbors,settings):
    ch=event['channel']-1;sw=event['sweep']-1;rate=segment['sampling_rate_hz'];peak=event['peak_sample_index']
    anchor=peak
    end_s=anchor/rate-settings['baseline_gap_ms']/1000
    start_s=end_s-settings['baseline_window_ms']/1000
    event.update(baseline_start_s=start_s,baseline_end_s=end_s)
    if start_s<segment['start_s']-1e-12 or end_s>segment['end_s']+1e-12:
        event['quality_flags'].append('baseline_outside_included_segment');return
    first=_ceil_point(start_s*rate);stop=_ceil_point(end_s*rate)
    if stop<=first:
        event['quality_flags'].append('baseline_window_contains_no_samples');return
    values=_read(recording,ch,sw,first,stop,rate)
    baseline=float(np.median(values));baseline_mv=baseline*segment['factor_to_mv'];amplitude=event['peak_mv']-baseline_mv
    event.update(baseline_value=baseline,baseline_mv=baseline_mv,amplitude_mv=amplitude,
        baseline_first_sample_index=first,baseline_stop_sample_index=stop)
    lo,hi=bisect_left(neighbors,first),bisect_left(neighbors,stop)
    if hi-lo-int(first<=peak<stop)>0:event['quality_flags'].append('baseline_contains_neighboring_candidate_peak')
    if amplitude<=0:
        event['quality_flags'].append('nonpositive_baseline_relative_amplitude');return
    half=baseline_mv+amplitude/2;event['half_height_mv']=half
    before=max(1,_ceil_point(settings['search_before_ms']*rate/1000));after=max(1,_ceil_point(settings['search_after_ms']*rate/1000))
    left=max(segment['first_sample_index'],peak-before);right=min(segment['stop_sample_index']-1,peak+after)
    position=bisect_left(neighbors,peak)
    if position:left=max(left,(neighbors[position-1]+peak+1)//2)
    if position+1<len(neighbors):right=min(right,(neighbors[position+1]+peak)//2)
    if left>=peak or right<=peak:
        event['quality_flags'].append('half_height_search_has_no_bracketing_context');return
    raw=_read(recording,ch,sw,left,right+1,rate)*segment['factor_to_mv']
    rise=fall=None
    for index in range(peak-left-1,-1,-1):
        a,b=float(raw[index]),float(raw[index+1])
        if a<=half<=b and b>a:
            rise=(left+index+(half-a)/(b-a))/rate;break
    for index in range(peak-left,len(raw)-1):
        a,b=float(raw[index]),float(raw[index+1])
        if a>=half>=b and a>b:
            fall=(left+index+(a-half)/(a-b))/rate;break
    event['half_width_left_time_s']=rise;event['half_width_right_time_s']=fall
    if rise is None:event['quality_flags'].append('half_height_rising_crossing_unavailable')
    if fall is None:event['quality_flags'].append('half_height_falling_crossing_unavailable')
    if rise is not None and fall is not None and fall>rise:event['half_width_ms']=(fall-rise)*1000


def ap_result(recording,plan):
    plan=validate_ap_plan(recording,plan)
    selected,segments,excluded=_segments(recording,plan)
    candidates=[];segment_processing=[];detector_account=[]
    for seg in segments:
        core_plan={key:deepcopy(plan[key]) for key in ['detector','bin_width_s','time_reference']}
        core_plan.update(action='spikes',method='spikes',channels=[seg['channel_index']],sweeps=[seg['sweep_index']],start_s=seg['start_s'],end_s=seg['end_s'])
        core=spike_result(recording,core_plan)
        candidates.extend(_candidate(row,seg) for row in core['candidates'])
        if len(candidates)>MAX_CANDIDATES:raise ValueError('Too many AP candidates across included segments; choose a shorter interval.')
        segment_processing.append({'segment_id':seg['segment_id'],'source_first_sample_index':seg['first_sample_index'],
            'source_stop_sample_index':seg['stop_sample_index'],'processing_steps':core['processing_steps']})
        detector_account.append(core['spike_accounting'])
    by_id={c['event_id']:c for c in candidates}
    review_actions=[]
    for index,decision in enumerate(plan['event_decisions']):
        if decision['operation']=='add':
            row=_manual(recording,decision,segments,plan)
            if row['event_id'] in by_id:raise ValueError('The chosen peak already exists as a candidate. Use its stable event ID to reject or restore it; no duplicate was added.')
            if len(candidates)>=MAX_CANDIDATES:raise ValueError('Too many reviewed candidates.')
            candidates.append(row);by_id[row['event_id']]=row
        else:
            if decision['event_id'] not in by_id:raise ValueError('The review event ID is stale, outside the selection, or excluded. No decision was silently ignored.')
            row=by_id[decision['event_id']]
            restore=decision['operation']=='restore'
            row.update(accepted=restore,rejection_reason=None if restore else 'manual_reject',
                review_status='manual_restored' if restore else 'manual_rejected',decision_reason=decision['reason'])
            if restore and row.get('auto_accepted') is False:row['refractory_override']=True
        action={**deepcopy(decision),'decision_index':index,'event_id':row['event_id']}
        row['review_history'].append(action);review_actions.append(action)
    candidates.sort(key=lambda r:(r['channel'],r['sweep'],r['peak_sample_index']))
    segment_map={s['segment_id']:s for s in segments}
    grouped=defaultdict(list)
    accepted_grouped=defaultdict(list)
    for event in candidates:
        grouped[event['included_segment_id']].append(event)
        if event['accepted']:accepted_grouped[event['included_segment_id']].append(event)
    for segment_id,group in grouped.items():
        peers=[event['peak_sample_index'] for event in group]
        for event in accepted_grouped[segment_id]:
            _measure(recording,event,segment_map[segment_id],peers,plan['measurements'])
    isi=[]
    for seg in segments:
        events=accepted_grouped[seg['segment_id']]
        for previous,current in zip(events,events[1:]):
            interval=(current['peak_sample_index']-previous['peak_sample_index'])/seg['sampling_rate_hz']*1000
            current['isi_ms']=interval;current['isi_previous_event_id']=previous['event_id']
            isi.append({'channel':current['channel'],'sweep':current['sweep'],'included_segment_id':seg['segment_id'],
                'previous_event_id':previous['event_id'],'event_id':current['event_id'],
                'previous_peak_time_s':previous['peak_time_s'],'peak_time_s':current['peak_time_s'],'isi_ms':interval})
    events=[deepcopy(r) for r in candidates if r['accepted']]
    rate_rows=[];pool_rows=[];bins=[]
    segments_by_selection=defaultdict(list)
    counts_by_selection=defaultdict(int)
    for seg in segments:segments_by_selection[seg['channel_index'],seg['sweep_index']].append(seg)
    for event in events:counts_by_selection[event['channel']-1,event['sweep']-1]+=1
    for key,spec in selected.items():
        here=segments_by_selection[key]
        exposure=sum(s['sampled_duration_s'] for s in here)
        count=counts_by_selection[key]
        retained=sum(s['stop_sample_index']-s['first_sample_index'] for s in here)
        rate_rows.append({'channel':key[0]+1,'sweep':key[1]+1,'channel_name':spec['channel_name'],'unit':spec['unit'],
            'spike_count':count,'sampled_duration_s':exposure,'firing_rate_hz':count/exposure if exposure else None,
            'first_sample_index':spec['first_sample_index'],'stop_sample_index':spec['stop_sample_index'],
            'excluded_sample_count':spec['stop_sample_index']-spec['first_sample_index']-retained,'included_segment_count':len(here)})
    for seg in segments:
        crossing_indices=sorted(e['crossing_sample_index'] for e in accepted_grouped[seg['segment_id']])
        rate=seg['sampling_rate_hz'];width=seg['bin_width_samples']
        for first in range(seg['first_sample_index'],seg['stop_sample_index'],width):
            stop=min(first+width,seg['stop_sample_index']);duration=(stop-first)/rate
            count=bisect_left(crossing_indices,stop)-bisect_left(crossing_indices,first)
            bins.append({'channel':seg['channel'],'sweep':seg['sweep'],'included_segment_id':seg['segment_id'],
                'start_s':first/rate,'end_s':stop/rate,'duration_s':duration,'spike_count':count,'firing_rate_hz':count/duration,
                'recording_start_s':seg['recording_sweep_start_s']+first/rate,'recording_end_s':seg['recording_sweep_start_s']+stop/rate,
                'first_sample_index':first,'stop_sample_index':stop,'bin_width_samples':width,'effective_bin_width_s':width/rate})
    for ch in plan['channels']:
        rows=[r for r in rate_rows if r['channel']==ch+1];duration=sum(r['sampled_duration_s'] for r in rows);count=sum(r['spike_count'] for r in rows)
        pool_rows.append({'channel':ch+1,'channel_name':rows[0]['channel_name'],'unit':rows[0]['unit'],'spike_count':count,
            'sampled_duration_s':duration,'firing_rate_hz':count/duration if duration else None,'selected_sweeps':len(rows)})
    included_public=[{key:s[key] for key in ['channel','sweep','segment_id','first_sample_index','stop_sample_index','start_s','end_s','sampled_duration_s']} for s in segments]
    selected_samples=sum(s['stop_sample_index']-s['first_sample_index'] for s in selected.values())
    included_samples=sum(s['stop_sample_index']-s['first_sample_index'] for s in segments)
    accounting={'selected_channel_samples':selected_samples,'included_channel_samples':included_samples,
        'excluded_channel_samples':selected_samples-included_samples,'accepted_events':len(events),'candidate_count':len(candidates),
        'automatic_candidates':sum(r['origin']=='automatic' for r in candidates),'manual_added_candidates':sum(r['origin']=='manual' for r in candidates),
        'manual_rejected_candidates':sum(r['review_status']=='manual_rejected' for r in candidates),
        'included_segments':included_public,'effective_excluded_regions':excluded,'review_decision_count':len(review_actions),
        'measurement_unavailable_events':sum(e['amplitude_mv'] is None or e['half_width_ms'] is None for e in events),
        'automatic_segment_accounting':detector_account,'original_recording_preserved':True,'inferential_analysis':False}
    warnings=[str(w) for w in getattr(recording,'warnings',[]) if 'event detection' not in str(w).casefold()]
    warnings += ['Automatic candidates use unchanged threshold-excursion detector '+DETECTOR_VERSION+' on unfiltered full-resolution voltage. Manual overrides are explicit derived decisions, not source edits.',
        'Amplitude is relative to the local pre-peak median baseline for both automatic and manually added events. This baseline is not resting voltage or a dV/dt-defined action-potential threshold. Half-width uses that baseline-relative half height; derived crossing times are linearly interpolated without resampling the recording.',
        'Missing full baselines or half-height brackets leave measurements unavailable with quality flags; reviewed events remain counted.',
        'ISI is peak-to-peak only within the same included channel/sweep segment. Firing-rate exposure excludes explicit artifact masks and acquisition gaps; bins never cross excluded regions.',
        'Manual additions may override automatic threshold/refractory criteria; inspect source waveforms and review reasons. No inferential test or biological replication assumption is made.']
    processing=[{'operation':'source_preservation','source_sha256':str(getattr(recording,'source_hash','unavailable')),'raw_sample_modification':'none'},
        {'operation':'explicit_derived_analysis_masks','requested_regions':deepcopy(plan['excluded_regions']),'effective_regions':excluded,'included_segments':included_public},
        {'operation':'automatic_detection_by_included_segment','detector_version':DETECTOR_VERSION,'detector_method':DETECTOR_METHOD,'segments':segment_processing},
        {'operation':'ordered_manual_review','actions':review_actions,'automatic_results_preserved_in_candidate_status':True},
        {'operation':'AP_measurements','measurement_version':MEASUREMENT_VERSION,'settings':deepcopy(plan['measurements']),
         'baseline_anchor':'peak for all events; local pre-peak median, not resting voltage','half_width_boundary':'peak search horizons and neighboring candidate peak midpoints','raw_interpolation':'none; derived crossing times only'},
        {'operation':'reviewed_counts_and_exposure','bin_assignment':'accepted crossing sample; manual crossing equals chosen peak','ISI_reference':'peak within included segment'}]
    summary=f"AP review: {len(events)} accepted events from {len(candidates)} retained candidates; {selected_samples-included_samples:,} channel-samples explicitly excluded from derived analysis. "
    summary+=f"{accounting['measurement_unavailable_events']} accepted event(s) have unavailable amplitude or half-width fields; all remain counted.\n"
    summary+='\n'.join(f"Channel {r['channel']}, sweep {r['sweep']}: {r['spike_count']} events / {r['sampled_duration_s']:.6g} included s = "+(f"{r['firing_rate_hz']:.6g} events/s." if r['firing_rate_hz'] is not None else 'rate unavailable (no included exposure).') for r in rate_rows[:8])
    if len(rate_rows)>8:summary+='\nAll channel/sweep measurements remain in Results and exports.'
    return _safe({'method':'action_potentials','plan':plan,'summary':summary,'events':events,'candidates':candidates,
        'tables':[{'title':'Action potential measurements','columns':AP_COLUMNS,'rows':deepcopy(events)},
            {'title':'Inter-spike intervals','columns':ISI_COLUMNS,'rows':isi},
            {'title':'Firing rate by sweep','columns':RATE_COLUMNS,'rows':rate_rows},
            {'title':'Pooled firing rate by channel','columns':POOL_COLUMNS,'rows':pool_rows},
            {'title':'Binned firing rate','columns':BIN_COLUMNS,'rows':bins}],
        'warnings':list(dict.fromkeys(warnings)),'processing_steps':processing,'ap_accounting':accounting,
        'spike_accounting':deepcopy(accounting),'source_sha256':str(getattr(recording,'source_hash','unavailable')),
        'detector_version':DETECTOR_VERSION,'detector_method':DETECTOR_METHOD,'measurement_version':MEASUREMENT_VERSION,
        'review_actions':review_actions})
