"""Publication figures from stored large-table aggregates and bounded samples.

Rendering never queries the imported table, reads the source, or reruns a plan.
Record counts are descriptive bookkeeping, not biological sample sizes.
"""
from __future__ import annotations

from copy import deepcopy
from pathlib import Path
import json
import math
import re

import matplotlib as mpl
from matplotlib.backends.backend_agg import FigureCanvasAgg
from matplotlib.figure import Figure
from matplotlib.ticker import MaxNLocator,StrMethodFormatter
import numpy as np

from .figures import RC,PALETTES,_style,_safe_label,_assert_not_clipped,_serialized_render

METHODS={'profile','count_by','find','summary','histogram','scatter'}
MAX_GROUPS=20
MAX_SCATTER_POINTS=5000
MAX_HISTOGRAM_BINS=500


def _plural(count,noun):
    return noun if count==1 else noun+'s'


def _integer(value,label,minimum=0):
    if isinstance(value,(bool,np.bool_)) or not isinstance(value,(int,np.integer)) or int(value)<minimum:
        raise ValueError(f'{label} must be an integer of at least {minimum}.')
    return int(value)


def _number(value,label):
    if isinstance(value,(bool,np.bool_)) or not isinstance(value,(int,float,np.number)):
        raise ValueError(f'{label} must be a finite number.')
    number=float(value)
    if not math.isfinite(number):raise ValueError(f'{label} must be a finite number.')
    return number


def _signature(plan):
    if not isinstance(plan,dict):raise ValueError('A large-table figure needs its accepted analysis plan.')
    return json.dumps({key:value for key,value in plan.items() if key not in ('style','action')},
        sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)


def _normalize(dataset,plan):
    from .large_table import validate_large_plan
    if not isinstance(plan,dict):raise ValueError('A large-table figure needs its accepted analysis plan.')
    scientific={key:value for key,value in plan.items() if key!='style'}
    normalized=validate_large_plan(dataset,scientific)
    if 'style' in plan:normalized['style']=deepcopy(plan['style'])
    return normalized


def _rows(result,title,required=True):
    tables=result.get('tables')
    if not isinstance(tables,list):raise ValueError('The stored large-table result is missing its tables.')
    found=[table for table in tables if isinstance(table,dict) and table.get('title')==title]
    if len(found)>1:raise ValueError(f'The result contains duplicate {title} tables.')
    if not found:
        if required:raise ValueError(f'The stored result is missing its {title} table.')
        return []
    rows=found[0].get('rows')
    if not isinstance(rows,list) or any(not isinstance(row,dict) for row in rows):
        raise ValueError(f'The {title} table contains invalid rows.')
    return rows


def _counts(dataset,result):
    accounting=result.get('large_table_accounting')
    if not isinstance(accounting,dict):raise ValueError('The large-table result has no record accounting.')
    total=_integer(accounting.get('source_record_count'),'Imported record count')
    selected=_integer(accounting.get('selected_record_count'),'Selected record count')
    if selected>total:raise ValueError('The selected record count exceeds the imported table.')
    current=getattr(dataset,'row_count',None)
    if current is not None and _integer(current,'Current imported record count')!=total:
        raise ValueError('The stored large-table result belongs to a different imported table.')
    return accounting,total,selected


def _column(plan,*keys):
    for key in keys:
        value=plan.get(key)
        if isinstance(value,str) and value:return value
    raise ValueError('The accepted plan must identify its plotted source column.')


def _numeric_summary(result,column):
    matches=[row for row in _rows(result,'Numeric summary',required=False) if row.get('column')==column]
    if len(matches)>1:raise ValueError('A numeric column has duplicate full-data summaries.')
    return matches[0] if matches else None


def _validate(dataset,result,plan):
    if getattr(dataset,'kind',None)!='large_table':raise ValueError('This figure needs an imported large table.')
    if not isinstance(result,dict) or result.get('method') not in METHODS:
        raise ValueError('This result is not a supported stored large-table analysis.')
    stored=_normalize(dataset,result.get('plan'));current=_normalize(dataset,plan)
    if _signature(current)!=_signature(stored):
        raise ValueError('The large-table analysis choices changed. Run the accepted plan before plotting those choices.')
    method=result['method']
    if stored.get('method')!=method:raise ValueError('The result method differs from its accepted plan.')
    digest=result.get('source_sha256');source=getattr(dataset,'source_hash',None)
    if digest not in (None,'','unavailable') and digest!=source:
        raise ValueError('This large-table result belongs to a different source file.')
    accounting,total,selected=_counts(dataset,result)
    data={'method':method,'accounting':accounting,'total':total,'selected':selected,'rows':[]}
    if method=='count_by':
        rows=_rows(result,'Counts by group');seen=set();represented=0
        for row in rows:
            value=row.get('value')
            if value is not None and not isinstance(value,(str,int,float,bool)):
                raise ValueError('A group label must be a scalar source value.')
            if isinstance(value,float) and not math.isfinite(value):raise ValueError('A nonfinite group label is invalid.')
            identity=(type(value).__name__,str(value))
            if identity in seen:raise ValueError('The count table contains duplicate groups.')
            seen.add(identity);represented+=_integer(row.get('count'),'Group record count',1)
        remaining=_integer(accounting.get('remaining_record_count',0),'Unshown group record count')
        omitted_groups=_integer(accounting.get('remaining_group_count',0),'Unshown group count')
        if represented+remaining!=selected:
            raise ValueError('Stored group counts do not account for all selected records.')
        if bool(remaining)!=bool(omitted_groups):raise ValueError('The remaining group and record counts are inconsistent.')
        data.update(rows=rows,column=_column(stored,'groupby','group_by','group','column'),represented=represented,
            remaining=remaining,omitted_groups=omitted_groups)
    elif method=='histogram':
        rows=_rows(result,'Histogram');column=_column(stored,'column','x_column','x');last=None;count=0
        if len(rows)>MAX_HISTOGRAM_BINS:raise ValueError('Too many histogram bins for a readable figure. Request fewer bins.')
        for index,row in enumerate(rows):
            left=_number(row.get('bin_left'),'Histogram left edge');right=_number(row.get('bin_right'),'Histogram right edge')
            if right<=left:raise ValueError('Every histogram bin must have positive width.')
            if last is not None and not math.isclose(left,last,rel_tol=1e-12,abs_tol=1e-12):
                raise ValueError('Stored histogram bins contain a gap or overlap.')
            if 'bin_index' in row and _integer(row['bin_index'],'Histogram bin index')!=index:
                raise ValueError('The stored histogram bin order is inconsistent.')
            count+=_integer(row.get('count'),'Histogram record count');last=right
        summary=_numeric_summary(result,column)
        if summary is None:raise ValueError('A full-data numeric summary is required to verify histogram coverage.')
        finite=_integer(summary.get('finite_count'),'Full-data finite record count')
        if _integer(summary.get('selected_rows'),'Numeric-summary selected record count')!=selected:
            raise ValueError('The numeric summary has different selected-record accounting.')
        absent=sum(_integer(summary.get(key),key+' record count') for key in ['null_count','invalid_count','nonfinite_count'])
        if finite+absent!=selected:raise ValueError('Finite, missing, invalid and nonfinite counts do not account for the selection.')
        if count!=finite or finite>selected:raise ValueError('The histogram does not cover all selected finite values.')
        if finite and not rows:raise ValueError('Finite values are missing from the stored histogram.')
        if finite:
            minimum=_number(summary.get('min'),'Full-data numeric minimum');maximum=_number(summary.get('max'),'Full-data numeric maximum')
            if minimum>maximum or rows[0]['bin_left']>minimum or rows[-1]['bin_right']<maximum:
                raise ValueError('The histogram edges do not include the full finite value range.')
        for key,expected in [('finite_record_count',finite),('histogram_record_count',count),('effective_bin_count',len(rows))]:
            if key in accounting and _integer(accounting[key],key)!=expected:
                raise ValueError('The histogram accounting disagrees with the stored bins.')
        data.update(rows=rows,column=column,finite=finite,summary=summary)
    elif method=='scatter':
        rows=_rows(result,'Scatter sample');x=_column(stored,'x_column','x');y=_column(stored,'y_column','y')
        if len(rows)>MAX_SCATTER_POINTS:raise ValueError('The stored scatter exceeds the 5,000-point display limit; request a bounded sample.')
        last=None
        for row in rows:
            record=_integer(row.get('source_record_number'),'Scatter source record number',1)
            if last is not None and record<=last:raise ValueError('Scatter source record identifiers are duplicated or out of order.')
            if record>total:raise ValueError('A scatter point lies outside the imported source records.')
            _number(row.get('x'),'Scatter x value');_number(row.get('y'),'Scatter y value');last=record
        finite=_integer(accounting.get('finite_pair_count'),'Full-data finite pair count')
        plotted=_integer(accounting.get('plotted_record_count'),'Plotted record count')
        if plotted!=len(rows) or plotted!=min(finite,current['limit']) or finite>selected:
            raise ValueError('Stored scatter sampling counts are inconsistent.')
        if finite and not plotted:raise ValueError('The scatter omits every selected finite pair.')
        sampling=accounting.get('sampling_method')
        if not isinstance(sampling,str) or not sampling.strip():raise ValueError('The scatter must disclose its deterministic sampling method.')
        if plotted<finite and 'deterministic' not in sampling.casefold():
            raise ValueError('The bounded scatter must disclose deterministic sampling.')
        if 'nonfinite_or_missing_pair_count' in accounting and _integer(accounting['nonfinite_or_missing_pair_count'],'Unavailable pair count')!=selected-finite:
            raise ValueError('The finite and unavailable pair counts are inconsistent.')
        data.update(rows=rows,x=x,y=y,finite=finite,plotted=plotted,sampling=sampling)
    else:
        title={'profile':'Column profile','find':'Matching records','summary':'Numeric summary'}[method]
        data['rows']=_rows(result,title)
    return current,data


def _filter_description(plan):
    filters=plan.get('predicates') or []
    if not filters:
        return ' No record filters were requested.'
    parts=[]
    pval_filtered=False
    pval_re=re.compile(r'(?:^|_|\b)(?:p[ _-]?val(?:ue)?|adjp(?:value)?|padj|fdr|q[ _-]?val(?:ue)?)$',re.I)
    for item in filters[:12]:
        col=_safe_label(str(item.get('column','')),48)
        op=_safe_label(str(item.get('op','')),12)
        val=_safe_label(repr(item.get('value')),64)
        parts.append(f'{col} {op} {val}')
        if pval_re.search(str(item.get('column',''))):
            pval_filtered=True
    extra=f' (+{len(filters)-12} more)' if len(filters)>12 else ''
    note=' Subsetted by a p-value/FDR threshold; does not represent the unthresholded testing family.' if pval_filtered else ''
    return f' The accepted filter conditions are recorded in the analysis plan ({"; ".join(parts)}{extra}).{note}'


def _caption(dataset,result,plan,data):
    method=data['method'];total=data['total'];selected=data['selected']
    name=Path(getattr(dataset,'source_path','Imported table')).name
    text=f'{name}: {selected:,} selected source {_plural(selected,"record")} from {total:,} imported {_plural(total,"record")}.'+_filter_description(plan)+' '
    if method=='count_by':
        if len(data['rows'])>MAX_GROUPS:
            text+=f'This is a text-only overview of the stored counts by {data["column"]}; no category marks are plotted because more than 20 groups were returned. Narrow the accepted predicates for a readable count chart. '
        elif not data['rows']:text+='There are no selected groups to plot; the figure is a text-only overview. '
        else:text+=f'Bars show exact record counts by {data["column"]}, in the stored group order. '
        if data['remaining']:
            text+=f'{len(data["rows"]):,} returned groups contain {data["represented"]:,} records; {data["omitted_groups"]:,} additional groups containing {data["remaining"]:,} records are outside this top-group display. '
        else:text+=f'All {len(data["rows"]):,} returned groups and all {selected:,} selected records are represented. '
        text+='Missing group values remain a separate category when present. Count charts start at zero. '
    elif method=='histogram':
        summary=data['summary']
        if not data['finite']:text+='No finite values are available to plot; this figure is a text-only overview. '
        text+=f'Exact histogram of {data["column"]}: all {data["finite"]:,} selected finite numeric values contribute to the stored {len(data["rows"]):,} bins; this is not a preview sample. '
        if data['finite'] and len(data['rows'])!=plan['bins']:
            text+=f'The plan requested {plan["bins"]:,} bins; the stored histogram uses {len(data["rows"]):,} effective bins. '
            if summary.get('min')==summary.get('max'):
                text+='All finite values are identical; the one display bin surrounds that constant value and does not imply a measured spread. '
        text+='Bin intervals are left-inclusive and right-exclusive, except the last bin includes its right edge. Heights encode record count per bin, not probability density. '
        omissions=[]
        for key,label in [('null_count','null'),('invalid_count','nonnumeric'),('nonfinite_count','nonfinite')]:
            if key in summary:omissions.append(f'{_integer(summary[key],label+" record count"):,} {label}')
        if omissions:text+='Numeric accounting: '+', '.join(omissions)+' records outside the finite histogram; their source values remain preserved. '
    elif method=='scatter':
        if not data['finite']:text+='No finite pairs are available to plot; this figure is a text-only overview. '
        text+=f'{data["x"]} versus {data["y"]}: {data["plotted"]:,} plotted records from {data["finite"]:,} finite x/y pairs among {selected:,} selected records. '
        if data['plotted']<data['finite']:
            text+='This is a deterministic bounded display sample, not every finite pair and not a random or representative probability sample. '
        else:text+='Every selected finite pair is plotted. '
        text+=f'Stored sampling method: {data["sampling"]}. Source-record identifiers are retained with the exported points. '
        text+=f'{selected-data["finite"]:,} selected records lack a finite numeric pair and are not plotted; source records are preserved. '
        text+='Points use stored source values without jitter, trend fitting, or density reweighting. '
    else:
        text+=f'This is a text-only data overview of the {method} result; it is not an inferential plot or a chart of associations. Exact returned values and any bounded search results remain in the Results/export tables. '
        if method=='find':text+='A bounded table of matching records must not be interpreted as every matching record unless the accounting explicitly establishes that. '
    text+='Numeric plots use the accepted query’s finite numeric conversion; original source text fields remain preserved. Source column names and numeric scales are retained; no physical unit, fold-change logarithm base, gene identity, biological replication, or independence is inferred. No effect estimates are pooled and no p-value, confidence interval, or credible interval is computed by this renderer.'
    return text


def large_caption(dataset,result,plan,style=None):
    normalized,data=_validate(dataset,result,plan);_style(normalized,style)
    return _caption(dataset,result,normalized,data)


def _footer(data):
    selected=data['selected']
    if data['method']=='scatter':
        prefix='Deterministic display sample' if data['plotted']<data['finite'] else 'All finite pairs'
        return f'{prefix}: {data["plotted"]:,} plotted of {data["finite"]:,} finite pairs · {selected:,} selected records'
    if data['method']=='histogram':return f'Full-data bin counts · {data["finite"]:,} finite values of {selected:,} selected records'
    if data['method']=='count_by':
        if data['remaining']:
            return f'Top {len(data["rows"]):,} groups: {data["represented"]:,} records shown · {data["remaining"]:,} records in {data["omitted_groups"]:,} additional groups'
        return f'All {selected:,} selected records · {len(data["rows"]):,} groups'
    return f'{selected:,} selected {_plural(selected,"record")} · {data["total"]:,} imported {_plural(data["total"],"record")} · descriptive overview'


def _group_labels(rows):
    missing='Missing value [NULL]'
    raw=[missing if row.get('value') is None else str(row['value']) for row in rows]
    labels=[]
    for row,text in zip(rows,raw):
        if row.get('value') is not None and text==missing:text+=' (literal text)'
        labels.append(_safe_label(text,30))
    if len(set(labels))!=len(labels):raise ValueError('Group display labels are ambiguous. Request a more specific grouping.')
    return labels


def _overview(fig,result,plan,data,settings):
    ax=fig.add_subplot(111);ax.set_axis_off()
    ax.set_xticks([]);ax.set_yticks([])
    title={'profile':'Imported table overview','find':'Matching records overview','summary':'Numeric summary overview',
        'histogram':'No finite histogram values','count_by':'No selected groups','scatter':'No finite pairs to plot'}[data['method']]
    if data['method']=='count_by' and data['rows']:title=f'Count table: {len(data["rows"])+data["omitted_groups"]:,} groups'
    ax.text(0.,.91,_safe_label(settings.get('title') or title,68),transform=ax.transAxes,
        ha='left',va='top',fontsize=settings['font_size']+2,fontweight='bold')
    lines=[f'{data["selected"]:,} selected source {_plural(data["selected"],"record")}',f'{data["total"]:,} imported source {_plural(data["total"],"record")}']
    if data['method']=='profile':lines.append(f'{len(data["rows"]):,} {_plural(len(data["rows"]),"column")} profiled')
    elif data['method']=='summary':lines.append(f'{len(data["rows"]):,} numeric {_plural(len(data["rows"]),"column")} summarized')
    elif data['method']=='find':lines.append(f'{len(data["rows"]):,} matching {_plural(len(data["rows"]),"record")} returned in the bounded Results table')
    elif data['method']=='count_by':lines.append(f'{len(data["rows"]):,} groups returned in the exact count table')
    ax.text(0.,.67,'\n'.join(lines),transform=ax.transAxes,ha='left',va='top',
        fontsize=settings['font_size']+1,linespacing=1.9)
    note=('Data overview only. Exact values are available in Results and exports.\n'
        'No inferential comparison or association is plotted.')
    if data['method']=='count_by' and len(data['rows'])>MAX_GROUPS:
        note=('The exact count table is available in Results and exports.\n'
            'Narrow the selection to at most 20 groups for a readable chart.')
    ax.text(0.,.22,note,transform=ax.transAxes,ha='left',va='top',fontsize=settings['font_size'],linespacing=1.6,color='#555B55')
    return ax


@_serialized_render
def make_large_figure(dataset,result,plan,style=None):
    plan,data=_validate(dataset,result,plan);settings=_style(plan,style)
    method=data['method'];color=PALETTES[settings['palette']][0]
    with mpl.rc_context(dict(RC,**{'font.size':settings['font_size']})):
        fig=Figure(figsize=(settings['width_mm']/25.4,settings['height_mm']/25.4),dpi=150,layout='constrained')
        footer=_footer(data);footer_font=max(8,settings['font_size']-.5)
        width=max(24,int(settings['width_mm']*.57*9/footer_font))
        footer=_safe_label(footer,width)
        footer_height=(footer.count('\n')+1)*footer_font*1.4*25.4/72+4
        fig.get_layout_engine().set(rect=(0,footer_height/settings['height_mm'],1,1-footer_height/settings['height_mm']),w_pad=.12,h_pad=.12)
        fig.text(.045,.025,footer,ha='left',va='bottom',fontsize=footer_font,color='#555B55',linespacing=1.35)
        if method in ('profile','summary','find') or not data['rows'] or (method=='count_by' and len(data['rows'])>MAX_GROUPS):
            ax=_overview(fig,result,plan,data,settings)
            form='text_overview'
        else:
            ax=fig.add_subplot(111)
            ax.tick_params(labelsize=max(8,settings['font_size']-.3))
            ax.spines['top'].set_visible(False);ax.spines['right'].set_visible(False)
            if method=='count_by':
                labels=_group_labels(data['rows']);line_count=sum(label.count('\n')+1 for label in labels)
                minimum=35+line_count*3.4*settings['font_size']/9
                if settings['height_mm']<minimum:
                    raise ValueError(f'These group labels need at least {math.ceil(minimum)} mm figure height. Increase the height or request fewer groups.')
                counts=[row['count'] for row in data['rows']];positions=np.arange(len(counts))
                ax.barh(positions,counts,height=.62,color=color,edgecolor='none')
                ax.set_yticks(positions,labels);ax.invert_yaxis();ax.set_xlim(0,max(counts)*1.18)
                for position,count in zip(positions,counts):
                    ax.annotate(f'{count:,}',(count,position),xytext=(5,0),textcoords='offset points',va='center',fontsize=max(8,settings['font_size']-.3),color='#303030')
                ax.xaxis.set_major_locator(MaxNLocator(nbins=5,integer=True));ax.xaxis.set_major_formatter(StrMethodFormatter('{x:,.0f}'))
                ax.set_xlabel(settings.get('xlabel') or 'Record count')
                if settings.get('ylabel'):ax.set_ylabel(_safe_label(settings['ylabel'],36))
                title=settings.get('title') or f'Records by {data["column"]}'
                form='horizontal_count_bars'
            elif method=='histogram':
                left=np.array([row['bin_left'] for row in data['rows']],dtype=float)
                right=np.array([row['bin_right'] for row in data['rows']],dtype=float)
                counts=np.array([row['count'] for row in data['rows']],dtype=int)
                ax.bar(left,counts,width=right-left,align='edge',color=color,edgecolor='white',linewidth=.35)
                ax.set_xlim(left[0],right[-1]);ax.set_ylim(bottom=0)
                ax.set_xlabel(_safe_label(settings.get('xlabel') or data['column'],60));ax.set_ylabel(settings.get('ylabel') or 'Record count per bin')
                ax.yaxis.set_major_locator(MaxNLocator(nbins=5,integer=True));ax.yaxis.set_major_formatter(StrMethodFormatter('{x:,.0f}'))
                ax.xaxis.set_major_locator(MaxNLocator(nbins=6));title=settings.get('title') or f'Distribution of {data["column"]}'
                form='full_data_count_histogram'
            else:
                x=np.array([row['x'] for row in data['rows']],dtype=float);y=np.array([row['y'] for row in data['rows']],dtype=float)
                ax.scatter(x,y,s=10,color=color,alpha=.55,edgecolors='none',rasterized=False)
                ax.set_xlabel(_safe_label(settings.get('xlabel') or data['x'],60));ax.set_ylabel(_safe_label(settings.get('ylabel') or data['y'],45))
                ax.xaxis.set_major_locator(MaxNLocator(nbins=6));ax.yaxis.set_major_locator(MaxNLocator(nbins=5));ax.margins(.06)
                title=settings.get('title') or f'{data["y"]} versus {data["x"]}'
                form='deterministic_scatter' if data['plotted']<data['finite'] else 'all_finite_pair_scatter'
            ax.set_title(_safe_label(title,max(30,int(settings['width_mm']*.42))),loc='left',fontsize=settings['font_size']+1.2,fontweight='bold',pad=12)
        FigureCanvasAgg(fig).draw()
        _assert_not_clipped(fig)
        renderer=fig.canvas.get_renderer()
        for text in [*fig.texts,*(text for axis in fig.axes for text in axis.texts)]:
            box=text.get_window_extent(renderer)
            if box.x0<0 or box.y0<0 or box.x1>fig.bbox.width or box.y1>fig.bbox.height:
                raise ValueError('The figure text does not fit at this size. Increase the figure dimensions.')
        if form!='text_overview' and ax.bbox.width<fig.bbox.width*.5:
            raise ValueError('The group labels leave too little space for the evidence. Increase the figure width or use fewer concise groups.')
        fig._statweave_style=settings
        fig._statweave_large_display={'form':form,'method':method,'selected_record_count':data['selected'],
            'source_record_count':data['total'],'plotted_record_count':data.get('plotted'),
            'finite_pair_count':data.get('finite') if method=='scatter' else None,'all_histogram_finite_values':method=='histogram',
            'source_values_modified':False,'analysis_rerun':False}
        fig._statweave_caption=_caption(dataset,result,plan,data)
        return fig
