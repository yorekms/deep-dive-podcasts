"""Bounded study-intake checks; no numerical analysis of a user's study."""
from copy import deepcopy
import json
from pathlib import Path
import time
import traceback
import zipfile

from .session import Session,sha256,canonical,verify_audit,versions


def require(condition,message):
    if not condition:raise ValueError(message)


def fixtures(directory):
    """Fabricated schema/metadata fixtures only, never biological observations."""
    from openpyxl import Workbook
    directory=Path(directory);directory.mkdir(parents=True,exist_ok=True)
    paths=[]
    for subject in (1,2):
        for trial in (1,2):
            path=directory/f'synthetic_#{subject}(label)_Trial{trial}.xlsx'
            book=Workbook();meta=book.active;meta.title='Metadata'
            meta.append(['Field','Value']);meta.append(['Internal animal ID',str(subject)])
            meta.append(['Pleth signal interpretation','Differential chamber-pressure waveform; not direct flow or direct volume'])
            summary=book.create_sheet('Summary')
            summary.append(['Condition','Condition_short','CO2_percent','Animal_ID','Weight_g','RR_bpm','VT_mL','MV_mL_per_min',
                            'VT_syringe_mL','MV_syringe_mL_per_min','Volume_calibrated','Syringe_calibrated','Thermobarometric_corrected'])
            for order,dose in enumerate((0,3,6,0),1):
                summary.append([f'synthetic Trial{trial} {dose}%',f'{dose}% ({order})',None,str(subject),None,None,None,None,None,None,False,True,False])
            breath=book.create_sheet('PerBreath');breath.append(['Condition','Animal_ID','RR_bpm','VT_mL','MV_mL_per_min'])
            marks=book.create_sheet('TextMarks');marks.append(['Time_s','Label']);marks.append([None,'synthetic metadata fixture'])
            book.save(path);paths.append(path)
    return paths


def check_export(output):
    folder=Path(output['folder']);manifest=json.loads((folder/'SHA256.json').read_text())
    for name,digest in manifest.items():
        path=(folder/name).resolve()
        require(path.is_relative_to(folder.resolve()) and path.is_file(),'Invalid export manifest entry')
        require(sha256(path)==digest,'Export checksum mismatch: '+name)
    with zipfile.ZipFile(output['archive']) as handle:require(handle.testzip() is None,'Export ZIP check failed')
    require(not (folder/'source').exists(),'Compact study export unexpectedly includes raw files')
    require(not list(folder.rglob('*.png')) and not list(folder.rglob('*.pdf')),'Planning export contains an unrequested scientific figure')
    return len(manifest)


def run(workspace,study_folder=None,live_model=False):
    root=Path(workspace).resolve();output=root/'study-self-test';output.mkdir(parents=True,exist_ok=True)
    report={'status':'running','checks':[],'environment':versions(),'input_scope':'explicit user folder' if study_folder else 'fabricated metadata fixtures'}
    try:
        paths=sorted(Path(study_folder).resolve().glob('*.xlsx')) if study_folder else fixtures(output/'synthetic-sources')
        require(bool(paths),'No XLSX files were provided for this intake check.')
        original={str(p):sha256(p) for p in paths}
        session=Session(root);started=time.monotonic();session.import_study(paths)
        report['import_seconds']=time.monotonic()-started
        require(session.is_study and not hasattr(session.dataset,'df') and session.result is None,'Study intake crossed the calculation boundary')
        manifest=session.dataset.manifest();report['source_count']=len(manifest['sources'])
        report['domain']=manifest['domain'];report['issues']=manifest['issues']
        report['checks'].append('multi_source_preservation_and_schema_intake_without_dataframe')
        commands=['show study','my goal is to plan a CO2-response comparison while preserving repeated measurements',
                  'show metadata conflicts','suggest analyses','discuss HCVR','plan figures']
        for text in commands:
            reply=session.command(text)
            require('prior study plan is retained' not in reply['message'].lower(),'Planning instruction failed: '+text+': '+reply['message'])
            require(session.result is None and not session.context['study_state']['approved_plan'],'Planning performed or approved a calculation')
        report['checks'].append('goal_questions_candidate_methods_and_figure_proposals')
        state=deepcopy(session.context['study_state'])
        for text in ['run an HCVR analysis','remove outliers to improve significance']:
            session.command(text);require(canonical(session.context['study_state'])==canonical(state),'Execution/pruning request changed the plan')
        report['checks'].append('execution_and_pruning_do_not_fall_through_to_engine')
        profile='synthetic-study-'+str(time.time_ns())
        for text in ['save import profile '+profile,'apply import profile '+profile]:
            reply=session.command(text);require('prior study plan is retained' not in reply['message'].lower(),'Profile instruction failed')
        report['checks'].append('schema_profile_without_subject_or_group_transfer')
        if live_model:
            from .llm import OllamaPlanner
            settings=root/'statweave-settings.json'
            require(settings.is_file(),'A live model check requires enabled settings in the chosen workspace.')
            config=json.loads(settings.read_text());require(config.get('enabled') is True,'Local model use is not enabled.')
            model=OllamaPlanner(config.get('base_url','http://127.0.0.1:11434'),config['model'],timeout=config.get('timeout',120))
            model.configured_model_digest=config.get('model_digest')
            before=deepcopy(session.context['study_state']);phase=time.monotonic()
            reply=session.command('Ask local AI: How would you help me choose between a CO2 response curve and an HCVR slope, and which metadata should we clarify first?',model=model)
            events=[json.loads(line) for line in (session.project_dir/'history.jsonl').read_text().splitlines()]
            matched=[e for e in events if e['type']=='model_plan_supplied' and e['payload'].get('input_type')=='study']
            require(matched and matched[-1]['payload']['plan'].get('action')=='study_discuss','The local model did not return a validated study discussion: '+reply['message'])
            require(session.result is None,'The model discussion produced a numerical result')
            for key in ['groups','subject_resolutions','session_resolutions','mapping_confirmed','approved_plan','selected_methods','goal']:
                require(session.context['study_state'].get(key)==before.get(key),'The model changed a confirmed planning field')
            report['local_model']={'model':model.model,'configured_digest':model.configured_model_digest,'seconds':time.monotonic()-phase,
                                   'action':matched[-1]['payload']['plan']['action'],'message':reply['message'],'confirmed_fields_unchanged':True}
            report['checks'].append('actual_local_model_discussion_without_calculation_or_confirmation')
        saved_state=deepcopy(session.context);project=session.save()
        reopened=Session(root);reopened.open_project(project);session=reopened
        require(session.context==saved_state and session.result is None,'Reopened planning state changed')
        report['checks'].append('study_reopen_exact_planning_state')
        result=session.export_bundle();report['export']=result;report['verified_export_files']=check_export(result)
        report['checks'].append('compact_plan_export_manifest_and_zip')
        for path,digest in original.items():require(sha256(path)==digest,'Original input changed')
        session._assert_integrity(full=True);head,count=verify_audit(session.project_dir/'history.jsonl',session.last_hash)
        report.update(status='passed',source_unchanged=True,calculations_performed=False,project=project,
                      audit_events=count,audit_head=head,commands=commands,
                      limits='Intake/planning only. No numerical user-study analysis, new HCVR or Bayesian routine, or scientific figure was run.')
        (output/'result.json').write_text(json.dumps(report,indent=2,ensure_ascii=False,allow_nan=False))
        return report
    except Exception as error:
        report.update(status='failed',error=str(error),traceback=traceback.format_exc())
        (output/'result.json').write_text(json.dumps(report,indent=2,ensure_ascii=False))
        raise
