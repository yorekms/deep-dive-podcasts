"""Native conversational AP measurement, review and folder-workflow verification."""
from pathlib import Path
import hashlib
import json
import shutil
import time
import traceback
from PySide6.QtCore import QTimer


def schedule(window,app,workspace,abf_path):
    source=Path(abf_path).resolve();target=Path(workspace).resolve()/'ui-ap-self-test'
    target.mkdir(parents=True,exist_ok=True);inputs=target/'inputs';inputs.mkdir(exist_ok=True)
    for name in ['cell-a.abf','cell-b.ABF']:shutil.copy2(source,inputs/name)
    other=source.parent/'16d22006_kim_gapfree.abf'
    if other.exists():shutil.copy2(other,inputs/'different-protocol.abf')
    before=hashlib.sha256(source.read_bytes()).hexdigest()
    commands=['show channel 1 full sweep','overlay sweeps 1 through 2',
        'measure action potential amplitude half-width and inter-spike intervals',
        'show analysis plan','show measurements for peak ch1-sw1-p2547','set baseline window to 3 ms',
        'analyze spikes from 100 to 900 ms','show full sweep',
        'exclude region from 100 to 150 ms on channel 1 sweep 1 because review demonstration only',
        'reject peak ch1-sw2-p876 because review demonstration only',
        'restore peak ch1-sw2-p876 because waveform checked for demonstration',
        'reject peak ch1-sw2-p876 because deliberate review demonstration, not a biological classification',
        'set the title to AP review demonstration',
        'save pipeline as "Current clamp demonstration"',
        f'check folder "{inputs}"',f'run pipeline on folder "{inputs}"',
        'export pipeline figures','export as SVG']
    steps=[lambda:window.open_path(source)]+[lambda text=text:window.send(text) for text in commands]
    state={'index':0,'idle':0,'deadline':time.monotonic()+180}
    timer=QTimer(window);window._ap_selftest_timer=timer
    def tick():
        try:
            if time.monotonic()>state['deadline']:raise AssertionError('AP desktop workflow timed out')
            if window.busy or window._after_work:state['idle']=0;return
            state['idle']+=1
            if state['idle']<3:return
            state['idle']=0
            if state['index']<len(steps):steps[state['index']]();state['index']+=1;return
            session=window.session
            assert session.plan['method']=='action_potentials'
            assert session.plan['measurements']['baseline_window_ms']==3
            assert len(session.plan['excluded_regions'])==1
            assert len(session.plan['event_decisions'])==3
            assert len(session.result['events'])==13
            assert session.result['ap_accounting']['excluded_channel_samples']==1000
            assert len(window.figure.axes)>=2
            assert 'mV' in window.figure.axes[0].get_ylabel()
            assert window.last_export and Path(window.last_export['figure']).is_file()
            assert Path(window.last_export['folder'],'review-decisions.json').is_file()
            batch=Path(session.context['last_batch']);report=json.loads((batch/'batch.json').read_text())
            assert sum(r['status']=='completed' for r in report['files'])==2
            assert len(report['exports'])==2 and all(e['status']=='exported' for e in report['exports'])
            for row in report['files']:
                if row['status']=='completed':
                    project=json.loads(Path(row['project']).read_text())
                    assert len(project['result']['events'])==15
                    assert project['plan']['event_decisions']==[] and project['plan']['excluded_regions']==[]
            assert hashlib.sha256(source.read_bytes()).hexdigest()==before
            session._assert_integrity()
            window.grab().save(str(target/'desktop.png'))
            output={'status':'passed','commands':commands,'events':len(session.result['events']),
                'source_sha256':before,'source_unchanged':True,'plan':session.plan,
                'excluded_channel_samples':session.result['ap_accounting']['excluded_channel_samples'],
                'export':window.last_export,'batch_dir':str(batch),'batch_report':report,
                'screenshot':str(target/'desktop.png')}
            (target/'result.json').write_text(json.dumps(output,indent=2))
            timer.stop();app.quit()
        except Exception as error:
            timer.stop();(target/'result.json').write_text(json.dumps({'status':'failed','error':str(error),'traceback':traceback.format_exc()},indent=2));app.exit(1)
    timer.timeout.connect(tick);timer.start(50)
