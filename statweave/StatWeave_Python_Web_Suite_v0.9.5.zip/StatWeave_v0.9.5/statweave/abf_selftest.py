"""Bounded real-file ABF checks for the standalone app. No automatic downloads."""
from pathlib import Path
import hashlib,json
from .session import Session,versions,sha256
from .figures import make_figure


def run(workspace,examples_dir):
    examples=Path(examples_dir).resolve()
    root=Path(workspace).resolve()/'abf-self-test'
    manifest=json.loads((examples/'SOURCES.json').read_text())
    reports=[]
    for item in manifest['items']:
        path=examples/item['filename']
        if not path.is_file():raise ValueError('Download the public fixtures explicitly first: '+str(path))
        assert sha256(path)==item['sha256']
        session=Session(root)
        session.import_file(path)
        assert session.is_recording
        response=session.command('show all channels')
        assert response.get('refresh'),response
        figure=make_figure(session.dataset,session.result,session.plan,session.style)
        assert len(figure.axes)==len(session.dataset.channels)
        if len(session.dataset.sweeps)>1:
            response=session.command('overlay sweeps 1 through 2')
            assert response.get('refresh'),response
        before=sha256(session.dataset.source_path)
        session.command('remove sweep 1')
        assert sha256(session.dataset.source_path)==before
        saved=session.save()
        other=Session(root);other.open_project(saved)
        assert other.plan==session.plan
        reports.append({'file':item['filename'],'source_sha256':before,
                        'channels':len(session.dataset.channels),'sweeps':len(session.dataset.sweeps),
                        'sampled_duration_s':session.dataset.metadata()['sampled_duration_s'],
                        'elapsed_duration_s':session.dataset.metadata()['elapsed_duration_s'],'status':'passed'})
    selected=Session(root)
    selected.import_file(examples/'17o05027_ic_ramp.abf')
    selected.command('overlay sweeps 1 through 2')
    output=selected.export_bundle()
    export_root=Path(output['folder'])
    for name,digest in json.loads((export_root/'SHA256.json').read_text()).items():
        assert sha256(export_root/name)==digest
    report={'status':'passed','fixtures':reports,'environment':versions(),'export':output,
            'scope':'Real public fixture import, channel/sweep plotting, source preservation, project reopening, local export and manifest integrity. No signal inference or filtering.'}
    root.mkdir(parents=True,exist_ok=True)
    (root/'result.json').write_text(json.dumps(report,indent=2))
    return report
