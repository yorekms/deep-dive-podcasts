"""Native ordinary-language study workflow using explicitly synthetic fixtures."""
from copy import deepcopy
import json
from pathlib import Path
import time
import traceback

from PySide6.QtCore import QTimer

from .execution_selftest import fixtures, require, setup_commands, verify_export
from .session import sha256, verify_audit, versions
from .study_bridge import result_is_current
from .study_display import display_result


def schedule(window, app, workspace):
    output = Path(workspace).resolve() / 'ui-natural-study-self-test'
    output.mkdir(parents=True, exist_ok=True)
    paths = fixtures(output / 'synthetic-sources')
    originals = {str(path): sha256(path) for path in paths}
    config = dict(window.config)
    window.config = {**config, 'enabled': False}
    window.update_mode()
    window.last_export = None
    started = time.monotonic()
    state = {'step': 0, 'idle': 0, 'checks': [], 'ticks': 0}
    steps = []
    timer = QTimer(window)
    window._natural_study_selftest_timer = timer

    def loaded():
        require(window.session.is_study and window.session.result is None, 'Synthetic study intake failed')
        for text in setup_commands(window.session):
            steps.append(lambda value=text: window.send(value))
        steps.extend([
            lambda: window.send('Can you give me figures and descriptives for all available measures?'), proposed,
            lambda: window.send('Yes, run that'), calculated,
            lambda: window.send('did we run any statistics?'), status_answered,
            lambda: window.send('Show me the respiratory frequency figure'), focused,
            lambda: window.send('Can we show the response as a percentage of baseline?'), normalization_proposed,
            lambda: window.send('not yet'), proposal_cancelled,
            lambda: window.send('Can you export the figures and tables?'),
        ])

    def proposed():
        session = window.session
        require(session.result is None, 'An ordinary analysis request ran before agreement')
        require(session.context['study_execution'].get('conversation_proposal'), 'Natural request did not produce a bound proposal')
        state['checks'].append('ordinary_request_shows_proposal_without_calculating')

    def calculated():
        session = window.session
        require(session.result and session.result.get('report'), 'Natural agreement did not run the displayed report')
        require(result_is_current(session), 'New result does not match reviewed choices')
        require(window.canvas.isVisible(), 'Calculated figures were not displayed')
        state['result'] = deepcopy(session.result)
        state['run_count'] = len(session.context['study_execution']['runs'])
        state['checks'].append('direct_user_agreement_runs_displayed_exact_recipe')

    def status_answered():
        session = window.session
        message = session.conversation[-1]['text'].lower()
        require('descriptive statistics' in message and 'group hypothesis test' in message, 'Saved-status answer did not distinguish descriptives and inference')
        require(session.result == state['result'], 'Status question changed the calculated result')
        require(len(session.context['study_execution']['runs']) == state['run_count'], 'Status question reran an analysis')
        state['checks'].append('saved_status_grounded_without_model_or_calculation')

    def focused():
        session = window.session
        require(session.context.get('study_figure_focus') == 'RR_bpm', 'Natural figure request did not focus respiratory frequency')
        require(display_result(session)['plot_data']['endpoint']['column'] == 'RR_bpm', 'Figure preview did not select the saved measure')
        require(session.result == state['result'] and result_is_current(session), 'Figure selection changed scientific results or choices')
        require(len(session.context['study_execution']['runs']) == state['run_count'], 'Viewing a saved figure reran an analysis')
        state['checks'].append('cached_measure_figure_shown_without_replacing_report')

    def normalization_proposed():
        session = window.session
        pending = session.context['study_execution'].get('conversation_proposal')
        require(pending and pending['options']['normalization'] == 'percent_baseline', 'Ordinary baseline request did not preview the requested normalization')
        require(session.result == state['result'] and result_is_current(session), 'Unapproved normalization changed the saved analysis')
        state['checks'].append('changed_scientific_choice_proposed_before_execution')

    def proposal_cancelled():
        session = window.session
        require(not session.context['study_execution'].get('conversation_proposal'), 'Not-yet reply did not withdraw the proposal')
        require(session.result == state['result'], 'Withdrawing a proposal changed the previous result')
        require(len(session.context['study_execution']['runs']) == state['run_count'], 'A declined proposal was calculated')
        state['checks'].append('natural_decline_keeps_prior_result_and_run_history')

    def finish():
        session = window.session
        require(window.last_export and window.last_export.get('input_type') == 'study_execution', 'Natural export request did not produce calculated outputs')
        file_count = verify_export(window.last_export)
        require(all(sha256(path) == digest for path, digest in originals.items()), 'Synthetic original source bytes changed')
        session._assert_integrity(full=True)
        head, event_count = verify_audit(session.project_dir / 'history.jsonl', session.last_hash)
        screenshot = output / 'desktop.png'
        require(window.grab().save(str(screenshot)), 'Native screenshot failed')
        report = {'status': 'passed', 'scope': 'Synthetic native ordinary-language workflow; no private study calculation or live model',
                  'seconds': time.monotonic() - started, 'event_loop_ticks': state['ticks'],
                  'checks': state['checks'] + ['natural_export_with_manifest_readback', 'original_sources_and_audit_preserved'],
                  'source_count': len(paths), 'figure_count': window.last_export['figure_count'],
                  'verified_export_files': file_count, 'audit_head': head, 'audit_events': event_count,
                  'project': str(session.project_dir / 'project.json'), 'export': window.last_export,
                  'screenshot': str(screenshot), 'environment': versions()}
        (output / 'result.json').write_text(json.dumps(report, indent=2, ensure_ascii=False))
        timer.stop()
        window.config = config
        app.quit()

    steps.extend([lambda: window.open_study_paths(paths), loaded])

    def tick():
        state['ticks'] += 1
        try:
            require(time.monotonic() - started < 240, 'Native natural-conversation check timed out')
            if window.busy or window._after_work:
                state['idle'] = 0
                return
            state['idle'] += 1
            if state['idle'] < 3:
                return
            state['idle'] = 0
            if state['step'] < len(steps):
                operation = steps[state['step']]
                state['step'] += 1
                operation()
                return
            finish()
        except Exception as error:
            timer.stop()
            window.config = config
            (output / 'result.json').write_text(json.dumps({'status': 'failed', 'step': state['step'],
                'checks': state['checks'], 'error': str(error), 'traceback': traceback.format_exc()}, indent=2))
            app.exit(1)

    timer.timeout.connect(tick)
    timer.start(50)
