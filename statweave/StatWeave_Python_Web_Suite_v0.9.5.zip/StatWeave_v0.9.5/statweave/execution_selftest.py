"""Bounded synthetic end-to-end execution/figure/export/reproduction check."""
from copy import deepcopy
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import zipfile

import openpyxl


def fixtures(directory):
    directory=Path(directory);directory.mkdir(parents=True,exist_ok=True)
    paths=[]
    for subject in range(1,5):
        for trial in range(1,3):
            path=directory/f'mouse{subject}_Trial{trial}.xlsx'
            book=openpyxl.Workbook();metadata=book.active;metadata.title='Metadata'
            for row in [['Field','Value'],['Internal animal ID',str(subject)],
                        ['Pleth signal interpretation','Synthetic differential chamber-pressure waveform'],
                        ['Syringe calibrated','Yes'],['Thermobarometric corrected','No']]:metadata.append(row)
            summary=book.create_sheet('Summary')
            summary.append(['Condition','Condition_short','CO2_percent','Animal_ID','Start_s','End_s',
                'RR_bpm','VT_syringe_mL','MV_syringe_mL_per_min','VT_mL','MV_mL_per_min',
                'Volume_calibrated','Syringe_calibrated','Thermobarometric_corrected','Ti_s','Te_s',
                'Tr_s','VT_raw_units','PIF_syringe_mL_per_s','PEF_syringe_mL_per_s','Pause','PenH',
                'LegacyPause_TeTi','LegacyPenH_TeTi','Breaths','Clipped_breaths_rejected','Duration_s','Weight_g'])
            for index,dose in enumerate([0,3,6,0]):
                value=100+subject*9+trial*3+dose*(2+subject)
                summary.append([f'synthetic protocol {dose}%',f'epoch{index} {dose}%',None,str(subject),
                    index*100,index*100+50,value,.02+subject*.001+dose*.001,value/20,None,None,
                    False,True,False,.08+subject*.002,.12+dose*.003,.03,.2+subject*.01,
                    .3+dose*.01,.25+dose*.01,.4,.6,.5,.7,round(value*50/60),0,50,20+subject])
            breath=book.create_sheet('PerBreath');breath.append(['Breath','Start_s','End_s','Condition','Animal_ID'])
            breath.append([1,0,1,'SYNTHETIC; never read by Summary execution',str(subject)])
            book.save(path);paths.append(path)
    return paths


def setup_commands(session):
    """Every scientific choice below is explicit synthetic-fixture setup."""
    commands=['my goal is to describe all available synthetic pleth measures while retaining repeated trials']
    for source in session.dataset.manifest()['sources']:
        sid=source['source_id'];subject=source['proposed_subject']['value'];trial=source['proposed_session']['value']
        if subject is None or trial is None:raise ValueError('Synthetic identities were not proposed.')
        commands.extend([f'resolve source {sid} subject as {subject}',f'resolve source {sid} session as {trial}'])
    commands+=['group subjects 1, 2 as Reference','group subjects 3, 4 as Variant',
        'pool trials equally within subject','confirm study mapping','experimental unit is subject',
        'report all available measures','propose protocol windows','review execution recipe']
    return commands


def require(value,message):
    if not value:raise ValueError(message)


def verify_export(output):
    from .session import sha256
    folder=Path(output['folder']);hashes=json.loads((folder/'SHA256.json').read_text())
    require(all(sha256(folder/name)==value for name,value in hashes.items()),'Export file checksum failed')
    with zipfile.ZipFile(output['archive']) as archive:require(archive.testzip() is None,'Export ZIP CRC failed')
    return len(hashes)


def run(workspace,reproduce=False):
    from .session import Session,sha256,verify_audit,versions
    from .study_bridge import result_is_current
    root=Path(workspace).resolve();output=root/'execution-self-test';output.mkdir(parents=True,exist_ok=True)
    report={'status':'running','scope':'Synthetic fixtures only; no private study analysis','environment':versions()}
    started=time.monotonic()
    try:
        paths=fixtures(output/'synthetic-sources');original={str(path):sha256(path) for path in paths}
        session=Session(root);session.import_study(paths)
        for command in setup_commands(session):
            reply=session.command(command);require('prior study plan is retained' not in reply['message'].lower(),command+': '+reply['message'])
        require(session.result is None,'Recipe review performed a calculation')
        before=deepcopy(session.context);reply=session.command('run agreed analysis')
        require(session.result is None and session.context==before,'Unapproved run changed state or executed')
        session.command('confirm execution recipe');require(session.result is None,'Recipe confirmation performed a calculation')
        reply=session.command('run agreed analysis');require(session.result and session.result.get('report'),reply['message'])
        require(result_is_current(session),'New report is stale')
        measures=session.result['measures'];executed=[m for m in measures if m['status']=='executed']
        require(len(executed)>=10,'Too few available synthetic measures received results')
        require(any(m['outcome']=='MV_mL_per_min' and m['status']!='executed' for m in measures),'Missing physiological MV was fabricated')
        require(all(not m['result'].get('comparison') for m in executed),'All-measure report performed automatic group tests')
        value=deepcopy(session.result);saved=session.save();reopened=Session(root);reopened.open_project(saved);session=reopened
        require(session.result==value and result_is_current(session),'Reopen changed calculated results')
        frozen=session.project_dir/session.context['study_execution']['runs'][-1]['directory']/'reproduction-source/statweave/study_execution.py'
        require(frozen.is_file(),'Execution implementation was not frozen with run')
        oldstyle=deepcopy(session.style);session.command('do not use blue');require(session.style==oldstyle,'Negated style request applied')
        session.command('show confidence intervals');require(session.style==oldstyle,'CI request silently substituted SD')
        session.command('use blue');require(session.style['palette']=='blue' and session.result==value,'Style changed numerical results or failed')
        # A compact export remains independently reproducible with original snapshots.
        exported=session.export_bundle();report['export']=exported;report['verified_export_files']=verify_export(exported)
        require(not (Path(exported['folder'])/'source').exists(),'Compact export included raw data')
        if reproduce:
            interpreter=sys.executable if not getattr(sys,'frozen',False) else os.environ.get('STATWEAVE_REPRO_PYTHON','python3')
            completed=subprocess.run([interpreter,str(Path(exported['folder'])/'reproduce.py'),'--source-project',str(session.project_dir)],
                capture_output=True,text=True,timeout=240)
            require(completed.returncode==0,'Independent numerical reproduction failed: '+completed.stdout+completed.stderr)
            report['independent_reproduction']='passed'
        session.command('remember that this is a synthetic test of preserving prior calculated results')
        require(session.result==value and not result_is_current(session),'Changed scientific context erased or relabelled historical results')
        reply=session.command('run agreed analysis');require('prior study plan is retained' in reply['message'].lower() and session.result==value,'Changed scientific choices reused old approval')
        for path,digest in original.items():require(sha256(path)==digest,'Original fixture changed')
        session._assert_integrity(full=True);head,count=verify_audit(session.project_dir/'history.jsonl',session.last_hash)
        report.update(status='passed',seconds=time.monotonic()-started,source_count=len(paths),measure_count=len(measures),
            executed_measures=len(executed),blocked_or_unavailable=len(measures)-len(executed),
            original_sources_unchanged=True,unapproved_run_blocked=True,no_automatic_group_tests=True,
            historical_results_retained=True,run_implementation_frozen=True,project=str(session.project_dir/'project.json'),
            audit_head=head,audit_events=count)
    except Exception as error:
        import traceback
        report.update(status='failed',error=str(error),traceback=traceback.format_exc())
        (output/'result.json').write_text(json.dumps(report,indent=2));raise
    (output/'result.json').write_text(json.dumps(report,indent=2,ensure_ascii=False));return report
