"""Restricted recording views and explicit threshold-based spike plans."""
from copy import deepcopy
import math
import re


def recording_help():
    return ('ABF viewing commands use channel and sweep numbers starting at 1. '
            'Try “show channel 1 from 0 to 1 seconds”, “overlay sweeps 1 through 2”, '
            '“show full sweep”, “show full recording”, “use recording time”, “show metadata”, '
            '“make it blue”, “set the title to Membrane voltage”, or “export as SVG”. '
            'Spike commands: “detect spikes”, “detect spikes on channel 1 using threshold -20 mV and refractory 2 ms”, “measure firing rate by sweep”, “firing rate in 100 ms bins”, or “set spike threshold to -10 mV”. The explicit detector defaults are -20 mV, 2 ms refractory, and 0.1 s firing-rate bins; it requires a voltage channel. “Show raw trace” returns to a trace-only view. Raw samples stay unchanged. This version does not filter signals, detect synaptic events, '
            'or treat waveform samples as independent statistical observations.')


def _indices(text,label):
    # Consume the entire selection phrase so trailing ranges are not discarded.
    pattern=rf'\b{label}s?(?![A-Za-z])\s*(.+?)(?=\s+(?:from|for|full|whole|entire|using|with|in|on|at|versus|against|over|plot|show|sweeps?|channels?|overlay)\b|$)'
    if label=='sweep':text=re.sub(r'\bsweep\s+time\b',' ',text,flags=re.I)
    match=re.search(pattern,text,re.I)
    if not match:return None
    phrase=match.group(1).strip().rstrip('.')
    values=[]
    for part in re.split(r'\s*(?:,|\band\b)\s*',phrase,flags=re.I):
        span=re.fullmatch(r'(\d+)\s*(?:-|through|to)\s*(\d+)',part,re.I)
        if span:
            first,last=map(int,span.groups())
            if last<first:raise ValueError(f'The {label} range is reversed.')
            if last-first>100:raise ValueError(f'Select a smaller {label} range.')
            values.extend(range(first,last+1))
        elif re.fullmatch(r'\d+',part):values.append(int(part))
        else:raise ValueError(f'Use whole-number {label} selections, for example {label} 1 or {label}s 1 through 3.')
    if any(x<1 for x in values):raise ValueError(f'{label.capitalize()} numbers start at 1 in conversation.')
    if len(set(values))!=len(values):raise ValueError(f'Duplicate {label} numbers are not a new recording view.')
    return [x-1 for x in values]


def _interpret_trace(text,recording,previous_plan=None):
    from .planner import _parse_style
    low=text.casefold().strip()
    if re.search(r'\b(?:help|commands|examples)\b',low):
        return {'action':'help','message':recording_help(),'unsupported':True}
    if re.search(r'\b(?:metadata|information|info|list channels|list sweeps|describe|summari[sz]e)\b',low):
        meta=recording.metadata()
        lines=[f'ABF recording: {len(recording.channels)} channels, {len(recording.sweeps)} sweeps/segments.',
               'Channels and sweeps are numbered from 1 in conversation.']
        for channel in recording.channels:
            lines.append(f"Channel {channel['index']+1}: {channel['name']} ({channel['unit'] or 'unit unavailable'}), {channel['sampling_rate_hz']:g} Hz.")
        for sweep in recording.sweeps[:12]:
            lines.append(f"Sweep {sweep['index']+1}: start {sweep['start_s']:g} s, duration {sweep['duration_s']:g} s, {sweep['sample_count']:,} samples/channel.")
        lines.extend(recording.warnings)
        return {'action':'help','message':'\n'.join(lines),'unsupported':True}
    style=_parse_style(text)
    if style and (set(style)&{'title','xlabel','ylabel'} or re.match(r'^(?:please\s+)?(?:set|change|make|label|title|colou?r)\b',low)):
        return {'action':'style','style':style,'message':'I will update the trace presentation. Raw recording samples remain unchanged.'}
    if re.search(r'\b(?:remove|delete|exclude|drop|prune|discard|trim|hide)\b',low):
        return {'action':'blocked','message':'No recording channels, sweeps or samples were deleted or excluded. To inspect a subset without changing the source, use “show channel 1” or select explicit sweep numbers.','unsupported':True}
    if re.search(r'\b(?:except|excluding|other than|apart from)\b',low):
        return {'action':'help','message':'Exclusion syntax is not supported for recording views. Name the channels or sweeps you want to view explicitly; the full raw recording stays preserved.','unsupported':True}
    if re.search(r'\b(?:filter|smooth|resample|decimate|baseline|detect|spikes?|events?|spectrum|fft|power|mean|median|rms|statistics|test|compare|anova|correlation|regression)\b',low):
        return {'action':'help','message':'This ABF version provides raw trace inspection and figure export. Signal processing, waveform measurements and inferential statistics need separate verified routines; no processing or statistical test was run. '+recording_help(),'unsupported':True}
    style=_parse_style(text)
    explicit_view=bool(re.search(r'\b(?:show|plot|trace|overlay|view|channel|sweep|recording time|sweep time|full recording|full sweep|entire)\b',low))
    if style and not explicit_view:
        return {'action':'style','style':style,'message':'I will update the trace presentation. The recording samples remain unchanged.'}
    if not explicit_view:
        return {'action':'help','message':'I could not safely translate that recording request. '+recording_help(),'unsupported':True}
    plan=deepcopy(previous_plan) if previous_plan and previous_plan.get('method')=='trace' else {'channels':[0],'sweeps':[0]}
    plan.update(action='trace',method='trace')
    try:
        channels=list(range(len(recording.channels))) if re.search(r'\ball channels\b',low) else _indices(text,'channel')
        sweeps=list(range(len(recording.sweeps))) if re.search(r'\ball sweeps\b',low) else _indices(text,'sweep')
    except ValueError as error:
        return {'action':'help','message':str(error),'unsupported':True}
    if channels is not None:plan['channels']=channels
    if sweeps is not None:plan['sweeps']=sweeps
    if re.search(r'\ball channels\b',low):plan['channels']=list(range(len(recording.channels)))
    if re.search(r'\ball sweeps\b|\b(?:full|entire|whole) recording\b',low):plan['sweeps']=list(range(len(recording.sweeps)))
    time_match=re.search(r'\bfrom\s+(-?\d+(?:\.\d+)?)\s*(ms|milliseconds?|s|seconds?)?\s+(?:to|through|-)\s*(-?\d+(?:\.\d+)?)\s*(ms|milliseconds?|s|seconds?)?\b',low)
    if time_match:
        first,u1,last,u2=time_match.groups()
        scale=.001 if (u2 or u1 or 's').startswith('m') else 1.
        scale1=.001 if (u1 or u2 or 's').startswith('m') else 1.
        plan['start_s']=float(first)*scale1;plan['end_s']=float(last)*scale
    elif re.search(r'\bfrom\b|\bbetween\b',low):
        return {'action':'help','message':'Give an explicit time window, for example “show channel 1 from 0 to 1 seconds”.','unsupported':True}
    if re.search(r'\b(?:full|entire|whole)\s+(?:sweep|recording|trace)\b',low):
        plan['start_s']=0.;plan['end_s']=None
    if re.search(r'\b(?:recording time|absolute time|full recording|entire recording|whole recording)\b',low):plan['time_reference']='recording'
    elif re.search(r'\boverlay\b|\bsweep time\b',low):plan['time_reference']='sweep'
    if time_match and plan.get('time_reference')=='recording':
        selected=plan.get('sweeps',[0])
        if len(selected)!=1:
            return {'action':'help','message':'For a recording-relative time window, select one sweep explicitly. Overlay windows use within-sweep time; “show full recording” retains all true sweep starts and gaps.','unsupported':True}
        index=selected[0]
        if not 0<=index<len(recording.sweeps):
            return {'action':'help','message':'That sweep is unavailable. Sweep numbering starts at 1.','unsupported':True}
        origin=recording.sweeps[index]['start_s']
        plan['start_s']-=origin;plan['end_s']-=origin
    if style:plan['style']=style
    plan['message']='I will show the selected raw recording window. No filtering, baseline correction, resampling or statistical inference is applied.'
    return plan

_NUMBER = r'[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:e[-+]?\d+)?'
_TIME_UNIT = r'(?:milliseconds?|ms|seconds?|s)'
_CONNECTOR = r'(?:(?:and|using|with)\s+)?'


def _spike_intent(text):
    return bool(re.search(r'\b(?:spikes?|spike detection|firing[ -]rates?|refractory|(?:spike\s+)?threshold|bin width|bin size)\b',text,re.I))


def _failure(message):
    return {'action':'help','message':message,'unsupported':True}


def _extract_spike_parameters(text):
    """Remove only explicit, unit-bearing parameters; retain unknown text."""
    found={};counts={}
    def take(key,number,unit):
        counts[key]=counts.get(key,0)+1
        if counts[key]>1:raise ValueError(f'Specify {key.replace("_"," ")} only once per instruction.')
        value=float(number)
        if not math.isfinite(value):raise ValueError('Detector parameters must be finite numbers.')
        if key!='threshold_mv' and value<=0:raise ValueError('Refractory period and firing-rate bin width must be greater than zero.')
        if key=='refractory_ms':value*=1. if unit.startswith('m') else 1000.
        if key=='bin_width_s':value*=.001 if unit.startswith('m') else 1.
        found[key]=value
        return ' '
    threshold=rf'\b{_CONNECTOR}(?:spike\s+)?threshold\s*(?:(?:to|of|at|is|=|:)\s*)?({_NUMBER})\s*(mv)\b'
    refractory=rf'\b{_CONNECTOR}refractory(?:\s+period)?\s*(?:(?:to|of|at|is|=|:)\s*)?({_NUMBER})\s*({_TIME_UNIT})\b'
    bin_prefix=rf'\b{_CONNECTOR}bin(?:ning)?(?:\s+(?:width|size))?\s*(?:(?:to|of|at|is|=|:)\s*)?({_NUMBER})\s*({_TIME_UNIT})\b'
    bin_suffix=rf'(?<!\w)({_NUMBER})\s*({_TIME_UNIT})\s+(?:wide\s+)?bins?\b'
    clean=re.sub(threshold,lambda m:take('threshold_mv',m.group(1),m.group(2)),text,flags=re.I)
    clean=re.sub(refractory,lambda m:take('refractory_ms',m.group(1),m.group(2)),clean,flags=re.I)
    clean=re.sub(bin_prefix,lambda m:take('bin_width_s',m.group(1),m.group(2)),clean,flags=re.I)
    clean=re.sub(bin_suffix,lambda m:take('bin_width_s',m.group(1),m.group(2)),clean,flags=re.I)
    if re.search(r'\bthreshold\b',clean):raise ValueError('Specify one numeric spike threshold with explicit mV units, for example “threshold -20 mV”. Other threshold units or extra threshold parameters are not supported.')
    if re.search(r'\brefractory\b',clean):raise ValueError('Specify one positive refractory period with explicit ms or seconds, for example “refractory 2 ms”.')
    if re.search(r'\bbins?\b|\bbinning\b',clean):raise ValueError('Specify one positive firing-rate bin width with explicit ms or seconds, for example “firing rate in 100 ms bins”.')
    return clean,found


def _strict_spike_language(text):
    """Account for the whole instruction, including numeric selection phrases."""
    clean=re.sub(r'\b(?:by|per)\s+sweep\b',' ',text,flags=re.I)
    clean=re.sub(r'\b(?:recording time|absolute time|sweep time)\b',' ',clean,flags=re.I)
    clean=re.sub(r'\b(?:full|whole|entire)\s+(?:recording|sweeps?|trace)\b',' ',clean,flags=re.I)
    clean=re.sub(r'\ball\s+(?:channels|sweeps)\b',' ',clean,flags=re.I)
    window=rf'\bfrom\s+({_NUMBER})\s*(ms|milliseconds?|s|seconds?)?\s+(?:to|through|-)\s*({_NUMBER})\s*(ms|milliseconds?|s|seconds?)?\b'
    matches=list(re.finditer(window,clean,re.I))
    if len(matches)>1:raise ValueError('Specify only one time window per instruction.')
    clean=re.sub(window,' ',clean,flags=re.I)
    for label in ['channel','sweep']:
        pattern=rf'\b{label}s?(?![A-Za-z])\s*(.+?)(?=\s+(?:from|for|full|whole|entire|using|with|in|on|at|versus|against|over|plot|show|sweeps?|channels?|overlay)\b|$)'
        match=re.search(pattern,clean,re.I)
        if match:
            _indices(clean,label)  # Validate the entire numerical phrase before removing it.
            clean=clean[:match.start()]+' '+clean[match.end():]
    clean=re.sub(r'\b(?:spike detection|firing[ -]rates?|action potentials?)\b',' ',clean,flags=re.I)
    clean=re.sub(r'\b(?:detect|find|count|identify|mark|show|plot|measure|calculate|estimate|compute|set|change|use|overlay|view|spikes?|raw|trace|recording|window|please|the|a|an|on|in|for|with|using|and|of|to|at|by|per|only|current|selected)\b',' ',clean,flags=re.I)
    clean=re.sub(r'[\s,.:!?]+',' ',clean).strip()
    if clean:raise ValueError('I could not safely interpret this part of the spike request: '+clean+'. No detector setting or analysis was changed. Use explicit channel/sweep numbers, one time window, threshold in mV, refractory period, and firing-rate bin width.')


def _interpret_spikes(text,recording,previous_plan=None):
    low=text.casefold()
    if re.search(r"\b(?:do\s+not|don['’]?t|dont|never|not|without|no|stop|cancel|avoid|disable|omit)\b",low):
        return _failure('This instruction negates or disables part of spike detection. No new spike analysis or detector-setting change was requested safely. Use “show raw trace” for a trace-only view, or state the detector settings you want to apply.')
    if re.search(r'\b(?:filter(?:ing)?|smooth(?:ing)?|resampl(?:e|ing)|decimat(?:e|ion|ing)|baseline|detrend|denois\w*|bandpass|highpass|lowpass|high[ -]pass|low[ -]pass|prominence|negative spikes?|negative[ -]going|downward|polarity|amplitude|rise time|decay|derivative|slope|synaptic|events?|spectrum|fft|power|mean|median|rms|statistics|test|compare|anova|correlation|regression|export|save)\b',low):
        return _failure('This spike command supports upward voltage-threshold crossings with an explicit refractory period and firing-rate bins. Requested filtering, baseline changes, negative-going spikes, prominence/shape criteria, other event detectors, statistical tests or combined export actions are not implemented here. No part of this combined request was run.')
    if ';' in text or re.search(r'\b(?:then|followed by|after that)\b',low):
        return _failure('Give one recording or detector instruction at a time. No part of this multi-step request was run.')
    try:
        clean,parameters=_extract_spike_parameters(low)
        clean=re.sub(r'\b(?:by|per)\s+sweep\b',' ',clean,flags=re.I)
        # Parameters and their connectors have been removed, so their numbers
        # cannot be accidentally consumed as channel/sweep selections.
        _strict_spike_language(clean)
        view_text=re.sub(r'\b(?:spike detection|firing[ -]rates?|action potentials?|spikes?|detect|find|count|identify|mark|measure|calculate|estimate|compute|set|change)\b',' ',clean,flags=re.I)
        view_text='show trace '+view_text
        previous=deepcopy(previous_plan) if previous_plan and previous_plan.get('method') in ('trace','spikes') else {'channels':[0],'sweeps':[0]}
        previous.update(action='trace',method='trace')
        view=_interpret_trace(view_text,recording,previous)
        if view.get('action')!='trace':return view
        channels=view.get('channels',[0])
        if any(not 0<=i<len(recording.channels) for i in channels):return _failure('That recording channel is unavailable. Channel numbering starts at 1.')
        voltage_units={'v','mv','uv','µv','μv'}
        invalid=[i for i in channels if str(recording.channels[i].get('unit','')).strip().casefold() not in voltage_units]
        if invalid:
            available=[str(i+1) for i,c in enumerate(recording.channels) if str(c.get('unit','')).strip().casefold() in voltage_units]
            detail=', '.join(f"{i+1} ({recording.channels[i].get('unit') or 'unit unavailable'})" for i in invalid)
            suggestion=('Available voltage channels: '+', '.join(available)+'. Try “detect spikes on channel '+available[0]+'”.') if available else 'This file has no channel with recognized voltage units.'
            return _failure('Spike detection requires voltage-recorded channels. Selected non-voltage channel(s): '+detail+'. '+suggestion+' No channel was selected automatically.')
        detector={'threshold_mv':-20.0,'refractory_ms':2.0}
        if previous_plan and previous_plan.get('method')=='spikes':detector.update(deepcopy(previous_plan.get('detector',{})))
        for key in ['threshold_mv','refractory_ms']:
            if key in parameters:detector[key]=parameters[key]
        bins=parameters.get('bin_width_s',previous_plan.get('bin_width_s',.1) if previous_plan and previous_plan.get('method')=='spikes' else .1)
        view.update(action='spikes',method='spikes',detector=detector,bin_width_s=bins)
        view.setdefault('start_s',0.)
        if 'end_s' not in view:
            selected=view.get('sweeps',[0])
            durations=[recording.sweeps[i]['duration_s'] for i in selected if 0<=i<len(recording.sweeps)]
            view['end_s']=min(10.,min(durations)) if durations else None
        view.setdefault('time_reference','sweep')
        end='end of each sweep' if view['end_s'] is None else f"{view['end_s']:g} s within each sweep"
        view['message']=(f"I will detect upward voltage-threshold crossings at {detector['threshold_mv']:g} mV with a {detector['refractory_ms']:g} ms refractory period and {bins:g} s firing-rate bins. "
            f"Selected channel(s): {', '.join(str(i+1) for i in channels)}; sweep(s): {', '.join(str(i+1) for i in view.get('sweeps',[0]))}. "
            f"Window: {view['start_s']:g} s to {end}; {view['time_reference']}-relative display. Raw samples remain unchanged; no filtering, baseline correction or inferential test is applied.")
        return view
    except (ValueError,TypeError,KeyError) as error:return _failure(str(error))


def interpret_recording(text,recording,previous_plan=None):
    """Select raw views or explicitly specified, restricted spike detection."""
    from .planner import _parse_style
    if not isinstance(text,str) or not text.strip():return _failure(recording_help())
    text=text.translate(str.maketrans({'−':'-','–':'-','’':"'"})).strip()
    low=text.casefold()
    style=_parse_style(text)
    # Figure labels are literal presentation text, even if they contain words
    # such as “detected spikes”, “mean”, or “firing rate”.
    if style and set(style)&{'title','xlabel','ylabel'}:
        return {'action':'style','style':style,'message':'I will update the trace presentation. Raw recording samples remain unchanged.'}
    raw_switch=bool(re.match(r'^(?:please\s+)?(?:show|plot|view|use)\s+(?:the\s+)?raw\s+(?:traces?|recording)\b',low))
    intent=_spike_intent(low)
    if raw_switch and intent:return _failure('Request either a raw trace view or spike detection in one instruction, then give the next instruction separately.')
    previous_spikes=previous_plan and previous_plan.get('method')=='spikes'
    view_intent=bool(re.search(r'\b(?:show|plot|trace|overlay|view|channel|sweep|recording time|sweep time|full recording|full sweep|entire)\b',low))
    if intent or (previous_spikes and view_intent and not raw_switch):
        try:
            presentation_text,_=_extract_spike_parameters(low)
        except ValueError as error:return _failure(str(error))
        # A firing-rate bin width is not a figure width. Inspect appearance only
        # after unit-bearing detector parameters are accounted for.
        detector_style=_parse_style(presentation_text)
        if detector_style:return _failure('Change figure appearance and detector settings in separate instructions; no partial change was applied.')
        return _interpret_spikes(text,recording,previous_plan)
    if raw_switch and previous_spikes:
        previous={k:deepcopy(v) for k,v in previous_plan.items() if k not in ('detector','bin_width_s')}
        previous.update(action='trace',method='trace')
        return _interpret_trace(text,recording,previous)
    return _interpret_trace(text,recording,previous_plan)
