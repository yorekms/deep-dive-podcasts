"""Read-only ABF recordings with calibrated, bounded signal access.

Neo AxonRawIO maps raw acquisition buffers and applies channel gain/offset only
when a requested chunk is read. This module never filters, reconstructs commands,
changes samples, or infers a biological experimental unit.
"""
from __future__ import annotations

from copy import deepcopy
import hashlib
import math
from pathlib import Path
import struct
import warnings as pywarnings

import numpy as np
from neo.rawio import AxonRawIO

MAX_WINDOW_SAMPLES = 5_000_000
MAX_CHUNK_SAMPLES = 1_000_000
MAX_SWEEPS = 100_000
MAX_CHANNELS = 256
MODES = {1: 'event-driven variable-length', 2: 'event-driven fixed-length',
         3: 'gap-free', 5: 'episodic stimulation'}


def _hash(path):
    digest = hashlib.sha256()
    with path.open('rb') as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def _preflight(path):
    """Bound header-controlled tables and reject bad signatures/truncation early."""
    size = path.stat().st_size
    with path.open('rb') as handle:
        prefix = handle.read(min(size, 6144))
    if len(prefix) < 512 or prefix[:4] not in (b'ABF ', b'ABF2'):
        raise ValueError('This is not a complete ABF1 or ABF2 recording header.')
    if prefix[:4] == b'ABF2':
        if len(prefix) < 76 + 18 * 16:
            raise ValueError('The ABF2 section table is truncated.')
        sections = []
        for index in range(18):
            block, width, count = struct.unpack_from('<IIq', prefix, 76 + index * 16)
            if count < 0:
                raise ValueError('The ABF2 section table contains a negative entry count.')
            if count and (not width or block * 512 + width * count > size):
                raise ValueError('An ABF2 section extends beyond the file; the recording is truncated or corrupt.')
            sections.append((block, width, count))
        # ADC and synchronization table entries must not create unbounded objects.
        if not 1 <= sections[1][2] <= MAX_CHANNELS:
            raise ValueError('The ABF2 channel count is missing or exceeds the supported limit.')
        if sections[15][2] > MAX_SWEEPS:
            raise ValueError('The recording has too many sweeps for this version.')
    else:
        channels = struct.unpack_from('<h', prefix, 120)[0]
        sweeps = struct.unpack_from('<i', prefix, 96)[0]
        if not 1 <= channels <= MAX_CHANNELS or not 0 <= sweeps <= MAX_SWEEPS:
            raise ValueError('The ABF1 channel or sweep count is invalid or exceeds the supported limit.')


def _index(value, count, label):
    if isinstance(value, (bool, np.bool_)) or not isinstance(value, (int, np.integer)):
        raise ValueError(f'{label} index must be an integer; internal indices start at zero.')
    value = int(value)
    if not 0 <= value < count:
        raise ValueError(f'{label} index {value} is outside the recording; choose 0 through {count - 1}.')
    return value


def _finite(value, label):
    if isinstance(value, (bool, np.bool_)):
        raise ValueError(f'{label} must be a finite time in seconds.')
    try:
        number = float(value)
    except (TypeError, ValueError, OverflowError):
        raise ValueError(f'{label} must be a finite time in seconds.') from None
    if not math.isfinite(number):
        raise ValueError(f'{label} must be a finite time in seconds.')
    return number


class ABFRecording:
    kind = 'recording'

    def __init__(self, path):
        source = Path(path).expanduser().resolve()
        if not source.is_file():
            raise ValueError(f'The ABF recording does not exist: {source}')
        if source.suffix.casefold() != '.abf':
            raise ValueError('Open an Axon Binary Format recording with an .abf extension.')
        self.source_path = str(source)
        self.warnings = []
        self._source_stat = (source.stat().st_size, source.stat().st_mtime_ns)
        _preflight(source)
        try:
            reader = AxonRawIO(filename=str(source))
            with pywarnings.catch_warnings(record=True) as caught:
                pywarnings.simplefilter('always')
                reader.parse_header()
            self.warnings.extend(str(item.message) for item in caught)
            if reader.block_count() != 1:
                raise ValueError('This version supports one ABF acquisition block per file.')
            streams = reader.header['signal_streams']
            if len(streams) != 1:
                raise ValueError('This ABF has multiple signal streams; this version will not silently combine them.')
            header_channels = reader.header['signal_channels']
            if not 1 <= len(header_channels) <= MAX_CHANNELS:
                raise ValueError('No usable channels were found, or the channel count is unsupported.')
            info = reader._axon_info
            mode = int(info.get('nOperationMode', info.get('protocol', {}).get('nOperationMode', -1)))
            if mode not in MODES:
                raise ValueError(f'ABF acquisition mode {mode} is not supported.')
            self.abf_version = round(float(info['fFileVersionNumber']), 4)
            if self.abf_version < 2:
                sequence = [int(v) for v in info['nADCSamplingSeq'] if int(v) >= 0]
                if len(sequence) != len(header_channels) or len(set(sequence)) != len(sequence):
                    raise ValueError('The ABF1 channel sampling sequence is inconsistent; channel calibration cannot be trusted.')
            self.acquisition_mode = MODES[mode]
            self.mode_code = mode
            rates = np.asarray(header_channels['sampling_rate'], dtype=float)
            if not np.isfinite(rates).all() or (rates <= 0).any() or not np.allclose(rates, rates[0], rtol=0, atol=1e-8):
                raise ValueError('Channels do not share a supported finite sampling rate.')
            self.channels = []
            for index, channel in enumerate(header_channels):
                unit = str(channel['units']).strip()
                name = str(channel['name']).strip() or f'Channel {index + 1}'
                gain, offset = float(channel['gain']), float(channel['offset'])
                if not math.isfinite(gain) or not math.isfinite(offset) or gain == 0:
                    raise ValueError(f'Channel {index + 1} has invalid calibration metadata.')
                if not unit:
                    self.warnings.append(f'Channel {index + 1} has no recorded unit; no voltage/current unit is assumed.')
                self.channels.append({'index': index, 'name': name, 'unit': unit,
                    'sampling_rate_hz': float(rates[index]), 'id': str(channel['id']),
                    'calibration_gain': gain, 'calibration_offset': offset,
                    'raw_dtype': str(channel['dtype'])})
            self.sweeps = []
            count = reader.segment_count(0)
            if not 1 <= count <= MAX_SWEEPS:
                raise ValueError('No usable sweeps were found, or the sweep count is unsupported.')
            rate = float(rates[0])
            for index in range(count):
                samples = int(reader.get_signal_size(0, index, 0))
                start = float(reader.get_signal_t_start(0, index, 0))
                if samples <= 0 or not math.isfinite(start) or start < 0:
                    raise ValueError(f'Sweep {index + 1} has invalid sample count or start time.')
                self.sweeps.append({'index': index, 'start_s': start, 'duration_s': samples / rate,
                                    'sample_count': samples})
            declared_values = int(info['lActualAcqLength']) if self.abf_version < 2 else int(info['sections']['DataSection']['llNumEntries'])
            mapped_values = sum(s['sample_count'] for s in self.sweeps) * len(self.channels)
            if declared_values != mapped_values:
                raise ValueError('ABF header sample accounting does not match the sweep/channel layout. Reading stopped rather than dropping unaccounted samples.')
            self._raw_values_declared = declared_values
            self._reader = reader
            self._recorded_datetime = info.get('rec_datetime')
            # Event tags remain annotations; command waveforms are not inferred.
            self.events = []
            if len(reader.header.get('event_channels', [])):
                times, _, labels = reader.get_event_timestamps(0, 0, 0)
                seconds = reader.rescale_event_timestamp(times, dtype='float64', event_channel_index=0)
                comments = getattr(reader, '_ev_comments', [])
                for i, (time, label) in enumerate(zip(seconds, labels)):
                    if np.isfinite(time):
                        self.events.append({'time_s': float(time), 'type': str(label),
                            'comment': str(comments[i]) if i < len(comments) else ''})
            self.warnings.append('Raw recorded signals only: no filtering, baseline correction, command-waveform reconstruction, or event detection is applied.')
            if mode == 1:
                self.warnings.append('Variable-length event acquisition: sweep lengths and header-derived start times are retained separately.')
        except ValueError:
            raise
        except Exception as error:
            raise ValueError(f'The ABF recording could not be read safely: {error}') from error
        self.source_hash = _hash(source)
        if (source.stat().st_size, source.stat().st_mtime_ns) != self._source_stat:
            raise ValueError('The ABF file changed while it was being opened. Open a stable recording copy.')

    def metadata(self):
        # This is a header label only, not proof that stimulus waveforms match.
        from pathlib import PureWindowsPath
        protocol = getattr(self._reader, '_axon_info', {}).get('sProtocolPath')
        if isinstance(protocol, bytes):
            protocol = protocol.decode('utf-8', errors='replace')
        protocol_name = PureWindowsPath(str(protocol).replace('\x00','')).name if protocol else None
        return {'input_type': 'recording', 'format': 'ABF', 'source_path': self.source_path,
            'source_hash': self.source_hash, 'file_size_bytes': self._source_stat[0],
            'abf_version': self.abf_version, 'acquisition_mode': self.acquisition_mode,
            'protocol_name': protocol_name,
            'acquisition_mode_code': self.mode_code, 'channels': deepcopy(self.channels),
            'sweeps': deepcopy(self.sweeps), 'channel_count': len(self.channels),
            'sweep_count': len(self.sweeps),
            'raw_values_declared': self._raw_values_declared,
            'sampled_duration_s': sum(s['duration_s'] for s in self.sweeps),
            'elapsed_duration_s': max(s['start_s'] + s['duration_s'] for s in self.sweeps),
            'recorded_datetime': self._recorded_datetime.isoformat() if self._recorded_datetime else None,
            'events': deepcopy(self.events), 'warnings': list(dict.fromkeys(self.warnings)),
            'time_origin': 'Header-derived sweep starts in seconds from acquisition origin; samples use within-sweep indices.',
            'signal_processing': 'none', 'command_waveforms': 'not reconstructed'}

    def _selection(self, channel_index, sweep_index, start_s, end_s):
        channel = _index(channel_index, len(self.channels), 'Channel')
        sweep = _index(sweep_index, len(self.sweeps), 'Sweep')
        spec = self.sweeps[sweep]
        start = _finite(start_s, 'Start time')
        stop = spec['duration_s'] if end_s is None else _finite(end_s, 'End time')
        tolerance = max(1e-12, np.finfo(float).eps * max(1.0, spec['duration_s']) * 8)
        if start < -tolerance or stop > spec['duration_s'] + tolerance or start > spec['duration_s'] + tolerance:
            raise ValueError(f'The time window is outside sweep {sweep + 1} (0 to {spec["duration_s"]:g} seconds).')
        start = max(0.0, min(start, spec['duration_s']))
        stop = max(0.0, min(stop, spec['duration_s']))
        if stop <= start:
            raise ValueError('Choose a nonempty time window with end after start.')
        rate = self.channels[channel]['sampling_rate_hz']
        # ceil selects only sample timestamps in the half-open requested interval.
        # The small ULP tolerance prevents e.g. 0.3*10000 from dropping a boundary.
        def ceil_sample(seconds):
            point = seconds * rate
            return int(math.ceil(point - max(1e-10, abs(point) * 4 * np.finfo(float).eps)))
        first, last = ceil_sample(start), ceil_sample(stop)
        first, last = max(0, first), min(spec['sample_count'], last)
        if first >= last:
            raise ValueError('No acquired samples fall inside that time window.')
        current = Path(self.source_path).stat()
        if (current.st_size, current.st_mtime_ns) != self._source_stat:
            raise ValueError('The preserved ABF file has changed since import. Reading stopped.')
        return channel, sweep, first, last

    def _read_samples(self, channel, sweep, first, last):
        try:
            raw = self._reader.get_analogsignal_chunk(block_index=0, seg_index=sweep,
                i_start=first, i_stop=last, stream_index=0, channel_indexes=[channel])
            values = self._reader.rescale_signal_raw_to_float(raw, dtype='float64',
                stream_index=0, channel_indexes=[channel])[:, 0]
        except Exception as error:
            raise ValueError(f'The requested ABF samples could not be read: {error}') from error
        if len(values) != last - first:
            raise ValueError('The ABF reader returned an incomplete signal window.')
        indices = np.arange(first, last, dtype=np.int64)
        rate = self.channels[channel]['sampling_rate_hz']
        return {'time_s': indices / rate, 'values': np.asarray(values), 'sample_indices': indices,
            'channel_index': channel, 'sweep_index': sweep, 'channel_name': self.channels[channel]['name'],
            'unit': self.channels[channel]['unit'], 'sampling_rate_hz': rate,
            'recording_start_s': self.sweeps[sweep]['start_s']}

    def read_window(self, channel_index=0, sweep_index=0, start_s=0.0, end_s=None):
        channel, sweep, first, last = self._selection(channel_index, sweep_index, start_s, end_s)
        if last - first > MAX_WINDOW_SAMPLES:
            raise ValueError('This full-resolution request exceeds five million samples. Select a shorter window or use chunked preview access.')
        return self._read_samples(channel, sweep, first, last)

    def iter_window_chunks(self, channel_index=0, sweep_index=0, start_s=0.0, end_s=None, chunk_samples=65536):
        if isinstance(chunk_samples, (bool, np.bool_)) or not isinstance(chunk_samples, (int, np.integer)) or not 1 <= chunk_samples <= MAX_CHUNK_SAMPLES:
            raise ValueError(f'Chunk size must be an integer from 1 to {MAX_CHUNK_SAMPLES:,} samples.')
        channel, sweep, first, last = self._selection(channel_index, sweep_index, start_s, end_s)
        for begin in range(first, last, int(chunk_samples)):
            yield self._read_samples(channel, sweep, begin, min(begin + int(chunk_samples), last))
