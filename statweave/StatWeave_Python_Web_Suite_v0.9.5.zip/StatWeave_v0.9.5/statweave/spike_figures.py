"""Stored voltage-event overlays and firing-rate figures.

Detection is never rerun by this module. Raw-waveform display reduction is used
only for the backdrop; every accepted event is drawn from its stored full-
resolution peak coordinates, and rate bins are drawn from the result tables.
"""
from __future__ import annotations

from copy import deepcopy
from pathlib import Path
from weakref import WeakKeyDictionary
import math
import re
import numpy as np
import matplotlib as mpl
from matplotlib.figure import Figure
from matplotlib.backends.backend_agg import FigureCanvasAgg
from matplotlib.lines import Line2D
from matplotlib.ticker import MaxNLocator

from .figures import RC, PALETTES, _style, _safe_label, _assert_not_clipped, _serialized_render
from .trace_figures import validate_trace_plan, _selection_rows, _display_trace, _channel, _sweep

MAX_PEAK_MARKERS = 100_000
MAX_RATE_BINS = 50_000
_DISPLAY_CACHE = WeakKeyDictionary()


def _finite(value, label):
    if isinstance(value, (bool, np.bool_)):
        raise ValueError(f'{label} must be a finite number.')
    try:
        value=float(value)
    except (TypeError, ValueError, OverflowError):
        raise ValueError(f'{label} must be a finite number.') from None
    if not math.isfinite(value):
        raise ValueError(f'{label} must be a finite number.')
    return value


def _integer(value, label, minimum=0):
    if isinstance(value,(bool,np.bool_)) or not isinstance(value,(int,np.integer)) or int(value)<minimum:
        raise ValueError(f'{label} must be an integer of at least {minimum}.')
    return int(value)


def _voltage_factor(unit):
    # Use the detector's exact unit handling when its implementation is present.
    from .spikes import voltage_factor_to_mv
    return voltage_factor_to_mv(unit)


def _normalize(recording,plan):
    if not isinstance(plan,dict) or plan.get('method','spikes')!='spikes':
        raise ValueError('A spike figure requires a stored spike-detection analysis.')
    traced=validate_trace_plan(recording,{**deepcopy(plan),'action':'trace','method':'trace'})
    traced.update(action='spikes',method='spikes')
    detector=deepcopy(plan.get('detector') or {})
    threshold=_finite(detector.get('threshold_mv',plan.get('threshold_mv',-20.)), 'Detection threshold')
    refractory=_finite(detector.get('refractory_ms',plan.get('refractory_ms',2.)), 'Refractory interval')
    width=_finite(plan.get('bin_width_s',.1), 'Firing-rate bin width')
    if refractory<0 or width<=0:
        raise ValueError('The refractory interval must be nonnegative and firing-rate bins must have positive duration.')
    traced['detector']={**detector,'threshold_mv':threshold,'refractory_ms':refractory}
    traced['bin_width_s']=width
    for index in traced['channels']:
        _voltage_factor(str(_channel(recording,index).get('unit') or ''))
    return traced


def _signature(plan):
    return (tuple(plan['channels']),tuple(plan['sweeps']),plan['start_s'],plan['end_s'],
            plan['detector']['threshold_mv'],plan['detector']['refractory_ms'],plan['bin_width_s'])


def _validate_result(recording,result,plan):
    if not isinstance(result,dict) or result.get('method')!='spikes':
        raise ValueError('The result is not a stored spike-detection analysis.')
    stored=_normalize(recording,result.get('plan',{}))
    current=_normalize(recording,plan)
    if _signature(stored)!=_signature(current):
        raise ValueError('The recording window or detector settings changed. Rerun spike detection before plotting those settings.')
    source_hash=result.get('source_sha256',result.get('source_hash'))
    if source_hash not in (None,'','unavailable') and source_hash!=getattr(recording,'source_hash',None):
        raise ValueError('These detected events belong to a different recording source.')
    selections={(r['channel'],r['sweep']):r for r in _selection_rows(recording,current)}
    events=result.get('events')
    if not isinstance(events,list):
        raise ValueError('The stored result has no accepted-event list.')
    if len(events)>MAX_PEAK_MARKERS:
        raise ValueError(f'This view contains more than {MAX_PEAK_MARKERS:,} accepted events. Select a shorter interval; peak markers will not be silently subsampled.')
    by_trace={key:[] for key in selections}
    for event in events:
        if not isinstance(event,dict) or event.get('accepted') is False:
            raise ValueError('The accepted-event list contains an invalid or rejected event.')
        channel=_integer(event.get('channel'),'Event channel',1)
        sweep=_integer(event.get('sweep'),'Event sweep',1)
        key=(channel,sweep)
        if key not in selections:
            raise ValueError('A stored event lies outside the selected channel or sweep.')
        spec=selections[key];rate=spec['sampling_rate_hz']
        crossing=_integer(event.get('crossing_sample_index'),'Crossing sample index')
        peak=_integer(event.get('peak_sample_index'),'Peak sample index')
        if not spec['first_sample_index']<=crossing<=peak<spec['stop_sample_index']:
            raise ValueError('A stored event lies outside the selected sample window.')
        ct=_finite(event.get('crossing_time_s'),'Crossing time')
        pt=_finite(event.get('peak_time_s'),'Peak time')
        if not math.isclose(ct,crossing/rate,rel_tol=1e-9,abs_tol=1e-9) or not math.isclose(pt,peak/rate,rel_tol=1e-9,abs_tol=1e-9):
            raise ValueError('Stored event times do not agree with the recorded sample indices.')
        origin=spec['recording_sweep_start_s']
        for name,expected in [('recording_crossing_time_s',origin+ct),('recording_peak_time_s',origin+pt)]:
            if not math.isclose(_finite(event.get(name),name),expected,rel_tol=1e-9,abs_tol=1e-9):
                raise ValueError('Stored recording-relative event times do not match the sweep origin.')
        unit=str(_channel(recording,channel-1).get('unit') or '')
        if event.get('unit')!=unit:
            raise ValueError('A stored event has different amplitude units from its source channel.')
        value=_finite(event.get('peak_value'),'Peak amplitude')
        mv=_finite(event.get('peak_mv'),'Peak amplitude in mV')
        if not math.isclose(value*_voltage_factor(unit),mv,rel_tol=1e-7,abs_tol=1e-8):
            raise ValueError('Stored peak amplitudes have inconsistent voltage scaling.')
        if mv<current['detector']['threshold_mv']-1e-9:
            raise ValueError('A stored accepted peak is below the requested detection threshold.')
        by_trace[key].append(event)
    bins=None
    for table in result.get('tables',[]):
        if table.get('title')=='Binned firing rate':
            bins=table.get('rows');break
    if not isinstance(bins,list) or len(bins)>MAX_RATE_BINS:
        raise ValueError('The stored firing-rate bins are missing or too numerous for this figure. Select a shorter interval or wider rate bins.')
    rates={key:[] for key in selections}
    for row in bins:
        if not isinstance(row,dict):raise ValueError('A firing-rate row is invalid.')
        key=(_integer(row.get('channel'),'Rate channel',1),_integer(row.get('sweep'),'Rate sweep',1))
        if key not in selections:raise ValueError('A firing-rate bin lies outside the selected channel or sweep.')
        start=_finite(row.get('start_s'),'Rate-bin start');end=_finite(row.get('end_s'),'Rate-bin end')
        duration=_finite(row.get('duration_s'),'Rate-bin duration')
        count=_integer(row.get('spike_count'),'Rate-bin spike count')
        rate=_finite(row.get('firing_rate_hz'),'Firing rate')
        selection=selections[key]
        sample_start=selection['first_sample_index']/selection['sampling_rate_hz']
        sample_end=selection['stop_sample_index']/selection['sampling_rate_hz']
        if end<=start or duration<=0 or start<sample_start-1e-9 or end>sample_end+1e-9:
            raise ValueError('A firing-rate bin has invalid bounds or lies outside the selected interval.')
        if not math.isclose(duration,end-start,rel_tol=1e-7,abs_tol=1e-9) or not math.isclose(rate,count/duration,rel_tol=1e-7,abs_tol=1e-9):
            raise ValueError('A stored firing rate does not equal its event count divided by its recorded bin duration.')
        rates[key].append(row)
    for key,rows in rates.items():
        rows.sort(key=lambda row:row['start_s'])
        if not rows:raise ValueError('A selected trace has no firing-rate bins.')
        for left,right in zip(rows,rows[1:]):
            if right['start_s']<left['end_s']-1e-9:
                raise ValueError('Stored firing-rate bins overlap.')
        if sum(row['spike_count'] for row in rows)!=len(by_trace[key]):
            raise ValueError('Stored firing-rate counts do not match the accepted events in this trace.')
    return current,by_trace,rates,selections


def _rate_path(rows,offset):
    """Piecewise-constant bins; no bridge over an uncovered interval."""
    times=[];values=[];last=None
    for row in rows:
        start=float(row['start_s'])+offset;end=float(row['end_s'])+offset
        if last is not None and start>last+1e-9:
            times.append((last+start)/2);values.append(np.nan)
        times.extend((start,end));values.extend((float(row['firing_rate_hz']),)*2)
        last=end
    return np.asarray(times),np.asarray(values)


def _sweep_encoding(order,colors):
    color=colors[0] if order==0 else colors[1+((order-1)//4)%(len(colors)-1)]
    # Redundant style distinction starts at the second sweep, so the common
    # two-sweep overlay remains interpretable in grayscale as well as color.
    line='-' if order==0 else ['--',':','-.','-'][(order-1)%4]
    return color,line


def _caption(recording,result,plan,display=None):
    detector=plan['detector']
    text=(f'Voltage-threshold event detection and binned firing rate for {Path(recording.source_path).name}. '
          f'Channels {", ".join(str(i+1) for i in plan["channels"])}; '
          f'sweeps {", ".join(str(i+1) for i in plan["sweeps"])}. ')
    if plan['end_s'] is None:
        text+=f'Window: {plan["start_s"]:g} s through the end of each selected sweep. '
    else:text+=f'Window: {plan["start_s"]:g}–{plan["end_s"]:g} s within each selected sweep. '
    text+=(f'The detector uses completed upward excursions across {detector["threshold_mv"]:g} mV with a '
           f'{detector["refractory_ms"]:g} ms refractory setting. '
           'Black triangles mark all stored accepted peaks at their original sampled amplitudes and times; '
           'the dashed horizontal line is the voltage threshold, converted to each channel’s recorded units. '
           'Events incomplete at the selected window boundaries are omitted by the detector and are not marked. ')
    text+=f'{len(result["events"]):,} accepted events are shown. '
    text+=(f'Firing-rate bins were requested at {plan["bin_width_s"]:g} s; each plotted rate is the stored accepted-event count '
           'divided by that bin’s actual sampled duration in seconds, including a shorter final bin when present. '
           'Rates are in spikes/s; no smoothing or uncertainty interval is applied. ')
    selections=_selection_rows(recording,plan)
    exposures=[(s['stop_sample_index']-s['first_sample_index'])/s['sampling_rate_hz'] for s in selections]
    text+='Actual sampled exposure per channel/sweep trace: '+', '.join(f'{duration:g} s' for duration in exposures)+'. '
    text+='Rate panels follow acquired-sample edges, which may extend less than one sampling interval beyond requested time limits. '
    text+='Time is within-sweep; separate sweeps are overlaid without concatenation. ' if plan['time_reference']=='sweep' else 'Time is recording-relative using actual sweep origins; no line is drawn between sweeps or their acquisition gaps. '
    if display:
        text+=f'The voltage backdrop represents {sum(d["source_sample_count"] for d in display):,} selected channel-samples. '
        reduced=[d for d in display if d.get('reduced')]
        if reduced:
            text+='Its display-only min/max envelope retains extrema and finite-run endpoints; bin counts: '+', '.join(str(d['bin_count']) for d in reduced)+'. '
        else:text+='The voltage backdrop is displayed at full sample resolution. '
    else:
        text+='Long voltage backdrops use the trace renderer’s bounded display-only min/max envelope. '
    text+=('Detection is not rerun during plotting or styling and does not use the reduced backdrop. '
           'No filtering or baseline correction is applied here. The raw recording remains preserved. '
           'These threshold-defined events require scientific review; sample, sweep and event counts are not independent biological replicates or an inferential test.')
    return text


def spike_caption(recording,result,plan,style=None):
    normalized,_,_,_=_validate_result(recording,result,plan)
    _style(normalized,style)
    try:
        display=_DISPLAY_CACHE.get(recording,{}).get(_signature(normalized)+(normalized['time_reference'],))
    except TypeError:
        display=None
    return _caption(recording,result,normalized,display)


@_serialized_render
def make_spike_figure(recording,result,plan,style=None):
    plan,events,rates,selections=_validate_result(recording,result,plan)
    settings=_style(plan,style)
    channels=plan['channels'];minimum_height=65 if len(channels)==1 else 15+42*len(channels)
    if settings['height_mm']<minimum_height:
        raise ValueError(f'{len(channels)} channels need at least {minimum_height:g} mm figure height for readable voltage and rate panels. Increase height or select fewer channels.')
    colors=PALETTES[settings['palette']]
    with mpl.rc_context(dict(RC,**{'font.size':settings['font_size']})):
        fig=Figure(figsize=(settings['width_mm']/25.4,settings['height_mm']/25.4),dpi=150,layout='constrained')
        fig.get_layout_engine().set(w_pad=.10,h_pad=.10,hspace=.10)
        grid=fig.add_gridspec(2*len(channels),1,height_ratios=[2,1]*len(channels))
        axes=[];displays=[];handles=[];labels=[]
        first_axis=None
        for ch_position,channel in enumerate(channels):
            voltage=fig.add_subplot(grid[2*ch_position,0],sharex=first_axis)
            if first_axis is None:first_axis=voltage
            firing=fig.add_subplot(grid[2*ch_position+1,0],sharex=first_axis)
            axes.extend((voltage,firing))
            ch=_channel(recording,channel);unit=str(ch.get('unit') or '')
            for order,sweep in enumerate(plan['sweeps']):
                key=(channel+1,sweep+1)
                x,y,account=_display_trace(recording,channel,sweep,plan['start_s'],plan['end_s'])
                offset=float(_sweep(recording,sweep)['start_s']) if plan['time_reference']=='recording' else 0.
                color,line=_sweep_encoding(order,colors)
                artist,=voltage.plot(x+offset,y,color=color,linestyle=line,linewidth=.65,alpha=.9,label=f'Sweep {sweep+1}')
                account.update(channel=channel+1,sweep=sweep+1)
                displays.append(account)
                accepted=events[key]
                # Stored full-resolution coordinates: never sample peak markers
                # from a display envelope and never run the detector here.
                px=[event['peak_time_s']+offset for event in accepted]
                py=[event['peak_value'] for event in accepted]
                voltage.scatter(px,py,marker='^',s=13,facecolor='#111111',edgecolor='white',linewidth=.25,zorder=5)
                rx,ry=_rate_path(rates[key],offset)
                firing.plot(rx,ry,color=color,linestyle=line,linewidth=1.1 if order==0 else .9)
                if ch_position==0:
                    handles.append(artist);labels.append(f'Sweep {sweep+1}')
            threshold=plan['detector']['threshold_mv']/_voltage_factor(unit)
            voltage.axhline(threshold,color='#777C77',linewidth=.75,linestyle='--',zorder=1)
            y_label=settings.get('ylabel') or str(ch['name'])
            if not re.search(r'[\[(]\s*'+re.escape(unit)+r'\s*[\])]',y_label):y_label+=f' ({unit})'
            voltage.set_ylabel(_safe_label(y_label,25),fontsize=settings['font_size'])
            firing.set_ylabel('Firing rate\n(spikes/s)',fontsize=settings['font_size'])
            firing.set_ylim(bottom=0)
            firing.yaxis.set_major_locator(MaxNLocator(nbins=3,min_n_ticks=2))
            voltage.yaxis.set_major_locator(MaxNLocator(nbins=4))
            for ax in (voltage,firing):
                ax.spines['top'].set_visible(False);ax.spines['right'].set_visible(False)
                ax.tick_params(labelsize=max(8,settings['font_size']-.3))
                ax.xaxis.set_major_locator(MaxNLocator(nbins=6))
                ax.margins(x=.01,y=.12)
            if len(channels)>1:
                voltage.set_title(f'Channel {channel+1} · {ch["name"]}',loc='left',fontsize=settings['font_size'],pad=6)
            voltage.tick_params(labelbottom=False)
            if ch_position<len(channels)-1:firing.tick_params(labelbottom=False)
        title=settings.get('title') or f'{Path(recording.source_path).stem} · threshold events'
        axes[0].set_title(_safe_label(title,75),loc='left',fontsize=settings['font_size']+1.2,fontweight='semibold',pad=12)
        xlabel=settings.get('xlabel') or ('Time within sweep (s)' if plan['time_reference']=='sweep' else 'Recording time (s)')
        if '(s)' not in xlabel and 'second' not in xlabel.casefold():xlabel+=' (s)'
        axes[-1].set_xlabel(xlabel,fontsize=settings['font_size'])
        bounds=[(p['first_sample_index']/p['sampling_rate_hz']+(p['recording_sweep_start_s'] if plan['time_reference']=='recording' else 0),
                 p['stop_sample_index']/p['sampling_rate_hz']+(p['recording_sweep_start_s'] if plan['time_reference']=='recording' else 0)) for p in selections.values()]
        axes[-1].set_xlim(min(b[0] for b in bounds),max(b[1] for b in bounds))
        if len(plan['sweeps'])==1:
            handles=[Line2D([0],[0],color=colors[0],lw=.8)];labels=['Recorded voltage / rate']
        handles.extend([Line2D([0],[0],marker='^',linestyle='none',color='#111111',markersize=4),
                        Line2D([0],[0],color='#777C77',linestyle='--',lw=.75)])
        labels.extend(['Accepted peak',f'Threshold {plan["detector"]["threshold_mv"]:g} mV'])
        fig.legend(handles,labels,frameon=False,loc='outside lower center',fontsize=max(8,settings['font_size']-.7),ncol=min(5,len(handles)))
        fig._statweave_trace_display=displays
        fig._statweave_spike_markers={'accepted_events':len(result['events']),'all_accepted_peaks_displayed':True}
        fig._statweave_style=settings
        fig._statweave_caption=_caption(recording,result,plan,displays)
        try:
            cache=_DISPLAY_CACHE.setdefault(recording,{})
            if len(cache)>12:cache.clear()
            cache[_signature(plan)+(plan['time_reference'],)]=deepcopy(displays)
        except TypeError:
            pass
        FigureCanvasAgg(fig).draw()
        _assert_not_clipped(fig)
        return fig
