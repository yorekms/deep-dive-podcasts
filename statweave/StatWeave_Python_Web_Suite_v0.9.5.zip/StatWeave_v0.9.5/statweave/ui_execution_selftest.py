"""Exercise literal conversational study execution through the native window."""
from copy import deepcopy
import json
from pathlib import Path
import time
import traceback

from PySide6.QtCore import QTimer

from .execution_selftest import fixtures,setup_commands,require,verify_export
from .session import sha256,verify_audit,versions
from .study_bridge import result_is_current


def schedule(window,app,workspace):
    output=Path(workspace).resolve()/'ui-execution-self-test';output.mkdir(parents=True,exist_ok=True)
    paths=fixtures(output/'synthetic-sources');original={str(p):sha256(p) for p in paths}
    config=dict(window.config);window.config={**config,'enabled':False};window.update_mode();window.last_export=None
    state={'step':0,'idle':0,'deadline':time.monotonic()+300,'checks':[]}
    timer=QTimer(window);window._execution_selftest_timer=timer
    steps=[]

    def loaded():
        require(window.session.is_study and window.session.result is None,'Native study intake failed')
        state['checks'].append('native_batch_intake')
        for text in setup_commands(window.session):steps.append(lambda t=text:window.send(t))
        steps.extend([reviewed,lambda:window.send('confirm execution recipe'),confirmed,
                      lambda:window.send('run agreed analysis'),executed,
                      lambda:window.send('use blue'),styled,reopen,reopened,
                      lambda:window.send('export analysis')])

    def reviewed():
        require(window.session.result is None,'Native recipe review calculated results')
        require(window.session.context.get('study_execution',{}).get('candidate_recipe'),'Native recipe review failed')
        state['checks'].append('literal_recipe_review_without_calculation')

    def confirmed():
        require(window.session.result is None,'Native confirmation calculated results')
        require(window.session.context['study_execution']['approved_digest'],'Exact recipe confirmation failed')
        state['checks'].append('explicit_recipe_digest_confirmation')

    def executed():
        session=window.session
        require(session.result and session.result.get('report'),'Native report run failed: '+str(session.conversation[-1:]))
        require(result_is_current(session),'Native report is already stale')
        require(window.canvas.isVisible() and not window.study_view.isVisible(),'Native result did not show the plotted figure')
        require(window.tabs.tabText(1)=='Results' and window.tabs.isTabVisible(4),'Native results/plan views missing')
        require('Measure' in window.results_view.toPlainText() or 'measure' in window.results_view.toPlainText(),'Measure results not visible')
        state['result']=deepcopy(session.result);state['checks'].append('all_measure_results_and_figure_visible')

    def styled():
        require(window.session.style['palette']=='blue','Native style command failed')
        require(window.session.result==state['result'],'Native style changed numerical results')

    def reopen():window.open_path(window.session.save())

    def reopened():
        require(window.session.result==state['result'] and result_is_current(window.session),'Native reopen changed results')
        require(window.canvas.isVisible() and window.tabs.tabText(1)=='Results','Native reopen lost result view')
        state['checks'].append('native_result_reopen_and_style')

    steps.extend([lambda:window.open_study_paths(paths),loaded])

    def finish():
        session=window.session
        require(window.last_export and window.last_export.get('input_type')=='study_execution','Native calculated export did not complete')
        count=verify_export(window.last_export)
        require(all(sha256(path)==digest for path,digest in original.items()),'An original synthetic source changed')
        session._assert_integrity(full=True);head,events=verify_audit(session.project_dir/'history.jsonl',session.last_hash)
        screenshot=output/'desktop.png';require(window.grab().save(str(screenshot)),'Native screenshot failed')
        measures=session.result['measures'];executed_count=sum(m['status']=='executed' for m in measures)
        report={'status':'passed','scope':'Synthetic native execution only; no private study analysis',
            'checks':state['checks']+['native_calculated_figure_export_with_verified_hashes','source_and_audit_integrity'],
            'source_count':len(paths),'measure_count':len(measures),'executed_measures':executed_count,
            'figure_count':window.last_export['figure_count'],'verified_export_files':count,
            'export':window.last_export,'project':str(session.project_dir/'project.json'),'screenshot':str(screenshot),
            'source_unchanged':True,'audit_head':head,'audit_events':events,'environment':versions()}
        (output/'result.json').write_text(json.dumps(report,indent=2,ensure_ascii=False))
        timer.stop();window.config=config;app.quit()

    def tick():
        try:
            require(time.monotonic()<state['deadline'],'Native execution check timed out')
            if window.busy or window._after_work:state['idle']=0;return
            state['idle']+=1
            if state['idle']<3:return
            state['idle']=0
            if state['step']<len(steps):
                step=steps[state['step']];state['step']+=1;step();return
            finish()
        except Exception as error:
            timer.stop();window.config=config
            (output/'result.json').write_text(json.dumps({'status':'failed','step':state['step'],'checks':state['checks'],
                'error':str(error),'traceback':traceback.format_exc()},indent=2));app.exit(1)
    timer.timeout.connect(tick);timer.start(50)
