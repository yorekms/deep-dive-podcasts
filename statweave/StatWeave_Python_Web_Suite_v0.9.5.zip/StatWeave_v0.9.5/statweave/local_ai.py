"""Start an explicitly configured project-local Ollama service; never install or pull."""
from datetime import datetime,timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time
import urllib.request
from urllib.parse import urlsplit


def _healthy(base_url):
    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self,*args,**kwargs):return None
    opener=urllib.request.build_opener(urllib.request.ProxyHandler({}),NoRedirect)
    try:
        with opener.open(base_url+'/api/tags',timeout=1) as response:
            data=response.read(131073)
        if len(data)>131072:return False
        payload=json.loads(data)
        return isinstance(payload,dict) and isinstance(payload.get('models'),list)
    except (OSError,ValueError,TypeError):return False


def ensure_local_service(workspace):
    root=Path(workspace).expanduser().resolve();settings=root/'statweave-settings.json'
    if not settings.exists():return {'status':'disabled','message':'Local AI is not configured.'}
    if settings.stat().st_size>32768:raise ValueError('Local AI settings exceed the supported size.')
    config=json.loads(settings.read_text(encoding='utf-8'))
    if config.get('provider') not in (None,'ollama'):
        return {'status':'disabled','message':'The local Ollama provider is not selected.'}
    if not config.get('enabled'):return {'status':'disabled','message':'Offline calculations remain available.'}
    base=config.get('base_url','http://127.0.0.1:11434').rstrip('/');parsed=urlsplit(base)
    if parsed.scheme not in ('http','https') or parsed.hostname not in ('127.0.0.1','localhost','::1') or parsed.username or parsed.password or parsed.path or parsed.query or parsed.fragment:
        raise ValueError('The local-model service must use a loopback address.')
    if _healthy(base):return {'status':'running','message':'The configured local-model service is available.'}
    if parsed.scheme!='http':return {'status':'unavailable','message':'Start the configured local HTTPS model service separately.'}
    runtime=root/'local-ai/ollama/bin/ollama';runtime_root=(root/'local-ai/ollama').resolve()
    if not runtime.is_file() or not runtime.resolve().is_relative_to(runtime_root):
        return {'status':'unavailable','message':'Install/start Ollama or configure an existing local service. No model is downloaded automatically.'}
    receipt=runtime_root/'INSTALL.json'
    try:
        if receipt.stat().st_size>32768:raise ValueError('Oversized runtime receipt')
        expected=json.loads(receipt.read_text(encoding='utf-8')).get('binary_sha256')
        if not isinstance(expected,str) or len(expected)!=64:raise ValueError('Missing runtime checksum')
        digest=hashlib.sha256()
        with runtime.open('rb') as handle:
            for block in iter(lambda:handle.read(1024*1024),b''):digest.update(block)
        if digest.hexdigest()!=expected:raise ValueError('Runtime checksum changed')
    except (OSError,ValueError,TypeError):
        return {'status':'unavailable','message':'The project-local Ollama runtime receipt/checksum could not be verified. Start a trusted local service separately or reinstall the runtime.'}
    model_root=root/'local-ai/models';temporary=root/'local-ai/tmp';logs=root/'local-ai/logs'
    for path in [model_root,temporary,logs]:path.mkdir(parents=True,exist_ok=True)
    env=dict(os.environ)
    port=parsed.port or 11434
    bind_host='[::1]' if parsed.hostname=='::1' else '127.0.0.1'
    env.update(OLLAMA_MODELS=str(model_root),OLLAMA_HOST=f'{bind_host}:{port}',
               OLLAMA_TMPDIR=str(temporary),OLLAMA_NO_CLOUD='1',OLLAMA_MAX_LOADED_MODELS='1',OLLAMA_NUM_PARALLEL='1')
    with (logs/'statweave-ollama.log').open('ab') as handle:
        process=subprocess.Popen([str(runtime),'serve'],cwd=root,env=env,stdin=subprocess.DEVNULL,
            stdout=handle,stderr=subprocess.STDOUT,start_new_session=True)
    (root/'local-ai/service.json').write_text(json.dumps({'pid':process.pid,'started_utc':datetime.now(timezone.utc).isoformat(),
        'base_url':base,'runtime':str(runtime),'models_directory':str(model_root),'cloud_enabled':False},indent=2))
    for _ in range(40):
        if _healthy(base):return {'status':'started','message':'Project-local Ollama is running; cloud features are disabled.'}
        if process.poll() is not None:break
        time.sleep(.2)
    return {'status':'unavailable','message':'The local-model service did not become ready. Check local-ai/logs; offline calculations remain available.'}
