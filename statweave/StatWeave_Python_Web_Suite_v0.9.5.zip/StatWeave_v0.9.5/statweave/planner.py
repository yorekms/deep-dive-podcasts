"""Deterministic conversation interpreter. This module is not a language model.

Plans use a small, auditable vocabulary and invoke statistical routines, never code.
"""
from __future__ import annotations

from copy import deepcopy
import re
from typing import Any
import pandas as pd

from .engine import MISSING_TOKENS, _PRUNING_REASON_RE

METHODS = {'describe', 'ttest', 'paired_t', 'anova', 'two_way_anova', 'timecourse_compare', 'kruskal', 'mannwhitney', 'pearson', 'spearman', 'regression', 'chi2', 'batch_compare', 'survival'}
PLOTS = {
    'distribution', 'scatter', 'paired', 'line', 'timecourse', 'spaghetti',
    'grouped_bar', 'grouped_box', 'grouped_violin', 'heatmap', 'survival',
    'box', 'violin', 'raincloud', 'histogram', 'ecdf', 'bar', 'superplot',
}
STYLE_KEYS = {
    'title', 'xlabel', 'ylabel', 'width_mm', 'height_mm', 'font_size',
    'palette', 'show_points', 'ci', 'format', 'dpi',
    'preset', 'error_bar', 'p_display', 'group_order', 'y_zero', 'ylim',
    'fill_style', 'point_style', 'point_size', 'point_alpha', 'jitter_width',
    'frame_style', 'grid', 'font_family', 'theme_bg', 'legend_loc',
    'yscale', 'xscale', 'hline', 'xtick_angle', 'cap_size', 'line_width',
}
ACTIONS = {'analyze', 'style', 'recommend', 'help', 'export', 'open', 'sheet', 'design', 'clarify', 'blocked', 'mask_rows'}


def capabilities() -> str:
    return (
        'Open CSV, TSV, Excel (including 6-tab ClampFlow workbooks), ODS data, paste a table from clipboard, or open an ABF recording, then type an instruction. '
        'Offline commands use a deterministic interpreter, not an LLM. '
        'Try: “Summarize score”; “Compare score by treatment”; “Welch t-test of score by treatment, independent observations”; '
        '“Compare RMP_mV by Group pooled by Mouse_ID, independent observations”; “Batch compare RMP_mV, Rin_MOhms by Group, independent observations”; '
        '“Paired t-test of before and after”; “Pearson correlation between age and score, independent observations”; '
        '“Regress score on age, independent observations”; “Chi-square of treatment and outcome, independent observations”; '
        '“Kaplan-Meier survival of time and status by group, independent observations”. '
        'Also supported: one-way ANOVA, Kruskal–Wallis, Mann–Whitney, Spearman correlation, weighted chi-square (“weighted by Count”), and reversible row masks (“exclude row 4 because seal lost”, “include all rows”). '
        'Figures: “Show a superplot”, “Show a violin plot”, “Use Okabe-Ito palette”, “Use SD error bars”, “Show exact p-value bracket”, '
        '“Slide preset”, “Journal single column”, “Set the title to Treatment response”, “Export as SVG”. '
        'No observations are deleted, no outliers are automatically removed, and missing or masked values are reported. '
        'Conversation settings can connect the OpenAI API or an installed local Ollama model through closed, verified tools. '
        'ABF views use local recording commands: “show channel 1 from 0 to 1 seconds”, “overlay sweeps 1 through 2”, “show full recording”, “show metadata”. '
        'Voltage ABF channels also support “detect spikes using threshold -20 mV and refractory 2 ms” and “firing rate in 100 ms bins”. '
        'Action potentials: “measure action potential amplitude half-width and inter-spike intervals”, “show analysis plan”, “explain amplitude”, '
        '“analyze spikes from 100 to 900 ms”, “set baseline window to 3 ms”, “exclude region from 0.2 to 0.25 seconds because pipette artifact”. '
        'Peak review uses stable IDs with a reason: “reject peak ch1-sw1-p2547 because artifact review”. '
        'Read stored values through conversation: “show measurements”, “show measurements for peak ch1-sw1-p2547”, or “show measurements from 9 to 15”. '
        'Folder recipes: save pipeline as "Current clamp"; check folder "/path/to/ABFs"; run pipeline on folder "/path/to/ABFs"; export pipeline figures. '
        'Derived detections and rates retain their processing record; ABF samples are never treated as independent statistical replicates.'
    )


def _norm(value: str) -> str:
    return re.sub(r'\s+', ' ', str(value).strip()).casefold()


def _numeric(df: pd.DataFrame) -> list[str]:
    result = []
    for c in df.columns:
        s = df[c].dropna()
        s = s.loc[~s.astype(str).str.strip().str.casefold().isin(MISSING_TOKENS | {''})]
        if pd.api.types.is_numeric_dtype(df[c]) or (len(s) and pd.to_numeric(s, errors='coerce').notna().all()):
            result.append(str(c))
    return result


def _identifier(c: str) -> bool:
    return bool(re.fullmatch(
        r'(?:id|subject|subject[ _-]?id|participant|participant[ _-]?id|patient[ _-]?id|sample[ _-]?id|'
        r'animal|animal[ _-]?id|mouse|mouse[ _-]?id|rat[ _-]?id|donor[ _-]?id|litter[ _-]?id|slice[ _-]?id|cell[ _-]?id|replicate|row)',
        c, re.I,
    ))


def _mentions(text: str, df: pd.DataFrame) -> list[tuple[int, str]]:
    cols = [str(c) for c in df.columns]
    found: list[tuple[int, str]] = []
    quoted_spans = []
    for m in re.finditer(r'(["`])(.+?)\1|“([^”]+)”|‘([^’]+)’', text):
        name = next(v for v in (m.group(2), m.group(3), m.group(4)) if v is not None)
        exact = [c for c in cols if c == name]
        matches = exact or [c for c in cols if _norm(c) == _norm(name)]
        if len(matches) > 1:
            raise ValueError(f'The column name {name!r} is ambiguous. Use its exact spelling in double quotes.')
        if matches:
            found.append((m.start(), matches[0])); quoted_spans.append(m.span())
    # Longest column name first prevents a short name matching inside a longer one.
    occupied = list(quoted_spans)
    for c in sorted(cols, key=len, reverse=True):
        pattern = r'(?<!\w)' + re.escape(c).replace(r'\ ', r'\s+') + r'(?!\w)'
        for m in re.finditer(pattern, text, re.I):
            if any(m.start() < end and m.end() > start for start, end in occupied):
                continue
            matches = [x for x in cols if _norm(x) == _norm(c)]
            if len(matches) > 1:
                raise ValueError(f'The column name {c!r} is ambiguous. Use its exact spelling in double quotes.')
            occupied.append(m.span()); found.append((m.start(), c))
    return sorted(found)


def _unique(values):
    return list(dict.fromkeys(values))


def _result(action: str, message: str, **kwargs) -> dict:
    return {'action': action, 'message': message, **kwargs}


def _clarify(plan: dict, question: str) -> dict:
    return _result('clarify', question, plan=deepcopy(plan))


def _parse_row_mask_command(text: str) -> dict | None:
    """Parse explicit reversible row exclusions with mandatory scientific reason."""
    stripped = text.strip()
    if re.fullmatch(r'(?:include\s+all\s+rows|clear\s+excluded\s+rows|restore\s+(?:all\s+)?excluded\s+rows|reset\s+excluded\s+rows)[.!]*', stripped, re.I):
        return {'action': 'mask_rows', 'mode': 'clear', 'excluded_rows': [],
                'message': 'Cleared all row-exclusion masks. Every source row is active again.'}
    m = re.fullmatch(
        r'(?:exclude|mask|omit)\s+rows?\s+([\d,\s]+(?:\s+and\s+\d+)?)\s+because\s+(.+?)\s*',
        stripped, re.I,
    )
    if not m:
        return None
    raw_nums, reason = m.group(1), m.group(2).strip().rstrip('.')
    if not reason or len(reason) < 3 or _PRUNING_REASON_RE.search(reason):
        return {
            'action': 'blocked',
            'message': 'Row exclusions require a concrete experimental or technical artifact reason (e.g. “because pipette seal lost”), never outlier removal or p-value optimization.',
        }
    rows = [int(tok) for tok in re.findall(r'\d+', raw_nums)]
    if not rows:
        return None
    entries = [{'row': r, 'reason': reason} for r in _unique(rows)]
    return {
        'action': 'mask_rows',
        'mode': 'add',
        'excluded_rows': entries,
        'message': f"Recorded reversible exclusion mask for source row(s) {', '.join(map(str, _unique(rows)))} (reason: {reason}). Use “include all rows” to restore them at any time.",
    }


def _blocked_request(text: str) -> bool:
    # Explicit reversible row masks with a valid technical reason are handled by _parse_row_mask_command.
    mask_cmd = _parse_row_mask_command(text)
    if mask_cmd is not None:
        return mask_cmd.get('action') == 'blocked'
    # Requests to hide or exclude data without an explicit row-level technical reason are blocked.
    return bool(re.search(
        r'\b(?:remove|delete|drop|exclude|prune|trim|discard|filter(?: out)?|hide|eliminate)\b.{0,65}\b(?:outliers?|rows?|subjects?|participants?|patients?|observations?|points?|values?|data|samples?|records?|replicates?|mouse|mice|animals?|trials?|windows?|donors?|cells?|sweeps?)\b'
        r'|\b(?:make|force|get|achieve)\b.{0,35}\b(?:statistically )?significan(?:t|ce)\b'
        r'|\b(?:smallest|lowest|best)\s+p[ -]?(?:value|values)\b'
        r'|\bp[ -]?hack(?:ing)?\b'
        r'|\b(?:winsori[sz]e|winsori[sz]ation)\b', text, re.I))


def _design(text: str) -> str | None:
    """Read explicit design statements conservatively, including their negation.

    ``unknown`` deliberately overrides an earlier session assumption when the user
    retracts it, asks about it, or supplies contradictory design information.
    """
    patterns = {
        'independent': r'\b(?:unpaired|independent(?: observations?| samples?| groups?| subjects?| participants?| animals?| mice| cells?)?|different subjects|different participants|different animals|different mice|between[ -]subjects)\b',
        'paired': r'\b(?:paired|same subjects|same participants|same animals|same mice|repeated measurements?|repeated observations?|repeated measures|within[ -]subjects|matched pairs?)\b',
    }
    positive = set(); uncertain = False; mentioned = False
    negative_before = re.compile(
        r"(?:\bnot(?:\s+(?:necessarily|actually|statistically|mutually|strictly|fully|all|the|really|truly|from|in|on|across|between|taken\s+from|drawn\s+from|coming\s+from|measured\s+(?:on|in)|collected\s+from))?"
        r"|\bnot\s+(?:known|confirmed|established|considered|verified)\s+(?:to\s+be|as)"
        r"|\b(?:isn|aren|wasn|weren|don|doesn)['’]?t(?:\s+(?:necessarily|actually|statistically|mutually|strictly|fully|all|the|from|in|on|taken\s+from|measured\s+on))?"
        r"|\bno|\bnever)\s*$", re.I)
    uncertainty_before = re.compile(r'\b(?:whether|if|might|may|could|possibly|maybe|unsure|uncertain|unknown|not sure)(?:\s+\w+){0,7}\s*$', re.I)
    for design, pattern in patterns.items():
        for match in re.finditer(pattern, text, re.I):
            mentioned = True
            before = re.split(r'[.;!?\n]', text[:match.start()])[-1][-100:]
            after = text[match.end():match.end() + 70]
            negated = bool(negative_before.search(before) or re.match(r'\s+(?:(?:has|have)\s+)?not\s+(?:been\s+)?(?:established|confirmed|verified|known)', after, re.I))
            question = bool('?' in text[match.end():] and re.search(r'\b(?:are|is|were|was)\s+(?:these|those|they|the(?:se)?\s+\w+|my\s+\w+|our\s+\w+)\s*$', before, re.I))
            if uncertainty_before.search(before) or question:
                uncertain = True
            elif negated:
                continue
            else:
                positive.add(design)
    has_negation = bool(re.search(r"\b(?:not|never|dependent|independence|isn't|aren't|wasn't|weren't)\b", text, re.I))
    if uncertain or len(positive) > 1:
        return 'unknown'
    if positive:
        return next(iter(positive))
    if mentioned or has_negation:
        return 'unknown'
    return None


def _parse_style(text: str, dataset=None) -> dict:
    low = text.casefold()
    style: dict[str, Any] = {}
    for target, label in [
        ('title', r'(?:figure\s+)?title'),
        ('xlabel', r'(?:x[ -]?(?:axis)?\s*label|label\s+(?:the\s+)?x(?:[ -]axis)?)'),
        ('ylabel', r'(?:y[ -]?(?:axis)?\s*label|label\s+(?:the\s+)?y(?:[ -]axis)?)'),
    ]:
        m = re.search(r'\b' + label + r'\s*(?:to|as|is|=|:)\s*["“\x27]?(.*?)["”\x27]?\s*$', text, re.I)
        if not m:
            m = re.search(r'\b' + label + r'\s+["“\x27](.*?)["”\x27]\s*$', text, re.I)
        if m:
            style[target] = m.group(1).strip().strip('"“”\x27')
    for key, phrase in [('width_mm', 'width'), ('height_mm', 'height')]:
        m = re.search(r'\b' + phrase + r'\s*(?:to|of|=|:)?\s*(\d+(?:\.\d+)?)\s*(mm|cm|inches|inch|in)?\b', low)
        if m:
            val = float(m.group(1)); unit = m.group(2) or 'mm'
            style[key] = val * (10 if unit == 'cm' else 25.4 if unit in ('inches', 'inch', 'in') else 1)
    if re.search(r'\b(?:dark\s+slide|dark\s+keynote|dark\s+presentation|slide[ _-]dark)\b', low):
        style['preset'] = 'slide_dark'
    elif re.search(r'\b(?:slide\s+preset|16\s*:\s*9\s*slide|presentation\s+slide)\b', low):
        style['preset'] = 'slide_16_9'
    elif re.search(r'\bposter\s+preset\b', low):
        style['preset'] = 'poster'
    elif re.search(r'\b(?:prism\s+(?:classic|preset|style)|graphpad\s+prism)\b', low):
        style['preset'] = 'prism_classic'
    elif re.search(r'\b(?:nature\s+(?:1[ -]?col|single[ -]?col|preset|style))\b', low):
        style['preset'] = 'nature_1col'
    elif re.search(r'\b(?:nejm\s+(?:clinical|preset|style))\b', low):
        style['preset'] = 'nejm_clinical'
    elif re.search(r'\bsquare\s+(?:panel|preset|figure)\b', low):
        style['preset'] = 'square_panel'
    elif re.search(r'\bjournal\s+single[ -]column\b', low):
        style['preset'] = 'journal_single'
    elif re.search(r'\bjournal\s+double[ -]column\b', low):
        style['preset'] = 'journal_double'
    elif re.search(r'\b(?:double[ -]column|two[ -]column)\b', low):
        style.update(width_mm=178.0, height_mm=108.0)
    elif re.search(r'\b(?:single[ -]column|one[ -]column)\b', low):
        style.update(width_mm=85.0, height_mm=60.0)
    m = re.search(r'\b(?:font(?: size)?|text size)\s*(?:to|of|=|:)?\s*(\d+(?:\.\d+)?)', low)
    if m:
        style['font_size'] = float(m.group(1))
    m = re.search(r'\b(\d{2,4})\s*dpi\b|\bdpi\s*(?:to|=|:)?\s*(\d{2,4})', low)
    if m:
        style['dpi'] = int(m.group(1) or m.group(2))
    if re.search(r'\b(?:okabe[ -]?ito|colorblind(?:[ -]safe)?)\b', low):
        style['palette'] = 'okabe_ito'
    elif re.search(r'\b(?:paul[ -]?tol|tol[ -]?muted)\b', low):
        style['palette'] = 'tol_muted'
    elif re.search(r'\b(?:npg|nature\s+(?:palette|colors?))\b', low):
        style['palette'] = 'npg'
    elif re.search(r'\bnejm(?:\s+(?:palette|colors?))?\b', low) and 'preset' not in style:
        style['palette'] = 'nejm'
    elif re.search(r'\blancet(?:\s+(?:palette|colors?))?\b', low):
        style['palette'] = 'lancet'
    elif re.search(r'\bjama(?:\s+(?:palette|colors?))?\b', low):
        style['palette'] = 'jama'
    elif re.search(r'\b(?:aaas|science\s+(?:palette|colors?))\b', low):
        style['palette'] = 'aaas'
    elif re.search(r'\bprism[ -]bold|\bprism\s+(?:palette|colors?)\b', low):
        style['palette'] = 'prism_bold'
    elif re.search(r'\bpastel(?:\s+(?:soft|palette|colors?))?\b', low):
        style['palette'] = 'pastel_soft'
    elif re.search(r'\bslate[ -]coral\b', low):
        style['palette'] = 'slate_coral'
    elif re.search(r'\bviridis\b', low):
        style['palette'] = 'viridis_cat'
    elif re.search(r'\b(?:blue|teal|mono(?:chrome)?|gr[ae]yscale|black and white)\b', low):
        style['palette'] = 'blue' if re.search(r'\bblue\b', low) else 'teal' if re.search(r'\bteal\b', low) else 'mono'
    if re.search(r'\b(?:show|include|display)\b.{0,20}\b(?:individual|raw|all|data)\s+(?:observations|points|values)\b', low):
        style['show_points'] = True
    # Hiding underlying observations is a style option only on request; never removes rows from analysis.
    if re.search(r'\b(?:hide|without|no)\s+(?:the\s+)?(?:individual |raw |data )?points\b', low):
        style['show_points'] = False
    if re.search(r'\b(?:hollow|open|unfilled|white[ -]filled)\s+(?:bars?|boxes|violins?|fill)\b', low):
        style['fill_style'] = 'hollow'
    elif re.search(r'\b(?:solid|opaque|saturated)\s+(?:bars?|boxes|violins?|fill)\b', low):
        style['fill_style'] = 'solid'
    elif re.search(r'\b(?:hatched|striped|patterned)\s*(?:bars?|boxes|violins?|fill)?\b', low):
        style['fill_style'] = 'hatched'
    elif re.search(r'\btinted\s+(?:bars?|boxes|violins?|fill)\b', low):
        style['fill_style'] = 'tinted'
    if re.search(r'\b(?:open|hollow)\s+(?:circles?|points?|dots?|markers?)\b', low):
        style['point_style'] = 'open_circle'
    elif re.search(r'\b(?:shapes?\s+by\s+group|different\s+(?:marker\s+)?shapes|distinct\s+shapes|by[ _-]group[ _-]shape)\b', low):
        style['point_style'] = 'by_group_shape'
    elif re.search(r'\bdiamond\s+(?:points?|dots?|markers?)\b', low):
        style['point_style'] = 'diamond'
    elif re.search(r'\bsquare\s+(?:points?|dots?|markers?)\b', low):
        style['point_style'] = 'square'
    elif re.search(r'\btriangle\s+(?:points?|dots?|markers?)\b', low):
        style['point_style'] = 'triangle'
    if re.search(r'\b(?:no\s+jitter|zero\s+jitter|center[ -]aligned\s+(?:points?|dots?))\b', low):
        style['jitter_width'] = 0.0
    if re.search(r'\b(?:capless|no\s+caps|without\s+caps)\b', low):
        style['cap_size'] = 0.0
    if re.search(r'\b(?:closed\s+box|full\s+box|box\s+frame|four[ -]sided\s+frame)\b', low):
        style['frame_style'] = 'box'
    elif re.search(r'\bminimal\s+(?:frame|axes|spines)\b', low):
        style['frame_style'] = 'minimal'
    elif re.search(r'\bopen\s+l[ -]?(?:frame|axes|spines)\b', low):
        style['frame_style'] = 'open_l'
    if re.search(r'\b(?:xy|both)\s+grid(?:lines?)?\b', low):
        style['grid'] = 'xy'
    elif re.search(r'\b(?:horizontal\s+grid(?:lines?)?|y[ -]?grid(?:lines?)?|show\s+grid(?:lines?)?)\b', low):
        style['grid'] = 'y'
    elif re.search(r'\b(?:no|hide|remove)\s+grid(?:lines?)?\b', low):
        style['grid'] = 'none'
    if re.search(r'\b(?:sans[ -]?serif)\b', low):
        style['font_family'] = 'sans'
    elif re.search(r'\bserif\s*(?:font|text|typeface)?\b', low):
        style['font_family'] = 'serif'
    elif re.search(r'\bmonospace\s*(?:font|text|typeface)?\b', low):
        style['font_family'] = 'mono'
    if re.search(r'\btransparent\s+(?:background|canvas)\b', low):
        style['theme_bg'] = 'transparent'
    elif re.search(r'\bdark\s+(?:background|theme|mode|canvas)\b', low):
        style['theme_bg'] = 'dark'
    elif re.search(r'\b(?:warm\s+paper|cream\s+background|paper\s+background)\b', low):
        style['theme_bg'] = 'paper'
    elif re.search(r'\bwhite\s+(?:background|theme|canvas)\b', low):
        style['theme_bg'] = 'white'
    if re.search(r'\b(?:hide|no|remove)\s+legend\b', low):
        style['legend_loc'] = 'none'
    elif re.search(r'\blegend\s+outside(?:\s+top)?\b', low):
        style['legend_loc'] = 'outside_top'
    if re.search(r'\b(?:log10?|logarithmic)\s+y(?:[ -]axis|\s+scale)?\b|\blog\s+scale\b', low):
        style['yscale'] = 'log10'
    elif re.search(r'\blinear\s+y(?:[ -]axis|\s+scale)?\b', low):
        style['yscale'] = 'linear'
    m_hl = re.search(r'\b(?:reference\s+line|hline|horizontal\s+line|baseline\s+line)\s*(?:at|y\s*=|=|:)\s*([-+]?\d+(?:\.\d+)?)', low)
    if m_hl:
        style['hline'] = float(m_hl.group(1))
    if re.search(r'\b(?:use|show|with|set)\b.{0,18}\bsd\s+error\s+bars?\b|\berror\s+bars?\s*(?:to|as|=|:)\s*sd\b', low):
        style['error_bar'] = 'sd'
    elif re.search(r'\b(?:use|show|with|set)\b.{0,18}\bsem\s+error\s+bars?\b|\berror\s+bars?\s*(?:to|as|=|:)\s*sem\b', low):
        style['error_bar'] = 'sem'
    elif re.search(r'\b(?:use|show|with|set)\b.{0,18}\biqr\s+error\s+bars?\b|\berror\s+bars?\s*(?:to|as|=|:)\s*iqr\b', low):
        style['error_bar'] = 'iqr'
    elif re.search(r'\b(?:show|include|add)\b.{0,20}\b(?:confidence intervals?|95%\s*ci|error bars?)\b', low):
        style['ci'] = True
    elif re.search(r'\b(?:hide|without|no)\s+(?:confidence intervals?|error bars?)\b', low):
        style['ci'] = False
    if re.search(r'\b(?:hide|remove|without|no)\s+(?:the\s+)?p[ -]?value(?:\s+bracket)?\b', low):
        style['p_display'] = 'none'
    elif re.search(r'\b(?:stars?\s+only|just\s+stars?|only\s+stars?)\b', low):
        style['p_display'] = 'stars_only'
    elif re.search(r'\b(?:stars?\s+and\s+p[ -]?value|p[ -]?value\s+with\s+stars?)\b', low):
        style['p_display'] = 'stars_and_p'
    elif re.search(r'\b(?:show|add|display|include)\s+(?:the\s+)?(?:exact\s+)?p[ -]?value(?:\s+bracket)?\b', low):
        style['p_display'] = 'exact'
    if re.search(r'\b(?:start\s+y(?:[ -]axis)?\s+at\s+(?:zero|0)|anchor\s+y(?:[ -]axis)?\s+at\s+(?:zero|0)|y(?:[ -]axis)?\s+from\s+(?:zero|0))\b', low):
        style['y_zero'] = True
    m_order = re.search(r'\border\s+groups?\s*(?:as|to|:)?\s+(.+?)\s*$', text, re.I)
    if m_order:
        items = [part.strip().strip('"“”\x27') for part in re.split(r',|\band\b', m_order.group(1)) if part.strip()]
        if items:
            style['group_order'] = items
    m = re.search(r'\b(pdf|svg|png|tiff?)\b', low)
    if m:
        style['format'] = 'tiff' if m.group(1) == 'tif' else m.group(1)
    return style


def _plot(text: str) -> str | None:
    for pattern, name in [
        (r'\b(?:kaplan[ -]?meier(?: (?:curve|curves|plot|figure))?|km (?:curve|curves|plot)|survival (?:curve|curves|plot|figure))\b', 'survival'),
        (r'\bsuper[ -]?plot\b', 'superplot'),
        (r'\brain[ -]?cloud(?: plot)?\b|\bhalf[ -]violin\b', 'raincloud'),
        (r'\bspaghetti(?: (?:plot|lines?|trajector(?:y|ies)))?\b', 'spaghetti'),
        (r'\bgrouped[ -]violins?(?: plot)?\b|\bdodged[ -]violins?\b', 'grouped_violin'),
        (r'\bgrouped[ -]box(?:es|plot| plot)?\b', 'grouped_box'),
        (r'\bgrouped[ -]bars?(?: plot| chart)?\b|\bdodged[ -]bars?\b', 'grouped_bar'),
        (r'\btime[ -]?course(?: (?:plot|line|chart|graph))?\b', 'timecourse'),
        (r'\b(?:paired (?:dots?|plot|lines?)|slope ?plot|before[ /-]after plot)\b', 'paired'),
        (r'\b(?:scatter(?:plot)?|scatter plot)\b', 'scatter'),
        (r'\bviolin(?: plot)?\b', 'violin'), (r'\bbox(?:plot| plot)?\b', 'box'),
        (r'\bhistogram\b', 'histogram'), (r'\b(?:ecdf|cumulative distribution)\b', 'ecdf'),
        (r'\bheat[ -]?map\b', 'heatmap'), (r'\b(?:line (?:chart|plot|graph)|time[ -]series plot)\b', 'line'),
        (r'\bbar (?:chart|plot|graph)\b', 'bar'), (r'\bdistribution(?: plot)?\b', 'distribution'),
    ]:
        if re.search(pattern, text, re.I):
            return name
    return None


def _method(text: str) -> str | None:
    low = text.casefold().replace('–', '-').replace('—', '-')
    for pattern, method in [
        (r'\b(?:kaplan[ -]?meier|log[ -]?rank|mantel[ -]?cox|survival(?:\s+(?:analysis|test|curves?|plot|comparison|by|of|across))?)\b', 'survival'),
        (r'\btwo[ -]?way[ -]?anova\b|\bfactorial[ -]?anova\b', 'two_way_anova'),
        (r'\btime[ -]?course[ -]?compar(?:e|ison)\b|\bper[ -]?time[ -]?point\s+(?:compar(?:e|ison)|t[ -]?tests?|mann[ -]?whitney|tests?)\b', 'timecourse_compare'),
        (r'\bbatch[ -]?compar(?:e|ison)\b|\bcompare\s+(?:multiple|all)\s+(?:measures?|endpoints?|columns?)\b', 'batch_compare'),
        (r'\bpaired\b.{0,22}\b(?:t[ -]?test|test|comparison)\b|\bpaired[ -]?t\b', 'paired_t'),
        (r'\b(?:mann[ -]?whitney|rank[ -]?sum)\b', 'mannwhitney'),
        (r'\bkruskal(?:[ -]?wallis)?\b', 'kruskal'),
        (r'\b(?:chi[ -]?(?:square|squared|2)|χ²)\b', 'chi2'),
        (r'\bspearman\b', 'spearman'), (r'\bpearson\b', 'pearson'),
        (r'\b(?:regress(?:ion)?|ordinary least squares|ols|linear fit)\b', 'regression'),
        (r'\b(?:anova|analysis of variance)\b', 'anova'),
        (r'\b(?:welch|t[ -]?test|ttest|two[ -]sample test|student.s t)\b', 'ttest'),
        (r'\b(?:summari[sz]e|summary|describe|descriptive|descriptives)\b', 'describe'),
    ]:
        if re.search(pattern, low):
            return method
    return None


def _readonly_question(text: str, dataset, previous_plan: dict | None, context: dict) -> dict | None:
    """Answer status, rationale, or column-inventory questions without running a calculation."""
    stripped = text.strip()
    low = stripped.casefold().rstrip('.!?').strip()

    # 1. Status questions ("Did we run any statistics?", "Have we run any tests?", "Do we have p-values?")
    is_status = bool(
        (re.search(r'\b(?:did|have|has|were|was)\b', low)
         and re.search(r'\b(?:run|ran|done|perform(?:ed)?|calculat(?:e|ed)|comput(?:e|ed)|tested|analy[sz]ed)\b', low)
         and re.search(r'\b(?:stats|statistic\w*|analys\w*|test\w*|p[- ]?values?)\b', low))
        or re.search(r'\bwhat\s+(?:stats|statistics|analyses|tests)\s+(?:have|did|were|are)\b', low)
        or re.search(r'^(?:do\s+we\s+have|are\s+there)\s+(?:any\s+)?p[- ]?values?$', low)
        or low in {'what have we done so far', 'what did we run', 'what has been calculated'}
    )
    if is_status:
        res_summary = context.get('result_summary')
        if res_summary:
            method_label = res_summary.get('method', 'analysis')
            summary_txt = res_summary.get('summary', '')
            inferential = method_label != 'describe'
            kind_note = 'an inferential test with recorded p-values/intervals' if inferential else 'descriptive statistics only (no hypothesis test or p-value)'
            return _result('help', f'Yes — the current saved result is {method_label} ({kind_note}): {summary_txt} No new calculation was run.')
        if previous_plan and previous_plan.get('method'):
            return _result('help', f"The current plan specifies {previous_plan['method']}, and no new calculation was run by this question.")
        return _result('help', 'No statistical analysis has been run in this project yet. Tell me which columns or comparison you want to examine.')

    # 2. Rationale / explanation questions ("Why did you choose that test?", "Why Welch t-test?", "Explain Mann-Whitney")
    if re.match(r'^(?:why\b|how\s+does\b|what\s+does\b.*\bmean|can\s+you\s+explain\b|explain\b)', low):
        res_summary = context.get('result_summary') or {}
        active_method = res_summary.get('method') or (previous_plan or {}).get('method') or _method(text)
        explanations = {
            'ttest': "Welch's two-sample t-test compares arithmetic means between two independent groups without assuming equal group variances, which makes it safer than a pooled-variance Student t-test when group spreads or sample sizes differ.",
            'paired_t': 'The paired t-test analyzes within-unit differences across two conditions on the same independent subjects, accounting for baseline variation between subjects.',
            'anova': 'One-way ANOVA tests whether arithmetic means differ across three or more independent groups under approximate normality and comparable group variances.',
            'mannwhitney': 'Mann–Whitney U compares rank distributions between two independent groups without assuming Gaussian residuals.',
            'kruskal': 'Kruskal–Wallis compares rank distributions across three or more independent groups.',
            'pearson': 'Pearson r measures linear association between two continuous variables on independent units.',
            'spearman': 'Spearman rho measures monotonic rank association between two variables on independent units.',
            'regression': 'One-predictor ordinary least-squares (OLS) regression estimates the linear change in y per unit of x along with a 95% t confidence band for the fitted mean.',
            'chi2': "Pearson's chi-square test evaluates association between two categorical variables in a contingency table (without Yates continuity correction).",
            'survival': 'Kaplan–Meier product-limit estimation computes right-censored survival probabilities with Greenwood log(-log) 95% bands and Brookmeyer–Crowley median survival intervals, while the Mantel–Cox log-rank test (and univariate Cox hazard ratio for two groups) compares survival across independent groups.',
            'batch_compare': 'Batch comparison evaluates multiple numeric endpoints across groups and reports step-down Holm–Bonferroni multiplicity-adjusted p-values alongside unadjusted p-values.',
            'describe': 'Descriptive summaries report observation counts, means, SD, medians, quartiles, and min/max without assuming independent experimental units or computing p-values.',
        }
        detail = explanations.get(active_method, 'StatWeave selects deterministic routines matching your stated study design (independent vs. paired) and measurement scale, never choosing tests to minimize p-values.')
        return _result('help', detail + ' No new calculation was run.')

    # 3. Column / measure inventory requests ("Show all the available measures", "What columns do we have?", "List variables")
    if dataset is not None and hasattr(dataset, 'df') and re.fullmatch(
        r'(?:please\s+)?(?:show|list|display|what\s+are|tell\s+me)\s+(?:all\s+)?(?:the\s+)?(?:available\s+)?(?:measures?|columns?|variables?|fields?|endpoints?)',
        low,
    ):
        df = dataset.df
        num = _numeric(df)
        ids = [str(c) for c in df.columns if _identifier(str(c))]
        meas = [c for c in num if c not in ids]
        cats = [str(c) for c in df.columns if str(c) not in num and str(c) not in ids]
        parts = [f'This table has {len(df)} rows and {len(df.columns)} columns.']
        if meas:
            parts.append('Numeric measures: ' + ', '.join(meas) + '.')
        if cats:
            parts.append('Grouping/categorical columns: ' + ', '.join(cats) + '.')
        if ids:
            parts.append('Identifier columns: ' + ', '.join(ids) + '.')
        if getattr(dataset, 'sheets', None) and len(dataset.sheets) > 1:
            parts.append(f"Workbook sheets ({len(dataset.sheets)}): {', '.join(dataset.sheets)} (active: {dataset.sheet}).")
        return _result('help', ' '.join(parts))

    return None


def _extract_clause_column(pattern: str, text: str, df: pd.DataFrame) -> str | None:
    m = re.search(pattern, text, re.I)
    if not m:
        return None
    tail = text[m.end():]
    tail_mentions = _mentions(tail, df)
    return tail_mentions[0][1] if tail_mentions else None


def _resolve_plan(plan: dict, text: str, dataset, context: dict) -> dict:
    df = dataset.df
    numerical = _numeric(df)
    numeric = [c for c in numerical if not _identifier(c)] or numerical
    cats = [str(c) for c in df.columns if str(c) not in numerical and not _identifier(str(c))]
    mentions = _mentions(text, df)

    pool_col = _extract_clause_column(r'\b(?:pooled\s+by|pool\s+by|averag(?:e|ing)\s+within|cluster(?:ed)?\s+by)\b', text, df)
    if pool_col:
        plan['pool_by'] = pool_col
        plan['pool_stat'] = 'median' if re.search(r'\bmedian\b', text, re.I) and re.search(r'\bpool', text, re.I) else plan.get('pool_stat', 'mean')

    count_col = _extract_clause_column(r'\b(?:weighted\s+by|using\s+counts?\s+in|count\s+column)\b', text, df)
    if count_col and plan.get('method') == 'chi2':
        plan['count'] = count_col

    reserved = {c for c in (pool_col, count_col) if c}
    filtered_mentions = [(pos, c) for pos, c in mentions if c not in reserved]
    mentioned = _unique(c for _, c in filtered_mentions)

    # Strip trailing "pooled by ..." clause before locating the grouping "by <Group>" keyword.
    group_search_text = re.split(r'\b(?:pooled\s+by|pool\s+by|weighted\s+by)\b', text, maxsplit=1, flags=re.I)[0]
    by = re.search(r'\b(?:grouped\s+by|by|across)\b', group_search_text, re.I)
    explicit_group = next((c for pos, c in filtered_mentions if by and pos > by.end() and pos < len(group_search_text)), None)
    explicit_outcomes = [c for pos, c in filtered_mentions if by and pos < by.start() and c in numerical and not _identifier(c)]
    explicit_outcome = explicit_outcomes[0] if explicit_outcomes else None

    mn = [c for c in mentioned if c in numerical]
    mc = [c for c in mentioned if c not in numerical]
    design = _design(text) or plan.get('design') or context.get('design') or 'unknown'
    plan['design'] = design
    if context.get('excluded_rows') and 'excluded_rows' not in plan:
        plan['excluded_rows'] = deepcopy(context['excluded_rows'])
    method = plan['method']

    if mentioned:
        if method == 'batch_compare':
            outcomes = explicit_outcomes or [c for c in mn if c != explicit_group and not _identifier(c)]
            if outcomes:
                plan['columns'] = _unique(outcomes)
            if explicit_group:
                plan['group'] = explicit_group
            elif mc:
                plan['group'] = mc[0]
        elif method in ('pearson', 'spearman', 'regression') or plan.get('plot') in ('scatter', 'line'):
            if len(mn) == 2:
                # Regression follows the common “regress Y on X” and “Y versus X” convention.
                if method == 'regression':
                    plan.update(y=mn[0], x=mn[1])
                else:
                    plan.update(x=mn[0], y=mn[1])
            elif len(mn) > 2:
                return _result('help', 'This version supports only two numeric variables for that analysis. Multiple-predictor regression and partial correlations need additional validated methods; I will not drop a named variable.', unsupported=True)
        elif method == 'chi2':
            if len(mentioned) == 2:
                plan.update(x=mentioned[0], y=mentioned[1])
        elif method == 'paired_t':
            if explicit_group and explicit_outcome:
                plan.update(y=explicit_outcome, group=explicit_group)
            ids = [c for c in mentioned if _identifier(c)]
            mn_clean = [c for c in mn if c not in ids and c != explicit_group]
            if len(mn_clean) == 2 and not mc and not explicit_group:
                plan.update(x=mn_clean[0], y=mn_clean[1], design='paired', plot='paired')
                plan.pop('group', None); plan.pop('subject', None)
            elif len(mn_clean) == 1 or (explicit_group and explicit_outcome):
                plan['y'] = explicit_outcome or mn_clean[0]
                group = [c for c in mc if c not in ids]
                if group and not explicit_group:
                    plan['group'] = group[0]
                if ids:
                    plan['subject'] = ids[0]
                plan['design'] = 'paired'; plan['plot'] = 'paired'
        elif method == 'survival' or (method == 'describe' and plan.get('plot') == 'survival'):
            from .working_sheets import _SURVIVAL_EVENT_COL_RE, detect_survival_structure
            surv_auto = detect_survival_structure(df)
            if explicit_group:
                plan['group'] = explicit_group
            rem = [c for c in mentioned if c != plan.get('group') and not _identifier(c)]
            if not explicit_group and len(rem) >= 3:
                # Check if last or categorical mention is a group column
                cat_rem = [c for c in rem if c in mc and not _SURVIVAL_EVENT_COL_RE.match(c)]
                if cat_rem:
                    plan['group'] = cat_rem[-1]
                    rem = [c for c in rem if c != plan['group']]
            if len(rem) == 2:
                c0, c1 = rem[0], rem[1]
                if _SURVIVAL_EVENT_COL_RE.match(c0) and not _SURVIVAL_EVENT_COL_RE.match(c1):
                    plan.update(x=c1, y=c0)
                else:
                    plan.update(x=c0, y=c1)
            elif len(rem) == 1 and surv_auto.get('detected'):
                c0 = rem[0]
                if c0 not in {surv_auto['time_col'], surv_auto['event_col']} and not plan.get('group'):
                    plan['group'] = c0
                plan.setdefault('x', surv_auto['time_col'])
                plan.setdefault('y', surv_auto['event_col'])
        elif method == 'describe':
            if explicit_group and explicit_outcome:
                plan.update(y=explicit_outcome, group=explicit_group, columns=[c for c in mn if c != explicit_group])
            else:
                if mn:
                    plan['columns'] = mn; plan['y'] = mn[0]
                if mc:
                    plan['group'] = mc[0]
        else:
            non_id_mc = [c for c in mc if not _identifier(c)]
            if len(non_id_mc) > 1 or (explicit_group and explicit_outcome and len([c for c in mentioned if not _identifier(c)]) > 2 and len(explicit_outcomes) <= 1):
                return _result('help', 'This version supports one grouping factor. A multi-factor or covariate-adjusted analysis needs an additional validated method; I will not drop a named factor.', unsupported=True)
            if explicit_group and len(explicit_outcomes) > 1:
                method = plan['method'] = 'batch_compare'
                plan.update(columns=_unique(explicit_outcomes), group=explicit_group)
                plan.pop('y', None)
            elif explicit_group and explicit_outcome:
                plan.update(y=explicit_outcome, group=explicit_group)
                plan.pop('columns', None)
            elif len(mn) == 1:
                plan['y'] = mn[0]
            elif len(mn) > 1:
                plan['columns'] = mn; plan['y'] = mn[0]
            if non_id_mc and not explicit_group:
                plan['group'] = non_id_mc[0]

    if method == 'batch_compare':
        if not plan.get('columns'):
            plan['columns'] = numeric
        if not plan.get('group') and len(cats) == 1:
            plan['group'] = cats[0]
        if len(plan.get('columns') or []) < 2 or not plan.get('group'):
            return _clarify(plan, 'For batch comparison, name at least two numeric outcome columns and one grouping column (for example: “Batch compare RMP_mV, Rin_MOhms by Group, independent observations”).')
        plan.setdefault('plot', 'superplot' if plan.get('pool_by') else 'distribution')
    elif method == 'survival':
        from .working_sheets import detect_survival_structure
        surv_auto = detect_survival_structure(df)
        if (not plan.get('x') or not plan.get('y')) and surv_auto.get('detected'):
            plan.setdefault('x', surv_auto['time_col'])
            plan.setdefault('y', surv_auto['event_col'])
        if not plan.get('group') and re.search(r'\b(?:log[ -]?rank|mantel[ -]?cox|by|across|between)\b', text, re.I):
            g_cands = surv_auto.get('group_cols') or [c for c in cats if c not in {plan.get('x'), plan.get('y')}]
            if len(g_cands) == 1:
                plan['group'] = g_cands[0]
        if not plan.get('x') or not plan.get('y'):
            return _clarify(plan, 'For survival analysis, name the follow-up time column and binary event/censoring column (and optional grouping column), for example: “Kaplan-Meier survival of time and status by group, independent observations”.')
        plan.setdefault('plot', 'survival')
    elif method == 'describe':
        if plan.get('plot') == 'survival':
            from .working_sheets import detect_survival_structure
            surv_auto = detect_survival_structure(df)
            if (not plan.get('x') or not plan.get('y')) and surv_auto.get('detected'):
                plan.setdefault('x', surv_auto['time_col'])
                plan.setdefault('y', surv_auto['event_col'])
            if not plan.get('x') or not plan.get('y'):
                return _clarify(plan, 'Which follow-up time and binary event/censoring columns should I plot on the Kaplan–Meier curve?')
            plan['columns'] = [plan['x']]
            plan.setdefault('plot', 'survival')
        else:
            if not plan.get('columns') and not plan.get('y'):
                plan['columns'] = numeric
            if not plan.get('y') and plan.get('columns'):
                plan['y'] = plan['columns'][0]
            if not plan.get('y'):
                return _clarify(plan, 'Which column should I summarize? I could not identify a numeric outcome.')
            plan.setdefault('plot', 'superplot' if plan.get('pool_by') else 'distribution')
    elif method in ('pearson', 'spearman', 'regression'):
        if not plan.get('x') or not plan.get('y'):
            if len(numeric) == 2:
                plan.update(x=numeric[0], y=numeric[1])
            else:
                return _clarify(plan, 'Which two numeric columns should I use? For example: “Pearson correlation between age and score”.')
        plan.setdefault('plot', 'scatter')
    elif method == 'chi2':
        if not plan.get('x') or not plan.get('y'):
            if len(cats) == 2:
                plan.update(x=cats[0], y=cats[1])
            else:
                return _clarify(plan, 'Name the two categorical columns for the chi-square test (and optionally “weighted by Count” for pre-aggregated tables).')
        plan.setdefault('plot', 'heatmap')
    elif method == 'paired_t':
        if plan.get('x') and plan.get('y'):
            plan['design'] = 'paired'
        else:
            if not plan.get('y') and len(numeric) == 1:
                plan['y'] = numeric[0]
            if not plan.get('group') and len(cats) == 1:
                plan['group'] = cats[0]
            ids = [str(c) for c in df.columns if _identifier(str(c))]
            if not plan.get('subject') and len(ids) == 1:
                plan['subject'] = ids[0]
            if not all(plan.get(k) for k in ('y', 'group', 'subject')):
                return _clarify(plan, 'For paired data, name the two measurement columns (“Paired t-test of before and after”), or name the outcome, condition and subject-ID columns.')
            plan['design'] = 'paired'
        plan.setdefault('plot', 'paired')
    else:
        if not plan.get('y') and len(numeric) == 1:
            plan['y'] = numeric[0]
        if not plan.get('group') and not plan.get('columns') and len(cats) == 1:
            plan['group'] = cats[0]
        if not plan.get('y') or (not plan.get('group') and not plan.get('columns')):
            return _clarify(plan, 'Which outcome and grouping columns should I use? For example: “Welch t-test of score by treatment”. For wide data, name the measurement columns.')
        plan.setdefault('plot', 'superplot' if plan.get('pool_by') else 'distribution')

    if method not in ('describe', 'paired_t'):
        if design == 'paired':
            return _clarify(plan, 'You said these are paired or repeated observations. I will not treat them as independent. For two measurements, request a paired t-test and identify the paired columns or subject IDs. If repeated technical sweeps belong to independent animals, use “pooled by Animal_ID, independent observations”.')
        if design != 'independent':
            return _clarify(plan, 'Are the observations independent, or are the same subjects measured more than once? Reply “independent observations”, “pooled by Mouse_ID, independent observations”, or describe the pairing. I need the study design before running this test.')

    names = {
        'ttest': 'Welch independent-samples t-test',
        'paired_t': 'paired t-test',
        'anova': 'one-way ANOVA',
        'kruskal': 'Kruskal–Wallis test',
        'mannwhitney': 'Mann–Whitney test',
        'pearson': 'Pearson correlation',
        'spearman': 'Spearman correlation',
        'regression': 'one-predictor linear regression',
        'chi2': 'chi-square test',
        'describe': 'descriptive summary',
        'batch_compare': 'multi-endpoint batch comparison with Holm–Bonferroni adjustment',
        'survival': 'Kaplan–Meier survival analysis and Mantel–Cox log-rank test',
        'timecourse_compare': 'per-timepoint comparison with Holm–Bonferroni adjustment',
        'two_way_anova': 'two-way factorial ANOVA',
    }
    plan['action'] = 'analyze'
    plan['message'] = f'I will run a {names[method]}. All original observations remain preserved; any unavailable or masked values will be itemized.'
    return plan


def interpret(text: str, dataset, previous_plan: dict | None = None, context: dict | None = None) -> dict:
    """Translate supported natural-language commands into explicit, inspectable plans."""
    if not isinstance(text, str) or not text.strip():
        return _result('help', 'Type an instruction, or “help” for examples.')
    text = text.strip(); low = text.casefold(); context = context or {}
    if getattr(dataset, 'kind', None) == 'large_table' and not re.match(r'^(?:open|load|import|export)\b', low) and not re.match(r'^save\s+(?:the\s+)?(?:figure|plot|chart|results|package|analysis)\b', low):
        from .large_commands import interpret_large
        return interpret_large(text, dataset, previous_plan, context)
    if getattr(dataset, 'kind', None) == 'recording':
        query = re.fullmatch(r'show\s+measurements(?:\s+for\s+peak\s+(ch[1-9]\d*-sw[1-9]\d*-p\d+)|\s+from\s+(\d+)\s+to\s+(\d+))?', low)
        if query:
            event_id, start, stop = query.groups()
            return {'action': 'ap_query', 'event_id': event_id, 'start': int(start) - 1 if start else 0, 'stop': int(stop) if stop else 20}
        from .pipelines import interpret_pipeline
        pipeline = interpret_pipeline(text)
        if pipeline is not None:
            return pipeline
        if not re.match(r'^(?:open|load|import)\b', low):
            from .ap_commands import interpret_ap
            ap = interpret_ap(text, dataset, previous_plan)
            if ap is not None:
                return ap

    mask_cmd = _parse_row_mask_command(text)
    if mask_cmd is not None:
        return mask_cmd
    if _blocked_request(text):
        return _result('blocked', 'I will not delete observations, remove outliers, or search for a significant result. The original data stay intact. Missing-value omissions are documented per analysis; for a genuine technical failure on a specific row, use “exclude row N because <technical reason>”.')
    if re.fullmatch(r'(?:help|commands|examples|what can you do|show (?:me )?(?:help|commands|examples))\??', low):
        return _result('help', capabilities())
    if re.search(r'\b(?:open|load|import)\s+(?:spreadsheet\s+|file\s+)?', low):
        m = re.search(r'\b(?:open|load|import)\s+(?:spreadsheet\s+|recording\s+|file\s+)?["\x27]?(.*?\.(?:csv|tsv|txt|xlsx|xlsm|xls|ods|abf|json))["\x27]?\s*$', text, re.I)
        if m:
            return _result('open', 'I will open that spreadsheet and preserve an unchanged source copy.', path=m.group(1))
    m = re.fullmatch(r'(?:use|switch to|open|select)\s+(?:the\s+)?sheet\s+["\x27]?(.*?)["\x27]?', text, re.I)
    if m:
        return _result('sheet', f'I will use sheet {m.group(1)}.', sheet=m.group(1).strip('"\x27'))
    if re.search(r'\b(?:export|save(?: the)? (?:figure|plot|chart|results|package|analysis))\b', low):
        if getattr(dataset, 'kind', None) == 'large_table' and re.search(r'\b(?:and|then|after|before)\b', low) and re.search(r'\b(?:profile|count|find|summary|summarize|histogram|scatter|rows|where)\b', low):
            return _result('help', 'Run the large-table query first, then export its result in a separate instruction. No earlier result was exported by this combined request.', unsupported=True)
        if getattr(dataset, 'kind', None) == 'recording' and re.search(r'\b(?:detect|spikes?|firing[ -]rates?|filter|smooth|baseline|resample|decimate|refractory|threshold|bins?|binning|amplitude|half[ -]?width|inter[ -]?spike|action potentials?)\b', low):
            return _result('help', 'Run the recording measurement or settings change first, then send “export as SVG” separately. This combined request did not run a measurement or export an earlier result.', unsupported=True)
        style = _parse_style(text, dataset)
        m = re.search(r'\b(?:to|in|at)\s+["\x27](.+?)["\x27]\s*$', text, re.I) or re.search(r'\b(?:to|in|at)\s+((?:/|~[/\\]|[A-Za-z]:[/\\]).+?)\s*$', text, re.I)
        return _result('export', 'I will export the figure and an accompanying reproducibility package.', style=style,
                       **({'include_source': True} if re.search(r'\b(?:with|including)\s+(?:the\s+)?(?:raw\s+)?source\b', low) else {}),
                       **({'path': m.group(1)} if m else {}))
    if dataset is None:
        return _result('help', 'Open a spreadsheet, paste a table from clipboard, or use the example data first. You can also type: open "/path/to/data.xlsx".')
    if getattr(dataset, 'kind', None) == 'recording':
        from .recording_commands import interpret_recording
        return interpret_recording(text, dataset, previous_plan)

    # Read-only status, rationale, and column-inventory questions never trigger calculations.
    readonly = _readonly_question(text, dataset, previous_plan, context)
    if readonly is not None:
        return readonly

    if re.search(r'\b(?:bayes(?:ian)?|posterior|credible intervals?)\b', low):
        return _result('help', 'Bayesian inference is a planned extension and is not available in this version. It will need explicit priors, posterior summaries, predictive checks and verified numerical routines. I will not replace a Bayesian request with a frequentist test.', unsupported=True)
    if re.search(r'\b(?:electrophysiology|ephys|patch[ -]?clamp|continuous recordings?|detect(?:ion|ing)? spikes?|spike detection|power spectr(?:um|a)|edf|abf|nwb)\b', low):
        return _result('help', 'Continuous electrophysiology is a local ABF recording workflow. Open an .abf file for waveform review, or import a ClampFlow compiled spreadsheet for group statistics. Signal samples are never treated as independent spreadsheet observations.', unsupported=True)
    if re.search(r'\b(?:two[ -]way anova|factorial anova|repeated[ -]measures anova|welch(?:[’\x27]s)?\s+(?:one[ -]way\s+)?(?:anova|analysis of variance)|one[ -]sample(?:\s+t[ -]?test)?|one[ -](?:tailed|sided)|pooled(?:[ -]variance)?(?:\s+t[ -]?test)?|equal[ -]variances?|student[’\x27]?s?\s+t[ -]?test|mixed[ -]effects?|mixed models?|logistic|(?:multivariable|multiple)\s+cox(?:\s+regression)?|wilcoxon|friedman|bayesian|mediation|structural equation|tukey|post[ -]?hoc|adjusted p|false discovery|benjamini|bonferroni|holm|robust\s+(?:linear\s+)?regression|robust\s+(?:standard\s+)?errors?|heteroscedasticity[ -]consistent|multiple\s+(?:linear\s+)?regression|multi[ -]predictor(?:\s+regression)?|partial\s+correlation|fisher(?:[’\x27]s)?\s+exact|z[ -]?test)\b', low):
        return _result('help', 'That method is not implemented as a standalone routine in this version. I will not substitute another analysis. Available routines include descriptive summaries, Kaplan–Meier survival & Mantel–Cox log-rank tests, Welch and paired t-tests, multi-endpoint batch comparisons (with Holm adjustment), one-way ANOVA, Kruskal–Wallis, Mann–Whitney, correlations, one-predictor linear regression and chi-square.', unsupported=True)

    style = _parse_style(text, dataset)
    plot = _plot(text)

    # Explicit "Keep the same analysis, but change the figure..." always routes to style without re-running stats.
    if previous_plan and (style or plot) and re.search(r'\b(?:keep|retain|leave)\s+(?:the\s+)?same\s+(?:analysis|statistics|stats|test|results?)\b|\bsame\s+(?:analysis|statistics|stats|test)\b.*\b(?:but|just|only)\b', low):
        return _result('style', 'I will update the figure presentation while keeping the existing statistical analysis unchanged.', style=style, **({'plot': plot} if plot else {}))

    design = _design(text)
    pending = context.get('pending_plan')
    method = _method(text)

    # A short answer resolves a prior design question without requiring repetition of the request.
    if design and (method is None) and not re.search(r'\b(?:compar(?:e|ison)|plot|scatter|correlat(?:e|ion)|recommend|suggest|analy[sz]e|title|label|font|width|height|colou?r|palette)\b', low) and (len(text.split()) < 16 or pending):
        if pending:
            p = deepcopy(pending); p['design'] = design
            if design == 'paired' and p.get('method') == 'ttest':
                p['method'] = 'paired_t'
            try:
                return _resolve_plan(p, text, dataset, {**context, 'design': design})
            except ValueError as e:
                return _result('clarify', str(e), plan=p)
        if design == 'unknown':
            return _result('clarify', 'The study design is uncertain or contradictory. Are the observations independent, or are measurements repeated on the same subjects?', plan={'method': 'describe', 'design': 'unknown'})
        return _result('design', f'I have recorded the study design as {design}.', design=design)

    if re.search(r'\b(?:recommend|suggest|which test|what test|appropriate test|what analysis|analy[sz]e (?:my |the |this )?data|check assumptions)\b', low):
        num = [c for c in _numeric(dataset.df) if not _identifier(c)]
        cat = [str(c) for c in dataset.df.columns if str(c) not in _numeric(dataset.df) and not _identifier(str(c))]
        return _result('recommend',
            f'I found {len(dataset.df)} rows, {len(num)} numeric measurement columns and {len(cat)} categorical columns. '
            'Choose the scientific question and experimental unit first. For two independent groups, a Welch t-test estimates a difference in means (use “pooled by Mouse_ID” for nested sweeps/cells); '
            'for the same units measured twice, use a paired t-test; for multiple endpoints across groups, use “batch compare”; for a relationship between two numeric variables, consider correlation or one-predictor regression. '
            'This version will not search through methods to find the smallest p-value. Tell me the outcome, grouping or predictor columns, and whether observations are independent or paired.')

    if plot is None and re.match(r'^(?:please\s+)?(?:plot|graph|chart|visuali[sz]e)\b', low):
        plot = 'distribution'
    if pending and method is None and not style and not plot:
        try:
            if _mentions(text, dataset.df):
                return _resolve_plan(deepcopy(pending), text, dataset, context)
        except ValueError as e:
            return _clarify(pending, str(e))
    if method is None and (style or plot):
        # Ignore column mentions that appear inside title/xlabel/ylabel or group_order text.
        stripped_for_mentions = re.sub(r'\b(?:(?:figure\s+)?title|x[ -]?(?:axis)?\s*label|y[ -]?(?:axis)?\s*label|label\s+(?:the\s+)?[xy](?:[ -]axis)?|order\s+groups?)\b.*$', '', text, flags=re.I)
        try:
            mentioned = _mentions(stripped_for_mentions, dataset.df)
        except ValueError as e:
            return _result('clarify', str(e), plan=previous_plan or {})
        if previous_plan and not mentioned:
            return _result('style', 'I will update the figure presentation. The analysis and its observations stay unchanged.', style=style, **({'plot': plot} if plot else {}))
        if plot:
            p = {'method': 'describe', 'style': style, 'plot': plot}
            try:
                return _resolve_plan(p, text, dataset, context)
            except ValueError as e:
                return _clarify(p, str(e))
        if not previous_plan:
            return _result('help', 'Run an analysis or request a plot first, then I can change its presentation.')
        return _result('style', 'I will update the figure presentation.', style=style, **({'plot': plot} if plot else {}))
    if method is None and re.search(r'\bcorrelat(?:ion|e)\b', low):
        return _result('clarify', 'Would you like Pearson correlation (linear association) or Spearman correlation (rank association)? Name the method and the two numeric columns.', plan={'method': 'pearson'})
    if method is None and re.search(r'\bcompar(?:e|ison)\b', low):
        try:
            mentioned_with_pos = _mentions(text, dataset.df)
            pool_col = _extract_clause_column(r'\b(?:pooled\s+by|pool\s+by|averag(?:e|ing)\s+within|cluster(?:ed)?\s+by)\b', text, dataset.df)
            names = _unique(c for _, c in mentioned_with_pos if c != pool_col)
            numerical = _numeric(dataset.df)
            cat = [c for c in names if c not in numerical and not _identifier(c)]
            allcats = [str(c) for c in dataset.df.columns if str(c) not in numerical and not _identifier(str(c))]
            group_search = re.split(r'\b(?:pooled\s+by|pool\s+by)\b', text, maxsplit=1, flags=re.I)[0]
            by = re.search(r'\b(?:grouped\s+by|by|across)\b', group_search, re.I)
            explicit_group = next((c for pos, c in mentioned_with_pos if by and pos > by.end() and pos < len(group_search) and c != pool_col), None)
            group = explicit_group or (cat[0] if len(cat) == 1 else (allcats[0] if len(allcats) == 1 else None))
            outcomes_before_by = [c for pos, c in mentioned_with_pos if by and pos < by.start() and c in numerical and not _identifier(c) and c != pool_col]
            if group and len(outcomes_before_by) > 1:
                method = 'batch_compare'
            else:
                n_groups = int(dataset.df[group].dropna().nunique()) if group else len([c for c in names if c in numerical])
                if n_groups == 2:
                    method = 'paired_t' if design == 'paired' else 'ttest'
                elif n_groups > 2:
                    method = 'anova'
                else:
                    return _clarify({'method': 'ttest'}, 'Name the numeric outcome and grouping column, or the two numeric columns you want to compare.')
        except ValueError as e:
            return _clarify({'method': 'ttest'}, str(e))
    if method is None:
        return _result('help', 'I could not translate that instruction safely. ' + capabilities())
    p = {'method': method}
    if style:
        p['style'] = style
    if plot:
        p['plot'] = plot
    if pending and pending.get('method') == method:
        p = {**deepcopy(pending), **p}
    try:
        return _resolve_plan(p, text, dataset, context)
    except ValueError as e:
        return _clarify(p, str(e))
