"""Source-linked study-planning cards; no numerical or file operations.

Cards describe possibilities, evidence and missing information. A study intake
never acquires an analysis backend merely by recognizing a domain or approving
a plan. Only bounded metadata from Study.model_context() is inspected here.
"""
from __future__ import annotations

from copy import deepcopy
import math
import re


METHOD_IDS = (
    'study_descriptive_overview', 'study_design_comparison',
    'pleth_co2_response_curve', 'pleth_ventilation_hcvr_slope',
    'pleth_frequency_response', 'pleth_baseline_normalization',
    'study_repeated_measures', 'study_bayesian_hierarchical',
)

SOURCES = {
    'amorim_2025_hcvr': {
        'id': 'amorim_2025_hcvr',
        'title': 'Targeting melanocortin 4 receptor to treat sleep-disordered breathing in mice',
        'authors': 'Amorim MR et al.', 'year': 2025,
        'doi': '10.1172/JCI177823',
        'url': 'https://pmc.ncbi.nlm.nih.gov/articles/PMC12165796/',
        'method_note': 'Uses a per-animal minute-ventilation slope against inspired CO2.',
        'transfer_limit': 'The published gas range, wakefulness and plateau timing describe that experiment; they are not automatic defaults.',
    },
    'detweiler_2018_wbp': {
        'id': 'detweiler_2018_wbp',
        'title': 'Role of acid-sensing ion channels in hypoxia- and hypercapnia-induced ventilatory responses',
        'authors': 'Detweiler ND, Vigil KG, Resta TC, Walker BR, Jernigan NL',
        'year': 2018, 'doi': '10.1371/journal.pone.0192724',
        'url': 'https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0192724',
        'method_note': 'Reports frequency, tidal volume and minute ventilation separately, including calibration and body-mass normalization.',
        'transfer_limit': 'An assay name or syringe calibration alone does not establish the validity of an absolute ventilation outcome.',
    },
    'receno_2019_baseline': {
        'id': 'receno_2019_baseline',
        'title': 'Young and middle-aged mouse breathing behavior during the light and dark cycles',
        'authors': 'Receno CN, Eassa BE, Cunningham CM, DeRuisseau LR',
        'year': 2019, 'doi': '10.14814/phy2.14060',
        'url': 'https://pmc.ncbi.nlm.nih.gov/articles/PMC6474843/',
        'method_note': 'Shows that baseline-window definitions affect normalized gas-exposure responses.',
        'transfer_limit': 'A published baseline duration or filter/exclusion setting is not a default for a new study.',
    },
}


def _key(value):
    return re.sub(r'[^a-z0-9]', '', str(value).casefold())


def _mapping(value):
    return value if isinstance(value, dict) else {}


def _sequence(value):
    return value if isinstance(value, (list, tuple)) else []


def _headers(source, schemas=None):
    names = set()
    schemas = schemas or {}
    for sheet in _sequence(source.get('sheets'))[:64]:
        if isinstance(sheet, dict):
            values = sheet.get('headers', sheet.get('columns'))
            if values is None:
                values = _mapping(schemas.get(sheet.get('schema_id'))).get('headers')
            for name in _sequence(values)[:1024]:
                if isinstance(name, str):
                    names.add(_key(name))
    return names


def _bool(value):
    if isinstance(value, bool):
        return value
    if isinstance(value, str) and value.strip().casefold() in {'true', 'false'}:
        return value.strip().casefold() == 'true'
    # Do not interpret arbitrary numbers, counts or text as calibration flags.
    return None


def _flag_values(value):
    """Read explicit observed flags, never infer them from a column name."""
    flag = _bool(value)
    if flag is not None:
        return [flag]
    if isinstance(value, (list, tuple)):
        return [flag for item in value[:100] if (flag := _bool(item)) is not None]
    if isinstance(value, dict):
        for name in ('observed_values', 'values', 'value'):
            if name in value:
                return _flag_values(value[name])
    return []


def _calibration(source, aliases):
    metadata = _mapping(source.get('metadata'))
    calibration = _mapping(metadata.get('calibration'))
    allowed = {_key(alias) for alias in aliases}
    values = []
    for container in (calibration, _mapping(metadata.get('summary_flag_values'))):
        for name, value in container.items():
            if _key(name) in allowed:
                values.extend(_flag_values(value))
    return list(dict.fromkeys(values))


def _facts(study, state):
    method = getattr(study, 'model_context', None)
    context = method() if callable(method) else study.metadata()
    if not isinstance(context, dict):
        raise ValueError('Study planning requires a metadata object.')
    detailed = [source for source in _sequence(context.get('sources'))[:100]
                if isinstance(source, dict)]
    inventory = [source for source in _sequence(context.get('all_sources'))[:100]
                 if isinstance(source, dict)]
    if inventory:
        by_id = {source.get('source_id'): source for source in detailed
                 if isinstance(source.get('source_id'), str)}
        sources = [{**source, **by_id.get(source.get('source_id'), {})} for source in inventory]
    else:
        sources = detailed
    schemas = {schema.get('schema_id'): schema
               for schema in _sequence(context.get('schema_registry'))[:640]
               if isinstance(schema, dict) and isinstance(schema.get('schema_id'), str)}
    candidates = [source for source in sources if source.get('role') != 'reference_analysis']
    headers = [_headers(source, schemas) for source in candidates]
    conditions = [condition for source in candidates
                  for condition in _sequence(_mapping(source.get('metadata')).get('conditions'))[:200]
                  if isinstance(condition, dict)]
    doses = [condition.get('dose_percent') for condition in conditions]
    recorded_doses = [dose for dose in doses if type(dose) in (int, float)
                      and math.isfinite(dose) and 0 <= dose <= 100]
    candidate_doses = any(_sequence(condition.get('percent_label_candidates')) for condition in conditions)
    flags = {
        'volume': [_calibration(source, ['Volume_calibrated', 'volume calibrated']) for source in candidates],
        'syringe': [_calibration(source, ['Syringe_calibrated', 'syringe calibrated']) for source in candidates],
        'thermobarometric': [_calibration(source, ['Thermobarometric_corrected', 'thermobarometric corrected']) for source in candidates],
    }
    availability = {
        name: [_calibration(source, [name]) for source in candidates]
        for name in ('body_temperature_present', 'weight_present',
                     'absolute_volume_values_present', 'absolute_minute_ventilation_values_present',
                     'syringe_volume_values_present')
    }
    complete_inspection = [
        _mapping(_mapping(source.get('metadata')).get('calibration')).get('summary_inspection_complete') is True
        for source in candidates
    ]
    issue_blocks = {
        block for issue in _sequence(context.get('issues'))[:1000] if isinstance(issue, dict)
        for block in _sequence(issue.get('blocks')) if isinstance(block, str)
    }
    domain = _mapping(context.get('domain'))
    declared=state.get('domain_confirmation')
    domain_name=declared if isinstance(declared,str) and declared.strip() else domain.get('name','')
    return {
        'pleth': _key(domain_name) in {'pleth','plethysmography','wholebodyplethysmography','wbp'},
        'domain_origin':'user declaration' if isinstance(declared,str) and declared.strip() else 'intake proposal',
        'source_count': len(sources), 'candidate_count': len(candidates),
        'reference_count': len(sources) - len(candidates),
        'omitted_source_details': len([source for source in sources if not source.get('sheets')]),
        'headers': headers, 'recorded_dose_count': len(recorded_doses),
        'conditions_count': len(conditions), 'candidate_doses': candidate_doses,
        'calibration': flags, 'availability': availability,
        'complete_inspection': complete_inspection, 'issue_blocks': issue_blocks,
        'mapping_confirmed': state.get('mapping_confirmed') is True,
        'has_goal': isinstance(state.get('goal'), str) and bool(state['goal'].strip()),
        'has_groups': bool(_mapping(state.get('groups'))),
        'pooling': state.get('pooling') if isinstance(state.get('pooling'), str) else 'undecided',
    }


def _presence(facts, names):
    aliases = {_key(name) for name in names}
    return sum(bool(headers & aliases) for headers in facts['headers'])


def _readiness(known, missing, status='needs_information', message=None):
    return {'status': status, 'message': message or 'Review the evidence and resolve the named method requirements before execution.',
            'known': list(known), 'missing': list(missing)}


def _execution(single_table_backend=None, message=None):
    return {'status': 'planning_only',
            'message': message or 'This study project supports intake and planning. No numerical analysis or figure has been run.',
            'study_backend': 'unavailable', 'single_table_backend': single_table_backend}


def _card(identifier, title, question, approach, requirements, known, missing,
          figure, sources=(), single_table_backend=None, status='needs_information', execution_message=None):
    return {'id': identifier, 'title': title, 'question': question,
            'formula_or_approach': approach, 'requirements': list(requirements),
            'readiness': _readiness(known, missing, status=status),
            'execution_status': _execution(single_table_backend, execution_message),
            'suggested_figure': figure,
            'sources': [deepcopy(SOURCES[source]) for source in sources]}


def method_cards(study, state=None):
    """Return fresh JSON-safe method cards from bounded intake evidence only."""
    if state is None:
        state = {}
    if not isinstance(state, dict):
        raise ValueError('Study planning state must be an object.')
    facts = _facts(study, state)
    known = [f"Intake lists {facts['source_count']} source file(s); {facts['reference_count']} are identified as reference analyses."]
    if facts['omitted_source_details']:
        known.append(f"Detailed schema/calibration metadata for {facts['omitted_source_details']} source(s) are outside this bounded context; their readiness remains unknown.")
    if facts['mapping_confirmed']:
        known.append('The user confirmed the study mapping; that confirmation does not establish statistical independence or calibration.')
    else:
        known.append('The study mapping is still proposed.')
    missing = [] if facts['mapping_confirmed'] else ['Confirm subject identities, sessions and source roles.']
    if not facts['has_goal']:
        missing.append('State the scientific goal and primary outcome.')
    design_missing = missing + ['Identify the experimental unit and which factors vary within versus between units.',
                                'Specify outcome units, measurement windows and existing inclusion/missingness rules.']
    cards = [
        _card('study_descriptive_overview', 'Describe the study before choosing a test',
              'What was measured, at which level, and which files contribute observations or references?',
              'Review source roles and schemas; propose record counts, missingness and distributions at the confirmed measurement level. Do not combine reference results with observations.',
              ['Source-role mapping', 'Outcome meaning and units', 'Subject/session hierarchy'],
              known, missing + ['Confirm the relevant data sheet and what one row represents.'],
              'Source inventory now; outcome distributions and subject trajectories after an explicit calculation is supported.',
              single_table_backend='Single-table descriptive methods exist in ordinary table projects; they are not executed by study intake.'),
        _card('study_design_comparison', 'Choose a comparison that matches the design',
              'What scientific contrast should the analysis estimate?',
              'Map the goal to an outcome, comparison, experimental unit and within/between-unit factors before choosing a statistical model.',
              ['Primary comparison and outcome', 'Experimental unit', 'Repeated/paired structure', 'Covariates and multiplicity plan'],
              known + (['Group assignments have been entered.'] if facts['has_groups'] else []),
              design_missing,
              'A proposed subject-level comparison or repeated-measure trajectory, with uncertainty defined by the selected method.',
              single_table_backend='Some two-group, paired and one-factor methods exist for ordinary table projects; complex study models require their own backend.'),
    ]
    if facts['pleth']:
        cards.extend(_pleth_cards(facts, known, design_missing))
    cards.extend([
        _card('study_repeated_measures', 'Plan a repeated-measures or hierarchical analysis',
              'Which observations share a subject, session, recording or other clustering unit?',
              'Consider a design-appropriate repeated-measures or mixed-effects model with justified subject effects. Retain the nested structure instead of counting repeated observations as independent units.',
              ['Confirmed subject and repeat keys', 'Within/between-unit factors', 'Outcome distribution and units', 'Missingness and covariance/random-effect choices'],
              known, design_missing + ['Specify the repeated or nested model and check that the available unit counts can support it.'],
              'Individual trajectories plus model estimates and defined intervals once a validated backend is available.',
              execution_message='Planning only. A repeated-measures/mixed-model backend is unavailable in study projects; no model fit or inference has been performed.'),
        _card('study_bayesian_hierarchical', 'Plan a Bayesian hierarchical model',
              'Would explicit uncertainty and partial pooling across repeated measurements answer the study question?',
              'Specify the likelihood, hierarchy, priors and estimand; plan prior/predictive checks, sampling diagnostics and sensitivity analysis. Naming a Bayesian model does not fit one.',
              ['Explicit estimand', 'Outcome likelihood', 'Subject/repeat hierarchy', 'Prior rationale', 'Predictive checks, diagnostics and prior-sensitivity plan'],
              known, design_missing + ['Select and validate a Bayesian backend; specify priors and diagnostic criteria.'],
              'Observed subject data with posterior estimates and intervals only after a validated model is actually fitted.',
              execution_message='Planning only. A Bayesian inference backend is unavailable in study projects; no posterior, credible interval or Bayes factor has been calculated.'),
    ])
    if facts['pleth']:
        supported={'study_descriptive_overview','pleth_co2_response_curve','pleth_ventilation_hcvr_slope',
                   'pleth_frequency_response','pleth_baseline_normalization'}
        for card in cards:
            if card['id'] in supported:
                card['execution_status']={'status':'planning_only','study_backend':'pleth_summary_v1',
                    'message':'A deterministic pleth Summary execution bridge is implemented for supported XLSX exports. This card is a proposal: review and confirm an exact outcome/window/unit/aggregation recipe, then explicitly run it. Calibration and completeness gates still apply. No slope or other statistic is computed by selecting this card.',
                    'single_table_backend':card['execution_status'].get('single_table_backend')}
    return cards


def _pleth_cards(facts, known, design_missing):
    count = facts['candidate_count']
    pleth_known = known + [('The user identifies this as plethysmography; the declaration does not validate an acquisition adapter or calibration.'
                           if facts.get('domain_origin')=='user declaration' else
                           'Intake proposes plethysmography from its schema/metadata evidence; this is not a validated acquisition or calibration decision.')]
    rr_count = _presence(facts, ['RR_bpm', 'RespiratoryRate_bpm', 'BreathingFrequency_bpm', 'FR_bpm'])
    absolute_count = _presence(facts, ['MV_mL_per_min', 'MinuteVentilation_mL_per_min'])
    syringe_count = _presence(facts, ['MV_syringe_mL_per_min', 'VT_syringe_mL'])
    mass_count = _presence(facts, ['Weight_g', 'BodyWeight_g', 'BodyMass_g'])
    if rr_count:
        pleth_known.append(f'A respiratory-frequency field is listed in the bounded schema evidence for {rr_count} of {count} candidate source(s); header presence does not validate its values.')
    if syringe_count:
        pleth_known.append('Syringe-only excursion fields are listed; their original names and calibration status must remain visible.')
    dose_missing = ['Confirm baseline, exposure and recovery roles, gas composition and the actual dose predictor.']
    if facts['recorded_dose_count']:
        pleth_known.append('Some explicit dose metadata are recorded; protocol assignments still require review.')
    else:
        dose_missing.append('Recorded numeric dose metadata are absent from the bounded intake evidence.')
    if facts['candidate_doses']:
        pleth_known.append('Condition labels contain dose candidates; these remain proposed assignments, not newly measured gases.')
    window_missing = ['Define baseline and exposure windows, equilibration and activity/state handling; no paper-specific delay is supplied as a default.']
    if 'dose_response' in facts['issue_blocks']:
        dose_missing.append('Resolve the specific dose/epoch mapping issues listed by intake before calculating a dose-response endpoint.')
    volume_flags = facts['calibration']['volume']
    volume_false = any(False in values for values in volume_flags)
    full_volume_true = bool(volume_flags) and all(values and all(values) for values in volume_flags)
    calibration_known = []
    if volume_false:
        calibration_known.append('At least one candidate source explicitly marks full volume calibration false.')
    elif full_volume_true:
        calibration_known.append('All candidate sources report full volume calibration true; metadata flags alone do not validate finite outcomes or the measurement method.')
    else:
        calibration_known.append('Full-volume calibration is not established across the candidate sources.')
    syringe_flags = facts['calibration']['syringe']
    if any(True in values for values in syringe_flags):
        calibration_known.append('Some source metadata explicitly report syringe calibration; this does not by itself admit an absolute physiological ventilation outcome.')
    if any(False in values for values in facts['calibration']['thermobarometric']):
        calibration_known.append('Some source metadata explicitly report no thermobarometric correction; review the measurement method before interpreting volume units.')
    ve_availability = facts['availability']['absolute_minute_ventilation_values_present']
    absolute_values_missing = any(False in values and facts['complete_inspection'][index]
                                  for index, values in enumerate(ve_availability))
    partial_values_missing = any(False in values and not facts['complete_inspection'][index]
                                 for index, values in enumerate(ve_availability))
    if absolute_values_missing:
        calibration_known.append('At least one complete inspected Summary has no populated absolute minute-ventilation outcomes.')
    if partial_values_missing:
        calibration_known.append('No populated absolute minute-ventilation outcomes were observed in at least one inspected Summary portion; uninspected rows remain unknown.')
    if any(True in values for values in ve_availability):
        calibration_known.append('Populated absolute minute-ventilation values are observed in some inspected metadata; admissibility, units and calibration still require review.')
    if not any(values for values in ve_availability):
        calibration_known.append('The populated-value status of absolute minute ventilation is not established by the bounded metadata; tidal-volume availability does not determine it.')
    if any(False in values for values in facts['availability']['body_temperature_present']):
        calibration_known.append('Body-temperature values are not observed in at least one inspected source; the calibration method and any required temperature evidence need review.')
    volume_missing = ['Establish a valid finite minute-ventilation outcome and its calibration/measurement definition; retain syringe-only quantities under their own labels.']
    if 'absolute_ventilation' in facts['issue_blocks']:
        volume_missing.append('Resolve the specific intake issues that block an absolute-ventilation endpoint.')
    if not absolute_count:
        volume_missing.append('An absolute minute-ventilation field is not listed in the bounded candidate schema evidence; uninspected fields remain unknown.')
    else:
        calibration_known.append('An absolute minute-ventilation field is listed; its population and admissibility have not been established from headers.')
    if not mass_count or any(False in values for values in facts['availability']['weight_present']):
        volume_missing.append('For a mass-normalized endpoint, obtain body mass and its units for each relevant recording.')
    else:
        volume_missing.append('If mass normalization is chosen, validate the recorded mass, units and within-recording consistency.')
    common = design_missing + dose_missing + window_missing
    return [
        _card('pleth_co2_response_curve', 'Plan a CO2-response curve',
              'How does a chosen respiratory measure change across the protocol exposures?',
              'Preserve baseline, gas exposure and recovery as distinct epochs. Plan a descriptive curve of a selected measure, retaining each subject/session and its units; no automatic pooling or calculation is performed.',
              ['Chosen respiratory endpoint and units', 'Reviewed dose/epoch mapping', 'Measurement windows', 'Subject/session hierarchy'],
              pleth_known, common,
              'Subject trajectories and group summaries across protocol epochs, with baseline and recovery separate and uncertainty explicitly defined.',
              sources=('detweiler_2018_wbp', 'receno_2019_baseline')),
        _card('pleth_ventilation_hcvr_slope', 'Consider a minute-ventilation HCVR slope',
              'Is a minute-ventilation response slope against inspired CO2 the intended endpoint?',
              'Propose VE = intercept + slope × inspired CO2, with the dose range and unit explicitly selected. A concentration slope is per CO2 percentage point, not per mmHg; arterial/end-tidal pressure is a different measured predictor. Keep recovery separate. Do not reconstruct mean VE as mean(rate) × mean(tidal volume) without an explicit aggregation definition.',
              ['Valid admitted minute ventilation and calibration evidence', 'Dose predictor and units', 'Selected range/windows', 'Within-subject trial aggregation', 'Separate subsequent group-comparison plan'],
              pleth_known + calibration_known, common + volume_missing,
              'Per-subject ventilation-versus-dose points with the proposed fitted range and separately reported slope; no fitted line is generated during intake.',
              sources=('amorim_2025_hcvr', 'detweiler_2018_wbp'),
              status='metadata_requires_resolution' if volume_false or absolute_values_missing else 'needs_information',
              execution_message='A calibrated minute-ventilation CO2 slope has a deterministic recipe path for supported Summary exports. Missing physiological calibration blocks that endpoint; a frequency or syringe-scale slope retains its own distinct name and unit.'),
        _card('pleth_frequency_response', 'Consider the frequency-response component',
              'Would the breathing-frequency component answer a stated part of the question?',
              'Plan fixed-dose changes or a descriptive respiratory-rate slope against the selected CO2 predictor. A concentration slope has units breaths/min per CO2 percentage point. Frequency alone is not minute ventilation and must retain its component label.',
              ['Valid respiratory-frequency outcome and unit', 'Reviewed dose and epoch mapping', 'Subject/session hierarchy', 'Specified contrast or slope definition'],
              pleth_known, common + ([] if rr_count == count and count else ['A respiratory-frequency field is not established across all candidate source schemas.']),
              'Breathing-frequency trajectories or subject-level component slopes, with the contributing unit counts distinguished from breaths and recordings.',
              sources=('detweiler_2018_wbp',)),
        _card('pleth_baseline_normalization', 'Consider a within-subject baseline response',
              'Should the endpoint be an absolute change, percent baseline or percent change from a defined baseline?',
              'Choose one endpoint: Ydose − Ybaseline; 100 × Ydose/Ybaseline; or 100 × (Ydose − Ybaseline)/Ybaseline. Ratios require a finite nonzero baseline. Keep recovery distinct and record whether trial pooling precedes normalization. Percent scaling does not prove volume calibration.',
              ['Explicit outcome and units', 'Matched subject/session baseline', 'Finite nonzero denominator for ratios', 'Baseline/exposure windows', 'Pooling and normalization order'],
              pleth_known, common + ['Validate baseline values and specify the normalization and missing-baseline rule.'],
              'Subject-level paired baseline/exposure values or normalized response trajectories with the exact normalization in the label.',
              sources=('receno_2019_baseline',)),
    ]
