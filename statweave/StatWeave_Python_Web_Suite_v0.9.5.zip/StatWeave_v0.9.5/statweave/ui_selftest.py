"""Exercise the frozen desktop interface through the same public UI actions."""
from pathlib import Path
import json,time,traceback
from PySide6.QtCore import QTimer


def schedule(window,app,workspace):
    target=Path(workspace).resolve()/'ui-self-test'
    target.mkdir(parents=True,exist_ok=True)
    def check_descriptive_layout():
        import numpy as np
        assert window.session.result['method']=='describe'
        assert len(window.figure.axes)==2
        points=np.asarray(window.figure.axes[0].collections[0].get_offsets(),dtype=float)
        assert len(points)==36
        for section in [slice(0,18),slice(18,36)]:
            assert abs(np.corrcoef(points[section,0],points[section,1])[0,1])<.95
        window.grab().save(str(target/'corrected-summary-desktop.png'))
    steps=[lambda:window.load_demo(),
           lambda:window.send('describe the data'),
           check_descriptive_layout,
           lambda:window.send('compare Score by Treatment'),
           lambda:window.send('independent observations'),
           lambda:window.send('set the title to Treatment response'),
           lambda:window.send('make it blue'),
           lambda:window.send('export as SVG')]
    state={'index':0,'idle':0,'deadline':time.monotonic()+90}
    timer=QTimer(window)
    window._selftest_timer=timer
    def tick():
        try:
            if time.monotonic()>state['deadline']:
                raise AssertionError('Desktop self-test timed out')
            if window.busy or window._after_work:
                state['idle']=0
                return
            state['idle']+=1
            if state['idle']<3:
                return
            state['idle']=0
            if state['index']<len(steps):
                steps[state['index']]()
                state['index']+=1
                return
            assert window.session.result['method']=='ttest'
            assert window.session.style['palette']=='blue'
            assert window.session.style['title']=='Treatment response'
            assert window.last_export and Path(window.last_export['figure']).is_file()
            assert 'Welch' in window.results_view.toPlainText()
            window.grab().save(str(target/'desktop.png'))
            report={'status':'passed','workflow':['spreadsheet import','descriptive point-layout regression','design clarification','Welch test','title','palette','figure and record export'],
                    'export':window.last_export,'screenshot':str(target/'desktop.png')}
            (target/'result.json').write_text(json.dumps(report,indent=2))
            timer.stop();app.quit()
        except Exception as error:
            timer.stop()
            (target/'result.json').write_text(json.dumps({'status':'failed','error':str(error),'traceback':traceback.format_exc()},indent=2))
            app.exit(1)
    timer.timeout.connect(tick)
    timer.start(50)
