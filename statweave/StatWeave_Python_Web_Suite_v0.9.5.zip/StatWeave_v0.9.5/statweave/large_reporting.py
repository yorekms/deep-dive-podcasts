"""Bounded user-facing results and separately whitelisted model context."""
import math
import re

_PVAL_COL_RE = re.compile(r'(?:^|_|\b)(?:p[ _-]?val(?:ue)?|adjp(?:value)?|padj|fdr|q[ _-]?val(?:ue)?)$', re.I)


def _format_predicates(predicates):
    parts = []
    for p in predicates or []:
        col = str(p.get('column', ''))
        op = str(p.get('op', ''))
        val = repr(p.get('value'))
        if len(val) > 80:
            val = val[:77] + '…'
        parts.append(f'{col} {op} {val}')
    return '; '.join(parts)


def model_aggregate_context(result):
    accounting={key:value for key,value in result.get('large_table_accounting',{}).items()
                if isinstance(value,(int,float,bool)) and not isinstance(value,str)}
    summaries=[]
    for table in result.get('tables',[]):
        if table.get('title')!='Numeric summary':continue
        for row in table.get('rows',[])[:10]:
            item={'column':row['column']}
            for key in ['selected_rows','finite_count','nonfinite_count','invalid_count','null_count','min','max','mean','sd','median']:
                value=row.get(key)
                if value is None or isinstance(value,(int,float)) and not isinstance(value,bool) and math.isfinite(value):item[key]=value
            summaries.append(item)
    return {'method':result.get('method'),'accounting':accounting,'numeric_summaries':summaries,
            'scope':'Computed aggregate numbers only; no raw records, category values, file paths or plot coordinates.'}


def large_message(result):
    lines=[result['summary']]
    predicates = result.get('plan', {}).get('predicates') or []
    if predicates:
        lines.append('Active filter conditions: ' + _format_predicates(predicates) + ' (use “use all rows” to clear).')
        if any(_PVAL_COL_RE.search(str(p.get('column', ''))) for p in predicates):
            lines.append('Note: this derived selection filters on a p-value/FDR column; summaries and plots reflect the selected subset rather than the full testing family.')
    for table in result.get('tables',[]):
        rows=table.get('rows',[])
        if not rows:continue
        lines.append('\n'+table['title']+':')
        columns=table['columns']
        if table['title']=='Matching records':
            queried=[p['column'] for p in result.get('plan',{}).get('predicates',[]) if p['column'] in columns]
            columns=list(dict.fromkeys([columns[0],*queried,*columns]))[:10]
        for row in rows[:12]:
            values=[]
            for column in columns:
                value=row.get(column)
                rendered='unavailable' if value is None else f'{value:.6g}' if isinstance(value,float) else str(value)
                if len(rendered)>140:rendered=rendered[:137]+'…'
                values.append(f'{column}: {rendered}')
            lines.append(' · '.join(values))
        if len(rows)>12 or len(columns)<len(table['columns']):
            lines.append(f'Chat shows up to 12 result rows and selected fields; the complete returned table has {len(rows):,} rows and {len(table["columns"])} fields in the saved result/export. This display limit does not remove source records.')
    lines.append('These are local descriptive calculations. Source records remain unchanged; no inference or row-independence assumption was added.')
    return '\n'.join(lines)
