"""Non-secret conversation preferences and backward-compatible local settings."""
from __future__ import annotations

import math
import json
import os
from pathlib import Path
import re
import tempfile

DEFAULT_OPENAI_MODEL = 'gpt-6-luna'
_FIELDS = {'provider', 'enabled', 'model', 'base_url', 'timeout', 'model_digest',
           'openai_model', 'openai_timeout', 'use_system_wallet'}


def clean_settings(value):
    """Allow only known non-secret fields; never serialize arbitrary incoming keys."""
    source = value if isinstance(value, dict) else {}
    result = {}
    for key in _FIELDS:
        item = source.get(key)
        if key in {'enabled', 'use_system_wallet'}:
            if type(item) is bool: result[key] = item
        elif key in {'timeout', 'openai_timeout'}:
            if type(item) in (int, float) and math.isfinite(item) and 1 <= item <= 120:
                result[key] = item
        elif isinstance(item, str) and len(item) <= 512:
            result[key] = item
    if result.get('provider') not in {'openai', 'ollama', 'offline'}:
        result.pop('provider', None)
    result.setdefault('enabled', False)
    result.setdefault('model', '')
    result.setdefault('base_url', 'http://127.0.0.1:11434')
    result.setdefault('openai_model', DEFAULT_OPENAI_MODEL)
    result.setdefault('use_system_wallet', False)
    return result


def selected_provider(config):
    if not config.get('enabled'):
        return 'offline'
    # Old settings and tests enable Ollama without a provider field.
    return config.get('provider', 'ollama')


def validate_api_model(value):
    model = value.strip() if isinstance(value, str) else ''
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._:-]{0,127}', model):
        raise ValueError('Enter a model name using letters, numbers, dots, colons, underscores or hyphens.')
    return model


def write_settings(path, settings):
    """Publish only non-secret preferences, retaining the previous file on error."""
    path=Path(path)
    path.parent.mkdir(parents=True,exist_ok=True)
    temporary=None
    try:
        with tempfile.NamedTemporaryFile(mode='w',encoding='utf-8',dir=path.parent,
                                         prefix='.statweave-preferences-',delete=False) as handle:
            temporary=Path(handle.name)
            json.dump(clean_settings(settings),handle,indent=2)
            handle.flush();os.fsync(handle.fileno())
        os.replace(temporary,path)
    finally:
        if temporary is not None and temporary.exists():temporary.unlink()
