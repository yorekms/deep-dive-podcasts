"""Versioned calculated study exports and AI-free original-source reproduction."""
from datetime import datetime
import csv
import json
import os
from pathlib import Path
import shutil
import sys
import uuid
import zipfile

from .scrubber import escape_csv_cell


def export_study_analysis(session,request=None):
    from .session import clean,sha256,versions
    from .figures import export_figure,_style
    from .study_figures import make_figure,figure_caption,visual_spec
    from .study_bridge import status_text,result_is_current
    session._assert_integrity(full=True)
    if not session.result or session.result.get('method')!='study_execution':
        raise ValueError('No calculated study result is available to export.')
    request=request or {}
    if set(request)-{'action','include_source','style'}:raise ValueError('Unsupported study-analysis export option.')
    include=request.get('include_source',False)
    if type(include) is not bool:raise ValueError('Source inclusion must be explicitly true or false.')
    result=session.result;recipe=result['recipe']
    style=_style({}, {**session.style,**request.get('style',{})})
    parent=session.project_dir/'exports'
    parent.mkdir(parents=True,exist_ok=True)
    stem_name=f'study-analysis-{datetime.now():%Y%m%d-%H%M%S}-{uuid.uuid4().hex[:4]}'
    folder=parent/stem_name
    stage=parent/f'.{stem_name}.tmp'
    archive=folder.with_suffix('.zip')
    temp_archive=parent/f'.{stem_name}.zip.tmp'
    stage.mkdir(parents=True,exist_ok=False)
    try:
        figure=make_figure(session.dataset,result,session.plan,style)
        formats=['pdf','svg','png']
        if style.get('format') and style['format'] not in formats:formats.append(style['format'])
        for extension in formats:export_figure(figure,stage/('figure.'+extension),dpi=style['dpi'])
        caption=figure_caption(session.dataset,result,session.plan,style)
        (stage/'caption.txt').write_text(caption,encoding='utf-8')
        figure_count=1
        if result.get('report'):
            for measure in result.get('measures',[]):
                child=measure.get('result')
                if measure.get('status')!='executed' or not child:continue
                name=measure['outcome']
                if not name.replace('_','').isalnum():raise ValueError('Invalid measure output identity.')
                directory=stage/'measures'/name;directory.mkdir(parents=True,exist_ok=False)
                fig=make_figure(session.dataset,child,child['recipe'],style)
                for extension in formats:export_figure(fig,directory/('figure.'+extension),dpi=style['dpi'])
                (directory/'caption.txt').write_text(figure_caption(session.dataset,child,child['recipe'],style),encoding='utf-8')
                (directory/'figure-spec.json').write_text(json.dumps(visual_spec(session.dataset,child,child['recipe'],style),indent=2,ensure_ascii=False))
                figure_count+=1
        for index,table in enumerate(result.get('tables',[]),1):
            with (stage/f'results-{index:02}.csv').open('w',encoding='utf-8',newline='') as handle:
                writer=csv.DictWriter(handle,fieldnames=table['columns']);writer.writeheader()
                for row in table['rows']:
                    writer.writerow({key:escape_csv_cell(json.dumps(clean(row.get(key)),ensure_ascii=False) if isinstance(row.get(key),(dict,list)) else clean(row.get(key))) for key in table['columns']})
        for name,value in [('result.json',result),('recipe.json',recipe),('planning-state.json',session.context['study_state']),
                           ('source-inventory.json',session.dataset.manifest()),('window-ledger.json',result.get('window_ledger',[])),
                           ('processing-steps.json',result.get('processing_steps',[])),('environment.json',versions()),
                           ('conversation.json',session.conversation),('figure-spec.json',visual_spec(session.dataset,result,session.plan,style))]:
            (stage/name).write_text(json.dumps(clean(value),indent=2,ensure_ascii=False,allow_nan=False),encoding='utf-8')
        # Reproduce the run's actual bound planning state, not a later edited plan.
        execution=session.context.get('study_execution',{})
        matched=next((run for run in reversed(execution.get('runs',[])) if run.get('recipe_sha256')==result['recipe_sha256']),None)
        if not matched:raise ValueError('The result has no registered completed execution run.')
        run_dir=(session.project_dir/matched['directory']).resolve()
        if not run_dir.is_relative_to(session.project_dir.resolve()):raise ValueError('The saved run is outside the project.')
        for name,digest in matched['files'].items():
            path=(run_dir/name).resolve()
            if not path.is_relative_to(run_dir) or not path.is_file() or sha256(path)!=digest:raise ValueError('A recorded execution run changed outside its history.')
        run_state_path=run_dir/'planning-state.json'
        if not run_state_path.is_file():raise ValueError('The execution run is missing its bound scientific planning state.')
        shutil.copy2(run_state_path,stage/'planning-state.json')
        run_environment=json.loads((run_dir/'environment.json').read_text())
        (stage/'export-environment.json').write_text(json.dumps(versions(),indent=2))
        shutil.copy2(run_dir/'environment.json',stage/'environment.json')
        shutil.copy2(session.dataset.source_path,stage/'study.json')
        if include:
            for source in session.dataset.manifest()['sources']:
                original=(session.project_dir/source['relative_path'])
                if original.is_symlink():raise ValueError('Refusing to export a symlinked study source.')
                original=original.resolve();target=(stage/source['relative_path']).resolve()
                if not original.is_relative_to(session.project_dir.resolve()) or not target.is_relative_to(stage.resolve()):raise ValueError('A registered source escaped the export.')
                target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(original,target)
                if sha256(target)!=source['sha256']:raise ValueError('A source changed during export.')
        spec={'schema_version':1,'input_type':'study_execution','recipe':recipe,'recipe_sha256':result['recipe_sha256'],
              'style':style,'raw_sources_included':include,'result_status':status_text(session),
              'matches_current_choices':result_is_current(session),'figure_count':figure_count}
        (stage/'analysis.json').write_text(json.dumps(clean(spec),indent=2,ensure_ascii=False))
        (stage/'reproduce.py').write_text(REPRODUCE,encoding='utf-8')
        code=stage/'reproduction-source/statweave';code.mkdir(parents=True)
        module_root=run_dir/'reproduction-source/statweave'
        fallback_root=Path(__file__).parent
        for name in ['__init__.py','scrubber.py','study.py','study_execution.py','study_figures.py','figures.py']:
            candidate=module_root/name if (module_root/name).is_file() else fallback_root/name
            shutil.copy2(candidate,code/name)
        pinned='\n'.join(f'{key}=={value}' for key,value in run_environment.items() if key in {'numpy','scipy','pandas','matplotlib','openpyxl','defusedxml'} and value!='not installed')
        (stage/'requirements.txt').write_text(pinned+'\n')
        methods=result['summary']+'\n\n'+status_text(session)+'\n\n'+caption+'\n\nProcessing steps\n'+json.dumps(result.get('processing_steps',[]),indent=2,ensure_ascii=False)
        (stage/'methods.txt').write_text(methods,encoding='utf-8')
        (stage/'START_HERE.md').write_text('# Recorded study analysis\n\nRead methods.txt, caption.txt and recipe.json. '
            'Every registered measure remains in the inventory, including unavailable/calibration-blocked measures. '
            'Per-measure figures are in measures/ for an all-measure report. Source windows are repeated observations, not independent animals.\n\n'+status_text(session)+
            '\n\nReproduction uses original Summary cells and the run’s scientific state without AI. Install requirements.txt in a Python environment, then run `python reproduce.py`. '
            'For a compact export supply the preserved project source tree: `python reproduce.py --source-project /path/to/project`. '
            'A source-inclusive export already contains those files. Each source hash must match. Reproduced output goes into a new directory and does not overwrite this record.\n',encoding='utf-8')
        session._assert_integrity(full=True)
        shutil.copy2(session.project_dir/'history.jsonl',stage/'history.jsonl')
        manifest={str(path.relative_to(stage)):sha256(path) for path in sorted(stage.rglob('*')) if path.is_file()}
        (stage/'SHA256.json').write_text(json.dumps(manifest,indent=2))
        with temp_archive.open('xb') as raw_zip:
            with zipfile.ZipFile(raw_zip,'w',compression=zipfile.ZIP_DEFLATED) as handle:
                for path in sorted(stage.rglob('*')):
                    if path.is_file():handle.write(path,str(Path(folder.name)/path.relative_to(stage)))
            raw_zip.flush();os.fsync(raw_zip.fileno())
        os.replace(stage,folder)
        os.replace(temp_archive,archive)
    except BaseException:
        shutil.rmtree(stage,ignore_errors=True)
        temp_archive.unlink(missing_ok=True)
        raise
    try:
        session._event('study_analysis_export',{'directory':str(folder),'recipe_sha256':result['recipe_sha256'],
            'raw_sources_included':include,'formats':formats,'figure_count':figure_count,'matches_current_choices':result_is_current(session)})
        session.save()
    except BaseException:
        shutil.rmtree(folder,ignore_errors=True)
        archive.unlink(missing_ok=True)
        raise
    return {'input_type':'study_execution','folder':str(folder),'archive':str(archive),'figure':str(folder/'figure.png'),
            'raw_sources_included':include,'calculations_performed':True,'figure_count':figure_count,'result_status':status_text(session)}


REPRODUCE=r'''"""Recompute the exact recorded study recipe from hash-verified originals; no AI."""
from pathlib import Path
import argparse,hashlib,json,shutil,sys,uuid
root=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'reproduction-source'))
from statweave.study import Study
from statweave.study_execution import run_recipe,run_report_recipe,recipe_digest
from statweave.study_figures import make_figure,figure_caption
from statweave.figures import export_figure
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--source-project',type=Path)
args=parser.parse_args()
spec=json.loads((root/'analysis.json').read_text())
recipe=json.loads((root/'recipe.json').read_text())
state=json.loads((root/'planning-state.json').read_text())
if recipe_digest(recipe)!=spec['recipe_sha256']:raise ValueError('The exported recipe digest changed.')
out=root/('reproduced-'+uuid.uuid4().hex[:8]);out.mkdir()
inventory=json.loads((root/'study.json').read_text())
source_root=(args.source_project or root).expanduser().resolve()
def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''):h.update(block)
    return h.hexdigest()
for source in inventory['sources']:
    original=(source_root/source['relative_path']).resolve()
    target=(out/source['relative_path']).resolve()
    if not original.is_relative_to(source_root) or not target.is_relative_to(out):raise ValueError('Unsafe source path.')
    if not original.is_file() or sha(original)!=source['sha256']:raise ValueError('Missing or changed source: '+source['source_id'])
    target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(original,target)
shutil.copy2(root/'study.json',out/'study.json')
study=Study.open(out/'study.json')
runner=run_report_recipe if recipe['adapter_id']=='pleth_summary_report_v1' else run_recipe
result=runner(study,state,recipe)
(out/'reproduced-result.json').write_text(json.dumps(result,indent=2,ensure_ascii=False,allow_nan=False))
stored=json.loads((root/'result.json').read_text())
if result!=stored:raise ValueError('Reproduced result differs from the recorded result.')
def render(value,directory):
    directory.mkdir(parents=True,exist_ok=True)
    fig=make_figure(study,value,value['recipe'],spec['style'])
    for ext in ('pdf','svg','png'):export_figure(fig,directory/('figure.'+ext),dpi=spec['style'].get('dpi',600))
    (directory/'caption.txt').write_text(figure_caption(study,value,value['recipe'],spec['style']))
render(result,out)
for measure in result.get('measures',[]):
    if measure.get('status')=='executed':render(measure['result'],out/'measures'/measure['outcome'])
print('Exact numerical reproduction passed. New figures and results:',out)
'''
