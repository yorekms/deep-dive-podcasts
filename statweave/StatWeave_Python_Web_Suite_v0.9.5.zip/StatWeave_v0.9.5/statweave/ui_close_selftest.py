"""Bounded native close-during-worker smoke test using one synthetic CSV."""
import hashlib
import json
from pathlib import Path
import time
import traceback

from PySide6.QtCore import QTimer

from .session import canonical,sha256,verify_audit,versions


def schedule(window,app,workspace):
    output=Path(workspace).resolve()/'ui-close-self-test';output.mkdir(parents=True,exist_ok=True)
    app.setQuitOnLastWindowClosed(False)
    started=time.monotonic()
    state={'followup_ran':False,'complete_callback_ran':False,'error':None,
           'deadline':started+8,'close_acknowledged':False}
    timer=QTimer(app);window._close_selftest_timer=timer

    def require(value,message):
        if not value:raise ValueError(message)

    def finish(error=None):
        # Never exit the process by destroying an active worker, even on failure.
        if window.thread is not None and window.thread.isRunning():
            state['error']=error or state['error'] or 'Close smoke check could not finish safely'
            window.close()
            return
        timer.stop()
        report={'status':'failed' if error else 'passed','scope':'One synthetic CSV; actual native Worker timeout and close lifecycle; no Ollama or private data',
                'seconds':time.monotonic()-started,'environment':versions()}
        if error:report.update(error=str(error),traceback=traceback.format_exc())
        else:
            session=window.session;session._assert_integrity(full=True)
            project=session.project_dir/'project.json';saved=json.loads(project.read_text())
            head,events=verify_audit(session.project_dir/'history.jsonl',saved['audit_head'])
            last=json.loads((session.project_dir/'history.jsonl').read_text().splitlines()[-1])
            content={key:value for key,value in saved.items() if key!='audit_head'}
            require(last['type']=='state_saved' and last['payload']['state_sha256']==hashlib.sha256(canonical(content).encode()).hexdigest(),'The close did not leave a valid saved checkpoint')
            require(sha256(state['original'])==state['source_sha256'] and sha256(session.dataset.source_path)==state['source_sha256'],'A synthetic original/snapshot changed during close')
            require(not state['followup_ran'] and window._after_work is None,'Queued follow-up ran after close request')
            require(not state['complete_callback_ran'],'Timeout worker unexpectedly ran success callback')
            require(any('Synthetic local-model timeout' in message['text'] for message in window.messages),'Timeout failure was not reported')
            report.update(checks=['visible_close_request_acknowledged','actual_worker_timeout_handled',
                'queued_followup_skipped','worker_thread_cleanup_before_close','window_closed_automatically',
                'project_checkpoint_and_audit_verified','original_and_snapshot_hashes_unchanged'],
                close_request_acknowledged=state['close_acknowledged'],worker_cleaned_up=window.thread is None,
                window_visible=window.isVisible(),followup_skipped=True,saved_checkpoint_verified=True,
                source_unchanged=True,project=str(project),audit_head=head,audit_events=events,
                screenshot=str(output/'close-requested.png'))
        (output/'result.json').write_text(json.dumps(report,indent=2,ensure_ascii=False))
        app.exit(1 if error else 0)

    def tick():
        try:
            if state['error']:
                finish(state['error']);return
            require(time.monotonic()<state['deadline'],'The bounded native close check exceeded eight seconds')
            if window.busy or window.isVisible():return
            require(window.thread is None,'The window closed before thread cleanup')
            finish()
        except Exception as error:
            state['error']=str(error) or type(error).__name__
            finish(state['error'])

    timer.timeout.connect(tick);timer.start(10)
    try:
        original=output/'synthetic-close.csv';original.write_text('Subject,Outcome\nsynthetic-subject,1.5\n')
        state.update(original=original,source_sha256=sha256(original))
        window.config={**window.config,'enabled':False};window.update_mode()
        window.session.import_file(original);window.refresh_workspace()
        def timeout_worker():
            time.sleep(.03)
            raise TimeoutError('Synthetic local-model timeout for the native close check.')
        def completed(value):state['complete_callback_ran']=True
        window.start_work(timeout_worker,completed,'Synthetic bounded worker for close verification…')
        window._after_work=lambda:state.update(followup_ran=True)
        require(not window.close(),'The busy window closed before the worker completed')
        require(window._close_requested and window.isVisible(),'The close request was not queued visibly')
        require(window.progress.isVisible() and 'Close requested' in window.progress.text(),'Visible close acknowledgement is missing')
        state['close_acknowledged']=True
        require(window.grab().save(str(output/'close-requested.png')),'Could not save synthetic close-acknowledgement screenshot')
    except Exception as error:
        state['error']=str(error) or type(error).__name__
        finish(state['error'])
