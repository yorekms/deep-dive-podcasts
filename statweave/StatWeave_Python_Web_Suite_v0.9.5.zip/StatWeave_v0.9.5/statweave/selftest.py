"""Bounded smoke verification of a source or frozen build, without a model."""
from pathlib import Path
import json
import sys
from .session import Session, sha256, verify_audit, versions


def run(workspace):
    root=Path(getattr(sys,'_MEIPASS',Path(__file__).resolve().parents[1]))
    work=Path(workspace).resolve()/'self-test'
    s=Session(work)
    s.import_file(root/'examples/independent_groups.csv')
    s.context['synthetic_demo']=True
    checks=[]
    for command,method in [
        ('describe the data','describe'),
        ('compare Score by Treatment, independent observations','ttest'),
        ('one-way ANOVA of Score by Treatment, independent observations','anova'),
        ('Mann-Whitney of Score by Treatment, independent observations','mannwhitney'),
        ('Kruskal-Wallis of Score by Treatment, independent observations','kruskal'),
        ('Pearson correlation of Dose and Score, independent observations','pearson'),
        ('Spearman correlation of Dose and Score, independent observations','spearman'),
        ('Regress Score on Dose, independent observations','regression')]:
        response=s.command(command)
        assert response.get('refresh') and s.result['method']==method,(command,response)
        checks.append(method)
    output=s.export_bundle()
    manifest=json.loads((Path(output['folder'])/'SHA256.json').read_text())
    for name,digest in manifest.items():
        assert sha256(Path(output['folder'])/name)==digest,name
    checks.append('export_manifest')
    reopen=Session(work)
    reopen.open_project(s.project_dir)
    assert reopen.result==s.result
    verify_audit(s.project_dir/'history.jsonl',reopen.last_hash)
    checks.append('project_readback')
    before=sha256(reopen.dataset.source_path)
    reply=reopen.command('remove outlier observations')
    assert sha256(reopen.dataset.source_path)==before and 'not delete' in reply['message']
    checks.append('pruning_blocked')
    s.import_file(root/'examples/paired_measurements.csv')
    response=s.command('paired t-test Before and After')
    assert response.get('refresh') and s.result['method']=='paired_t',response
    checks.append('paired_t')
    # Exercise the included Excel reader when the synthetic workbook is bundled.
    workbook=root/'examples/synthetic_workbook.xlsx'
    if workbook.exists():
        s.import_file(workbook)
        assert len(s.dataset.sheets)==2
        response=s.command('describe the data')
        assert response.get('refresh'),response
        checks.append('xlsx_multisheet')
    report={'status':'passed','checks':checks,'environment':versions(),'example_export':output,
            'limits':'Synthetic examples only. No live model, clean-machine, Windows, or macOS execution.'}
    work.mkdir(parents=True,exist_ok=True)
    (work/'self-test-result.json').write_text(json.dumps(report,indent=2))
    return report
