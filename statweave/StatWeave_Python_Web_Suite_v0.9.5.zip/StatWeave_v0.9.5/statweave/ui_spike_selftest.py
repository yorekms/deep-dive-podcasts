"""Exercise conversational spike measurements in the actual desktop app."""
from pathlib import Path
import json
import time
import traceback
from PySide6.QtCore import QTimer


def schedule(window, app, workspace, abf_path):
    target = Path(workspace).resolve() / 'ui-spike-self-test'
    target.mkdir(parents=True, exist_ok=True)
    steps = [lambda: window.open_path(Path(abf_path).resolve()),
             lambda: window.send('show channel 1 full sweep'),
             lambda: window.send('detect spikes using threshold -20 mV and refractory 2 ms'),
             lambda: window.send('overlay sweeps 1 through 2'),
             lambda: window.send('firing rate in 100 ms bins'),
             lambda: window.send('set spike threshold to -10 mV'),
             lambda: window.send('set the title to Detected spikes and firing rate'),
             lambda: window.send('export as SVG')]
    state = {'index': 0, 'idle': 0, 'deadline': time.monotonic() + 100}
    timer = QTimer(window)
    window._spike_selftest_timer = timer

    def tick():
        try:
            if time.monotonic() > state['deadline']:
                raise AssertionError('Desktop spike workflow timed out')
            if window.busy or window._after_work:
                state['idle'] = 0
                return
            state['idle'] += 1
            if state['idle'] < 3:
                return
            state['idle'] = 0
            if state['index'] < len(steps):
                steps[state['index']]()
                state['index'] += 1
                return
            session = window.session
            assert session.is_recording and session.result['method'] == 'spikes'
            assert session.plan['sweeps'] == [0, 1]
            assert session.plan['detector']['threshold_mv'] == -10
            assert session.plan['bin_width_s'] == .1
            assert session.result['events']
            assert session.result['processing_steps']
            assert window.last_export and Path(window.last_export['figure']).is_file()
            assert len(window.figure.axes) >= 2
            assert 'mV' in window.figure.axes[0].get_ylabel()
            history = [json.loads(line) for line in (session.project_dir / 'history.jsonl').read_text().splitlines()]
            analyses = [event for event in history if event['type'] == 'spike_analysis']
            assert len(analyses) >= 4
            assert analyses[0]['payload']['plan']['detector']['threshold_mv'] == -20
            assert analyses[-1]['payload']['plan']['detector']['threshold_mv'] == -10
            session._assert_integrity()
            window.grab().save(str(target / 'desktop.png'))
            report = {'status': 'passed', 'workflow': ['ABF import', 'full sweep selection', 'spike detection',
                'two-sweep overlay', '100 ms firing-rate bins', 'threshold adjustment', 'title', 'export'],
                'source_sha256': session.dataset.source_hash, 'events': len(session.result['events']),
                'analysis_history_entries': len(analyses), 'plan': session.plan,
                'export': window.last_export, 'screenshot': str(target / 'desktop.png')}
            (target / 'result.json').write_text(json.dumps(report, indent=2))
            timer.stop()
            app.quit()
        except Exception as error:
            timer.stop()
            (target / 'result.json').write_text(json.dumps({'status': 'failed', 'error': str(error),
                'traceback': traceback.format_exc()}, indent=2))
            app.exit(1)

    timer.timeout.connect(tick)
    timer.start(50)
