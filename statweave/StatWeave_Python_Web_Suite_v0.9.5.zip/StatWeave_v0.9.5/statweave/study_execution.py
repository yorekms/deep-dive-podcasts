"""Deterministic execution of a reviewed standard pleth Summary recipe.

This adapter reads preserved workbook Summary rows only.  It never reads
PerBreath, recalibrates a signal, infers an experimental unit, selects windows,
or asks a language model to perform arithmetic.
"""
from __future__ import annotations

from collections import defaultdict
from copy import deepcopy
import hashlib
import json
import math
from pathlib import Path
import re

import warnings as _warnings

import numpy as np
import openpyxl
from scipy import stats

try:
    with _warnings.catch_warnings():
        _warnings.simplefilter('ignore', DeprecationWarning)
        import defusedxml
        defusedxml.defuse_stdlib()
except ImportError:  # pragma: no cover
    pass

from .scrubber import zip_guard as _zip_guard

ADAPTER_ID = 'pleth_summary_v1'
MAX_SUMMARY_ROWS = 10_000
OUTCOMES = {
    'RR_bpm': {'column': 'RR_bpm', 'label': 'Respiratory frequency',
               'unit': 'breaths/min', 'calibration_class': 'frequency'},
    'VT_syringe_mL': {'column': 'VT_syringe_mL', 'label': 'Syringe-equivalent tidal excursion',
                      'unit': 'syringe-equivalent mL', 'calibration_class': 'syringe_only'},
    'MV_syringe_mL_per_min': {'column': 'MV_syringe_mL_per_min', 'label': 'Syringe-equivalent minute-volume signal',
                             'unit': 'syringe-equivalent mL/min', 'calibration_class': 'syringe_only'},
    'VT_mL': {'column': 'VT_mL', 'label': 'Tidal volume',
              'unit': 'mL', 'calibration_class': 'physiological_volume'},
    'MV_mL_per_min': {'column': 'MV_mL_per_min', 'label': 'Minute ventilation',
                      'unit': 'mL/min', 'calibration_class': 'physiological_volume'},
}
OUTCOMES.update({
    'VT_raw_units': {'column': 'VT_raw_units', 'label': 'Raw tidal excursion', 'unit': 'source raw units',
                     'calibration_class': 'raw_signal', 'caution': 'Raw source-signal excursion is not calibrated tidal volume.'},
    **{column: {'column': column, 'label': label, 'unit': 's', 'calibration_class': 'timing'}
       for column, label in [('Ti_s', 'Inspiratory time'), ('Te_s', 'Expiratory time'), ('Tr_s', 'Relaxation time')]},
    **{column: {'column': column, 'label': label, 'unit': 'syringe-equivalent mL/s', 'calibration_class': 'syringe_only'}
       for column, label in [('PIF_syringe_mL_per_s', 'Syringe-equivalent peak inspiratory signal'),
                             ('PEF_syringe_mL_per_s', 'Syringe-equivalent peak expiratory signal')]},
    **{column: {'column': column, 'label': label, 'unit': 'mL/s', 'calibration_class': 'physiological_volume'}
       for column, label in [('PIF_mL_per_s', 'Peak inspiratory flow'), ('PEF_mL_per_s', 'Peak expiratory flow')]},
    **{column: {'column': column, 'label': label, 'unit': unit, 'calibration_class': 'mass_normalized_volume'}
       for column, label, unit in [('VT_uL_per_g', 'Body-mass-normalized tidal volume', 'µL/g'),
                                  ('MV_mL_per_min_per_g', 'Body-mass-normalized minute ventilation', 'mL/min/g'),
                                  ('PIF_mL_per_s_per_g', 'Body-mass-normalized peak inspiratory flow', 'mL/s/g'),
                                  ('PEF_mL_per_s_per_g', 'Body-mass-normalized peak expiratory flow', 'mL/s/g')]},
    **{column: {'column': column, 'label': label, 'unit': 'source-defined index', 'calibration_class': 'source_index',
               'caution': 'This is a source-defined computed index. PenH and related indices are not direct measurements of airway resistance.'}
       for column, label in [('Pause', 'Pause (source-defined)'), ('PenH', 'PenH (source-defined)'),
                             ('LegacyPause_TeTi', 'Legacy Pause Te/Ti index'),
                             ('LegacyPenH_TeTi', 'Legacy PenH Te/Ti index')]},
})
_OPTION_KEYS = {'method', 'outcome', 'experimental_unit', 'pooling', 'normalization',
                'normalization_order', 'windows', 'fit_doses', 'inference', 'independent_subjects'}
_STATE_KEYS = ('goal', 'domain_confirmation', 'groups', 'subject_resolutions',
               'session_resolutions', 'mapping_confirmed', 'pooling', 'notes', 'selected_methods')
_FLAGS = ('Volume_calibrated', 'Syringe_calibrated', 'Thermobarometric_corrected')
_DIAGNOSTICS = ('Breaths', 'Clipped_breaths_rejected', 'Duration_s', 'Weight_g')


def _canonical(value):
    return json.dumps(value, ensure_ascii=False, allow_nan=False, sort_keys=True, separators=(',', ':'))


def recipe_digest(recipe):
    """Hash the complete closed recipe, without a self-referential hash field."""
    return hashlib.sha256(_canonical(recipe).encode('utf-8')).hexdigest()


def planning_state_digest(state):
    """Bind scientific declarations, while excluding execution approval itself."""
    return recipe_digest({key: state.get(key) for key in _STATE_KEYS})


def _number(value, location, *, minimum=None, maximum=None):
    if isinstance(value, bool) or value is None or isinstance(value, str) and not value.strip():
        raise ValueError(f'{location} must contain a finite numeric value; blank is not zero.')
    try:
        number = float(value)
    except (TypeError, ValueError, OverflowError):
        raise ValueError(f'{location} contains a nonnumeric value (type {type(value).__name__}); inspect the source cell directly.') from None
    if not math.isfinite(number):
        raise ValueError(f'{location} contains a nonfinite value.')
    if minimum is not None and number < minimum or maximum is not None and number > maximum:
        raise ValueError(f'{location} is outside the supported range {minimum}–{maximum}.')
    return number


def _dose(value, location):
    if type(value) not in (int, float):
        raise ValueError(f'{location} must be an explicit numeric inspired CO2 percentage, not a label.')
    return _number(value, location, minimum=0, maximum=100)


def _literal(value):
    if value is None or isinstance(value, (str, bool, int)):
        return value
    if isinstance(value, float):
        return value if math.isfinite(value) else str(value)
    return str(value)


def _true(value):
    # Explicit Excel booleans or the literal textual boolean are supported.
    # Nonzero numeric quantities and strings such as "yes" do not grant calibration.
    return value is True or isinstance(value, str) and value.strip().casefold() == 'true'


def _sources(study):
    if getattr(study, 'kind', None) != 'study' or not callable(getattr(study, 'verify_integrity', None)):
        raise ValueError('The pleth execution adapter requires an intact study project.')
    study.verify_integrity(full=True)
    manifest = study.manifest()
    observations = [source for source in manifest['sources'] if source.get('role') != 'reference_analysis']
    if not observations:
        raise ValueError('There are no observation exports; reference analyses are not observations.')
    for source in observations:
        if source.get('role') != 'standardized_export':
            raise ValueError(f"{source.get('source_id')}: the pleth Summary adapter does not support this observation layout. No source was silently excluded.")
        if Path(source.get('original_name', '')).suffix.casefold() != '.xlsx':
            raise ValueError(f"{source.get('source_id')}: the first pleth Summary adapter requires XLSX source exports.")
    return manifest, observations


def inspect_summary(study):
    """Return every physical Summary data row, with its raw cached cell values.

    Header-only or 64-row intake evidence is never used as the numerical table.
    Formula expressions are not evaluated.  Blank cached formula values remain
    blank and block execution when they are selected as an outcome.
    """
    manifest, observations = _sources(study)
    rows = []
    for source in observations:
        sid = source['source_id']
        if getattr(study, 'source_path', None):
            root = Path(study.source_path).parent.resolve()
            path = (root / source['relative_path']).resolve()
            if not path.is_relative_to(root):
                raise ValueError(f'{sid}: a source path escaped the project.')
        else:
            path = Path(study._paths[sid])
        _zip_guard(path)
        book = openpyxl.load_workbook(path, read_only=True, data_only=True, keep_links=False)
        try:
            sheets = [sheet for sheet in book if sheet.title.casefold() == 'summary']
            if len(sheets) != 1:
                raise ValueError(f'{sid}: exactly one Summary worksheet is required.')
            sheet = sheets[0]
            if sheet.max_column is None or sheet.max_column > 256:
                raise ValueError(f'{sid}: the Summary column extent is unsupported.')
            if sheet.max_row is None or sheet.max_row - 1 > MAX_SUMMARY_ROWS:
                raise ValueError(f'{sid}: Summary exceeds the {MAX_SUMMARY_ROWS:,}-row execution bound.')
            header = list(next(sheet.iter_rows(min_row=1, max_row=1, max_col=256, values_only=True), ()))
            named = [value for value in header if value is not None]
            if any(not isinstance(value, str) for value in named) or len(named) != len(set(named)):
                raise ValueError(f'{sid}: Summary headers must be unique literal text.')
            required = {'Condition', 'Start_s', 'End_s'}
            if not required.issubset(named):
                raise ValueError(f'{sid}: Summary needs literal headers Condition, Start_s and End_s.')
            for physical, values in enumerate(sheet.iter_rows(min_row=2, max_row=MAX_SUMMARY_ROWS + 2, max_col=max(1, len(header)), values_only=True), 2):
                if physical - 1 > MAX_SUMMARY_ROWS:
                    raise ValueError(f'{sid}: Summary exceeds the {MAX_SUMMARY_ROWS:,}-row execution bound.')
                if not any(value is not None and value != '' for value in values):
                    continue
                cells = dict(zip(header, values))
                row = {'source_id': sid, 'row': physical,
                       'label': _literal(cells.get('Condition')),
                       'short_label': _literal(cells.get('Condition_short')),
                       'start_s': _literal(cells.get('Start_s')),
                       'end_s': _literal(cells.get('End_s')),
                       'observed_co2_percent': _literal(cells.get('CO2_percent'))}
                row.update({key: _literal(cells.get(key)) for key in (*OUTCOMES, *_FLAGS, *_DIAGNOSTICS)})
                row['other_numeric_fields'] = {key: _literal(value) for key, value in cells.items()
                                               if isinstance(key, str) and key not in {*OUTCOMES, *_FLAGS, *_DIAGNOSTICS, 'Start_s', 'End_s', 'CO2_percent'}
                                               and type(value) in (int, float)}
                rows.append(row)
                if len(rows) > MAX_SUMMARY_ROWS:
                    raise ValueError(f'The study has more than {MAX_SUMMARY_ROWS:,} Summary rows; no calculation was run.')
        finally:
            book.close()
    study.verify_integrity(full=True)
    if not rows:
        raise ValueError('No nonblank Summary rows are available to execute.')
    return rows


def _bindings(observations, state):
    if not isinstance(state, dict) or state.get('mapping_confirmed') is not True:
        raise ValueError('Confirm source-to-subject/session mappings and groups before reviewing an execution recipe.')
    if not isinstance(state.get('goal'), str) or not state['goal'].strip():
        raise ValueError('State the scientific goal before reviewing an execution recipe.')
    bindings = []
    seen = set()
    for source in observations:
        sid = source['source_id']
        subject = state.get('subject_resolutions', {}).get(sid)
        session = state.get('session_resolutions', {}).get(sid)
        if not isinstance(subject, str) or not subject.strip() or not isinstance(session, str) or not session.strip():
            raise ValueError(f'{sid}: explicitly confirm both subject and session identities.')
        group = state.get('groups', {}).get(subject)
        if not isinstance(group, str) or not group.strip():
            raise ValueError(f'{sid}: assign subject {subject} to a reviewed group.')
        session_key = re.sub(r'\s+', '', session.casefold())
        session_key = re.sub(r'^(trial)0+(\d+)$', r'\1\2', session_key)
        key = (subject, session_key)
        if key in seen:
            raise ValueError(f'{sid}: duplicate source binding for subject {subject}, session {session}; do not count the same trial twice.')
        seen.add(key)
        bindings.append({'source_id': sid, 'subject': subject, 'session': session, 'group': group})
    return bindings


def _selection(options, rows, endpoint=None):
    windows = options.get('windows')
    if not isinstance(windows, list) or not windows or len(windows) > MAX_SUMMARY_ROWS:
        raise ValueError('Review an explicit window assignment for every Summary row before execution.')
    by_key = {(row['source_id'], row['row']): row for row in rows}
    selected = []
    seen = set()
    intervals = defaultdict(list)
    for incoming in windows:
        if not isinstance(incoming, dict) or set(incoming) - {'source_id', 'row', 'phase', 'co2_percent', 'reason'}:
            raise ValueError('Window assignments accept only source_id, row, phase, co2_percent and reason.')
        sid, physical = incoming.get('source_id'), incoming.get('row')
        if not isinstance(sid, str) or type(physical) is not int or (sid, physical) not in by_key:
            raise ValueError(f'{sid} Summary row {physical}: this physical source row does not exist.')
        key = (sid, physical)
        if key in seen:
            raise ValueError(f'{sid} Summary row {physical} occurs more than once in the recipe.')
        seen.add(key)
        phase = incoming.get('phase')
        if phase not in {'baseline', 'exposure', 'recovery', 'omit'}:
            raise ValueError(f'{sid} Summary row {physical}: explicitly assign baseline, exposure, recovery or omit.')
        reason = incoming.get('reason', '')
        if not isinstance(reason, str) or len(reason) > 2000 or '\x00' in reason:
            raise ValueError('A window reason must be text of at most 2,000 characters.')
        if phase == 'omit' and not reason.strip():
            raise ValueError(f'{sid} Summary row {physical}: an omitted window needs an explicit scientific/protocol reason.')
        if phase == 'omit' and re.search(r'\b(?:significan\w*|p\s*[-=<>]|outlier\w*|best\s+result)\b', reason, re.I):
            raise ValueError('Significance/outlier-based source pruning is not supported. Define a protocol or acquisition rule instead.')
        assignment = {'source_id': sid, 'row': physical, 'phase': phase,
                      'co2_percent': None, 'reason': reason.strip()}
        if phase != 'omit':
            assignment['co2_percent'] = _dose(incoming.get('co2_percent'), f'{sid} Summary row {physical} CO2 assignment')
            source = by_key[key]
            start = _number(source['start_s'], f'{sid} Summary!Start_s row {physical}')
            end = _number(source['end_s'], f'{sid} Summary!End_s row {physical}')
            if start >= end:
                raise ValueError(f'{sid} Summary row {physical}: require finite Start_s < End_s.')
            intervals[sid].append((start, end, physical))
            if endpoint is not None:
                minimum = None if endpoint['calibration_class'] == 'source_index' else 0
                _number(source.get(endpoint['column']), f"{sid} Summary!{endpoint['column']} row {physical}", minimum=minimum)
            if endpoint is not None and endpoint['calibration_class'] == 'syringe_only' and not _true(source.get('Syringe_calibrated')):
                raise ValueError(f'{sid} Summary row {physical}: syringe calibration is not explicitly true for this endpoint.')
            if endpoint is not None and endpoint['calibration_class'] in {'physiological_volume', 'mass_normalized_volume'}:
                for flag in ('Volume_calibrated', 'Thermobarometric_corrected'):
                    if not _true(source.get(flag)):
                        raise ValueError(f'{sid} Summary row {physical}: {flag} must be explicitly true for absolute physiological volume/ventilation.')
                if endpoint['calibration_class'] == 'mass_normalized_volume':
                    weight = _number(source.get('Weight_g'), f'{sid} Summary!Weight_g row {physical}', minimum=0)
                    if weight <= 0:
                        raise ValueError(f'{sid} Summary!Weight_g row {physical} must be positive for a body-mass-normalized endpoint.')
        elif incoming.get('co2_percent') is not None:
            assignment['co2_percent'] = _dose(incoming['co2_percent'], f'{sid} omitted row {physical} CO2 assignment')
        selected.append(assignment)
    missing = set(by_key) - seen
    if missing:
        sid, row = sorted(missing)[0]
        raise ValueError(f'{len(missing)} Summary row(s) lack an explicit assignment; first is {sid} row {row}. Nothing was silently dropped.')
    if not any(row['phase'] != 'omit' for row in selected):
        raise ValueError('The recipe omits every Summary row.')
    for sid, values in intervals.items():
        ordered = sorted(values)
        for previous, current in zip(ordered, ordered[1:]):
            if current[0] < previous[1]:
                raise ValueError(f'{sid}: admitted Summary windows {previous[2]} and {current[2]} overlap in time.')
    return sorted(selected, key=lambda row: (row['source_id'], row['row']))


def build_recipe(study, state, options):
    """Compile and fully validate explicit human choices into a bound recipe."""
    return _build_recipe(study, state, options)


def _build_recipe(study, state, options, inspection=None):
    if not isinstance(options, dict) or set(options) - _OPTION_KEYS:
        raise ValueError('The execution options contain unsupported fields.')
    choices = deepcopy(options)
    choices.setdefault('normalization_order', 'after_pooling')
    choices.setdefault('inference', 'none')
    choices.setdefault('independent_subjects', False)
    choices.setdefault('fit_doses', [])
    if choices.get('method') not in {'response_curve', 'co2_slope'}:
        raise ValueError('Choose the implemented response_curve or co2_slope method.')
    if choices.get('outcome') not in OUTCOMES:
        raise ValueError('Choose one implemented outcome column: ' + ', '.join(OUTCOMES) + '.')
    if choices.get('experimental_unit') != 'subject':
        raise ValueError('Explicitly declare the experimental unit as subject; breaths and trials are not independent subjects.')
    if choices.get('pooling') not in {'equal_within_subject', 'separate'}:
        raise ValueError('Explicitly choose equal_within_subject or separate trial handling.')
    if choices['pooling'] != state.get('pooling'):
        raise ValueError('Recipe trial handling differs from the recorded study choice. Update that choice and review the recipe again.')
    if choices.get('normalization') not in {'none', 'fold_baseline', 'percent_baseline', 'percent_change'}:
        raise ValueError('Explicitly choose none, fold_baseline, percent_baseline or percent_change normalization.')
    if choices['normalization_order'] not in {'after_pooling', 'within_trial'}:
        raise ValueError('Normalization order must be after_pooling or within_trial.')
    if choices['pooling'] == 'separate' and choices['normalization'] != 'none' and choices['normalization_order'] != 'within_trial':
        raise ValueError('Separate trials are normalized within each trial. Explicitly choose normalization_order=within_trial before reviewing the recipe; after_pooling does not apply when trials stay separate.')
    if choices['inference'] not in {'none', 'welch_slopes'} or type(choices['independent_subjects']) is not bool:
        raise ValueError('Inference must be none or welch_slopes, with an explicit boolean independent_subjects declaration.')
    manifest, observations = _sources(study) if inspection is None else inspection[:2]
    bindings = _bindings(observations, state)
    endpoint = deepcopy(OUTCOMES[choices['outcome']])
    if endpoint['calibration_class'] == 'mass_normalized_volume':
        conflicts = [issue for issue in manifest.get('issues', []) if issue.get('type') == 'weight_conflict']
        if conflicts:
            raise ValueError('Body-mass-normalized endpoints are blocked by unresolved source body-weight conflicts: '+', '.join(issue['source_id'] for issue in conflicts)+'. Frequency and unnormalized outcomes remain available.')
    rows = inspect_summary(study) if inspection is None else inspection[2]
    choices['windows'] = _selection(choices, rows, endpoint)
    admitted_sources = {row['source_id'] for row in choices['windows'] if row['phase'] != 'omit'}
    if admitted_sources != {binding['source_id'] for binding in bindings}:
        raise ValueError('Every observation source/trial must contribute an admitted window. Whole-trial/subject exclusion requires a future explicit study-admission adapter.')
    fit = choices['fit_doses']
    if not isinstance(fit, list) or len(fit) > 100:
        raise ValueError('fit_doses must be an explicit list of at most 100 numeric CO2 percentages.')
    fit = [_dose(value, 'Slope fit dose') for value in fit]
    if len(set(fit)) != len(fit):
        raise ValueError('Slope fit doses must be distinct.')
    choices['fit_doses'] = sorted(fit)
    if choices['method'] == 'co2_slope':
        if choices['pooling'] != 'equal_within_subject':
            raise ValueError('Subject CO2 slopes require equal_within_subject pooling in this adapter.')
        if len(fit) < 3:
            raise ValueError('A subject CO2 slope requires at least three explicitly selected distinct fit doses.')
    elif fit:
        raise ValueError('Fit doses belong to a co2_slope recipe; response_curve does not fit a slope.')
    if choices['inference'] == 'welch_slopes' and (choices['method'] != 'co2_slope' or not choices['independent_subjects']):
        raise ValueError('Welch slope comparison requires co2_slope and an explicit independent_subjects=True declaration.')
    recipe = {'schema_version': 1, 'adapter_id': ADAPTER_ID,
              'source_manifest_sha256': recipe_digest(manifest),
              'planning_state_sha256': planning_state_digest(state),
              'endpoint': endpoint, 'options': choices, 'source_bindings': bindings}
    # Review validates structural prerequisites only.  It does not calculate
    # group means, slopes or hypothesis tests before the run is approved.
    _validate_grid(rows, recipe)
    return recipe


def _validate_grid(rows, recipe, *, validate_baseline=True):
    options = recipe['options']
    actual = {(row['source_id'], row['row']): row for row in rows}
    grids = defaultdict(set)
    positive_baselines = set()
    for window in options['windows']:
        if window['phase'] == 'omit':
            continue
        sid = window['source_id']
        grids[sid].add((window['phase'], window['co2_percent']))
        if validate_baseline and window['phase'] == 'baseline' and float(actual[(sid, window['row'])][options['outcome']]) > 0:
            positive_baselines.add(sid)
    by_subject = defaultdict(list)
    for binding in recipe['source_bindings']:
        sid = binding['source_id']
        by_subject[binding['subject']].append(binding)
        if validate_baseline and options['normalization'] != 'none' and sid not in positive_baselines:
            raise ValueError(f'{sid}: every admitted trial requires a positive explicit baseline for normalization.')
    if options['normalization'] != 'none':
        baseline_doses = {window['co2_percent'] for window in options['windows'] if window['phase'] == 'baseline'}
        if len(baseline_doses) != 1:
            raise ValueError('Normalized responses require one explicitly reviewed baseline CO2 concentration; do not blend distinct baseline doses.')
    if options['pooling'] == 'equal_within_subject':
        for subject, bindings in by_subject.items():
            first = grids[bindings[0]['source_id']]
            for binding in bindings[1:]:
                if grids[binding['source_id']] != first:
                    raise ValueError(f'Subject {subject}: incomplete trial grid. Explicitly review window choices instead of silently changing trial weights.')
            if options['method'] == 'co2_slope':
                found = sorted(dose for phase, dose in first if phase != 'recovery' and dose in options['fit_doses'])
                if found != options['fit_doses']:
                    raise ValueError(f'Subject {subject}: every fit dose needs exactly one non-recovery phase; expected {options["fit_doses"]}, found {found}.')
    if options['inference'] == 'welch_slopes':
        groups = defaultdict(set)
        for binding in recipe['source_bindings']:
            groups[binding['group']].add(binding['subject'])
        if len(groups) != 2 or any(len(subjects) < 2 for subjects in groups.values()):
            raise ValueError('Welch slope comparison requires exactly two groups with at least two distinct subject slopes in each.')


def _mean(values):
    try:
        return float(math.fsum(values)/len(values))
    except OverflowError:
        pass
    scale = max(abs(value) for value in values)
    return float(scale * (math.fsum(value/scale for value in values)/len(values))) if scale else 0.0


def _sd(values):
    if len(values) < 2:
        return None
    scale = max(abs(value) for value in values)
    return float(np.std(np.asarray(values, dtype=float)/scale, ddof=1)*scale) if scale else 0.0


def _descriptive(values):
    """Descriptive statistics for the actual units in one explicit stratum.

    Hazen/type-5 quartiles match the supplied reviewed MATLAB descriptive
    convention. SEM is SD/sqrt(n), not a confidence interval or evidence that
    the scientific independence assumption is established.
    """
    if not values:
        return {'mean': None, 'sd': None, 'sem': None, 'median': None, 'q1': None,
                'q3': None, 'iqr': None, 'minimum': None, 'maximum': None,
                'iqr_method': 'hazen/type-5'}
    scale = max(abs(value) for value in values)
    quantiles = (np.percentile(np.asarray(values, dtype=float)/scale,
                              [25, 50, 75], method='hazen')*scale
                 if scale else np.zeros(3, dtype=float))
    q1, median, q3 = (float(value) for value in quantiles)
    sd = _sd(values)
    return {'mean': _mean(values), 'sd': sd,
            'sem': sd/math.sqrt(len(values)) if sd is not None else None,
            'median': median, 'q1': q1, 'q3': q3, 'iqr': q3-q1,
            'minimum': min(values), 'maximum': max(values),
            'iqr_method': 'hazen/type-5'}


def _normalize(value, baseline, mode, location):
    if mode == 'none':
        return value
    if baseline is None or baseline <= 0:
        raise ValueError(f'{location}: normalization requires an explicitly selected positive baseline for the same trial/subject.')
    ratio = value / baseline
    if mode == 'fold_baseline':
        return ratio
    if mode == 'percent_baseline':
        return 100.0 * ratio
    return 100.0 * (ratio - 1.0)


def _table(title, rows, columns=None):
    return {'title': title, 'columns': columns or (list(rows[0]) if rows else []), 'rows': rows}


def _calculate(rows, recipe):
    options = recipe['options']
    mode, order = options['normalization'], options['normalization_order']
    bindings = {binding['source_id']: binding for binding in recipe['source_bindings']}
    assignments = {(window['source_id'], window['row']): window for window in options['windows']}
    response, ledger = [], []
    trial_buckets = defaultdict(list)
    for row in rows:
        sid, physical = row['source_id'], row['row']
        assign, binding = assignments[(sid, physical)], bindings[sid]
        entry = {**binding, 'row': physical, 'label': row['label'], 'short_label': row['short_label'],
                 'start_s': row['start_s'], 'end_s': row['end_s'],
                 'phase': assign['phase'], 'co2_percent': assign['co2_percent'],
                 'source_co2_percent': row['observed_co2_percent'], 'included': assign['phase'] != 'omit',
                 'reason': assign['reason'], 'outcome_column': options['outcome'],
                 'source_value': row.get(options['outcome'])}
        ledger.append(entry)
        if assign['phase'] == 'omit':
            continue
        minimum = None if recipe['endpoint']['calibration_class'] == 'source_index' else 0
        value = _number(row.get(options['outcome']), f'{sid} Summary row {physical} {options["outcome"]}', minimum=minimum)
        value_row = {**binding, 'row': physical, 'phase': assign['phase'], 'co2_percent': assign['co2_percent'], 'value': value}
        response.append(value_row)
        trial_buckets[(sid, assign['phase'], assign['co2_percent'])].append(value_row)
    raw_trials = []
    for (sid, phase, dose), entries in sorted(trial_buckets.items()):
        raw_trials.append({**bindings[sid], 'phase': phase, 'co2_percent': dose,
                           'value': _mean([entry['value'] for entry in entries]),
                           'rows': [entry['row'] for entry in entries], 'n_windows': len(entries)})
    baseline_by_source = defaultdict(list)
    # A trial baseline is the equal-window mean over all explicitly selected
    # baseline windows, not a breath-count- or duration-weighted average.
    for entry in response:
        if entry['phase'] == 'baseline':
            baseline_by_source[entry['source_id']].append(entry['value'])
    trial_baselines = {sid: _mean(values) for sid, values in baseline_by_source.items()}
    if mode != 'none':
        for sid in bindings:
            if sid not in trial_baselines or trial_baselines[sid] <= 0:
                raise ValueError(f'{sid}: every admitted trial requires a positive explicit baseline for normalization.')
    trial_rows = []
    for raw in raw_trials:
        final = deepcopy(raw)
        final['raw_value'] = raw['value']
        if mode != 'none' and (order == 'within_trial' or options['pooling'] == 'separate'):
            final['value'] = _normalize(raw['value'], trial_baselines.get(raw['source_id']), mode, raw['source_id'])
        final['value_stage'] = 'final_trial_response' if options['pooling'] == 'separate' or order == 'within_trial' else 'raw_trial_summary'
        trial_rows.append(final)
    trial_group_rows = []
    trial_group_buckets = defaultdict(list)
    for trial in trial_rows:
        trial_group_buckets[(trial['group'], trial['session'], trial['phase'], trial['co2_percent'], trial['value_stage'])].append(trial)
    for (group, session, phase, dose, value_stage), entries in sorted(trial_group_buckets.items()):
        subjects = [entry['subject'] for entry in entries]
        if len(set(subjects)) != len(subjects):
            raise ValueError(f'{group}, {session}, {phase} {dose:g}%: duplicate subject in trial-specific descriptive stratum.')
        trial_group_rows.append({'group': group, 'session': session, 'phase': phase,
                                 'co2_percent': dose, 'value_stage': value_stage,
                                 **_descriptive([entry['value'] for entry in entries]),
                                 'n_subjects': len(entries), 'subjects': subjects})
    subject_rows, group_rows, slopes, slope_group_rows, comparison = [], [], [], [], []
    if options['pooling'] == 'equal_within_subject':
        buckets = defaultdict(list)
        for trial in trial_rows:
            buckets[(trial['subject'], trial['group'], trial['phase'], trial['co2_percent'])].append(trial)
        # Every trial of a subject must contribute every displayed phase/dose.
        # Otherwise a nominal equal-trial curve would change its denominator.
        expected_sources = defaultdict(set)
        for binding in bindings.values():
            expected_sources[binding['subject']].add(binding['source_id'])
        subject_baselines = {}
        for subject, sources in expected_sources.items():
            if mode != 'none':
                subject_baselines[subject] = _mean([trial_baselines[sid] for sid in sorted(sources)])
        for (subject, group, phase, dose), trials in sorted(buckets.items()):
            if {trial['source_id'] for trial in trials} != expected_sources[subject]:
                raise ValueError(f'Subject {subject}, {phase} {dose:g}%: incomplete trial grid. Explicitly review window choices instead of silently changing trial weights.')
            value = _mean([trial['value'] for trial in trials])
            if mode != 'none' and order == 'after_pooling':
                value = _normalize(value, subject_baselines.get(subject), mode, f'Subject {subject}')
            subject_rows.append({'subject': subject, 'group': group, 'phase': phase, 'co2_percent': dose,
                                 'value': value, 'n_trials': len(trials),
                                 'source_ids': [trial['source_id'] for trial in trials],
                                 'lineage': [{'source_id': trial['source_id'], 'rows': trial['rows']} for trial in trials]})
        group_buckets = defaultdict(list)
        for subject_row in subject_rows:
            group_buckets[(subject_row['group'], subject_row['phase'], subject_row['co2_percent'])].append(subject_row)
        for (group, phase, dose), entries in sorted(group_buckets.items()):
            values = [entry['value'] for entry in entries]
            group_rows.append({'group': group, 'phase': phase, 'co2_percent': dose,
                               **_descriptive(values), 'n_subjects': len(entries),
                               'subjects': [entry['subject'] for entry in entries]})
        if options['method'] == 'co2_slope':
            fit_doses = options['fit_doses']
            subject_buckets = defaultdict(list)
            for entry in subject_rows:
                if entry['phase'] != 'recovery' and entry['co2_percent'] in fit_doses:
                    subject_buckets[entry['subject']].append(entry)
            for subject in sorted(expected_sources):
                entries = sorted(subject_buckets[subject], key=lambda entry: entry['co2_percent'])
                doses = [entry['co2_percent'] for entry in entries]
                if doses != fit_doses:
                    raise ValueError(f'Subject {subject}: every fit dose needs exactly one non-recovery phase; expected {fit_doses}, found {doses}.')
                x = np.asarray(doses, dtype=float)
                y = np.asarray([entry['value'] for entry in entries], dtype=float)
                xbar, ybar = float(np.mean(x)), float(np.mean(y))
                centered = x - xbar
                slope = float(np.dot(centered, y - ybar) / np.dot(centered, centered))
                intercept = float(ybar - slope * xbar)
                residual = y - (intercept + slope * x)
                sse, sst = float(np.dot(residual, residual)), float(np.dot(y-ybar, y-ybar))
                slopes.append({'subject': subject, 'group': entries[0]['group'], 'slope': slope,
                               'intercept': intercept, 'r_squared': 1.0 - sse/sst if sst > 0 else None,
                               'n_doses': len(doses), 'fit_doses': doses, 'residual_sum_squares': sse,
                               'lineage': [entry['lineage'] for entry in entries]})
            by_group = defaultdict(list)
            for entry in slopes:
                by_group[entry['group']].append(entry)
            for group, entries in sorted(by_group.items()):
                values = [entry['slope'] for entry in entries]
                slope_group_rows.append({'group': group, **_descriptive(values),
                                         'n_subjects': len(entries), 'subjects': [entry['subject'] for entry in entries]})
            if options['inference'] == 'welch_slopes':
                if len(by_group) != 2 or any(len(entries) < 2 for entries in by_group.values()):
                    raise ValueError('Welch slope comparison requires exactly two groups with at least two distinct subject slopes in each.')
                names = sorted(by_group)
                a = np.asarray([entry['slope'] for entry in by_group[names[0]]], dtype=float)
                b = np.asarray([entry['slope'] for entry in by_group[names[1]]], dtype=float)
                va, vb = float(np.var(a, ddof=1)/len(a)), float(np.var(b, ddof=1)/len(b))
                variance = va + vb
                if variance <= 0:
                    raise ValueError('Both groups have zero slope variance; Welch uncertainty is undefined. Keep the descriptive slope result or revise the scientific model.')
                se = math.sqrt(variance)
                df = variance**2/(va**2/(len(a)-1) + vb**2/(len(b)-1))
                effect = _mean(a.tolist()) - _mean(b.tolist())
                statistic = effect/se
                p = float(2*stats.t.sf(abs(statistic), df))
                interval = float(stats.t.ppf(.975, df)*se)
                comparison.append({'contrast': f'{names[0]} minus {names[1]}', 'group_1': names[0], 'group_2': names[1],
                                   'mean_difference': effect, 'standard_error': se, 'df': df, 't': statistic,
                                   'p_two_sided': p, 'ci_level': .95, 'ci_low': effect-interval,
                                   'ci_high': effect+interval, 'n_1': len(a), 'n_2': len(b)})
    plot_data = {'endpoint': deepcopy(recipe['endpoint']), 'normalization': mode, 'normalization_order': order,
                 'pooling': options['pooling'], 'method': options['method'], 'fit_doses': options['fit_doses'],
                 'response_rows': response, 'trial_rows': trial_rows, 'subject_rows': subject_rows,
                 'trial_group_rows': trial_group_rows, 'group_rows': group_rows,
                 'slopes': slopes, 'slope_group_rows': slope_group_rows}
    return plot_data, ledger, comparison


def run_recipe(study, state, recipe):
    """Revalidate source/state binding, then execute locally without AI."""
    if not isinstance(recipe, dict) or recipe.get('schema_version') != 1 or recipe.get('adapter_id') != ADAPTER_ID:
        raise ValueError('This execution recipe has an unsupported adapter or schema version.')
    compiled = build_recipe(study, state, recipe.get('options'))
    if _canonical(compiled) != _canonical(recipe):
        raise ValueError('The execution recipe, source evidence or scientific state changed. Review and confirm a new recipe before running.')
    rows = inspect_summary(study)
    result = _execute_compiled(study, compiled, rows)
    study.verify_integrity(full=True)
    return result


def _execute_compiled(study, compiled, rows):
    plot_data, ledger, comparison = _calculate(rows, compiled)
    options = compiled['options']
    omitted = [{'source_id': row['source_id'], 'row': row['row'], 'reason': row['reason']} for row in ledger if not row['included']]
    references = [{'source_id': source['source_id'], 'role': 'reference_analysis',
                   'reason': 'Derived/reference analysis is not an additional observation.'}
                  for source in study.manifest()['sources'] if source.get('role') == 'reference_analysis']
    warnings = ['Raw files and every source row remain intact. Summary outputs are source-software summaries; upstream breath detection and exclusions were not revalidated.',
                'Group descriptives use distinct subjects. SD, SEM and confidence intervals have different meanings; the figure caption declares the selected display. No breath/trial is counted as an independent subject.',
                'Inspired CO2 percentages are explicit recipe declarations; this adapter does not measure arterial or end-tidal CO2 pressure.']
    if compiled['endpoint']['calibration_class'] == 'syringe_only':
        warnings.append('Syringe-equivalent values are not physiologically corrected tidal volume/minute ventilation; normalization does not establish calibration. Do not label this slope calibrated HCVR.')
    if options['outcome'] == 'RR_bpm' and options['method'] == 'co2_slope':
        warnings.append('This is a respiratory-frequency response slope, not a minute-ventilation HCVR slope.')
    if options['pooling'] == 'separate':
        warnings.append('Trials are displayed separately. No independent group summary, subject-slope comparison or group p-value was calculated.')
    else:
        group_counts = defaultdict(set)
        for row in plot_data.get('group_rows', []):
            group_counts[row['group']].add(row['n_subjects'])
        for grp, counts in sorted(group_counts.items()):
            if len(counts) > 1:
                warnings.append(
                    f"Group '{grp}' has unequal subject coverage across protocol doses "
                    f"(n_subjects ranges from {min(counts)} to {max(counts)} due to explicit omissions or protocol differences); "
                    "connected group means reflect differing subject subsets across doses."
                )
    warnings.append('Trial-specific descriptive strata count distinct subjects within each session. Repeated sessions are not additional independent subjects. SEM is SD/sqrt(n), not a confidence interval; group plots use the separately selected interval setting.')
    if options['normalization'] != 'none':
        warnings.append('Normalization order is '+options['normalization_order']+'. Mean of trial ratios differs from ratio of pooled trial means; the chosen order is part of the recipe.')
    if options['inference'] == 'none':
        warnings.append('Descriptive execution: no group hypothesis test or p-value was requested or calculated.')
    else:
        warnings.append('Welch inference uses the user-declared independence of distinct subjects. Small groups can give unstable variance, confidence intervals and p-values; normality was not tested to select a method.')
    processing = [
        {'step': 1, 'operation': 'verify_sources', 'detail': 'Verify source-manifest binding and full SHA-256 hashes before and after numerical reads.'},
        {'step': 2, 'operation': 'read_summary', 'detail': 'Read every nonblank physical Summary row with cached values only; do not read PerBreath or execute formulas.', 'rows': len(ledger)},
        {'step': 3, 'operation': 'apply_reviewed_window_assignments', 'detail': 'Use the exact human-reviewed phase/dose assignments and explicit omission reasons.', 'included': len(ledger)-len(omitted), 'omitted': len(omitted)},
        {'step': 4, 'operation': 'validate_endpoint', 'detail': 'Validate selected source endpoint cells and endpoint-specific explicit calibration flags; never reconstruct MV from mean RR and mean VT.'},
        {'step': 5, 'operation': 'trial_window_mean', 'formula': 'arithmetic mean of admitted same-phase/same-dose windows within one source trial; equal window weights'},
        {'step': 6, 'operation': 'aggregate_and_normalize', 'pooling': options['pooling'], 'normalization': options['normalization'],
         'normalization_order': options['normalization_order'], 'formula': 'Equal trial means within subject; after_pooling normalizes pooled condition mean by equal-trial mean baseline. within_trial normalizes each trial first. fold_baseline=Y/B; percent_baseline=100*Y/B; percent_change=100*(Y/B-1). Baseline uses equal-window arithmetic mean within each trial.'},
        {'step': 7, 'operation': 'group_description', 'formula': 'Arithmetic mean, sample SD (ddof=1), SEM=SD/sqrt(n), median, Hazen/type-5 Q1/Q3/IQR, minimum and maximum of actual subject values; n counts distinct subjects; unavailable SD/SEM is null.',
         'quartile_method': 'hazen/type-5', 'trial_strata': 'Also summarize distinct subjects within group/session/phase/dose. Preserve trial value_stage: after_pooling-normalized recipes retain raw trial summaries, rather than calling them normalized trial responses.'},
    ]
    if options['method'] == 'co2_slope':
        processing.append({'step': 8, 'operation': 'subject_slope', 'formula': 'OLS with free intercept and equal weight per selected dose; slope=sum((x-xbar)*(y-ybar))/sum((x-xbar)^2). Recovery never enters fit.', 'fit_doses_percent': options['fit_doses']})
    if comparison:
        processing.append({'step': 9, 'operation': 'welch_subject_slopes', 'formula': 'Two-sided Welch t contrast on independent subject slopes; Satterthwaite df; t-based 95% CI of group1 minus group2. No multiplicity family beyond this single declared contrast.'})
    tables = [_table('Window accounting and physical source lineage', ledger),
              _table('Trial summaries', plot_data['trial_rows']),
              _table('Trial-specific group descriptive summaries', plot_data['trial_group_rows']),
              _table('Subject summaries', plot_data['subject_rows']),
              _table('Group descriptive summaries', plot_data['group_rows'])]
    if plot_data['slopes']:
        tables += [_table('Subject CO2 response slopes', plot_data['slopes']),
                   _table('Group slope descriptive summaries', plot_data['slope_group_rows'])]
    if comparison:
        tables.append(_table('Declared Welch comparison of subject slopes', comparison))
    if references:
        tables.append(_table('Reference sources excluded from observations', references))
    endpoint_name = compiled['endpoint']['label']
    if options['method'] == 'co2_slope':
        endpoint_name += ' CO2-response slope'
    summary = (f'{endpoint_name}: {len(ledger)-len(omitted)} of {len(ledger)} Summary windows admitted, '
               f'{len(compiled["source_bindings"])} trials and '
               f'{len({binding["subject"] for binding in compiled["source_bindings"]})} distinct subjects. '
               f'Trial handling: {options["pooling"]}; normalization: {options["normalization"]} ({options["normalization_order"]}). '
               + ('One explicitly declared Welch slope contrast was calculated.' if comparison else 'No group hypothesis test was calculated.'))
    result = {'method': 'study_execution', 'recipe': compiled, 'recipe_sha256': recipe_digest(compiled),
              'summary': summary, 'tables': tables, 'warnings': warnings,
              'row_accounting': {'total': len(ledger), 'used': len(ledger)-len(omitted), 'omitted': len(omitted), 'omitted_rows': omitted},
              'processing_steps': processing, 'plot_data': plot_data, 'window_ledger': ledger,
              'reference_sources': references, 'comparison': comparison}
    # A final finite JSON check rejects overflow rather than silently replacing
    # undefined arithmetic with zero or nonstandard JSON NaN.
    try:
        _canonical(result)
    except (ValueError, TypeError, OverflowError) as error:
        raise ValueError('The requested arithmetic produced an unsupported nonfinite result; no result was committed.') from error
    return result


def _report_options(state, options):
    if not isinstance(options, dict) or set(options) - _OPTION_KEYS:
        raise ValueError('The measure-report options contain unsupported fields.')
    choices = deepcopy(options)
    choices.setdefault('normalization_order', 'after_pooling')
    choices.setdefault('inference', 'none')
    choices.setdefault('independent_subjects', False)
    choices.setdefault('fit_doses', [])
    if choices.get('method') != 'measure_report' or choices.get('outcome') != 'all_available':
        raise ValueError('An all-measure report requires method=measure_report and outcome=all_available.')
    if choices.get('experimental_unit') != 'subject':
        raise ValueError('Explicitly declare the experimental unit as subject before preparing the report.')
    if choices.get('pooling') not in {'equal_within_subject', 'separate'} or choices['pooling'] != state.get('pooling'):
        raise ValueError('Report trial handling must match the reviewed equal_within_subject or separate study choice.')
    if choices.get('normalization') not in {'none', 'fold_baseline', 'percent_baseline', 'percent_change'}:
        raise ValueError('Explicitly choose none, fold_baseline, percent_baseline or percent_change report normalization.')
    if choices['normalization_order'] not in {'after_pooling', 'within_trial'}:
        raise ValueError('Report normalization order must be after_pooling or within_trial.')
    if choices['pooling'] == 'separate' and choices['normalization'] != 'none' and choices['normalization_order'] != 'within_trial':
        raise ValueError('Separate trials are normalized within each trial. Explicitly choose normalization_order=within_trial before reviewing the report; after_pooling does not apply when trials stay separate.')
    if choices['inference'] != 'none' or choices['fit_doses'] != []:
        raise ValueError('The all-measure report is descriptive and does not run a test battery or automatically fit slopes. Select a separate explicit endpoint/slope recipe for inference.')
    if type(choices['independent_subjects']) is not bool:
        raise ValueError('independent_subjects must be an explicit boolean declaration.')
    return choices


def _raw_counts(rows, column, *, other=False):
    values, missing, invalid = [], 0, 0
    for row in rows:
        value = row.get('other_numeric_fields', {}).get(column) if other else row.get(column)
        if value is None or isinstance(value, str) and not value.strip():
            missing += 1
            continue
        try:
            values.append(_number(value, column))
        except ValueError:
            invalid += 1
    return {'total_windows': len(rows), 'numeric_windows': len(values), 'missing_windows': missing,
            'invalid_windows': invalid}, values


def build_report_recipe(study, state, options):
    """Review every closed-registry measure without performing report arithmetic.

    Missing or uncalibrated measures remain explicit inventory entries.  A bad
    protocol/window/unit declaration still blocks the report as a whole.
    """
    choices = _report_options(state, options)
    manifest, observations = _sources(study)
    bindings = _bindings(observations, state)
    rows = inspect_summary(study)
    choices['windows'] = _selection(choices, rows)
    admitted_ids = {row['source_id'] for row in choices['windows'] if row['phase'] != 'omit'}
    if admitted_ids != {binding['source_id'] for binding in bindings}:
        raise ValueError('Every observation trial must contribute to the report; whole-trial exclusions need a separately implemented study-admission rule.')
    base = {'schema_version': 1, 'adapter_id': 'pleth_summary_report_v1',
            'source_manifest_sha256': recipe_digest(manifest), 'planning_state_sha256': planning_state_digest(state),
            'options': choices, 'source_bindings': bindings}
    _validate_grid(rows, base, validate_baseline=False)
    allowed = {(window['source_id'], window['row']) for window in choices['windows'] if window['phase'] != 'omit'}
    admitted = [row for row in rows if (row['source_id'], row['row']) in allowed]
    measures = []
    inspection = (manifest, observations, rows)
    for column, endpoint in OUTCOMES.items():
        counts, _ = _raw_counts(admitted, column)
        item = {'outcome': column, 'label': endpoint['label'], 'unit': endpoint['unit'],
                'status': 'unavailable', 'reason': '', 'counts': counts, 'recipe': None}
        if counts['numeric_windows'] == 0 and counts['invalid_windows'] == 0:
            item['reason'] = 'No populated values for this registered outcome in admitted source windows; blanks remain missing.'
        else:
            child_options = {**choices, 'method': 'response_curve', 'outcome': column}
            try:
                item['recipe'] = _build_recipe(study, state, child_options, inspection)
                item['status'] = 'ready'
                item['reason'] = 'Every admitted row passes the endpoint and design requirements.'
            except ValueError as error:
                item['status'] = 'blocked'
                item['reason'] = str(error)
        measures.append(item)
    base['measures'] = measures
    base['diagnostic_fields'] = list(_DIAGNOSTICS)
    base['other_numeric_fields'] = sorted({key for row in rows for key in row['other_numeric_fields']})
    study.verify_integrity(full=True)
    return base


def run_report_recipe(study, state, recipe):
    """Execute only validated report measures and inventory all unavailable ones."""
    if not isinstance(recipe, dict) or recipe.get('schema_version') != 1 or recipe.get('adapter_id') != 'pleth_summary_report_v1':
        raise ValueError('This all-measure report recipe has an unsupported adapter or schema version.')
    compiled = build_report_recipe(study, state, recipe.get('options'))
    if _canonical(compiled) != _canonical(recipe):
        raise ValueError('The report recipe, source evidence or scientific state changed. Review and confirm a new recipe before running.')
    rows = inspect_summary(study)
    options = compiled['options']
    assignments = {(window['source_id'], window['row']): window for window in options['windows']}
    bindings = {binding['source_id']: binding for binding in compiled['source_bindings']}
    admitted = [row for row in rows if assignments[(row['source_id'], row['row'])]['phase'] != 'omit']
    ledger = [{**bindings[row['source_id']], 'row': row['row'], 'label': row['label'], 'short_label': row['short_label'],
               'start_s': row['start_s'], 'end_s': row['end_s'],
               'source_co2_percent': row['observed_co2_percent'],
               'phase': assignments[(row['source_id'], row['row'])]['phase'],
               'co2_percent': assignments[(row['source_id'], row['row'])]['co2_percent'],
               'included': assignments[(row['source_id'], row['row'])]['phase'] != 'omit',
               'reason': assignments[(row['source_id'], row['row'])]['reason']}
              for row in rows]
    measures = []
    inventory = []
    tables = []
    for item in compiled['measures']:
        column = item['outcome']
        counts, values = _raw_counts(admitted, column)
        descriptive = {**counts, 'mean': _mean(values) if values else None, 'sd': _sd(values),
                       'min': min(values) if values else None, 'max': max(values) if values else None,
                       'unit_of_summary': 'source Summary windows; not independent subjects',
                       'endpoint_requirements_passed': item['status'] == 'ready',
                       'calibration_class': OUTCOMES[column]['calibration_class']}
        entry = {'outcome': column, 'label': item['label'], 'unit': item['unit'],
                 'status': 'executed' if item['status'] == 'ready' else item['status'],
                 'reason': item['reason'], 'result': None, 'descriptive': descriptive}
        if item['status'] == 'ready':
            entry['result'] = _execute_compiled(study, item['recipe'], rows)
            for table in entry['result']['tables']:
                if table['title'] != 'Window accounting and physical source lineage':
                    tables.append({**deepcopy(table), 'title': column+' — '+table['title']})
        measures.append(entry)
        inventory.append({key: entry[key] for key in ('outcome', 'label', 'unit', 'status', 'reason')}
                         | {key: descriptive[key] for key in ('total_windows', 'numeric_windows', 'missing_windows', 'invalid_windows', 'mean', 'sd', 'min', 'max')})
    diagnostics = []
    for column in (*compiled['diagnostic_fields'], *compiled['other_numeric_fields']):
        other = column in compiled['other_numeric_fields']
        counts, values = _raw_counts(admitted, column, other=other)
        diagnostics.append({'field': column, 'role': 'metadata_or_unsupported_numeric_field' if other else 'acquisition_or_metadata_diagnostic',
                            **counts, 'mean': _mean(values) if values else None, 'sd': _sd(values),
                            'min': min(values) if values else None, 'max': max(values) if values else None,
                            'scope': 'Descriptive source-window values only; not a biological endpoint or independent subject sample.'})
    omitted = [{'source_id': row['source_id'], 'row': row['row'], 'reason': row['reason']} for row in ledger if not row['included']]
    executed = sum(entry['status'] == 'executed' for entry in measures)
    blocked = sum(entry['status'] == 'blocked' for entry in measures)
    references = [{'source_id': source['source_id'], 'role': 'reference_analysis',
                   'reason': 'Derived/reference analysis is not an additional observation.'}
                  for source in study.manifest()['sources'] if source.get('role') == 'reference_analysis']
    tables = [_table('All-measure availability and source-window descriptives', inventory),
              _table('Window accounting and physical source lineage', ledger),
              _table('Acquisition metadata and unregistered numeric diagnostics', diagnostics), *tables]
    warnings = ['Descriptive all-measure report: no automatic hypothesis-test battery, smallest-p selection, slope fit, or group inference was performed.',
                'Inventory means and SD describe admitted source Summary windows, not independent biological n. Use each executed measure’s subject/group tables for equal-trial subject summaries.',
                'Unavailable or incomplete measures remain in the inventory with counts and reasons; partial values are not silently promoted to complete-case group curves.',
                'Syringe-equivalent and raw signal outcomes retain source labels and do not become physiologically corrected volume. PenH and related indices are not direct airway-resistance measurements.',
                'Raw source files remain intact. This adapter does not revalidate upstream breath detection or exclusions.']
    if options['normalization'] != 'none':
        warnings.append('The same explicitly requested normalization formula was considered for each source measure. This mathematical transform does not establish biomarker validity, physiological calibration or interpretability of a source-defined index.')
    result = {'method': 'study_execution', 'report': True, 'recipe': compiled, 'recipe_sha256': recipe_digest(compiled),
              'summary': f'All-measure descriptive report: {executed} complete measures executed; {blocked} blocked and {len(measures)-executed-blocked} unavailable registered measures retained in the inventory. {len(admitted)} of {len(rows)} Summary windows admitted. No group hypothesis tests were calculated.',
              'measures': measures, 'diagnostics': diagnostics, 'tables': tables, 'window_ledger': ledger,
              'row_accounting': {'total': len(rows), 'used': len(admitted), 'omitted': len(omitted), 'omitted_rows': omitted},
              'processing_steps': [
                  {'step': 1, 'operation': 'verify_and_inspect_all_summary_rows', 'adapter_id': 'pleth_summary_report_v1', 'source_rows': len(rows)},
                  {'step': 2, 'operation': 'apply_shared_reviewed_window_protocol', 'admitted': len(admitted), 'omitted': len(omitted)},
                  {'step': 3, 'operation': 'inventory_closed_registry_measures', 'registered': len(measures), 'executed': executed, 'blocked': blocked,
                   'detail': 'Endpoint-specific calibration, complete admitted values, normalization prerequisites and design rules are validated independently.'},
                  {'step': 4, 'operation': 'execute_complete_descriptive_curves', 'detail': 'Each executed measure retains its complete local processing_steps, per-trial and per-subject lineage. No test or slope battery.'},
                  {'step': 5, 'operation': 'retain_partial_and_metadata_descriptives', 'detail': 'Raw source-window descriptive counts/mean/SD/min/max remain explicitly separate from independent subject summaries and endpoint validity.'}],
              'warnings': warnings, 'reference_sources': references, 'comparison': [],
              'plot_data': {'report': True, 'method': 'measure_report', 'executed_count': executed,
                            'blocked_count': blocked, 'registered_count': len(measures)}}
    study.verify_integrity(full=True)
    try:
        _canonical(result)
    except (ValueError, TypeError, OverflowError) as error:
        raise ValueError('The measure report produced unsupported nonfinite arithmetic; no report was committed.') from error
    return result
