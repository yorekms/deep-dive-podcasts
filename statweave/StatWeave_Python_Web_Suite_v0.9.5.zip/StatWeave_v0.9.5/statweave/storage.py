"""Bounded storage checks and failure-safe appends for local project records.

An unsuccessful append restores only the bytes attempted by that append. It
never removes a previously committed audit record or repairs an existing log.
"""
from __future__ import annotations

import errno
import os
from pathlib import Path
import shutil
import sys

try:
    import fcntl
except ImportError:  # pragma: no cover - Windows runtime fallback
    fcntl = None
try:
    import msvcrt
except ImportError:  # pragma: no cover - POSIX runtime
    msvcrt = None


MIB = 1024 * 1024


class StorageError(OSError):
    def __init__(self, message, error_number=errno.ENOSPC):
        super().__init__(error_number, message)
        self.message = message

    def __str__(self):
        return self.message


def is_space_error(error):
    return isinstance(error, OSError) and error.errno in {errno.ENOSPC, errno.EDQUOT}


def storage_error(error, action='save the project'):
    if isinstance(error, StorageError):
        return error
    if not is_space_error(error):
        return StorageError(f'StatWeave could not {action}: {error}. '
                            'Your original data and last complete checkpoint are retained. '
                            'Keep this window open and retry saving after the storage problem is resolved.',
                            error.errno or errno.EIO)
    return StorageError(
        f'StatWeave could not {action} because disk storage is full. '
        'Your original data and last complete saved checkpoint are retained. '
        'Keep this window open, free some space, then choose File → Save project. '
        'The latest request has not been confirmed as saved.', error.errno)


def require_space(path, minimum_bytes, action):
    path = Path(path)
    while not path.exists() and path != path.parent:
        path = path.parent
    try:
        free = shutil.disk_usage(path).free
    except OSError:
        if sys.platform == 'emscripten':
            return
        raise
    if free == 0 and sys.platform == 'emscripten':
        return
    if free < minimum_bytes:
        raise StorageError(
            f'There is not enough free disk space to {action}. '
            f'About {minimum_bytes / MIB:.0f} MB is needed, including room to save safely; '
            f'{free / MIB:.0f} MB is available. No new operation was started. '
            'Free some space and try again. Your original data and saved results are retained.')


def _lock_fd(fd):
    if fcntl is not None:
        try:
            fcntl.flock(fd, fcntl.LOCK_EX)
        except OSError:
            if sys.platform != 'emscripten':
                raise
    elif msvcrt is not None:  # pragma: no cover - Windows runtime fallback
        os.lseek(fd, 0, os.SEEK_SET)
        msvcrt.locking(fd, msvcrt.LK_LOCK, 1)


def _unlock_fd(fd):
    if fcntl is not None:
        try:
            fcntl.flock(fd, fcntl.LOCK_UN)
        except OSError:
            pass
    elif msvcrt is not None:  # pragma: no cover - Windows runtime fallback
        try:
            os.lseek(fd, 0, os.SEEK_SET)
            msvcrt.locking(fd, msvcrt.LK_UNLCK, 1)
        except OSError:
            pass


def _pread_one(fd, offset):
    if hasattr(os, 'pread'):
        return os.pread(fd, 1, offset)
    current = os.lseek(fd, 0, os.SEEK_CUR)
    try:
        os.lseek(fd, offset, os.SEEK_SET)
        return os.read(fd, 1)
    finally:
        os.lseek(fd, current, os.SEEK_SET)


def append_record(path, encoded, finalize=None):
    """Durably append one record, restoring its own suffix if commit fails.

``finalize`` is used only by checkpoint saving: after the state event is durable,
the already-written temporary checkpoint is atomically published. If publishing
fails, this new state event alone is rolled back under the same lock.
"""
    target = Path(path)
    if target.is_symlink():
        raise ValueError('Refusing to append to a symbolic-link audit record.')
    flags = os.O_RDWR | os.O_APPEND | os.O_CREAT | getattr(os, 'O_NOFOLLOW', 0)
    fd = os.open(target, flags, 0o666)
    try:
        _lock_fd(fd)
        start = os.lseek(fd, 0, os.SEEK_END)
        if start and _pread_one(fd, start - 1) != b'\n':
            raise ValueError('The processing history ends with an incomplete record. '
                             'It has been left unchanged; recover a verified checkpoint copy before continuing.')
        try:
            remaining = memoryview(encoded)
            while remaining:
                written = os.write(fd, remaining)
                if written <= 0:
                    raise OSError(errno.ENOSPC, 'The audit record could not be written completely.')
                remaining = remaining[written:]
            os.fsync(fd)
            if finalize is not None:
                finalize()
        except BaseException:
            # Remove only this uncommitted append, never earlier audit history.
            os.ftruncate(fd, start)
            os.fsync(fd)
            raise
    finally:
        _unlock_fd(fd)
        os.close(fd)
