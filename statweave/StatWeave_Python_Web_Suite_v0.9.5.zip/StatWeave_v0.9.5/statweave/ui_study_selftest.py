"""Drive the native study-planning UI without numerical analysis or model calls."""
from copy import deepcopy
import json
from pathlib import Path
import time
import traceback

from PySide6.QtCore import QTimer

from .session import sha256,verify_audit,versions
from .study_selftest import fixtures,require,check_export


def schedule(window,app,workspace,study_folder=None):
    output=Path(workspace).resolve()/'ui-study-self-test';output.mkdir(parents=True,exist_ok=True)
    try:
        paths=sorted(Path(study_folder).resolve().glob('*.xlsx')) if study_folder else fixtures(output/'synthetic-sources')
        require(bool(paths),'No source workbooks for study UI check')
        original={str(p):sha256(p) for p in paths}
    except Exception as error:
        (output/'result.json').write_text(json.dumps({'status':'failed','error':str(error)},indent=2));app.exit(1);return
    config=dict(window.config);window.config={**config,'enabled':False};window.update_mode();window.last_export=None
    state={'step':0,'idle':0,'deadline':time.monotonic()+180,'checks':[]}
    timer=QTimer(window);window._study_selftest_timer=timer

    def loaded():
        require(window.session.is_study and window.session.result is None,'Native intake did not open a study project')
        require(not hasattr(window.session.dataset,'df'),'Study intake created an observations dataframe')
        require(window.study_view.isVisible() and not window.canvas.isVisible(),'Study view is not distinct from a calculated figure')
        require(window.data_table.model().rowCount()==len(paths),'Source inventory has the wrong file count')
        state['source_count']=len(paths);state['project']=str(window.session.project_dir/'project.json')
        state['checks'].append('native_multi_file_intake_and_planning_view')

    def goal():
        require(bool(window.session.context['study_state'].get('goal')),'Goal was not recorded')
        require(window.session.result is None,'A planning instruction produced a calculated result')
        state['checks'].append('conversational_goal_and_method_proposals')

    def before_run():state['before_run']=deepcopy(window.session.context['study_state'])

    def blocked_run():
        require(window.session.result is None and window.session.context['study_state']==state['before_run'],'A run request crossed the study planning boundary')
        state['checks'].append('execution_request_retains_plan_without_calculation')

    def reopen():
        state['before_reopen']=deepcopy(window.session.context['study_state'])
        window.open_path(window.session.save())

    def reopened():
        require(window.session.context['study_state']==state['before_reopen'],'Native reopen changed the study state')
        state['checks'].append('project_reopened_with_exact_planning_state')

    steps=[lambda:window.open_path(study_folder) if study_folder else window.open_study_paths(paths),loaded,
           lambda:window.send('my goal is to discuss CO2-response options while preserving repeated measurements'),
           lambda:window.send('suggest analyses'),goal,
           lambda:window.send('show metadata conflicts'),lambda:window.send('plan figures'),before_run,
           lambda:window.send('run an HCVR analysis'),blocked_run,reopen,reopened,
           lambda:window.send('export study plan')]

    def finish():
        session=window.session
        require(window.last_export is not None,'Native study-plan export did not complete')
        verified=check_export(window.last_export)
        for path,digest in original.items():require(sha256(path)==digest,'An original source changed')
        session._assert_integrity(full=True);head,count=verify_audit(session.project_dir/'history.jsonl',session.last_hash)
        screenshot=output/'desktop.png';require(window.grab().save(str(screenshot)),'Native screenshot failed')
        report={'status':'passed','checks':state['checks']+['study_plan_export_hashes_zip','all_sources_unchanged_and_audit_verified'],
                'source_count':state['source_count'],'project':state['project'],'domain':session.dataset.manifest()['domain'],
                'calculations_performed':False,'live_model_used':False,'source_unchanged':True,
                'export':window.last_export,'verified_export_files':verified,'screenshot':str(screenshot),
                'audit_head':head,'audit_events':count,'environment':versions(),
                'limits':'Native intake and planning only; no scientific calculation, figure or new statistical routine was executed.'}
        (output/'result.json').write_text(json.dumps(report,indent=2,ensure_ascii=False,allow_nan=False))
        timer.stop();window.config=config;app.quit()

    def tick():
        try:
            require(time.monotonic()<state['deadline'],'Native study planning check timed out')
            if window.busy or window._after_work:state['idle']=0;return
            state['idle']+=1
            if state['idle']<3:return
            state['idle']=0
            if state['step']<len(steps):
                step=steps[state['step']];state['step']+=1;step();return
            finish()
        except Exception as error:
            timer.stop();window.config=config
            (output/'result.json').write_text(json.dumps({'status':'failed','step':state['step'],'checks':state['checks'],
                'error':str(error),'traceback':traceback.format_exc()},indent=2));app.exit(1)
    timer.timeout.connect(tick);timer.start(50)
