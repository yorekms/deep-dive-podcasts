"""Native desktop interface. Numerical work is dispatched away from the UI thread."""
from __future__ import annotations
import argparse
import html
import json
import os
from pathlib import Path
import sys
import time
import traceback
from copy import deepcopy

from PySide6.QtCore import Qt, QAbstractTableModel, QModelIndex, QObject, Signal, Slot, QThread, QTimer, QUrl
from PySide6.QtGui import QAction, QKeySequence, QDesktopServices, QFont, QColor, QIcon, QPainter, QPen, QPixmap
from PySide6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QSplitter, QTabWidget, QTextBrowser, QPlainTextEdit, QTableView,
    QFileDialog, QMessageBox, QDialog, QFormLayout, QLineEdit, QCheckBox, QDialogButtonBox,
    QFrame, QScrollArea, QHeaderView, QComboBox, QSpinBox, QSizePolicy)
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg
from matplotlib.figure import Figure

from . import __version__
from .session import Session, versions
from .figures import make_figure, figure_caption, FIGURE_LOCK
from .planner import capabilities
from .provider_settings import clean_settings, selected_provider, validate_api_model, write_settings, DEFAULT_OPENAI_MODEL
from .credentials import Credentials, CredentialError, validate_key


WELCOME = ('Open data and tell me what you want to learn. Select several workbooks, open a study folder, or choose Plan a study from files to inspect metadata and discuss an analysis plan before calculating.\n\n'
           'You can describe the data, compare groups, examine a relationship, make a figure, '
           'and refine it through this conversation. Large CSV/TSV tables use a disk-backed reader, bounded previews and full-data aggregate queries. An optional language model discusses a compact data description while verified routines calculate results. Ask about the data structure or describe the result you need.\n\n'
           'Your original observations stay intact. Any missing values omitted from an analysis are recorded. '
           'I never remove outliers automatically.\n\n'
           'Offline commands work immediately. Conversation settings can connect the OpenAI API or an installed local Ollama model for broader discussion. '
           'Type “help” for examples.')


class Frame(QFrame):
    def __init__(self, name=None):
        super().__init__()
        if name:
            self.setObjectName(name)


class FigureCanvas(FigureCanvasQTAgg):
    """Keep Qt repainting and background export font rendering serialized."""
    def draw(self, *args, **kwargs):
        with FIGURE_LOCK:
            return super().draw(*args, **kwargs)

    def paintEvent(self, event):
        with FIGURE_LOCK:
            return super().paintEvent(event)


class DataModel(QAbstractTableModel):
    def __init__(self, dataset=None):
        super().__init__()
        self.dataset = dataset

    def rowCount(self, parent=QModelIndex()):
        return 0 if parent.isValid() or self.dataset is None else len(self.dataset.df)

    def columnCount(self, parent=QModelIndex()):
        return 0 if parent.isValid() or self.dataset is None else len(self.dataset.df.columns)

    def data(self, index, role=Qt.ItemDataRole.DisplayRole):
        if not index.isValid() or self.dataset is None:
            return None
        value = self.dataset.df.iat[index.row(), index.column()]
        if role == Qt.ItemDataRole.DisplayRole:
            import pandas as pd
            if pd.isna(value):
                return '—'
            return str(value)
        if role == Qt.ItemDataRole.TextAlignmentRole:
            import numbers
            return int(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter) if isinstance(value, numbers.Number) else None
        if role == Qt.ItemDataRole.ForegroundRole:
            import pandas as pd
            if pd.isna(value):
                return QColor('#92938a')
        return None

    def headerData(self, section, orientation, role=Qt.ItemDataRole.DisplayRole):
        if self.dataset is None or role != Qt.ItemDataRole.DisplayRole:
            return None
        if orientation == Qt.Orientation.Horizontal:
            return str(self.dataset.df.columns[section])
        return str(self.dataset.row_numbers[section])


class Composer(QPlainTextEdit):
    submitted = Signal()
    def keyPressEvent(self, event):
        if event.key() in (Qt.Key.Key_Return, Qt.Key.Key_Enter) and not event.modifiers() & Qt.KeyboardModifier.ShiftModifier:
            self.submitted.emit()
            return
        super().keyPressEvent(event)


class Worker(QThread):
    """A retained GUI-owned thread whose Python run function returns naturally.

    Using the QThread completion signal avoids deleting a Python QObject in the
    worker thread while GUI callbacks are dispatching its result signals.
    """
    complete = Signal(object)
    failed = Signal(str)
    def __init__(self, function, parent=None):
        super().__init__(parent)
        self.function = function
    def run(self):
        try:
            self.complete.emit(self.function())
        except Exception as error:
            self.failed.emit(str(error) or type(error).__name__)


def resources():
    return Path(getattr(sys, '_MEIPASS', Path(__file__).resolve().parents[1]))


def app_icon():
    pix = QPixmap(128, 128)
    pix.fill(Qt.GlobalColor.transparent)
    painter = QPainter(pix)
    painter.setRenderHint(QPainter.RenderHint.Antialiasing)
    painter.setBrush(QColor('#185c4b'))
    painter.setPen(Qt.PenStyle.NoPen)
    painter.drawRoundedRect(4, 4, 120, 120, 28, 28)
    painter.setPen(QPen(QColor('#e7f2e8'), 7, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
    painter.drawLine(31, 88, 31, 63)
    painter.drawLine(53, 88, 53, 46)
    painter.drawLine(75, 88, 75, 59)
    painter.drawLine(97, 88, 97, 31)
    painter.end()
    return QIcon(pix)


class Settings(QDialog):
    """Stage preferences and a masked key until the user explicitly saves them."""

    def __init__(self, config, parent=None, credentials=None):
        super().__init__(parent)
        self.previous_config=clean_settings(config)
        self.credentials=credentials if credentials is not None else Credentials()
        self.test_thread=None
        self.test_planner=None
        self.connection_verified=False
        self._verified_signature=None
        self._close_after_test=False
        self.setWindowTitle('Conversation settings')
        self.setMinimumWidth(640)
        layout = QVBoxLayout(self)
        note = QLabel('Choose how StatWeave discusses your data. Calculations, source files and figure rendering stay on this computer.')
        note.setWordWrap(True)
        layout.addWidget(note)
        form = QFormLayout()
        self.provider = QComboBox()
        for label,value in [('OpenAI API','openai'),('Local Ollama','ollama'),('Offline commands','offline')]:
            self.provider.addItem(label,value)
        initial = (selected_provider(config) if config.get('enabled') else config.get('provider', 'openai'))
        self.provider.setCurrentIndex(max(0,self.provider.findData(initial)))
        form.addRow('Conversation provider',self.provider)
        layout.addLayout(form)

        self.api_panel=QWidget()
        api_form=QFormLayout(self.api_panel);api_form.setContentsMargins(0,0,0,0)
        self.api_model=QLineEdit(config.get('openai_model',DEFAULT_OPENAI_MODEL))
        self.api_model.setPlaceholderText(DEFAULT_OPENAI_MODEL)
        api_form.addRow('OpenAI model',self.api_model)
        self.api_key=QLineEdit()
        self.api_key.setEchoMode(QLineEdit.EchoMode.Password)
        self.api_key.setMaxLength(512)
        self.api_key.setPlaceholderText('Enter a key here; leave blank to keep the existing key')
        self.api_key.setInputMethodHints(Qt.InputMethodHint.ImhHiddenText | Qt.InputMethodHint.ImhNoPredictiveText)
        api_form.addRow('API key',self.api_key)
        self.key_status=QLabel()
        self.key_status.setWordWrap(True)
        api_form.addRow('',self.key_status)
        self.remember=QCheckBox('Remember in the system wallet (KWallet)')
        self.remember.setChecked(bool(config.get('use_system_wallet',False)))
        api_form.addRow('',self.remember)
        key_note=QLabel('A new key stays in memory for this app session unless you select the system wallet. '
                       'OPENAI_API_KEY is also supported. Keys are never written to a project, settings file or export.')
        key_note.setWordWrap(True);key_note.setObjectName('muted')
        api_form.addRow('',key_note)
        test_row=QHBoxLayout()
        self.test_button=QPushButton('Test connection')
        self.test_button.clicked.connect(self.test_connection)
        self.cancel_test_button=QPushButton('Cancel test')
        self.cancel_test_button.clicked.connect(self.cancel_test)
        self.cancel_test_button.setVisible(False)
        test_row.addWidget(self.test_button);test_row.addWidget(self.cancel_test_button);test_row.addStretch()
        api_form.addRow('',test_row)
        self.test_status=QLabel('Not tested. A test sends only “Reply OK” to OpenAI and uses a small amount of billed API usage. No project data is sent.')
        self.test_status.setWordWrap(True)
        api_form.addRow('',self.test_status)
        layout.addWidget(self.api_panel)

        self.local_panel=QWidget()
        local_form=QFormLayout(self.local_panel);local_form.setContentsMargins(0,0,0,0)
        self.host = QLineEdit(config.get('base_url', 'http://127.0.0.1:11434'))
        self.model = QLineEdit(config.get('model', ''))
        self.model.setPlaceholderText('Your installed model name')
        local_form.addRow('Local Ollama address', self.host)
        local_form.addRow('Installed model', self.model)
        layout.addWidget(self.local_panel)
        self.privacy = QLabel()
        self.privacy.setWordWrap(True)
        self.privacy.setObjectName('muted')
        layout.addWidget(self.privacy)
        self.buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel)
        self.buttons.accepted.connect(self.accept)
        self.buttons.rejected.connect(self.reject)
        layout.addWidget(self.buttons)
        self.provider.currentIndexChanged.connect(self.update_provider)
        self.api_model.textChanged.connect(self.invalidate_test)
        self.api_key.textChanged.connect(self.invalidate_test)
        self.remember.toggled.connect(self.invalidate_test)
        self.update_provider()

    def update_provider(self):
        provider=self.provider.currentData()
        self.api_panel.setVisible(provider=='openai')
        self.local_panel.setVisible(provider=='ollama')
        self.key_status.setText('Existing credential: '+(self.credentials.source() or 'none; enter a key before using the API')+'.')
        if provider=='openai':
            text=('Saving OpenAI API enables requests when you send a message. OpenAI receives your typed conversation, '
                  'bounded column/type/count metadata, reviewed study design, and saved numeric summaries used in discussion. '
                  'Raw files and raw spreadsheet rows are not uploaded. Column names, design labels and text you type can still contain sensitive information. '
                  'API usage is billed to your OpenAI API account. Model availability depends on that account. '
                  'You review proposed analysis choices before local execution; no generated code is executed.')
        elif provider=='ollama':
            text=('Your typed request and bounded data metadata are sent to the selected loopback Ollama service. '
                  'Raw spreadsheet rows are not sent. Calculations use supported local routines; no generated code is executed.')
        else:text='Offline commands use no model service or API account. Source files and analysis history stay local.'
        self.privacy.setText(text)
        self.adjustSize()

    def invalidate_test(self,*args):
        self.connection_verified=False
        self._verified_signature=None
        if self.test_thread is None:
            self.test_status.setText('Not tested. Test connection makes one small billed API request with no project data.')

    def _test_signature(self):
        # No credential bytes or digests are retained in connection metadata.
        return self.api_model.text().strip(),self.credentials.revision

    def test_connection(self):
        if self.test_thread is not None:return
        try:
            from .api_provider import OpenAIPlanner
            model=validate_api_model(self.api_model.text())
            typed=self.api_key.text().strip()
            if typed: key=validate_key(typed);resolver=lambda:key
            else:resolver=self.credentials.resolve
            self.test_planner=OpenAIPlanner(credential_resolver=resolver,model=model)
        except Exception:
            self.test_status.setText('Enter a valid model and API key in the masked field, then test again. No request was sent.')
            return
        self.test_status.setText('Testing the OpenAI API with a minimal request… No project data is being sent.')
        self.provider.setEnabled(False);self.api_model.setEnabled(False);self.api_key.setEnabled(False)
        self.remember.setEnabled(False);self.buttons.button(QDialogButtonBox.StandardButton.Save).setEnabled(False)
        self.test_button.setEnabled(False);self.cancel_test_button.setVisible(True);self.cancel_test_button.setEnabled(True)
        self.test_thread=Worker(self.test_planner.check_connection,self)
        self.test_thread.complete.connect(self.test_complete,Qt.ConnectionType.QueuedConnection)
        self.test_thread.failed.connect(self.test_failed,Qt.ConnectionType.QueuedConnection)
        self.test_thread.finished.connect(self.test_finished,Qt.ConnectionType.QueuedConnection)
        self.test_thread.start()

    @Slot(object)
    def test_complete(self,result):
        if self.test_planner is None or self.test_planner.cancelled:
            self.test_status.setText('The connection test was cancelled. Connection not verified.');return
        self.connection_verified=True
        self._verified_signature=self._test_signature()
        usage=result.get('usage',{}) if isinstance(result,dict) else {}
        counts=[]
        for field in ('input_tokens','output_tokens'):
            if type(usage.get(field)) is int:counts.append(f'{usage[field]} {field.replace("_"," ")}')
        self.test_status.setText('Connection verified for this model. '+(', '.join(counts)+'. ' if counts else '')+
                                 'This test used your API account. Analysis requests may use more tokens.')

    @Slot(str)
    def test_failed(self,message):
        self.connection_verified=False
        self._verified_signature=None
        # Provider exceptions are sanitized; additionally remove the exact typed key.
        key=self.api_key.text().strip()
        safe=message.replace(key,'[credential hidden]') if key else message
        self.test_status.setText('Connection not verified. '+safe)

    @Slot()
    def test_finished(self):
        thread=self.test_thread
        if thread is not None and not thread.wait(0):
            QTimer.singleShot(1,self.test_finished);return
        self.test_thread=None;self.test_planner=None
        if thread is not None:thread.deleteLater()
        self.provider.setEnabled(True);self.api_model.setEnabled(True);self.api_key.setEnabled(True)
        self.remember.setEnabled(True);self.buttons.button(QDialogButtonBox.StandardButton.Save).setEnabled(True)
        self.test_button.setEnabled(True);self.cancel_test_button.setVisible(False)
        if self._close_after_test:
            self.api_key.clear()
            super().reject()

    def cancel_test(self):
        if self.test_planner is not None:
            self.cancel_test_button.setEnabled(False)
            self.test_status.setText('Stopping the connection test…')
            self.test_planner.cancel()

    def reject(self):
        if self.test_thread is not None:
            self._close_after_test=True;self.cancel_test();return
        self.api_key.clear()
        super().reject()

    def closeEvent(self,event):
        if self.test_thread is not None:
            self._close_after_test=True;self.cancel_test();event.ignore();return
        self.api_key.clear();event.accept()

    def accept(self):
        if self.test_thread is not None:return
        try:
            settings=self.values()
            if settings['provider']=='openai':
                validate_api_model(settings['openai_model'])
                key=self.api_key.text().strip()
                if key:validate_key(key)
            elif settings['provider']=='ollama':
                from .llm import OllamaPlanner
                OllamaPlanner(base_url=settings['base_url'],model=settings['model'])
        except ValueError as error:
            QMessageBox.warning(self,'Conversation settings',str(error));return
        super().accept()

    def values(self):
        provider=self.provider.currentData()
        values={**self.previous_config,'provider':provider,'enabled':provider!='offline',
                'base_url':self.host.text().strip(),'model':self.model.text().strip(),
                'openai_model':self.api_model.text().strip(), 'use_system_wallet':self.remember.isChecked()}
        if values['model']!=self.previous_config.get('model'):values.pop('model_digest',None)
        return clean_settings(values)


class Window(QMainWindow):
    model_activity = Signal(bool)

    def __init__(self, workspace):
        super().__init__()
        self.workspace = Path(workspace).resolve()
        self.session = Session(self.workspace)
        self.session.defer_figure_validation = True
        self._pre_command_state = None
        self.thread = self.worker = None
        self.busy = False
        self._close_requested = False
        self._after_work = None
        self._work_callback = None
        self._work_started = None
        self._work_label = ''
        self._model_active = False
        self._active_provider = 'offline'
        self._api_verified = None
        self._settings_dialog = None
        self._cancel_requested = False
        self._cancel_discussion = None
        self._progress_timer = QTimer(self)
        self._progress_timer.setInterval(500)
        self._progress_timer.timeout.connect(self.update_work_progress)
        self.model_activity.connect(self.set_model_activity, Qt.ConnectionType.QueuedConnection)
        self.last_export = None
        self.messages = [{'role': 'assistant', 'text': WELCOME}]
        self.config_path = self.workspace / 'statweave-settings.json'
        try:
            self.config = clean_settings(json.loads(self.config_path.read_text()))
        except (OSError, ValueError):
            self.config = clean_settings({})
        self.credentials = Credentials(use_system_wallet=self.config.get('use_system_wallet',False))
        self.setWindowTitle(f'StatWeave {__version__} — statistics through conversation')
        self.setWindowIcon(app_icon())
        self.resize(1440, 930)
        self.setMinimumSize(1050, 700)
        self.setAcceptDrops(True)
        self.build_ui()
        self.build_menu()
        self.apply_style()
        self.render_messages()
        self.update_mode()
        self.show_empty_figure()

    def build_ui(self):
        main = QWidget()
        self.setCentralWidget(main)
        outer = QVBoxLayout(main)
        outer.setContentsMargins(26, 19, 26, 18)
        outer.setSpacing(16)
        top = QHBoxLayout()
        icon = QLabel()
        icon.setPixmap(app_icon().pixmap(38, 38))
        top.addWidget(icon)
        brand = QVBoxLayout()
        brand.setSpacing(0)
        title = QLabel('StatWeave')
        title.setObjectName('brand')
        brand.addWidget(title)
        sub = QLabel('Statistics through conversation')
        sub.setObjectName('muted')
        brand.addWidget(sub)
        top.addLayout(brand)
        top.addStretch()
        self.mode_label = QLabel()
        self.mode_label.setObjectName('mode')
        top.addWidget(self.mode_label)
        self.paste_button = QPushButton('Paste table')
        self.paste_button.clicked.connect(self.paste_clipboard_table)
        top.addWidget(self.paste_button)
        self.open_button = QPushButton('Open data')
        self.open_button.setObjectName('primary')
        self.open_button.clicked.connect(self.open_dialog)
        top.addWidget(self.open_button)
        outer.addLayout(top)

        self.source_bar = Frame('sourcebar')
        sb = QHBoxLayout(self.source_bar)
        sb.setContentsMargins(16, 10, 16, 10)
        self.source_label = QLabel('No spreadsheet open')
        self.source_label.setObjectName('source')
        sb.addWidget(self.source_label, 1)
        self.sheet_combo = QComboBox()
        self.sheet_combo.setMinimumWidth(145)
        self.sheet_combo.setVisible(False)
        self.sheet_combo.currentTextChanged.connect(self.sheet_changed)
        sb.addWidget(self.sheet_combo)
        self.source_note = QLabel('Original data preserved')
        self.source_note.setObjectName('muted')
        sb.addWidget(self.source_note)
        outer.addWidget(self.source_bar)

        self.splitter = QSplitter(Qt.Orientation.Horizontal)
        self.splitter.setChildrenCollapsible(False)
        left = Frame('conversation')
        ll = QVBoxLayout(left)
        ll.setContentsMargins(18, 17, 18, 16)
        ll.setSpacing(12)
        left_header = QHBoxLayout()
        h = QLabel('Your analysis')
        h.setObjectName('section')
        left_header.addWidget(h)
        left_header.addStretch()
        help_button = QPushButton('Examples')
        help_button.setObjectName('quiet')
        help_button.clicked.connect(lambda: self.add_message('assistant', capabilities()))
        left_header.addWidget(help_button)
        ll.addLayout(left_header)
        self.chat = QTextBrowser()
        self.chat.setObjectName('chat')
        self.chat.setOpenExternalLinks(False)
        ll.addWidget(self.chat, 1)
        self.progress = QLabel('Ready')
        self.progress.setObjectName('muted')
        self.progress.setWordWrap(True)
        ll.addWidget(self.progress)
        self.proposal_bar = Frame('proposalbar')
        self.proposal_bar.setVisible(False)
        pbl = QHBoxLayout(self.proposal_bar)
        pbl.setContentsMargins(12, 8, 12, 8)
        pbl.setSpacing(8)
        self.proposal_label = QLabel('Review the proposed plan above before running.')
        self.proposal_label.setObjectName('muted')
        self.proposal_label.setWordWrap(True)
        pbl.addWidget(self.proposal_label, 1)
        self.dismiss_proposal_button = QPushButton('Dismiss')
        self.dismiss_proposal_button.clicked.connect(self.dismiss_pending_proposal)
        pbl.addWidget(self.dismiss_proposal_button)
        self.approve_proposal_button = QPushButton('Approve && Run')
        self.approve_proposal_button.setObjectName('primary')
        self.approve_proposal_button.clicked.connect(self.approve_pending_proposal)
        pbl.addWidget(self.approve_proposal_button)
        ll.addWidget(self.proposal_bar)
        self.composer = Composer()
        self.composer.setPlaceholderText('Tell me what to do with your data…')
        self.composer.setMinimumHeight(86)
        self.composer.setMaximumHeight(120)
        self.composer.submitted.connect(self.send)
        ll.addWidget(self.composer)
        foot = QHBoxLayout()
        hint = QLabel('Enter to send · Shift+Enter for a new line')
        hint.setObjectName('small')
        foot.addWidget(hint)
        foot.addStretch()
        self.cancel_button = QPushButton('Cancel reply')
        self.cancel_button.setVisible(False)
        self.cancel_button.clicked.connect(self.cancel_discussion)
        foot.addWidget(self.cancel_button)
        self.send_button = QPushButton('Send')
        self.send_button.setObjectName('primary')
        self.send_button.clicked.connect(self.send)
        foot.addWidget(self.send_button)
        ll.addLayout(foot)
        self.splitter.addWidget(left)

        right = Frame('workspace')
        rl = QVBoxLayout(right)
        rl.setContentsMargins(18, 16, 18, 12)
        rl.setSpacing(10)
        right_header = QHBoxLayout()
        self.work_title = QLabel('Figure studio')
        self.work_title.setObjectName('section')
        right_header.addWidget(self.work_title)
        right_header.addStretch()
        self.export_button = QPushButton('Export figure && record')
        self.export_button.clicked.connect(self.export_current)
        self.export_button.setEnabled(False)
        right_header.addWidget(self.export_button)
        rl.addLayout(right_header)
        self.tabs = QTabWidget()
        self.figure_tab = QWidget()
        fl = QVBoxLayout(self.figure_tab)
        fl.setContentsMargins(8, 16, 8, 6)
        self.figure = Figure(figsize=(7.0, 4.4), dpi=110)
        self.canvas = FigureCanvas(self.figure)
        self.canvas.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        fl.addWidget(self.canvas, 1)
        self.study_view=QTextBrowser()
        self.study_view.setOpenExternalLinks(True)
        self.study_view.setVisible(False)
        fl.addWidget(self.study_view,1)
        self.figure_note = QTextBrowser()
        self.figure_note.setObjectName('caption')
        self.figure_note.setMaximumHeight(132)
        self.figure_note.setMinimumHeight(70)
        fl.addWidget(self.figure_note)
        self.tabs.addTab(self.figure_tab, 'Figure')
        self.results_view = QTextBrowser()
        self.tabs.addTab(self.results_view, 'Results')
        data_tab = QWidget()
        dl = QVBoxLayout(data_tab)
        self.data_note = QLabel('Source values are read-only. Row labels show positions in the original file.')
        self.data_note.setWordWrap(True)
        self.data_note.setObjectName('muted')
        dl.addWidget(self.data_note)
        self.data_table = QTableView()
        self.data_table.setAlternatingRowColors(True)
        self.data_table.setSelectionBehavior(QTableView.SelectionBehavior.SelectRows)
        self.data_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
        self.data_table.horizontalHeader().setDefaultSectionSize(140)
        self.data_table.verticalHeader().setDefaultSectionSize(30)
        self.data_table.setModel(DataModel())
        dl.addWidget(self.data_table, 1)
        self.tabs.addTab(data_tab, 'Spreadsheet')
        self.record_view = QTextBrowser()
        self.tabs.addTab(self.record_view, 'Analysis record')
        self.study_plan_tab=QTextBrowser();self.study_plan_tab.setOpenExternalLinks(True)
        self.study_metadata_tab=QTextBrowser()
        self.tabs.addTab(self.study_plan_tab,'Study plan')
        self.tabs.addTab(self.study_metadata_tab,'Metadata review')
        self.tabs.setTabVisible(4,False);self.tabs.setTabVisible(5,False)
        rl.addWidget(self.tabs, 1)
        footer = QHBoxLayout()
        self.figure_size = QLabel('PDF · SVG · 600 dpi PNG')
        self.figure_size.setObjectName('small')
        footer.addWidget(self.figure_size)
        footer.addStretch()
        self.demo_button = QPushButton('Try example data')
        self.demo_button.setObjectName('quiet')
        self.demo_button.clicked.connect(self.load_demo)
        footer.addWidget(self.demo_button)
        rl.addLayout(footer)
        self.splitter.addWidget(right)
        self.splitter.setSizes([440, 920])
        outer.addWidget(self.splitter, 1)
        self.statusBar().showMessage('Local calculations. Original observations retained. Projects save automatically.')

    def build_menu(self):
        file_menu = self.menuBar().addMenu('File')
        actions = [('Open data files…', 'Ctrl+O', self.open_dialog),
                   ('Paste table from clipboard', 'Ctrl+Shift+V', self.paste_clipboard_table),
                   ('Plan a study from files…', None, self.study_dialog),
                   ('Open study folder…', None, self.study_folder_dialog),
                   ('Open saved project…', 'Ctrl+Shift+O', self.project_dialog),
                   ('Save project', 'Ctrl+S', self.save_project),
                   ('Export figure and record', 'Ctrl+E', self.export_current),
                   ('Show project folder', None, self.show_project)]
        for text, shortcut, slot in actions:
            action = QAction(text, self)
            if shortcut:
                action.setShortcut(QKeySequence(shortcut))
            action.triggered.connect(slot)
            file_menu.addAction(action)
        examples = self.menuBar().addMenu('Examples')
        for name, paired in [('Independent groups (synthetic)', False), ('Paired observations (synthetic)', True)]:
            action = QAction(name, self)
            action.triggered.connect(lambda checked=False, p=paired: self.load_demo(p))
            examples.addAction(action)
        for label,filename,channel in [
            ('Public ABF: continuous voltage (download if needed)','16d22006_kim_gapfree.abf',2),
            ('Public ABF: two episodic sweeps (download if needed)','17o05027_ic_ramp.abf',1),
            ('Public ABF1: sweeps with recording gaps (download if needed)','05210017_vc_abf1.abf',1),
            ('Public ABF: four channels (download if needed)','pclamp11_4ch.abf',1)]:
            action=QAction(label,self)
            action.triggered.connect(lambda checked=False,f=filename,c=channel:self.load_abf_example(f,c))
            examples.addAction(action)
        conversation = self.menuBar().addMenu('Conversation')
        settings = QAction('Conversation settings…', self)
        settings.triggered.connect(self.settings)
        conversation.addAction(settings)
        library_menu = self.menuBar().addMenu('Knowledge')
        library_action = QAction('Reference library…', self)
        library_action.triggered.connect(self.show_library)
        library_menu.addAction(library_action)
        folder_action = QAction('Open reference folder', self)
        folder_action.triggered.connect(lambda: QDesktopServices.openUrl(QUrl.fromLocalFile(str(self.workspace / 'knowledge'))))
        library_menu.addAction(folder_action)
        help_menu = self.menuBar().addMenu('Help')
        how = QAction('Supported instructions', self)
        how.triggered.connect(lambda: self.add_message('assistant', capabilities()))
        help_menu.addAction(how)
        about = QAction('About StatWeave', self)
        about.triggered.connect(lambda: QMessageBox.information(self, 'StatWeave',
            f'StatWeave {__version__}\nLocal statistics and publication figure preparation.\n\n'
            'This first version supports a defined set of verified workflows. Offline commands are a rule-based interpreter. '
            'Conversation can use your OpenAI API account or a separately installed local Ollama model. '
            'API requests use bounded project context; raw data files are not uploaded.\n\n'
            'No automatic outlier removal. Source files and analysis history are retained.\n'
            'History hashes are tamper-evident within a saved project, not tamper-proof or externally signed.'))
        help_menu.addAction(about)

    def apply_style(self):
        self.setStyleSheet('''
            QMainWindow, QDialog {background:#f4f5f0; color:#202820;}
            QWidget {font-family:"DejaVu Sans"; font-size:12px; color:#242d28;}
            QLabel#brand {font-size:24px; font-weight:600; color:#163e32;}
            QLabel#section {font-size:17px; font-weight:600;}
            QLabel#muted {color:#667368; font-size:11px;}
            QLabel#small {color:#6c756b; font-size:10px;}
            QLabel#source {font-weight:600;}
            QLabel#mode {color:#32654d; background:#e5ece0; border-radius:11px; padding:6px 11px; font-size:11px;}
            QFrame#conversation,QFrame#workspace {background:#fff; border:1px solid #dce2d7; border-radius:12px;}
            QFrame#sourcebar {background:#e9eee4; border-radius:8px;}
            QFrame#proposalbar {background:#eef5ee; border:1px solid #bcd0bc; border-radius:8px;}
            QPushButton {border:1px solid #d5ded2; border-radius:7px; background:white; padding:9px 13px; font-weight:500;}
            QPushButton:hover {background:#edf3e8; border-color:#8fa68e;}
            QPushButton:disabled {background:#f0f1ed; color:#9aa196; border-color:#e4e7df;}
            QPushButton#primary {background:#185c4b; color:#fff; border:1px solid #185c4b;}
            QPushButton#primary:hover {background:#22715c;}
            QPushButton#primary:disabled {background:#97afa4; border-color:#97afa4;}
            QPushButton#quiet {border:0; color:#346c54; background:transparent; padding:6px 8px; font-size:11px;}
            QTextBrowser {border:0; background:white; padding:10px; selection-background-color:#d5e7d5;}
            QTextBrowser#chat {padding:0;}
            QTextBrowser#caption {background:#f6f8f2; border-radius:7px; padding:6px; font-size:11px;}
            QPlainTextEdit,QLineEdit,QComboBox,QSpinBox {border:1px solid #cbd7c7; border-radius:7px; padding:9px; background:#fcfdf9;}
            QPlainTextEdit:focus,QLineEdit:focus {border:1px solid #367e62;}
            QTabWidget::pane {border:0; border-top:1px solid #e0e5dc;}
            QTabBar::tab {background:transparent; color:#6a756b; padding:12px 15px; border-bottom:2px solid transparent;}
            QTabBar::tab:selected {color:#185c4b; border-bottom:2px solid #185c4b; font-weight:600;}
            QTableView {background:white; alternate-background-color:#f6f8f3; border:1px solid #e2e7dc; gridline-color:#edf0e8; selection-background-color:#deebd9;}
            QHeaderView::section {background:#edf2e8; border:0; border-bottom:1px solid #d5dfce; padding:8px; font-weight:600;}
            QSplitter::handle {background:transparent; width:14px;}
            QStatusBar {color:#697565; font-size:10px;}
            QMenuBar {background:#f4f5f0;}
        ''')

    def update_mode(self):
        if getattr(self.session, 'is_recording', False):
            self.mode_label.setText('Local ABF commands · AI bypassed for raw recordings')
            return
        provider=selected_provider(self.config)
        if provider=='openai':
            verified=self._api_verified==(self.config.get('openai_model',DEFAULT_OPENAI_MODEL),self.credentials.revision)
            state=('connection tested' if verified else 'not tested') if self.credentials.source() else 'key needed'
            self.mode_label.setText('OpenAI API · '+state)
        else:self.mode_label.setText('Local AI enabled' if provider=='ollama' else 'Offline commands')

    def update_proposal_bar(self):
        api_prop = self.session.context.get('api_proposal')
        study_prop = (self.session.context.get('study_execution', {}).get('conversation_proposal')
                      if self.session.is_study else None)
        active = bool(api_prop or study_prop)
        self.proposal_bar.setVisible(active)
        if active:
            kind = (api_prop or {}).get('kind', 'analysis')
            labels = {
                'analysis': 'Proposed analysis ready — review above, then click Approve & Run or ask questions.',
                'sheet': 'Proposed worksheet switch ready — click Approve & Run to switch tabs.',
                'export': 'Proposed export ready — click Approve & Run to export.',
                'design': 'Proposed study mapping ready — click Approve & Run to confirm.',
                'view': 'Proposed figure view ready — click Approve & Run.',
            }
            self.proposal_label.setText(labels.get(kind, 'Proposal ready for your review.'))
            self.approve_proposal_button.setEnabled(not self.busy)
            self.dismiss_proposal_button.setEnabled(not self.busy)

    def approve_pending_proposal(self):
        if self.busy:
            return
        user_text = 'Proceed with the displayed proposal.' if self.session.context.get('api_proposal') else 'yes, run that'
        self._pre_command_state = {key: deepcopy(getattr(self.session, key)) for key in ('plan', 'result', 'style', 'context', 'pending_plan')}
        self.add_message('user', user_text)
        self.start_work(self.session.approve_proposal, self.command_complete, 'Running your approved proposal locally…')

    def dismiss_pending_proposal(self):
        if self.busy:
            return
        self._pre_command_state = {key: deepcopy(getattr(self.session, key)) for key in ('plan', 'result', 'style', 'context', 'pending_plan')}
        self.start_work(self.session.dismiss_proposal, self.command_complete, 'Dismissing proposal…')

    def render_messages(self):
        parts = ['<html><body style="font-family:DejaVu Sans;font-size:12px;color:#2d352e;">']
        for message in self.messages:
            user = message['role'] == 'user'
            color = '#185c4b' if user else '#5e6a5e'
            label = 'You' if user else 'StatWeave'
            text = html.escape(message['text']).replace('\n', '<br>')
            parts.append(f'<p style="margin:16px 0 5px;color:{color};font-size:10px;"><b>{label}</b></p>'
                         f'<p style="margin:0 0 18px;line-height:145%;">{text}</p>')
        parts.append('</body></html>')
        self.chat.setHtml(''.join(parts))
        self.chat.verticalScrollBar().setValue(self.chat.verticalScrollBar().maximum())

    def add_message(self, role, text):
        self.messages.append({'role': role, 'text': str(text)})
        self.render_messages()

    def start_work(self, function, callback, label='Working locally…', cancel=None):
        if self.busy:
            return
        self.busy = True
        self._work_error = False
        self._work_started = time.monotonic()
        self._work_label = label
        self._cancel_discussion = cancel
        self._cancel_requested = False
        self._model_active = False
        self.progress.setText(label)
        self._progress_timer.start()
        for widget in [self.send_button, self.open_button, self.paste_button, self.demo_button, self.export_button,
                       self.sheet_combo, self.approve_proposal_button, self.dismiss_proposal_button]:
            widget.setEnabled(False)
        self.thread = self.worker = Worker(function,self)
        self._work_callback = callback
        self.worker.complete.connect(self.dispatch_complete, Qt.ConnectionType.QueuedConnection)
        self.worker.failed.connect(self.work_failed,Qt.ConnectionType.QueuedConnection)
        self.thread.finished.connect(self.work_finished,Qt.ConnectionType.QueuedConnection)
        self.thread.start()

    @Slot(bool)
    def set_model_activity(self, active):
        """Only the model transport is cancellable, not an analysis or export."""
        self._model_active = bool(active) and self.busy
        self.cancel_button.setVisible(self._model_active and self._cancel_discussion is not None)
        self.cancel_button.setEnabled(self._model_active and not self._cancel_requested)
        self.update_work_progress()

    @Slot()
    def update_work_progress(self):
        if not self.busy or self._work_started is None:
            return
        seconds = int(time.monotonic() - self._work_started)
        if self._close_requested:
            text = ('Close requested — stopping the discussion…' if self._cancel_requested
                    else 'Close requested — waiting for the current operation to finish…')
        elif self._cancel_requested:
            text = 'Stopping the API discussion…' if self._active_provider=='openai' else 'Stopping the local discussion…'
        elif self._model_active:
            text = 'Discussing your question with OpenAI…' if self._active_provider=='openai' else 'Discussing your question locally…'
        else:
            text = self._work_label
        self.progress.setText(f'{text} · {seconds}s')

    @Slot()
    def cancel_discussion(self):
        if not self.busy or not self._model_active or not callable(self._cancel_discussion) or self._cancel_requested:
            return
        self._cancel_requested = True
        self.cancel_button.setEnabled(False)
        self.update_work_progress()
        self.statusBar().showMessage('Stopping this reply. Your saved analyses and source files are retained.', 0)
        try:
            self._cancel_discussion()
        except Exception as error:
            self.statusBar().showMessage('The reply is still finishing: '+(str(error) or type(error).__name__), 12000)

    @Slot(object)
    def dispatch_complete(self, result):
        if self._work_callback:
            try:
                self._work_callback(result)
            except Exception as error:
                self.work_failed('The operation finished, but the display needs attention: '+
                                 (str(error) or type(error).__name__))

    @Slot(str)
    def work_failed(self, message):
        self._work_error = True
        self.add_message('assistant', message)
        self.statusBar().showMessage(message, 12000)

    @Slot()
    def work_finished(self):
        thread=self.thread
        if thread is not None and not thread.wait(0):
            # Keep Python references until native thread-local cleanup has also
            # finished. This zero-time join never blocks the GUI event loop.
            QTimer.singleShot(1,self.work_finished)
            return
        self.busy = False
        self._progress_timer.stop()
        self.cancel_button.setVisible(False)
        self._model_active = False
        self._cancel_discussion = None
        self._work_started = None
        if self._cancel_requested:
            self.statusBar().clearMessage()
        self._cancel_requested = False
        if getattr(self.session, 'storage_error', None):
            self.progress.setText('Save failed · free disk space, then save the project')
        elif getattr(self, '_work_error', False):
            self.progress.setText('Ready · the last request did not complete')
        else:
            self.progress.setText('Ready · project saved automatically' if self.session.project_dir else 'Ready')
        for widget in [self.send_button, self.open_button, self.paste_button, self.demo_button, self.sheet_combo]:
            widget.setEnabled(True)
        self.update_proposal_bar()
        self.export_button.setEnabled((self.session.result is not None or self.session.is_study) and not getattr(self,'_data_integrity_error',False))
        self.thread = self.worker = None
        if thread is not None:thread.deleteLater()
        self._work_callback = None
        if self._close_requested:
            self._after_work = None
            self.progress.setText('Closing — saving the completed operation…')
            QTimer.singleShot(0, self.close)
            return
        self.composer.setFocus()
        if self._after_work:
            next_step, self._after_work = self._after_work, None
            QTimer.singleShot(0, next_step)

    def send(self, text=None):
        if self.busy:
            return
        text = text if isinstance(text, str) else self.composer.toPlainText().strip()
        if not text:
            return
        self.composer.clear()
        self.add_message('user', text)
        self._pre_command_state = {key: deepcopy(getattr(self.session,key)) for key in ('plan','result','style','context','pending_plan')}
        model = None
        provider=selected_provider(self.config)
        self._active_provider=provider
        if provider!='offline' and not self.session.is_recording:
            try:
                if provider=='openai':
                    from .api_provider import OpenAIPlanner
                    if not self.credentials.source():
                        raise CredentialError('Open Conversation settings and enter an API key in the masked field. No request was sent.')
                    model=OpenAIPlanner(credential_resolver=self.credentials.resolve,
                        model=validate_api_model(self.config.get('openai_model',DEFAULT_OPENAI_MODEL)),
                        timeout=self.config.get('openai_timeout',90))
                else:
                    from .llm import OllamaPlanner
                    model = OllamaPlanner(base_url=self.config.get('base_url', 'http://127.0.0.1:11434'), model=self.config.get('model',''),timeout=self.config.get('timeout',120))
                    model.configured_model_digest=self.config.get('model_digest')
                model.activity_callback=self.model_activity.emit
            except Exception as error:
                self.add_message('assistant', f'Conversation settings need attention: {error}')
                return
        self.start_work(lambda: self.session.command(text, model=model), self.command_complete,
                        'Reading your message…' if model else 'Working through your request locally…',
                        cancel=getattr(model,'cancel',None))

    def command_complete(self, response):
        if response.get('save_failed'):
            self.work_failed(response['message'])
            self._after_work = None
            return
        if response.get('refresh') and self.session.result:
            try:
                # Qt and font rendering stay on the GUI thread. Numerical work
                # and optional model requests use the background worker.
                make_figure(self.session.dataset, self.session.result, self.session.plan, self.session.style)
            except Exception as error:
                if self._pre_command_state:
                    for key,value in self._pre_command_state.items():
                        setattr(self.session,key,value)
                message = str(error) + '\n\nThe previous successful analysis and figure are retained.'
                self.session._event('figure_change_rejected', {'error':str(error)})
                self.session.conversation.append({'role':'assistant','text':message})
                self.session.save()
                self.add_message('assistant', message)
                self.update_record()
                return
        self.add_message('assistant', response['message'])
        if response.get('refresh'):
            self.refresh_workspace()
        else:
            self.update_record()
        self.update_proposal_bar()
        if response.get('open_dialog'):
            self._after_work = self.open_dialog
        if response.get('export_request') is not None:
            request = response['export_request']
            self._after_work = lambda: self.export_current(request)
        if response.get('batch_export_request') is not None:
            request=response['batch_export_request']
            self._after_work=lambda:self.export_pipeline_current(request)

    def export_pipeline_current(self,request):
        if self.busy:return
        from .pipelines import batch_projects,record_batch_exports
        try:
            folder,report,projects=batch_projects(request['batch_dir'])
        except Exception as error:
            self.work_failed(str(error));return
        if not projects:
            self.add_message('assistant','This batch has no completed analyses to export. Check its file-status report.');return
        self.busy=True
        for widget in [self.send_button,self.open_button,self.demo_button,self.export_button,self.sheet_combo]:widget.setEnabled(False)
        state={'index':0,'exports':[]}
        def next_file():
            if state['index']>=len(projects):
                try:
                    record_batch_exports(self.session,folder,state['exports'])
                    passed=sum(e['status']=='exported' for e in state['exports'])
                    self.add_message('assistant',f'Exported {passed} of {len(projects)} pipeline figure and reproduction packages. Each local package includes its original ABF. File outcomes are recorded in: '+str(folder/'batch.json'))
                    self.update_record()
                except Exception as error:self.work_failed(str(error))
                finally:self.work_finished()
                return
            project=projects[state['index']];state['index']+=1
            self.progress.setText(f'Exporting pipeline figure {state["index"]} of {len(projects)}…')
            try:
                child=Session(folder);child.open_project(project)
                output=child.export_bundle()
                state['exports'].append({'project':str(project),'status':'exported',**output})
            except Exception as error:
                state['exports'].append({'project':str(project),'status':'failed','error':str(error)})
            QTimer.singleShot(0,next_file)
        QTimer.singleShot(0,next_file)

    def open_dialog(self):
        if self.busy:
            return
        paths, _ = QFileDialog.getOpenFileNames(self, 'Open data files — select several workbooks for a study', str(self.workspace),
            'Data files (*.abf *.xlsx *.xlsm *.xls *.csv *.tsv *.txt *.ods);;ABF recordings (*.abf);;Spreadsheets and data (*.xlsx *.xlsm *.xls *.csv *.tsv *.txt *.ods);;All files (*)')
        if len(paths)>1:self.open_study_paths(paths)
        elif paths:self.open_path(paths[0])

    def study_dialog(self):
        if self.busy:return
        paths,_=QFileDialog.getOpenFileNames(self,'Plan a study from source files',str(self.workspace),
                                          'Study sources (*.xlsx *.csv *.tsv *.txt)')
        if paths:self.open_study_paths(paths)

    def study_folder_dialog(self):
        if self.busy:return
        path=QFileDialog.getExistingDirectory(self,'Open a folder of study source files',str(self.workspace))
        if path:self.open_path(path)

    def open_study_paths(self,paths):
        if self.busy:return
        def load():
            self.session.import_study(paths)
            return self.session.import_message()
        def loaded(message):
            self.messages=list(self.session.conversation);self.add_message('assistant',message)
            self.session.conversation=list(self.messages);self.session.save();self.refresh_workspace()
        self.start_work(load,loaded,'Preserving study sources and inspecting metadata — no analysis is being run…')

    def paste_clipboard_table(self):
        if self.busy:
            return
        text = QApplication.clipboard().text()
        if not text or not text.strip():
            self.add_message('assistant', 'Your clipboard is empty. Copy cells from Excel, Google Sheets, Prism, or ClampFlow first, then click Paste table.')
            return
        def load():
            self.session.import_pasted_table(text)
            return self.session.import_message()
        def loaded(message):
            self.messages = list(self.session.conversation)
            self.add_message('assistant', message)
            self.session.conversation = list(self.messages)
            self.session.save()
            self.refresh_workspace()
        self.start_work(load, loaded, 'Importing pasted table and preserving an immutable TSV snapshot…')

    def open_path(self, path, demo=False):
        if self.busy:
            return
        p = Path(path)
        is_reopen = (p.name == 'project.json' or (p.is_dir() and (p / 'project.json').is_file())) and not demo
        def load():
            if p.is_dir() and not (p / 'project.json').is_file():
                self.session.import_study_folder(path)
            elif p.name == 'project.json' or p.is_dir():
                self.session.open_project(path, recover=True)
            else:
                self.session.import_file(path)
            if demo:
                self.session.context['synthetic_demo'] = True
                self.session._event('synthetic_demonstration', {'file': p.name})
                self.session.save()
            return self.session.import_message()
        def loaded(message):
            self.messages = list(self.session.conversation)
            if not is_reopen or not self.messages or self.session.context.get('checkpoint_recovery'):
                self.add_message('assistant', ('Synthetic demonstration data.\n\n' if demo else '') + message)
                self.session.conversation = list(self.messages)
                self.session.save()
            else:
                self.render_messages()
            self.refresh_workspace()
            if demo:
                self.add_message('assistant', 'Try “paired t test Before and After” for this example.' if 'paired_measurements' in str(path)
                                 else 'Try “compare Score by Treatment”, then “independent observations”.\nOr “scatter Dose against Score”.')
        self.start_work(load, loaded, 'Reading spreadsheet and preserving its original bytes…')

    def load_demo(self, paired=False):
        name = 'paired_measurements.csv' if paired else 'independent_groups.csv'
        self.open_path(resources() / 'examples' / name, demo=True)

    def load_abf_example(self,filename,channel=1):
        if self.busy:return
        def load():
            from .public_examples import fetch_public_example
            public=fetch_public_example(filename,self.workspace)
            self.session.import_file(public['path'])
            self.session.context['public_example']={'title':filename,'source_url':public['source']['source_page'],
                'rights_status':public['source']['rights']['status']}
            self.session._event('public_recording_example',self.session.context['public_example'])
            if channel!=1:
                self.session.command(f'show channel {channel}')
            self.session.save()
            return self.session.import_message()
        def loaded(message):
            self.messages=list(self.session.conversation)
            self.add_message('assistant','Public reference recording.\n\n'+message+
                f'\nThe example view selects channel {channel}, as recorded in the view plan. '
                'No species, treatment, or biological protocol is inferred from the filename.')
            self.session.conversation=list(self.messages);self.session.save();self.refresh_workspace()
        self.start_work(load,loaded,'Fetching or verifying the pinned public ABF example…')

    def project_dialog(self):
        if self.busy:
            return
        path, _ = QFileDialog.getOpenFileName(self, 'Open a saved StatWeave project', str(self.workspace / 'projects'), 'StatWeave project (project.json)')
        if path:
            self.open_path(path)

    def save_project(self):
        if self.busy:
            return
        try:
            path = self.session.save()
            self.progress.setText('Ready · project saved')
            self.statusBar().showMessage('Project saved: ' + path, 12000)
        except (ValueError, OSError) as error:
            self.work_failed(str(error))
            self.progress.setText('Save failed · see the message above')

    def show_project(self):
        if self.session.project_dir:
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(self.session.project_dir)))

    def sheet_changed(self, name):
        if not self.busy and self.session.dataset and name and name != self.session.dataset.sheet:
            self._pre_command_state = {key: deepcopy(getattr(self.session, key)) for key in ('plan', 'result', 'style', 'context', 'pending_plan')}
            user_text = f'Switch to worksheet "{name}".'
            self.add_message('user', user_text)
            def switch():
                self.session.conversation.append({'role': 'user', 'text': user_text})
                self.session._event('instruction', {'text': user_text, 'interpreter': 'UI worksheet selector'})
                return self.session.select_sheet(name, reply=True)
            self.start_work(switch, self.command_complete, f'Switching to worksheet {name}…')

    def show_empty_figure(self):
        self.study_view.setVisible(False);self.canvas.setVisible(True)
        self.figure.clear()
        self.figure.set_facecolor('#ffffff')
        ax = self.figure.add_subplot(111)
        ax.set_axis_off()
        ax.text(.5, .59, 'Your next figure starts here', ha='center', va='center', fontsize=20, color='#215c47', transform=ax.transAxes)
        ax.text(.5, .44, 'Open a spreadsheet, then tell me what to plot.\nRefine the figure through conversation.',
                ha='center', va='center', linespacing=1.7, fontsize=11, color='#6e7d6c', transform=ax.transAxes)
        self.canvas.draw_idle()
        self.figure_note.setPlainText('Exports include PDF and SVG vector figures, a 600 dpi PNG, numerical results, source data, and an analysis record.')

    def refresh_workspace(self):
        self.update_mode()
        self.update_proposal_bar()
        data = self.session.dataset
        if data is None:
            return
        self._data_integrity_error=False
        if self.session.is_study:
            self.refresh_study_workspace()
            return
        self.tabs.setTabVisible(4,False);self.tabs.setTabVisible(5,False)
        self.study_view.setVisible(False);self.canvas.setVisible(True)
        self.work_title.setText('Figure studio');self.export_button.setText('Export figure && record')
        self.tabs.setTabText(0,'Figure');self.tabs.setTabText(1,'Results')
        if self.session.is_large_table:
            self.refresh_large_workspace()
            return
        if self.session.is_recording:
            self.refresh_recording_workspace()
            return
        self.tabs.setTabText(2,'Spreadsheet')
        self.source_label.setText(f'{Path(data.source_path).name}   ·   {len(data.df):,} rows × {len(data.df.columns)} columns')
        synthetic = self.session.context.get('synthetic_demo')
        clampflow = getattr(data, 'is_clampflow', False)
        self.source_note.setText(
            'Synthetic example · source preserved' if synthetic
            else 'ClampFlow workbook · metadata scrubbed · source preserved' if clampflow
            else 'Original data preserved'
        )
        self.sheet_combo.blockSignals(True)
        self.sheet_combo.clear()
        self.sheet_combo.addItems(data.sheets)
        if data.sheet:
            self.sheet_combo.setCurrentText(data.sheet)
        self.sheet_combo.setVisible(len(data.sheets) > 1)
        self.sheet_combo.blockSignals(False)
        self.data_table.setModel(DataModel(data))
        self.data_note.setText(f'All {len(data.df):,} source rows are available. Values are read-only; row labels refer to original file positions. '
                               'Missing values appear as —. No outlier removal is applied.')
        if self.session.result:
            try:
                figure = make_figure(data, self.session.result, self.session.plan, self.session.style)
                layout = self.figure_tab.layout()
                layout.removeWidget(self.canvas)
                self.canvas.deleteLater()
                self.figure = figure
                self.canvas = FigureCanvas(figure)
                self.canvas.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
                layout.insertWidget(0, self.canvas, 1)
                self.canvas.draw()
                caption = figure_caption(data, self.session.result, self.session.plan, self.session.style)
                if synthetic:
                    caption = 'Synthetic demonstration data. ' + caption
                self.figure_note.setPlainText(caption)
                self.figure_size.setText(f"{self.session.style.get('width_mm',178):g} × {self.session.style.get('height_mm',110):g} mm · PDF · SVG · {self.session.style.get('dpi',600)} dpi PNG")
                self.tabs.setCurrentIndex(0)
            except Exception as error:
                self.add_message('assistant', 'The analysis completed, but the figure needs an adjustment: ' + str(error))
                self.show_empty_figure()
            self.render_results()
        else:
            self.show_empty_figure()
            self.results_view.setPlainText('Ask for an analysis to see numerical results, assumptions, and row accounting here.')
        self.update_record()
        self.export_button.setEnabled(self.session.result is not None and not self.busy)

    def refresh_study_workspace(self):
        from types import SimpleNamespace
        import pandas as pd
        from .study_view import overview_html,issues_html,source_rows
        data=self.session.dataset;state=self.session.context['study_state']
        try:data.verify_integrity()
        except Exception as error:
            self._data_integrity_error=True;self.export_button.setEnabled(False)
            self.study_view.setHtml('<p>Study source verification stopped: '+html.escape(str(error))+'</p>')
            return
        self.canvas.setVisible(False);self.study_view.setVisible(True)
        self.work_title.setText('Scientific planning');self.export_button.setText('Export study plan')
        self.tabs.setTabText(0,'Study plan');self.tabs.setTabText(1,'Metadata review');self.tabs.setTabText(2,'Source files')
        self.sheet_combo.setVisible(False)
        sources=data.manifest().get('sources',[])
        self.source_label.setText(f'Study intake · {len(sources)} preserved source files · planning only')
        self.source_note.setText('Original files preserved · no calculation performed')
        self.study_view.setHtml(overview_html(data,state));self.results_view.setHtml(issues_html(data,state))
        rows=source_rows(data,state);frame=pd.DataFrame(rows)
        self.data_table.setModel(DataModel(SimpleNamespace(df=frame,row_numbers=[r['Source'] for r in rows])))
        self.data_note.setText('Source roles, identities and worksheet structure are inspected without combining observations. Proposed identifiers remain separate from your recorded confirmations.')
        executed=bool(self.session.result and self.session.result.get('method')=='study_execution')
        self.tabs.setTabVisible(4,executed);self.tabs.setTabVisible(5,executed)
        if executed:
            from .study_bridge import status_text,result_is_current
            from .study_display import display_result
            self.study_plan_tab.setHtml(overview_html(data,state));self.study_metadata_tab.setHtml(issues_html(data,state))
            self.canvas.setVisible(True);self.study_view.setVisible(False)
            self.work_title.setText('Study results');self.export_button.setText('Export figure && record')
            self.tabs.setTabText(0,'Figure');self.tabs.setTabText(1,'Results')
            self.source_label.setText(f'Study · {len(sources)} preserved source files · recorded analysis')
            self.source_note.setText('Original files preserved · '+('current recipe' if result_is_current(self.session) else 'historical result'))
            try:
                visible_result=display_result(self.session)
                figure=make_figure(data,visible_result,self.session.plan,self.session.style)
                layout=self.figure_tab.layout();layout.removeWidget(self.canvas);self.canvas.deleteLater()
                self.figure=figure;self.canvas=FigureCanvas(figure)
                self.canvas.setSizePolicy(QSizePolicy.Policy.Expanding,QSizePolicy.Policy.Expanding)
                layout.insertWidget(0,self.canvas,1);self.canvas.draw()
                self.figure_note.setPlainText(status_text(self.session)+'\n\n'+figure_caption(data,visible_result,self.session.plan,self.session.style))
            except Exception as error:
                self.figure_note.setPlainText('Recorded result retained; figure needs attention: '+str(error))
            self.render_results();self.tabs.setCurrentIndex(0)
            self.figure_size.setText(f'{self.session.style.get("width_mm",178):g} × {self.session.style.get("height_mm",110):g} mm · PDF · SVG · {self.session.style.get("dpi",600)} dpi PNG')
            self.update_record();self.export_button.setEnabled(not self.busy)
            return
        self.figure_note.setPlainText('A study plan becomes executable through a reviewed, confirmed recipe. Try “show outcomes”, “propose protocol windows” and “review execution recipe”. Selecting a method card or acknowledging a plan does not run it.')
        self.figure_size.setText('Source evidence · focused questions · methods with references · reusable import profiles')
        self.tabs.setCurrentIndex(0);self.update_record()
        self.export_button.setEnabled(not self.busy)

    def refresh_large_workspace(self):
        from types import SimpleNamespace
        data=self.session.dataset
        self.source_label.setText(f'{Path(data.source_path).name}   ·   {data.row_count:,} source records × {len(data.columns)} columns · disk-backed')
        self.source_note.setText('Original file preserved · bounded preview')
        self.sheet_combo.setVisible(False);self.tabs.setTabText(2,'Data preview')
        preview_error=None
        try:preview=data.preview(limit=200)
        except ValueError as error:
            import pandas as pd
            preview=pd.DataFrame(columns=data.columns[:20]);preview_error=str(error)
        self._data_integrity_error=bool(preview_error and '8 MiB output budget' not in preview_error)
        self.data_table.setModel(DataModel(SimpleNamespace(df=preview,row_numbers=list(preview.index))))
        self.data_note.setText(f'Showing {len(preview):,} of {data.row_count:,} source records. Row labels are one-based CSV data-record numbers, not physical line numbers or biological sample IDs. The full table remains in the local read-only cache; queries report complete selected-record counts.')
        if preview_error:
            self.data_note.setText('Data preview unavailable: '+preview_error+' The recorded result has not been replaced. For a display-size limit, request fewer fields or records; for an integrity error, verify the preserved source/cache before continuing.')
        if self._data_integrity_error:
            self.source_note.setText('Data verification stopped')
            self.figure_note.setPlainText('Data verification stopped: '+preview_error+' The previously recorded result is retained; exports require a verified source and cache.')
            self.export_button.setEnabled(False);self.update_record();return
        if self.session.result:
            figure=make_figure(data,self.session.result,self.session.plan,self.session.style)
            layout=self.figure_tab.layout();layout.removeWidget(self.canvas);self.canvas.deleteLater()
            self.figure=figure;self.canvas=FigureCanvas(figure)
            self.canvas.setSizePolicy(QSizePolicy.Policy.Expanding,QSizePolicy.Policy.Expanding)
            layout.insertWidget(0,self.canvas,1);self.canvas.draw()
            self.figure_note.setPlainText(figure_caption(data,self.session.result,self.session.plan,self.session.style))
            self.figure_size.setText(f'{self.session.style.get("width_mm",178):g} × {self.session.style.get("height_mm",110):g} mm · full-data aggregates / disclosed bounded samples')
            self.render_results();self.tabs.setCurrentIndex(0)
        self.update_record();self.export_button.setEnabled(self.session.result is not None and not self.busy)

    def refresh_recording_workspace(self):
        from types import SimpleNamespace
        import pandas as pd
        data=self.session.dataset
        meta=data.metadata()
        self.source_label.setText(f'{Path(data.source_path).name}   ·   {len(data.channels)} channels · {len(data.sweeps)} sweeps/segments')
        self.source_note.setText('Public example · raw source preserved' if self.session.context.get('public_example') else 'Raw recording preserved')
        self.sheet_combo.setVisible(False)
        self.tabs.setTabText(2,'Recording details')
        rows=[{'Channel':c['index']+1,'Name':c['name'],'Unit':c['unit'] or 'unavailable',
               'Sample rate (Hz)':c['sampling_rate_hz'],'Sweeps/segments':len(data.sweeps)} for c in data.channels]
        table=SimpleNamespace(df=pd.DataFrame(rows),row_numbers=list(range(1,len(rows)+1)))
        self.data_table.setModel(DataModel(table))
        self.data_note.setText(f"ABF {meta.get('abf_version','')}, {meta['acquisition_mode']}. "
            f"Sampled duration per channel: {meta['sampled_duration_s']:g} s; elapsed extent: {meta['elapsed_duration_s']:g} s. "
            'Channel and sweep numbers start at 1. Metadata is shown here; signal samples are read in bounded chunks for the trace view.')
        if self.session.result:
            try:
                figure=make_figure(data,self.session.result,self.session.plan,self.session.style)
                layout=self.figure_tab.layout();layout.removeWidget(self.canvas);self.canvas.deleteLater()
                self.figure=figure;self.canvas=FigureCanvas(figure)
                self.canvas.setSizePolicy(QSizePolicy.Policy.Expanding,QSizePolicy.Policy.Expanding)
                layout.insertWidget(0,self.canvas,1);self.canvas.draw()
                caption=figure_caption(data,self.session.result,self.session.plan,self.session.style)
                if self.session.context.get('public_example'):caption='Public reference recording. '+caption
                self.figure_note.setPlainText(caption)
                kind='action potentials and firing rate' if self.session.result.get('method')=='action_potentials' else 'spikes and firing rate' if self.session.result.get('method')=='spikes' else 'raw trace'
                self.figure_size.setText(f"{self.session.style.get('width_mm',178):g} × {self.session.style.get('height_mm',110):g} mm · {kind} · PDF · SVG")
                self.tabs.setCurrentIndex(0)
            except Exception as error:
                self.add_message('assistant','The recording opened, but this trace view needs an adjustment: '+str(error))
                self.show_empty_figure()
            self.render_results()
        self.update_record()
        self.export_button.setEnabled(self.session.result is not None and not self.busy)

    def render_results(self):
        result = self.session.result
        esc = lambda x: html.escape(str(x))
        parts = ['<html><head><style>body{font-family:DejaVu Sans;font-size:12px;color:#28372b;} '
                 'table{border-collapse:collapse;width:100%;margin:14px 0 24px;} th{text-align:left;border-bottom:1px solid #98ad98;padding:8px;background:#f0f5eb;} '
                 'td{padding:8px;border-bottom:1px solid #e4eadd;} h2{font-size:18px;}h3{font-size:14px;}</style></head><body>']
        parts += [f'<h2>{esc(result.get("method", "Analysis"))}</h2><p>{esc(result["summary"]).replace(chr(10),"<br>")}</p>']
        for table in result.get('tables', []):
            columns=table['columns']
            if result.get('method') in ('spikes','action_potentials'):
                preferred={
                    'Firing rate by sweep':['channel','sweep','spike_count','sampled_duration_s','firing_rate_hz'],
                    'Pooled firing rate by channel':['channel','selected_sweeps','spike_count','sampled_duration_s','firing_rate_hz'],
                    'Binned firing rate':['channel','sweep','start_s','end_s','duration_s','spike_count','firing_rate_hz'],
                    'Detected spikes':['channel','sweep','crossing_time_s','peak_time_s','peak_mv'],
                    'Action potential measurements':['event_id','sweep','peak_time_s','amplitude_mv','half_width_ms','isi_ms','quality_flags'],
                    'Inter-spike intervals':['channel','sweep','event_id','isi_ms']}
                columns=preferred.get(table['title'],columns)
            labels={'sampled_duration_s':'Sampled duration (s)','firing_rate_hz':'Firing rate (spikes/s)',
                    'start_s':'Start (s)','end_s':'End (s)','duration_s':'Duration (s)',
                    'crossing_time_s':'Crossing time (s)','peak_time_s':'Peak time (s)','peak_mv':'Peak (mV)',
                    'event_id':'Peak ID','amplitude_mv':'Baseline-relative amplitude (mV)',
                    'half_width_ms':'Half-width (ms)','isi_ms':'ISI (ms)','quality_flags':'Measurement notes'}
            label=lambda c:labels.get(c,c.replace('_',' ').capitalize()) if result.get('method') in ('spikes','action_potentials') else c
            parts.append(f'<h3>{esc(table["title"])}</h3><table><tr>' + ''.join(f'<th>{esc(label(c))}</th>' for c in columns) + '</tr>')
            for row in table['rows'][:200]:
                parts.append('<tr>' + ''.join(f'<td>{esc(format_value(row.get(c)))}</td>' for c in columns) + '</tr>')
            parts.append('</table>')
            if len(table['rows'])>200:
                parts.append(f'<p>Showing the first 200 of {len(table["rows"]):,} result rows. All rows remain in the saved result and exported CSV.</p>')
        if result.get('method') in ('spikes','action_potentials'):
            parts.append('<p>Complete tables, including original sample indices and detector accounting, remain in the saved result and exported CSV files. Event times above are within each sweep.</p>')
        accounting=(result.get('large_table_accounting',{}) if self.session.is_large_table else result.get('ap_accounting',result.get('spike_accounting',result.get('trace_accounting',{}))) if self.session.is_recording else result.get('row_accounting',{}))
        parts.append('<h3>'+('Recording view accounting' if self.session.is_recording else 'Row accounting')+'</h3><p>' + esc(json.dumps(accounting, indent=2)).replace('\n','<br>') + '</p>')
        if result.get('processing_steps'):
            parts.append('<h3>Processing steps</h3><pre>'+esc(json.dumps(result['processing_steps'],indent=2))+'</pre>')
        if result.get('warnings'):
            parts.append('<h3>Analysis notes</h3>' + ''.join('<p>' + esc(w) + '</p>' for w in result['warnings']))
        parts.append('</body></html>')
        self.results_view.setHtml(''.join(parts))

    def update_record(self):
        if not self.session.dataset:
            self.record_view.setPlainText('Opening a spreadsheet creates a project with its original source and a record of your instructions.')
            return
        text = ('PROJECT\n' + str(self.session.project_dir) + '\n\nSOURCE SHA-256\n' + self.session.dataset.source_hash +
                '\n\nSTUDY STRUCTURE\n' + self.session.context.get('design','unknown') +
                '\n\nCURRENT ANALYSIS\n' + json.dumps(self.session.plan, indent=2, ensure_ascii=False) +
                '\n\nPROCESSING STEPS\n' + json.dumps((self.session.result or {}).get('processing_steps', []), indent=2, ensure_ascii=False) +
                '\n\nFIGURE SETTINGS\n' + json.dumps(self.session.style, indent=2, ensure_ascii=False) +
                '\n\nHISTORY\n')
        try:
            events = [json.loads(line) for line in (self.session.project_dir / 'history.jsonl').read_text().splitlines()]
            for event in events:
                text += event['time_utc'][:19].replace('T',' ') + ' UTC   ' + event['type'] + '\n'
                if event['type'] == 'instruction':
                    text += '  ' + str(event['payload'].get('text','')) + '\n'
        except (ValueError, OSError):
            text += 'History is unavailable.\n'
        text += '\nHistory hashes detect inconsistent records; they are not an external signature or proof against deliberate rewriting.'
        if self.session.is_study:
            text+='\n\nSTUDY PLANNING STATE\n'+json.dumps(self.session.context.get('study_state',{}),indent=2,ensure_ascii=False)
            text+='\n\nEXECUTION RECIPE AND RUNS\n'+json.dumps(self.session.context.get('study_execution',{}),indent=2,ensure_ascii=False)
        self.record_view.setPlainText(text)

    def export_current(self, request=None):
        if self.busy or (not self.session.result and not self.session.is_study):
            return
        request = request if isinstance(request, dict) else {}
        if self.session.is_study and self.session.result:
            self.start_work(lambda:self.session.export_bundle(request),self.export_complete,
                'Exporting study figures, tables and original-source reproduction record…')
            return
        self.busy = True
        self.progress.setText('Exporting study plan and provenance…' if self.session.is_study and not self.session.result else 'Exporting figures and reproducibility record…')
        for widget in [self.send_button,self.open_button,self.demo_button,self.export_button,self.sheet_combo]:
            widget.setEnabled(False)
        def perform_export():
            try:
                self.export_complete(self.session.export_bundle(request))
            except Exception as error:
                self.work_failed(str(error))
            finally:
                self.work_finished()
        # All font/figure rendering uses the GUI thread; the progress message
        # is painted before this bounded export begins.
        QTimer.singleShot(0, perform_export)

    def export_complete(self, result):
        self.last_export = result
        if result.get('input_type')=='study_execution':
            self.add_message('assistant','Exported PDF/SVG/PNG figures, result tables, source window ledger, exact recipe, processing history, checksums and AI-free Python reproduction source. '+
                ('Verified originals are included.' if result.get('raw_sources_included') else 'Original files remain in the project; the compact export records their identities and hashes.')+
                '\n\n'+result.get('result_status','')+'\n\nSaved in:\n'+result['folder'])
            self.statusBar().showMessage('Study analysis exported: '+result['folder'],20000);self.update_record();return
        if result.get('input_type')=='study':
            detail='Exact source files are included.' if result.get('raw_sources_included') else 'The original files remain in the project; this compact package records their hashes.'
            self.add_message('assistant','Exported the study plan, observed metadata, review decisions, candidate method references, conversation and audit record. No numerical result or calculated figure is included. '+detail+'\n\nSaved in:\n'+result['folder'])
            self.statusBar().showMessage('Study plan exported: '+result['folder'],20000);self.update_record();return
        if result.get('input_type')=='large_table':
            detail='The preserved source is included.' if result.get('raw_source_included') else 'The preserved source remains in its project; this compact export records its path and checksum. Provide the original file separately when moving the recipe to another computer.'
            self.add_message('assistant','Exported the stored results, PDF/SVG/PNG figure, query/processing record, checksums and Python reproduction source. '+detail+'\n\nSaved in:\n'+result['folder'])
            self.statusBar().showMessage('Large-table export complete: '+result['folder'],20000);self.update_record();return
        if result.get('input_type')=='recording':
            is_spikes=self.session.result.get('method') in ('spikes','action_potentials')
            kind='action-potential and firing-rate figure' if self.session.result.get('method')=='action_potentials' else 'spike and firing-rate figure' if is_spikes else 'ABF trace'
            detail=('with event and firing-rate tables, candidate decisions, every processing step, detector settings, '
                    if is_spikes else 'with recording metadata, the exact view and display-reduction record, ')
            self.add_message('assistant',f'Exported the {kind} as PDF, SVG and {self.session.style.get("dpi",600)} dpi PNG, '+
                detail+'original ABF, history and reproduction source. '
                'The local export ZIP includes the raw source recording.\n\nSaved in:\n'+result['folder'])
            self.statusBar().showMessage(('Spike analysis' if is_spikes else 'Trace')+' export complete: '+result['folder'],20000)
            self.update_record()
            return
        self.add_message('assistant', f'Exported PDF, SVG and {self.session.style.get("dpi",600)} dpi PNG, result tables, caption, methods, original source, history, '
                         'and a runnable reproduction recipe.\n\nSaved in:\n' + result['folder'] + '\n\nA ZIP copy is saved beside that folder.')
        self.statusBar().showMessage('Export complete: ' + result['folder'], 20000)
        self.update_record()

    def settings(self):
        if self.busy:
            return
        dialog = Settings(self.config, self, credentials=self.credentials)
        self._settings_dialog=dialog
        if dialog.exec() == QDialog.DialogCode.Accepted:
            settings = dialog.values()
            try:
                typed=dialog.api_key.text().strip()
                if settings['provider']=='openai' and typed:
                    self.credentials.save(typed,remember=settings['use_system_wallet'])
                self.credentials.use_system_wallet=settings['use_system_wallet']
                # Persist preferences atomically. Credential bytes never enter this dict.
                write_settings(self.config_path,settings)
            except Exception as error:
                safe=str(error)
                if typed:safe=safe.replace(typed,'[credential hidden]')
                QMessageBox.warning(self,'Conversation settings could not be saved',safe)
                dialog.api_key.clear();dialog.deleteLater();self._settings_dialog=None;return
            self.config = settings
            self._api_verified=((settings['openai_model'],self.credentials.revision)
                                if dialog.connection_verified else None)
            self.update_mode()
            provider=selected_provider(settings)
            message={'openai':'OpenAI API conversation is selected. When you send a message, your typed chat and bounded project context go to OpenAI; calculations and raw files stay local. '
                                'API usage is billed to your API account. '+('This model connection was tested.' if dialog.connection_verified else 'The connection has not been tested.'),
                     'ollama':'Local Ollama interpretation is enabled. If the model is unavailable, I will explain the connection error.',
                     'offline':'Offline commands are enabled. No model service is contacted.'}[provider]
            self.add_message('assistant',message)
        dialog.api_key.clear();dialog.deleteLater();self._settings_dialog=None
        if self._close_requested:QTimer.singleShot(0,self.close)

    def show_library(self):
        from .knowledge import session_reference_library
        try:
            library = session_reference_library(self)
            summary = library.summary()
            entries = library.entries()
        except Exception as error:
            QMessageBox.warning(self, 'Reference library', str(error))
            return
        dialog = QDialog(self)
        dialog.setWindowTitle('Reference library')
        dialog.resize(690, 520)
        layout = QVBoxLayout(dialog)
        view = QTextBrowser()
        view.setOpenExternalLinks(True)
        paragraphs = ['<h2>Local method references</h2>',
            '<p>Reviewed local text can be supplied to an enabled local AI model. '
            'Links alone are a reading list; their content has not been downloaded or used for training.</p>',
            f'<p>{summary["total"]} catalog entries; {summary["reviewed_with_text"]} reviewed text sources.</p>']
        for entry in entries:
            esc = html.escape
            paragraphs.append(f'<h3>{esc(entry["title"])}</h3><p><a href="{esc(entry["url"],quote=True)}">Read source</a><br>'
                f'{esc(entry["license"])}<br>Status: {esc(entry["status"])}; '
                f'{"local text" if entry.get("text_file") else "link only"}</p>')
        paragraphs.append('<p>See knowledge/README.md and CONTRIBUTING.md for the review process, rights metadata, '
                          'and how to contribute synthetic worked examples with independently checked results.</p>')
        view.setHtml(''.join(paragraphs))
        layout.addWidget(view)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Close)
        buttons.rejected.connect(dialog.reject)
        layout.addWidget(buttons)
        dialog.exec()

    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls() and not self.busy:
            event.acceptProposedAction()

    def dropEvent(self, event):
        paths = [u.toLocalFile() for u in event.mimeData().urls() if u.isLocalFile()]
        if paths and not self.busy:
            if len(paths)>1:self.open_study_paths(paths)
            else:self.open_path(paths[0])
            event.acceptProposedAction()

    def closeEvent(self, event):
        dialog=self._settings_dialog
        if dialog is not None and dialog.test_thread is not None:
            self._close_requested=True
            dialog.reject()
            self.statusBar().showMessage('Stopping the connection test. StatWeave will close when it has stopped.',0)
            event.ignore();return
        thread_running = self.thread is not None and self.thread.isRunning()
        if self.busy or thread_running:
            self._close_requested = True
            self.progress.setText('Close requested — waiting for the current operation to finish…')
            if self._model_active and callable(self._cancel_discussion):
                self.cancel_discussion()
                self.statusBar().showMessage('Stopping the discussion. StatWeave will save and close automatically when it has stopped.', 0)
            else:
                self.statusBar().showMessage('StatWeave will save and close automatically when the current operation finishes.', 0)
            self.update_work_progress()
            event.ignore()
            return
        self._close_requested = False
        if self.session.project_dir:
            try:
                self.session.save()
            except Exception as error:
                message=(str(error) or type(error).__name__)
                answer=QMessageBox.warning(self, 'The project could not be saved',
                    'The latest project state could not be saved:\n\n'+message+
                    '\n\nYour existing saved project and original files have not been discarded. '
                    'Choose Cancel to keep the window open, or Close to exit without saving this latest state.',
                    QMessageBox.StandardButton.Close | QMessageBox.StandardButton.Cancel,
                    QMessageBox.StandardButton.Cancel)
                if answer != QMessageBox.StandardButton.Close:
                    self.statusBar().showMessage('Close cancelled because the latest project state could not be saved.', 12000)
                    event.ignore()
                    return
        event.accept()


def format_value(value):
    if value is None:
        return '—'
    if isinstance(value, float):
        return f'{value:.6g}'
    return str(value)


def main():
    parser = argparse.ArgumentParser(description='StatWeave desktop statistics')
    parser.add_argument('file', nargs='?', help='Spreadsheet or saved project.json to open')
    parser.add_argument('--workspace', default=os.environ.get('STATWEAVE_WORKSPACE', str(Path.cwd())))
    parser.add_argument('--demo', action='store_true')
    parser.add_argument('--ui-self-test', action='store_true', help='Run the bounded desktop workflow check and exit')
    parser.add_argument('--ui-abf-self-test',action='store_true',help='Run the recording desktop workflow check and exit')
    parser.add_argument('--ui-spike-self-test',action='store_true',help='Run the spike detection desktop workflow check and exit')
    parser.add_argument('--ui-ap-self-test',action='store_true',help='Run the action-potential desktop workflow check and exit')
    parser.add_argument('--ui-large-self-test',action='store_true',help='Run the large-table desktop workflow check and exit')
    parser.add_argument('--ui-study-self-test',action='store_true',help='Run the study intake/planning desktop workflow check and exit')
    parser.add_argument('--ui-execution-self-test',action='store_true',help='Run the synthetic study execution/figure/export desktop check and exit')
    parser.add_argument('--ui-close-self-test',action='store_true',help='Run the bounded synthetic close-during-worker desktop check and exit')
    parser.add_argument('--ui-conversation-self-test',action='store_true',help='Run the synthetic cancellable-reply desktop check and exit without a model')
    parser.add_argument('--ui-natural-study-self-test',action='store_true',help='Run the synthetic ordinary-language study workflow and exit')
    parser.add_argument('--ui-api-settings-self-test',action='store_true',help='Run synthetic provider/settings/cancellation checks without credentials or API traffic')
    parser.add_argument('--conversation-settings',action='store_true',help='Open the conversation provider and masked credential settings')
    parser.add_argument('--study-folder',help='Folder for study intake or its bounded desktop check')
    parser.add_argument('--large-project',help='Existing large-table project for the bounded desktop check')
    parser.add_argument('--abf-file',help='ABF fixture for the recording desktop check')
    args = parser.parse_args()
    app = QApplication(sys.argv[:1])
    app.setApplicationName('StatWeave')
    app.setApplicationVersion(__version__)
    app.setOrganizationName('StatWeave')
    app.setStyle('Fusion')
    font = QFont('DejaVu Sans', 10)
    app.setFont(font)
    window = Window(args.workspace)
    window.show()
    if args.ui_api_settings_self_test:
        from .ui_api_settings_selftest import schedule
        QTimer.singleShot(250,lambda:schedule(window,app,args.workspace))
    elif args.ui_natural_study_self_test:
        from .ui_natural_study_selftest import schedule
        QTimer.singleShot(250,lambda:schedule(window,app,args.workspace))
    elif args.ui_conversation_self_test:
        from .ui_conversation_selftest import schedule
        QTimer.singleShot(250,lambda:schedule(window,app,args.workspace))
    elif args.ui_close_self_test:
        from .ui_close_selftest import schedule
        QTimer.singleShot(250,lambda:schedule(window,app,args.workspace))
    elif args.ui_execution_self_test:
        from .ui_execution_selftest import schedule
        QTimer.singleShot(250,lambda:schedule(window,app,args.workspace))
    elif args.ui_study_self_test:
        from .ui_study_selftest import schedule
        QTimer.singleShot(250,lambda:schedule(window,app,args.workspace,args.study_folder))
    elif args.ui_large_self_test:
        from .ui_large_selftest import schedule
        QTimer.singleShot(250,lambda:schedule(window,app,args.workspace,args.large_project))
    elif args.ui_ap_self_test:
        if not args.abf_file:parser.error('--ui-ap-self-test requires --abf-file')
        from .ui_ap_selftest import schedule
        QTimer.singleShot(250,lambda:schedule(window,app,args.workspace,args.abf_file))
    elif args.ui_spike_self_test:
        if not args.abf_file:parser.error('--ui-spike-self-test requires --abf-file')
        from .ui_spike_selftest import schedule
        QTimer.singleShot(250,lambda:schedule(window,app,args.workspace,args.abf_file))
    elif args.ui_abf_self_test:
        if not args.abf_file:parser.error('--ui-abf-self-test requires --abf-file')
        from .ui_abf_selftest import schedule
        QTimer.singleShot(250,lambda:schedule(window,app,args.workspace,args.abf_file))
    elif args.ui_self_test:
        from .ui_selftest import schedule
        QTimer.singleShot(250, lambda: schedule(window,app,args.workspace))
    elif args.study_folder:
        QTimer.singleShot(250,lambda:window.open_path(args.study_folder))
    elif args.file:
        QTimer.singleShot(250, lambda: window.open_path(args.file))
    elif args.demo:
        QTimer.singleShot(250, window.load_demo)
    if args.conversation_settings:
        def open_settings_when_ready():
            if window.busy:QTimer.singleShot(100,open_settings_when_ready)
            else:window.settings()
        QTimer.singleShot(500,open_settings_when_ready)
    return app.exec()
