"""Offline, explicit action-potential measurements and source-preserving review.

This interpreter only constructs supported plans. It does not inspect signals,
remove source samples, perform inference, or execute text from a reason/label.
"""
from __future__ import annotations
from copy import deepcopy
import math
import re

from .recording_commands import interpret_recording, _NUMBER, _TIME_UNIT, _spike_intent

_DEFAULT_MEASUREMENTS = {'baseline_window_ms':2.0, 'baseline_gap_ms':.5,
                         'search_before_ms':5.0, 'search_after_ms':10.0,
                         'isi_reference':'peak'}
_VIEW_KEYS = {'channels','sweeps','start_s','end_s','time_reference','detector','bin_width_s','style'}
_EVENT_ID = r'ch[1-9]\d*-sw[1-9]\d*-p\d+'
_WINDOW = rf'\bfrom\s+({_NUMBER})\s*(ms|milliseconds?|s|seconds?)?\s+(?:to|through|-)\s*({_NUMBER})\s*(ms|milliseconds?|s|seconds?)?\b'


def _failure(message):
    return {'action':'help','message':message,'unsupported':True}


def _seconds(number,unit):
    value=float(number)
    if not math.isfinite(value):raise ValueError('Review times must be finite numbers.')
    return value*(.001 if unit.casefold().startswith('m') else 1.)


def _ap_state(previous_plan):
    prior=previous_plan or {}
    state={key:deepcopy(value) for key,value in prior.items() if key in _VIEW_KEYS}
    state.setdefault('channels',[0]);state.setdefault('sweeps',[0])
    state.setdefault('start_s',0.);state.setdefault('time_reference','sweep')
    state['detector']={'threshold_mv':-20.,'refractory_ms':2.,**state.get('detector',{})}
    state.setdefault('bin_width_s',.1)
    measurements=deepcopy(_DEFAULT_MEASUREMENTS)
    if prior.get('method')=='action_potentials':measurements.update(deepcopy(prior.get('measurements',{})))
    state['measurements']=measurements
    state['excluded_regions']=deepcopy(prior.get('excluded_regions',[])) if prior.get('method')=='action_potentials' else []
    state['event_decisions']=deepcopy(prior.get('event_decisions',[])) if prior.get('method')=='action_potentials' else []
    if prior.get('method')=='action_potentials' and 'review_source_sha256' in prior:
        state['review_source_sha256']=prior['review_source_sha256']
    state.update(action='action_potentials',method='action_potentials')
    return state


def _delegate_previous(previous_plan):
    state=_ap_state(previous_plan)
    view={k:deepcopy(v) for k,v in state.items() if k in _VIEW_KEYS}
    view.update(action='spikes',method='spikes')
    return view


def _settings(state):
    m=state['measurements'];d=state['detector']
    return (f"Threshold {d['threshold_mv']:g} mV; refractory {d['refractory_ms']:g} ms; firing-rate bins {state['bin_width_s']:g} s. "
            f"Baseline window {m['baseline_window_ms']:g} ms and gap {m['baseline_gap_ms']:g} ms; half-width search before/after peak {m['search_before_ms']:g}/{m['search_after_ms']:g} ms; peak-to-peak ISI. "
            f"Active excluded regions: {len(state['excluded_regions'])}; manual peak decisions: {len(state['event_decisions'])}.")


def analysis_plan_message(previous_plan=None):
    state=_ap_state(previous_plan)
    label='Current action-potential plan' if previous_plan and previous_plan.get('method')=='action_potentials' else 'Proposed action-potential plan (not executed)'
    return (label+':\n'+_settings(state)+'\n\n'
        'Automatic events use upward voltage-threshold crossings. For every accepted peak, automatic or manually added, the local baseline is the median of the exact pre-peak interval ending the baseline gap before that peak. This local pre-peak reference is not an assumed resting membrane voltage. '
        'Amplitude is peak voltage minus that baseline. Half-height is baseline plus half the amplitude; half-width uses the surrounding upward/downward half-height crossings, with linearly interpolated crossing times. '
        'Searches are bounded around the peak and by neighboring candidate peaks. A baseline or crossing that cannot be established inside one included segment is flagged unavailable, rather than clipped or invented. '
        'Inter-spike intervals use successive reviewed accepted peak times within the same channel, sweep and included segment; no interval bridges an excluded region or sweep gap. '
        'Region and peak-review commands require reasons and use within-sweep source time. Raw recording samples remain preserved. This plan performs descriptive waveform measurements, not a group statistical test.')


def _extract_measurements(text):
    clean=text;updates={};counts={}
    labels={
        'baseline_window_ms':r'baseline\s+window',
        'baseline_gap_ms':r'baseline\s+gap',
        'search_before_ms':r'(?:peak\s+)?search(?:\s+window)?\s+before',
        'search_after_ms':r'(?:peak\s+)?search(?:\s+window)?\s+after'}
    for key,label in labels.items():
        pattern=rf'\b(?:(?:and|using|with)\s+)?{label}\s*(?:(?:to|of|at|is|=|:)\s*)?({_NUMBER})\s*({_TIME_UNIT})\b'
        def take(match,key=key):
            counts[key]=counts.get(key,0)+1
            if counts[key]>1:raise ValueError('Specify each measurement setting once per instruction.')
            value=_seconds(match.group(1),match.group(2))*1000.
            if value<0 or (key!='baseline_gap_ms' and value==0):raise ValueError('The baseline gap must be nonnegative; baseline and search windows must be positive.')
            updates[key]=value
            return ' '
        clean=re.sub(pattern,take,clean,flags=re.I)
    if re.search(r'\bbaseline\b|\bsearch\s+(?:window\s+)?(?:before|after)\b',clean,re.I):
        raise ValueError('Use explicit measurement settings with ms or seconds, for example “set baseline window to 2 ms” or “set baseline gap to 0.5 ms”. Baseline correction is not applied.')
    reference=re.search(r'\b(?:isi|inter[ -]spike interval)\s+reference\s*(?:(?:to|is|=|:)\s*)?(peak)\b',clean,re.I)
    if reference:
        updates['isi_reference']='peak';clean=clean[:reference.start()]+' '+clean[reference.end():]
    return clean,updates


def _reason(text):
    from .engine import _PRUNING_REASON_RE
    parts=re.split(r'\bbecause\b',text,maxsplit=1,flags=re.I)
    if len(parts)!=2 or not parts[1].strip():raise ValueError('Give a reason using “because …”. No review decision or mask was changed.')
    instruction,reason=parts[0].strip(),parts[1].strip()
    if len(reason)>1000:raise ValueError('Keep the review reason below 1,000 characters.')
    if ';' in reason or '\n' in reason or re.search(r'\b(?:then|followed by|and\s+(?:export|delete|remove|filter|measure|analy[sz]e|reject|restore|add|set|change|use|show|plot|detect|calculate|compute))\b',reason,re.I):
        raise ValueError('Give one review instruction and its reason at a time; no partial instruction was applied.')
    if _PRUNING_REASON_RE.search(reason):
        raise ValueError('Review decisions and exclusions require a concrete waveform or experimental artifact reason (for example “because pipette artifact”), never statistical outlier pruning or p-value optimization.')
    return instruction,reason


def _review_scope(scope,recording,previous_plan):
    """Only channel/sweep selection can accompany a manual annotation."""
    remainder=re.sub(r'\b(?:on|in|for|using|with|the|channel|channels|sweep|sweeps|through|to|and|all|selected|current)\b',' ',scope,flags=re.I)
    remainder=re.sub(r'[\s,\d.-]+',' ',remainder).strip()
    if remainder:
        raise ValueError('A review annotation may specify only its region/peak, channel and sweep scope, plus its reason. Give detector, measurement or presentation settings separately.')
    prior=_delegate_previous(previous_plan);prior['time_reference']='sweep'
    return interpret_recording('show trace '+scope,recording,prior)


def _review_plan(text,recording,previous_plan):
    if not previous_plan or previous_plan.get('method')!='action_potentials':
        return _failure('Run “measure action potentials” first so review decisions have a current measurement plan and source selection.')
    instruction,reason=_reason(text)
    state=_ap_state(previous_plan)
    # The numerical validator supplies the binding after a first analysis. A
    # newly annotated parser plan can bind now when metadata provides the hash.
    if not state.get('review_source_sha256') and getattr(recording,'source_hash',None):
        state['review_source_sha256']=recording.source_hash
    if re.fullmatch(r'clear\s+(?:all\s+)?excluded\s+regions',instruction,re.I):
        state['excluded_regions']=[]
        if not state['event_decisions']:state['review_source_sha256']=None
        state['message']='Cleared the excluded-region masks because '+reason+'. Raw samples stay intact; the instruction and reason remain in the analysis record. '+_settings(state)
        return state
    if re.fullmatch(r'clear\s+(?:all\s+)?peak\s+decisions',instruction,re.I):
        state['event_decisions']=[]
        if not state['excluded_regions']:state['review_source_sha256']=None
        state['message']='Cleared the manual peak decisions because '+reason+'. Earlier review instructions remain in the analysis record. '+_settings(state)
        return state
    event=re.fullmatch(rf'(reject|restore)\s+(?:the\s+)?peak\s+({_EVENT_ID})',instruction,re.I)
    if event:
        operation,event_id=event.groups()
        decision={'operation':operation.casefold(),'event_id':event_id.casefold(),'reason':reason}
        state['event_decisions'].append(decision)
        state['message']=f"Requested {operation.casefold()} for {event_id.casefold()} because {reason}. The source event ID and selection must pass validation; no raw samples are deleted. "+_settings(state)
        return state
    if re.search(r'\b(?:recording time|absolute time)\b',instruction,re.I):
        raise ValueError('Manual regions and added peaks use within-sweep source time. Use within-sweep seconds or milliseconds and name the channel/sweep; recording-relative review annotations are not guessed.')
    region=re.match(r'^exclude\s+(?:the\s+|a\s+)?(?:region|interval)\b',instruction,re.I)
    if region:
        scope=instruction[region.end():].strip()
        windows=list(re.finditer(_WINDOW,scope,re.I))
        if len(windows)!=1 or not (windows[0].group(2) or windows[0].group(4)):
            raise ValueError('Specify one excluded region with explicit time units, for example “exclude region from 0.2 to 0.25 seconds because pipette artifact”.')
        window=windows[0]
        first,u1,last,u2=window.groups()
        start=_seconds(first,u1 or u2);end=_seconds(last,u2 or u1)
        # Parse only selection language with the shared strict interpreter.
        # Source times here are independent of the current display reference.
        scope=scope[:window.start()]+' '+scope[window.end():]
        scope=re.sub(r'\bwithin[ -]sweep(?:\s+source)?\s+time\b',' ',scope,flags=re.I)
        view=_review_scope(scope,recording,previous_plan)
        if view.get('action')!='spikes':return view
        if start is None or end is None or not math.isfinite(start) or not math.isfinite(end) or start<0 or end<=start:
            raise ValueError('The excluded region must have finite, nonnegative, increasing within-sweep bounds.')
        channels=view['channels'];sweeps=view['sweeps']
        if not set(channels)<=set(state['channels']) or not set(sweeps)<=set(state['sweeps']):
            raise ValueError('A review region must be scoped to the currently selected channels and sweeps. Change the selection explicitly before adding that region.')
        state['excluded_regions'].append({'start_s':start,'end_s':end,'channels':list(channels),'sweeps':list(sweeps),'reason':reason})
        state['message']=f'Requested exclusion mask [{start:g}, {end:g}) s within each scoped sweep because {reason}. The full raw signal remains retained; bounds are validated without clipping. '+_settings(state)
        return state
    added=re.match(rf'^add\s+(?:a\s+)?peak\s+near\s+({_NUMBER})\s*({_TIME_UNIT})\s+within\s+({_NUMBER})\s*({_TIME_UNIT})\b',instruction,re.I)
    if added:
        time_s=_seconds(added.group(1),added.group(2));tolerance_ms=_seconds(added.group(3),added.group(4))*1000.
        if time_s<0 or tolerance_ms<=0:raise ValueError('An added-peak time must be nonnegative and its search tolerance must be positive.')
        scope=instruction[added.end():].strip()
        scope=re.sub(r'\bwithin[ -]sweep(?:\s+source)?\s+time\b',' ',scope,flags=re.I)
        if re.search(r'\b(?:from|through|time|full|all|recording)\b',scope,re.I):raise ValueError('An added peak needs one channel and one sweep, not another time window or a multi-sweep scope.')
        view=_review_scope(scope,recording,previous_plan)
        if view.get('action')!='spikes':return view
        channels=view['channels'];sweeps=view['sweeps']
        if len(channels)!=1 or len(sweeps)!=1:raise ValueError('Name exactly one channel and one sweep for an added peak.')
        if not set(channels)<=set(state['channels']) or not set(sweeps)<=set(state['sweeps']):raise ValueError('The added peak must belong to the current source selection; select that channel/sweep before reviewing it.')
        state['event_decisions'].append({'operation':'add','channel':channels[0],'sweep':sweeps[0],'time_s':time_s,'tolerance_ms':tolerance_ms,'reason':reason})
        state['message']=f'Requested a peak near {time_s:g} s within its sweep, searching within {tolerance_ms:g} ms, because {reason}. A source-local peak and its complete search interval must pass validation. '+_settings(state)
        return state
    raise ValueError('Use an exact review command: exclude region from … to … because …; reject/restore peak ch1-sw1-p2547 because …; add peak near … s within … ms on channel 1 sweep 1 because …; or clear excluded regions/peak decisions because … .')


def interpret_ap(text,recording,previous_plan=None):
    """Return an AP/review plan, safe explanation, style/raw view, or None.

    None delegates unrelated requests—including folder pipelines and generic raw
    deletion/outlier requests—to the caller's existing routing and protections.
    """
    from .planner import _parse_style
    if not isinstance(text,str) or not text.strip():return None
    text=text.translate(str.maketrans({'−':'-','–':'-','’':"'"})).strip()
    main=re.split(r'\bbecause\b',text,maxsplit=1,flags=re.I)[0].strip()
    low=main.casefold();previous_ap=previous_plan and previous_plan.get('method')=='action_potentials'
    if re.search(r'\b(?:pipeline|folder|directory|batch|workflow)\b',low):return None
    # Global export routes construct the reproduction package. A format name
    # alone is presentation syntax, but "export as SVG" is not an AP change.
    export_action=r'(?:export(?:\s+(?:the\s+)?(?:figure|plot|chart|results|package|analysis))?|save\s+(?:the\s+)?(?:figure|plot|chart|results|package|analysis))'
    export_format=r'(?:\s+(?:as\s+)?(?:svg|pdf|png|tiff?))?'
    export_path=r'''(?:\s+(?:to|in|at)\s+(?:"[^"\n]+"|'[^'\n]+'|(?:/|~/|[a-z]:[/\\])[^\n;]+))?'''
    if re.fullmatch(export_action+export_format+export_path,text,re.I):return None
    style=_parse_style(text)
    if style and set(style)&{'title','xlabel','ylabel'}:
        prefix=re.split(r'\b(?:title|label)\b',main,maxsplit=1,flags=re.I)[0]
        if re.search(r"\b(?:do\s+not|don['’]?t|dont|never|not|no|stop|cancel|avoid|disable|omit)\b",prefix,re.I):
            return _failure('The presentation instruction is negated. No figure label was changed.')
        return interpret_recording(text,recording,_delegate_previous(previous_plan)) if previous_ap or re.search(r'\b(?:action[ -]potentials?|aps?)\b',text,re.I) else None
    review=bool(re.search(r'\b(?:exclude\s+(?:(?:the|a)\s+)?(?:region|interval)|(?:reject|restore|add)\s+(?:(?:the|a)\s+)?peak|clear\s+(?:all\s+)?(?:excluded regions|peak decisions))\b',low))
    if not review and re.search(r'\b(?:remove|delete|drop|prune|discard|trim|hide|exclude|outliers?|winsori[sz]\w*)\b',low):return None
    plan_question=bool(re.fullmatch(r'(?:please\s+)?(?:show|explain|describe)\s+(?:the\s+)?(?:current\s+)?(?:analysis plan|action[ -]potential plan|ap plan)\??',low))
    definition=r'(?:action[ -]potential\s+)?(?:amplitude|half[ -]?width|baseline|inter[ -]spike intervals?|isi)'
    explain_question=bool(re.fullmatch(rf'(?:please\s+)?(?:explain\s+(?:the\s+)?{definition}|what\s+(?:does\s+(?:the\s+)?{definition}\s+mean|is\s+(?:the\s+)?{definition})|how\s+is\s+(?:the\s+)?{definition}\s+(?:calculated|measured))\??',low))
    named=bool(re.search(r'\b(?:action[ -]potentials?|aps?|half[ -]?widths?|inter[ -]spike intervals?|isi)\b',low))
    analyze_spikes=bool(re.search(r'\b(?:measure|analy[sz]e|quantify)\s+(?:the\s+)?spikes?\b',low))
    settings=bool(re.search(r'\bbaseline\s+(?:window|gap)\b|\bsearch\s+(?:window\s+)?(?:before|after)\b',low))
    followup=previous_ap and bool(style or _spike_intent(low) or re.search(r'\b(?:analy[sz]e|measure|show|plot|overlay|view|channel|sweep|threshold|refractory|firing[ -]rate|bin|recording time|sweep time|full|entire|whole)\b',low))
    if not (review or plan_question or explain_question or named or analyze_spikes or settings or followup):return None
    if plan_question or explain_question:return {'action':'help','message':analysis_plan_message(previous_plan),'unsupported':True}
    if re.search(r"\b(?:do\s+not|don['’]?t|dont|never|not|without|no|stop|cancel|avoid|disable|omit)\b",low):
        return _failure('This instruction negates or disables part of the AP workflow. No measurement setting, mask or peak decision was changed. State one positive instruction, or use “show raw trace”.')
    if ';' in main or '\n' in main or re.search(r'\b(?:then|followed by|after that)\b',low):
        return _failure('Give one AP measurement, setting or review instruction at a time. No partial instruction was applied.')
    if re.search(r'\b(?:filter(?:ing)?|smooth(?:ing)?|resampl\w*|decimat\w*|detrend|denois\w*|bandpass|highpass|lowpass|baseline\s+(?:correction|subtraction)|negative[ -]going|negative spikes?|prominence|synaptic|spectrum|fft|anova|regression|correlation|bayes\w*|export|save)\b',low):
        return _failure('This request includes processing, a detector criterion, inference or a combined save/export action outside the AP measurement plan. No part was run. AP measurements retain raw samples and explicit review choices.')
    try:
        if review:return _review_plan(text,recording,previous_plan)
        if re.match(r'^(?:please\s+)?(?:show|plot|view|use)\s+(?:the\s+)?raw\s+(?:traces?|recording)\b',low):
            if named or analyze_spikes or settings:
                return _failure('Request either AP measurements or a raw trace view in one instruction. No partial change was applied.')
            return interpret_recording(text,recording,_delegate_previous(previous_plan))
        if re.search(r'\braw\s+(?:traces?|recording)\b',low):
            return _failure('Request either AP measurements or a raw trace view in one instruction. No partial change was applied.')
        clean,measurement_changes=_extract_measurements(text)
        if style and previous_ap and not (named or analyze_spikes or measurement_changes):
            presentation=interpret_recording(text,recording,_delegate_previous(previous_plan))
            if presentation.get('action')=='style':return presentation
        # These names request the supported, explicitly defined AP measurement
        # set. Unrecognized measurement words remain for the strict delegate.
        clean=re.sub(r'\b(?:action[ -]potentials?|aps?|half[ -]?widths?|inter[ -]spike intervals?|isi|amplitudes?)\b',' ',clean,flags=re.I)
        clean=re.sub(r'\b(?:analy[sz]e|measure|quantify|compute)\b',' ',clean,flags=re.I)
        command='detect spikes '+clean
        view=interpret_recording(command,recording,_delegate_previous(previous_plan))
        if view.get('action')=='style':return view
        if view.get('action')!='spikes':return view
        state=_ap_state(previous_plan)
        state.update({key:deepcopy(value) for key,value in view.items() if key in _VIEW_KEYS})
        state['measurements'].update(measurement_changes)
        state['message']='I will measure baseline-relative action-potential amplitudes, half-widths and within-segment peak-to-peak inter-spike intervals. '+_settings(state)+' Raw samples remain unchanged; unavailable measurements are flagged, and no inferential test is applied.'
        return state
    except (ValueError,TypeError,KeyError) as error:return _failure(str(error))
