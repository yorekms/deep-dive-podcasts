"""Read-only native study overview, evidence and method-card presentation."""
import html
import json


def value(proposal):
    return proposal.get('value') if isinstance(proposal,dict) else proposal


def _text(item):
    if isinstance(item,(dict,list)):return json.dumps(item,ensure_ascii=False,indent=2)
    return str(item if item is not None else 'Not established')


def _message(item):
    return item.get('message',_text(item)) if isinstance(item,dict) else _text(item)


def overview_html(study,state):
    from .study_methods import method_cards
    from .study_planner import _questions
    esc=lambda text:html.escape(_text(text))
    data=study.manifest();sources=data.get('sources',[]);domain=data.get('domain',{})
    status='Plan acknowledged' if state.get('approved_plan') else 'Mapping confirmed · plan in progress' if state.get('mapping_confirmed') else 'Study structure needs review'
    parts=['<html><body style="font-family:DejaVu Sans;font-size:11pt;color:#263b34;">',
           '<h2 style="color:#185c4b;">'+esc(status)+'</h2>',
           '<p>Method cards describe proposals. The implemented pleth Summary adapter runs only after a separate execution-recipe review, confirmation and run instruction. Calculated results, when present, appear in Figure and Results.</p>',
           '<h3>Scientific goal</h3><p>'+esc(state.get('goal') or 'Tell me what you want to learn from this study.')+'</p>',
           '<h3>Observed sources</h3><p>'+str(len(sources))+' preserved files. Proposed data type: <b>'+esc(domain.get('name','unknown'))+'</b>.</p>']
    evidence=domain.get('evidence',[])
    signals=[]
    for item in evidence:
        text=_text(item)
        if text.startswith('S') and ': ' in text:text=text.split(': ',1)[1]
        for signal in text.split('; '):
            if signal not in signals:signals.append(signal)
    if signals:parts+=['<ul>'+''.join('<li>'+esc(signal)+'</li>' for signal in signals[:4])+'</ul>']
    proposed_subjects={str(value(s.get('proposed_subject'))) for s in sources if value(s.get('proposed_subject')) is not None and s.get('role')!='reference_analysis'}
    proposed_sessions={str(value(s.get('proposed_session'))) for s in sources if value(s.get('proposed_session')) is not None and s.get('role')!='reference_analysis'}
    parts+=['<p>Proposed subject IDs: <b>'+str(len(proposed_subjects))+'</b>. Proposed session labels: <b>'+str(len(proposed_sessions))+'</b>. These remain identity proposals until reviewed.</p>']
    questions=_questions(study,state)
    if questions:parts+=['<h3>Next useful questions</h3><ol>'+''.join('<li>'+esc(q)+'</li>' for q in questions)+'</ol>']
    parts+=['<h3>Current choices</h3><p>Trial handling: '+esc(state.get('pooling','undecided'))+'.<br>Groups: '+esc(state.get('groups') or 'Not established')+'.</p>']
    if state.get('domain_confirmation'):parts+=['<p>Your domain interpretation: <b>'+esc(state['domain_confirmation'])+'</b>. The inspected source evidence above is retained.</p>']
    if state.get('profile_proposal'):parts+=['<p>Import profile proposal: '+esc(state['profile_proposal'].get('name'))+'. Schema match: '+esc(state['profile_proposal'].get('schema_matches'))+'. No previous identities or confirmations were transferred.</p>']
    if state.get('notes'):
        parts+=['<h3>Your study notes</h3><p>User-supplied declarations, kept separate from inspected source facts.</p><ul>'+''.join('<li>'+esc(note.get('text',''))+'</li>' for note in state['notes'][-3:])+'</ul>']
    issues=data.get('issues',[])
    parts+=['<h3>Metadata review</h3><p>'+str(len(issues))+' detected issues remain visible in the Metadata review tab. Endpoint-specific requirements appear below.</p>',
            '<h3>Candidate methods and figure plans</h3>']
    for card in method_cards(study,state):
        parts+=['<h4>'+esc(card['title'])+'</h4>',
                '<p><b>'+esc(_message(card.get('execution_status','Planning only')))+'</b><br>'+esc(card.get('question',''))+'</p>',
                '<p>Approach: '+esc(card.get('formula_or_approach',''))+'<br>Readiness: '+esc(_message(card.get('readiness',{})))+'<br>Figure proposal: '+esc(card.get('suggested_figure',''))+'</p>']
        readiness=card.get('readiness',{})
        if isinstance(readiness,dict) and readiness.get('missing'):
            parts+=['<p>To establish: '+esc(readiness['missing'])+'</p>']
        refs=[]
        for reference in card.get('sources',[]):
            if isinstance(reference,dict) and isinstance(reference.get('url'),str) and reference['url'].startswith(('https://','http://')):
                refs.append('<a href="'+html.escape(reference['url'],quote=True)+'">'+esc(reference.get('title',reference.get('id','Primary source')))+'</a>')
        if refs:parts+=['<p>'+ '<br>'.join(refs)+'</p>']
    parts+=['<h3>Conversation examples</h3><p>“my goal is to compare responses across conditions”<br>“suggest analyses”<br>“show metadata conflicts”<br>“plan figures”<br>“export study plan”</p></body></html>']
    return ''.join(parts)


def issues_html(study,state):
    esc=lambda text:html.escape(_text(text))
    parts=['<html><body style="font-family:DejaVu Sans;font-size:10pt;"><h2>Source metadata and review decisions</h2>',
           '<p>Detected issues describe source evidence. A current-study resolution is recorded separately and does not rewrite that evidence.</p>']
    for issue in study.manifest().get('issues',[]):parts+=['<pre>'+esc(issue)+'</pre><hr>']
    sources=study.manifest().get('sources',[])
    parts+=['<h3>Inspected source metadata</h3>']
    for source in sources[:32]:
        parts+=['<h4>'+esc(source.get('source_id',''))+' '+esc(source.get('original_name',''))+'</h4><pre>'+esc(source.get('metadata',{}))+'</pre>']
    if len(sources)>32:parts+=['<p>Showing metadata for the first 32 sources here; the source inventory and exported evidence retain all sources.</p>']
    parts+=['<h3>Current study decisions</h3><pre>'+esc(state)+'</pre></body></html>']
    return ''.join(parts)


def source_rows(study,state):
    rows=[]
    resolutions=state.get('subject_resolutions',{})
    for source in study.manifest().get('sources',[]):
        source_id=source.get('source_id','')
        rows.append({'Source':source_id,'File':source.get('original_name',''),
                     'Role':source.get('role','unknown'),'Proposed subject':value(source.get('proposed_subject')),
                     'Current subject':value(resolutions.get(source_id)),'Proposed session':value(source.get('proposed_session')),
                     'Sheets':', '.join(str(s.get('name',s.get('title',''))) for s in source.get('sheets',[]) if isinstance(s,dict)),
                     'Bytes':source.get('bytes'),'SHA-256':source.get('sha256','')})
    return rows
