"""Select an already calculated study figure without changing its analysis.

The full recorded result remains the result used by tables, audit and exports.
This view selection never reads source cells or calculates new statistics.
"""
from __future__ import annotations


def display_result(session):
    """Return a saved measure for the preview, or the complete result overview."""
    result = session.result
    if not isinstance(result, dict) or result.get('method') != 'study_execution' or not result.get('report'):
        return result
    focus = session.context.get('study_figure_focus')
    if not isinstance(focus, str):
        return result
    for measure in result.get('measures', []):
        if not isinstance(measure, dict) or measure.get('status') != 'executed':
            continue
        child = measure.get('result')
        if not isinstance(child, dict):
            continue
        endpoint = child.get('plot_data', {}).get('endpoint', {}).get('column')
        if isinstance(endpoint, str) and endpoint.casefold() == focus.casefold():
            return child
    return result
