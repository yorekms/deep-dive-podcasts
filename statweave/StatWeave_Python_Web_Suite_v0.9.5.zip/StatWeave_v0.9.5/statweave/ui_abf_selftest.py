"""Drive actual desktop recording actions and capture publication trace previews."""
from pathlib import Path
import json,time,traceback
from PySide6.QtCore import QTimer


def schedule(window,app,workspace,abf_path):
    target=Path(workspace).resolve()/'ui-abf-self-test'
    target.mkdir(parents=True,exist_ok=True)
    open_step=(lambda:window.load_abf_example('17o05027_ic_ramp.abf',1)) if abf_path=='public-example' else (lambda:window.open_path(Path(abf_path).resolve()))
    steps=[open_step,
           lambda:window.send('show channel 1 from 0 to 1 seconds'),
           lambda:window.send('overlay sweeps 1 through 2'),
           lambda:window.send('set the title to Public ABF recording'),
           lambda:window.send('export as SVG')]
    state={'index':0,'idle':0,'deadline':time.monotonic()+90}
    timer=QTimer(window);window._abf_selftest_timer=timer
    def tick():
        try:
            if time.monotonic()>state['deadline']:raise AssertionError('Desktop ABF workflow timed out')
            if window.busy or window._after_work:state['idle']=0;return
            state['idle']+=1
            if state['idle']<3:return
            state['idle']=0
            if state['index']<len(steps):
                steps[state['index']]();state['index']+=1;return
            assert window.session.is_recording
            assert window.session.plan['sweeps']==[0,1]
            assert window.last_export and Path(window.last_export['figure']).is_file()
            assert 'mV' in window.figure.axes[0].get_ylabel()
            assert len(window.figure.axes[0].lines)==2
            assert 'Recording details'==window.tabs.tabText(2)
            window.grab().save(str(target/'desktop.png'))
            report={'status':'passed','workflow':[('public ABF example menu/download' if abf_path=='public-example' else 'ABF import'),'channel/time instruction','sweep overlay','title','trace export'],
                    'source_sha256':window.session.dataset.source_hash,'export':window.last_export,
                    'screenshot':str(target/'desktop.png')}
            (target/'result.json').write_text(json.dumps(report,indent=2))
            timer.stop();app.quit()
        except Exception as error:
            timer.stop();(target/'result.json').write_text(json.dumps({'status':'failed','error':str(error),'traceback':traceback.format_exc()},indent=2));app.exit(1)
    timer.timeout.connect(tick);timer.start(50)
