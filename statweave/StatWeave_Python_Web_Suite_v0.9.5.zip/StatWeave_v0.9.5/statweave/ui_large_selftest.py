"""Native conversational large-table checks using synthetic data by default.

An explicitly provided saved project is opened in place, without reimporting its
source. The hook records hashes/counts and drives the public UI; it never sends
table values to a model or changes source records. Query history/exports belong
to the opened project. This module does not choose a private project itself.
"""
from copy import deepcopy
import csv
import json
import os
from pathlib import Path
import time
import traceback

from PySide6.QtCore import QTimer

from .session import sha256,verify_audit,versions
from .large_selftest import _check_manifest,_rows


def _synthetic_source(target):
    source=target/'synthetic-large-table.csv';count=genes=finite=0
    padding='synthetic-only-display-padding-'*110
    with source.open('w',encoding='utf-8',newline='') as handle:
        writer=csv.writer(handle)
        writer.writerow(['logFC','AdjPValue','GeneSymbol','Species','StudyID','ContrastID','padding'])
        while True:
            for _ in range(256):
                gene='Rab7a' if count%997==0 else 'RAB7A' if count%997==1 else 'RAB7A-AS1' if count%997==2 else f'SyntheticGene{count:06}'
                value='NaN' if count%97==0 else f'{((count%201)-100)/10:.1f}'
                writer.writerow([value,f'{(count%101)/100:.2f}',gene,['mouse','human'][count%2],
                    f'SyntheticStudy{count%3}',f'SyntheticContrast{count%2}',padding])
                genes+=gene.casefold()=='rab7a';finite+=value!='NaN';count+=1
            handle.flush()
            if os.fstat(handle.fileno()).st_size>=33*1024*1024:break
    assert source.stat().st_size>=32*1024*1024
    return source,{'row_count':count,'gene_count':genes,'finite_count':finite}


def schedule(window,app,workspace,project_path=None):
    """Schedule public UI operations; write desktop.png/result.json and exit."""
    target=Path(workspace).resolve()/'ui-large-self-test';target.mkdir(parents=True,exist_ok=True)
    source=None;expected=None
    try:
        if project_path is None:
            source,expected=_synthetic_source(target);opening=source
        else:
            opening=Path(project_path).expanduser().resolve()
            if opening.is_dir():opening=opening/'project.json'
            if opening.name!='project.json' or not opening.is_file():
                raise ValueError('The large-project check requires an existing project.json or project directory; it never reimports a supplied CSV.')
    except Exception as error:
        (target/'result.json').write_text(json.dumps({'status':'failed','stage':'fixture_or_project_selection',
            'error':str(error),'traceback':traceback.format_exc()},indent=2),encoding='utf-8')
        app.exit(1);return
    # This is an in-memory verification setting, never a change to the user's
    # saved model configuration. Native self-tests must make no live AI call.
    original_config=dict(window.config)
    window.config={**window.config,'enabled':False}
    window.update_mode();window.last_export=None
    commands=['use all rows','describe this data','count rows by Species','find gene RAB7A',
        'summarize logFC','use all rows','histogram logFC','histogram logFC','export as SVG']
    state={'index':0,'idle':0,'deadline':time.monotonic()+240,'checks':[],
        'opened_project':project_path is not None,'commands':commands}
    timer=QTimer(window);window._large_selftest_timer=timer

    def loaded():
        session=window.session;data=session.dataset
        assert session.is_large_table and not hasattr(data,'df')
        assert all(name in data.columns for name in ['logFC','AdjPValue','GeneSymbol','Species'])
        assert window.data_table.model().rowCount()<=200
        state.update(row_count=data.row_count,source_path=data.source_path,source_sha256=sha256(data.source_path),
            cache_identity=data.cache_identity(),project=str(session.project_dir))
        assert state['source_sha256']==data.source_hash
        if expected:assert data.row_count==expected['row_count']
        if source is not None:state['synthetic_source_sha256']=sha256(source)
        state['checks'].append('automatic_large_import' if source is not None else 'existing_project_open_without_reingestion')
        before=deepcopy(session.result);original_preview=data.preview;injected={'raised':False}
        def guarded_preview(*args,**kwargs):
            if not injected['raised']:
                injected['raised']=True
                raise ValueError('Synthetic verification: this preview exceeds the 8 MiB output budget; choose fewer fields.')
            return original_preview(*args,**kwargs)
        try:
            data.preview=guarded_preview;window.refresh_workspace()
            assert injected['raised'] and window.session.result==before
            assert window.data_table.model().rowCount()<=200
        finally:data.preview=original_preview
        window.refresh_workspace()
        assert window.session.result==before
        state['checks'].append('oversized_preview_fallback_retains_result')

    def selection(method,full=False):
        result=window.session.result
        assert result['method']==method,(method,result.get('method'))
        count=result['large_table_accounting']['selected_record_count']
        if full:assert count==state['row_count']
        return result

    def profile():
        result=selection('profile',True)
        item=next(row for row in _rows(result,'Column profile') if row['column']=='logFC')
        assert sum(item[key] for key in ['finite_count','nonfinite_count','invalid_count','null_count'])==state['row_count']
        state['finite_count']=item['finite_count']
        if expected:assert state['finite_count']==expected['finite_count']
        state['checks'].append('full_selected_profile')

    def count_groups():
        result=selection('count_by',True)
        assert sum(row['count'] for row in _rows(result,'Counts by group'))+result['large_table_accounting']['remaining_record_count']==state['row_count']
        state['checks'].append('all_selected_group_counts')

    def found():
        result=selection('find');state['gene_count']=result['large_table_accounting']['selected_record_count']
        for row in _rows(result,'Matching records'):
            assert row['GeneSymbol'].casefold()=='rab7a'
            assert row['GeneSymbol'].casefold()!='rab7a-as1'
        if expected:assert state['gene_count']==expected['gene_count']
        state['checks'].append('exact_gene_query_without_suffix_match')

    def summary():
        result=selection('summary')
        assert result['large_table_accounting']['selected_record_count']==state['gene_count']
        item=_rows(result,'Numeric summary')[0]
        assert sum(item[key] for key in ['finite_count','nonfinite_count','invalid_count','null_count'])==state['gene_count']
        state['checks'].append('summary_preserves_explicit_selection')

    def histogram():
        result=selection('histogram',True)
        assert sum(row['count'] for row in _rows(result,'Histogram'))==state['finite_count']
        assert result['large_table_accounting']['histogram_record_count']==state['finite_count']
        assert len(window.figure.axes)>=1
        state['checks'].append('exact_full_finite_histogram')

    def reopen():
        state['reopen_result']=deepcopy(window.session.result)
        path=window.session.save();window.open_path(path)

    def reopened():
        assert window.session.is_large_table
        assert window.session.result==state.pop('reopen_result')
        assert window.session.dataset.cache_identity()==state['cache_identity']
        state['checks'].append('project_reopened_through_native_window')

    steps=[lambda:window.open_path(opening),loaded,
        lambda:window.send(commands[0]),lambda:window.send(commands[1]),profile,
        lambda:window.send(commands[2]),count_groups,
        lambda:window.send(commands[3]),found,
        lambda:window.send(commands[4]),summary,
        lambda:window.send(commands[5]),lambda:selection('summary',True),
        lambda:window.send(commands[6]),histogram,reopen,reopened,
        lambda:window.send(commands[7]),histogram,lambda:window.send(commands[8])]

    def finish():
        session=window.session;data=session.dataset
        histogram()
        assert session.is_large_table and not hasattr(data,'df')
        assert window.data_table.model().rowCount()<=200
        assert window.last_export and Path(window.last_export['figure']).is_file()
        assert not window.last_export['raw_source_included']
        assert not (Path(window.last_export['folder'])/'source').exists()
        files=_check_manifest(window.last_export)
        assert sha256(data.source_path)==state['source_sha256']
        if source is not None:assert sha256(source)==state['synthetic_source_sha256']
        assert data.cache_identity()==state['cache_identity']
        session._assert_integrity(full=True)
        head,events=verify_audit(session.project_dir/'history.jsonl',session.last_hash)
        screenshot=target/'desktop.png';assert window.grab().save(str(screenshot))
        report={'status':'passed','checks':state['checks']+['compact_export_manifest','source_and_cache_unchanged','audit_verified'],
            'commands':commands,'row_count':state['row_count'],'finite_logFC_count':state['finite_count'],
            'exact_gene_selected_count':state['gene_count'],'preview_record_count':window.data_table.model().rowCount(),
            'source_sha256':state['source_sha256'],'source_unchanged':True,'cache_identity':state['cache_identity'],
            'project':str(session.project_dir),'export':window.last_export,'verified_export_files':files,
            'audit_head':head,'audit_events':events,'screenshot':str(screenshot),'environment':versions(),
            'provenance':'Explicitly supplied saved project opened without reingestion.' if project_path is not None else 'CSV >=33MiB fabricated solely for native software verification; no biological observations.',
            'live_model_used':False,'limits':'Desktop workflow and exact bookkeeping only; scientific inference and physiological/biological validation are not tested.'}
        (target/'result.json').write_text(json.dumps(report,indent=2,allow_nan=False),encoding='utf-8')
        timer.stop();window.config=original_config;app.quit()

    def tick():
        try:
            if time.monotonic()>state['deadline']:raise AssertionError('Large-table desktop workflow timed out after 240 seconds.')
            if window.busy or window._after_work:state['idle']=0;return
            state['idle']+=1
            if state['idle']<3:return
            state['idle']=0
            if state['index']<len(steps):
                step=steps[state['index']];state['index']+=1;step();return
            finish()
        except Exception as error:
            timer.stop();window.config=original_config
            (target/'result.json').write_text(json.dumps({'status':'failed','step':state['index'],
                'checks':state['checks'],'commands':commands,'error':str(error),
                'traceback':traceback.format_exc()},indent=2),encoding='utf-8')
            app.exit(1)
    timer.timeout.connect(tick);timer.start(50)
