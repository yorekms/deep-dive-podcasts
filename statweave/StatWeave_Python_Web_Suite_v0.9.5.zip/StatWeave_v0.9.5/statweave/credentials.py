"""API credentials stay in memory, the environment, or one OS wallet entry.

No file storage, credential enumeration, network requests, or wallet access occur
on import or construction. Wallet operations require an explicit UI action or a
previously saved selection to use that wallet for a user-initiated API request.
"""
from __future__ import annotations

import os
import threading

_FOLDER = 'StatWeave'
_ENTRY = 'OpenAI_API_KEY'
_ENV = 'OPENAI_API_KEY'
_APP = 'StatWeave'


class CredentialError(ValueError):
    pass


def validate_key(value):
    if not isinstance(value, str):
        raise CredentialError('Enter an API key in the masked key field.')
    value = value.strip()
    if not 12 <= len(value) <= 512 or not value.isascii() or any(char.isspace() or ord(char) < 33 for char in value):
        raise CredentialError('The API key must be a single valid key with no spaces or line breaks.')
    return value


class KWallet:
    """Access only StatWeave/OpenAI_API_KEY; never inspect other applications."""
    def __init__(self, window_id=0):
        self.window_id = int(window_id)

    def _open(self):
        try:
            from PySide6.QtCore import QMetaObject, Q_ARG, Q_RETURN_ARG, Qt
            from PySide6.QtDBus import QDBusConnection, QDBusInterface
            interface = QDBusInterface('org.kde.kwalletd6', '/modules/kwalletd6',
                                      'org.kde.KWallet', QDBusConnection.sessionBus())
            if not interface.isValid():
                interface = QDBusInterface('org.kde.kwalletd5', '/modules/kwalletd5',
                                          'org.kde.KWallet', QDBusConnection.sessionBus())
            if not interface.isValid():
                raise CredentialError('The system wallet is unavailable. Use a session key or OPENAI_API_KEY instead.')
            interface.setTimeout(30000)
            wallet = QMetaObject.invokeMethod(interface, 'networkWallet', Qt.ConnectionType.DirectConnection,
                                              Q_RETURN_ARG(str))
            if not wallet:
                raise CredentialError('No system wallet is configured. Use a session key instead.')
            handle = QMetaObject.invokeMethod(interface, 'open', Qt.ConnectionType.DirectConnection,
                Q_RETURN_ARG(int), Q_ARG(str, wallet), Q_ARG('qlonglong', self.window_id), Q_ARG(str, _APP))
            if handle < 0:
                raise CredentialError('The system wallet was not unlocked. Your key can be kept for this session instead.')
            return interface, handle
        except CredentialError:
            raise
        except Exception:
            raise CredentialError('The system wallet could not be opened. Use a session key instead.') from None

    def _call(self, interface, method, *args):
        from PySide6.QtDBus import QDBusMessage
        reply = interface.call(method, *args)
        if reply.type() == QDBusMessage.MessageType.ErrorMessage or not reply.arguments():
            raise CredentialError('The system wallet could not complete that action. No plaintext key file was written.')
        return reply.arguments()[0]

    def read(self):
        interface, handle = self._open()
        try:
            if not self._call(interface, 'hasEntry', handle, _FOLDER, _ENTRY, _APP):
                raise CredentialError('No StatWeave API key is saved in the system wallet. Enter a key in Conversation settings.')
            value = self._call(interface, 'readPassword', handle, _FOLDER, _ENTRY, _APP)
            return validate_key(value)
        finally:
            # Do not force-lock the user's wallet or interrupt other applications.
            self._call(interface, 'close', handle, False, _APP)

    def write(self, key):
        key = validate_key(key)
        interface, handle = self._open()
        try:
            if not self._call(interface, 'hasFolder', handle, _FOLDER, _APP):
                if not self._call(interface, 'createFolder', handle, _FOLDER, _APP):
                    raise CredentialError('StatWeave could not create its system wallet folder.')
            if self._call(interface, 'writePassword', handle, _FOLDER, _ENTRY, key, _APP) != 0:
                raise CredentialError('The system wallet did not save the key. No plaintext key file was written.')
        finally:
            self._call(interface, 'close', handle, False, _APP)


class Credentials:
    def __init__(self, *, use_system_wallet=False, wallet=None, environment=None):
        self._key = None
        self._lock = threading.Lock()
        self.use_system_wallet = bool(use_system_wallet)
        self.wallet = wallet if wallet is not None else KWallet()
        self.environment = os.environ if environment is None else environment
        self.revision = 0

    def __repr__(self):
        return '<StatWeave Credentials: secret values hidden>'

    def source(self):
        """A status label only: never open a wallet or return a credential."""
        with self._lock:
            if self._key: return 'session'
        if self.environment.get(_ENV): return 'environment'
        return 'system wallet' if self.use_system_wallet else None

    def set_session(self, value):
        key = validate_key(value) if value else None
        with self._lock:
            self._key = key
            self.revision += 1

    def resolve(self):
        with self._lock:
            key = self._key
        if key: return key
        key = self.environment.get(_ENV)
        if key: return validate_key(key)
        if self.use_system_wallet:
            key = self.wallet.read()
            self.set_session(key)
            return key
        raise CredentialError('Open Conversation settings and enter an OpenAI API key in the masked field. No request was sent.')

    def save(self, key, *, remember=False):
        value = validate_key(key)
        if remember:
            self.wallet.write(value)
        self.set_session(value)
        self.use_system_wallet = bool(remember)
