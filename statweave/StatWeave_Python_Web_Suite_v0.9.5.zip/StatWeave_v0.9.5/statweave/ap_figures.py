"""Reviewed action-potential events over the preserved raw recording.

This layer draws stored decisions and measurements. It does not detect or
remeasure events, conceal excluded raw data, or change a rate denominator.
"""
from __future__ import annotations

from copy import deepcopy
from bisect import bisect_left
from pathlib import Path
from weakref import WeakKeyDictionary
import json
import math
import re
import matplotlib as mpl
from matplotlib.figure import Figure
from matplotlib.backends.backend_agg import FigureCanvasAgg
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
from matplotlib.ticker import MaxNLocator

from .figures import RC,PALETTES,_style,_safe_label,_assert_not_clipped,_serialized_render
from .trace_figures import _selection_rows,_display_trace,_channel,_sweep
from .spike_figures import _finite,_integer,_voltage_factor,_sweep_encoding,_rate_path

MAX_REVIEW_MARKERS=200_000
MAX_EVENT_LABELS=8
MAX_RATE_BINS=100_000
_CACHE=WeakKeyDictionary()


def _normalize(recording,plan):
    from .action_potentials import validate_ap_plan
    return validate_ap_plan(recording,deepcopy(plan))


def _signature(plan):
    # These are presentation fields. All measurement settings, masks and review
    # decisions remain part of the scientific signature, including future fields.
    scientific={k:v for k,v in plan.items() if k not in ('style','time_reference','action','method','plot','event_id')}
    return json.dumps(scientific,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)


def _mask_rows(result,selections):
    account=result.get('ap_accounting',{})
    if not isinstance(account,dict):raise ValueError('The AP accounting record is invalid.')
    rows=account.get('effective_excluded_regions',[])
    if not isinstance(rows,list):raise ValueError('The effective excluded-region record is invalid.')
    grouped={key:[] for key in selections}
    for item in rows:
        if not isinstance(item,dict):raise ValueError('An excluded region is invalid.')
        key=(_integer(item.get('channel'),'Excluded-region channel',1),_integer(item.get('sweep'),'Excluded-region sweep',1))
        if key not in selections:raise ValueError('An excluded region lies outside the selected channel or sweep.')
        first=_integer(item.get('first_sample_index'),'Excluded-region first sample')
        stop=_integer(item.get('stop_sample_index'),'Excluded-region stop sample')
        selected=selections[key];rate=selected['sampling_rate_hz']
        if not selected['first_sample_index']<=first<stop<=selected['stop_sample_index']:
            raise ValueError('An effective excluded region lies outside the selected sample window.')
        start=_finite(item.get('start_s'),'Excluded-region start')
        end=_finite(item.get('end_s'),'Excluded-region end')
        if not math.isclose(start,first/rate,rel_tol=1e-9,abs_tol=1e-9) or not math.isclose(end,stop/rate,rel_tol=1e-9,abs_tol=1e-9):
            raise ValueError('Excluded-region times do not match their acquired-sample bounds.')
        grouped[key].append(item)
    for rows in grouped.values():
        rows.sort(key=lambda row:row['first_sample_index'])
        if any(b['first_sample_index']<a['stop_sample_index'] for a,b in zip(rows,rows[1:])):
            raise ValueError('Effective excluded regions overlap; the saved union accounting is inconsistent.')
    return grouped


def _event(recording,row,selections):
    if not isinstance(row,dict):raise ValueError('A reviewed-event row is invalid.')
    channel=_integer(row.get('channel'),'Event channel',1);sweep=_integer(row.get('sweep'),'Event sweep',1)
    key=(channel,sweep)
    if key not in selections:raise ValueError('A reviewed event lies outside the selected channel or sweep.')
    spec=selections[key];rate=spec['sampling_rate_hz']
    peak=_integer(row.get('peak_sample_index'),'Peak sample index')
    if not spec['first_sample_index']<=peak<spec['stop_sample_index']:
        raise ValueError('A reviewed peak lies outside the selected sample window.')
    event_id=row.get('event_id')
    if event_id!=f'ch{channel}-sw{sweep}-p{peak}':
        raise ValueError('A reviewed event ID does not match its channel, sweep and peak sample.')
    if row.get('origin') not in ('automatic','manual'):
        raise ValueError('A reviewed peak must identify its automatic or manual origin.')
    time=_finite(row.get('peak_time_s'),'Peak time')
    if not math.isclose(time,peak/rate,rel_tol=1e-9,abs_tol=1e-9):
        raise ValueError('A reviewed peak time does not match its acquired sample.')
    recording_time=_finite(row.get('recording_peak_time_s'),'Recording-relative peak time')
    if not math.isclose(recording_time,time+spec['recording_sweep_start_s'],rel_tol=1e-9,abs_tol=1e-9):
        raise ValueError('A reviewed peak has an inconsistent recording-relative time.')
    crossing=_integer(row.get('crossing_sample_index'),'Crossing sample index')
    crossing_time=_finite(row.get('crossing_time_s'),'Crossing time')
    if not spec['first_sample_index']<=crossing<=peak or not math.isclose(crossing_time,crossing/rate,rel_tol=1e-9,abs_tol=1e-9):
        raise ValueError('A reviewed crossing does not match its acquired sample.')
    if not math.isclose(_finite(row.get('recording_crossing_time_s'),'Recording-relative crossing time'),crossing_time+spec['recording_sweep_start_s'],rel_tol=1e-9,abs_tol=1e-9):
        raise ValueError('A reviewed crossing has an inconsistent recording-relative time.')
    unit=str(_channel(recording,channel-1).get('unit') or '')
    if row.get('unit')!=unit:raise ValueError('A reviewed peak has different units from its source channel.')
    factor=_voltage_factor(unit);raw=_finite(row.get('peak_value'),'Raw peak amplitude')
    mv=_finite(row.get('peak_mv'),'Peak amplitude in mV')
    if not math.isclose(raw*factor,mv,rel_tol=1e-7,abs_tol=1e-8):
        raise ValueError('A reviewed peak has inconsistent original-unit and mV amplitudes.')
    return key


def _check_measurements(event):
    baseline=event.get('baseline_mv');amplitude=event.get('amplitude_mv')
    if baseline is not None and amplitude is not None:
        baseline=_finite(baseline,'AP baseline');amplitude=_finite(amplitude,'AP amplitude')
        if not math.isclose(event['peak_mv']-baseline,amplitude,rel_tol=1e-7,abs_tol=1e-8):
            raise ValueError('A stored AP amplitude does not equal its peak minus baseline.')
    width=event.get('half_width_ms');left=event.get('half_width_left_time_s');right=event.get('half_width_right_time_s')
    if width is not None:
        width=_finite(width,'AP half-width');left=_finite(left,'Left half-height crossing');right=_finite(right,'Right half-height crossing')
        if width<=0 or not left<=event['peak_time_s']<=right or not math.isclose(width,(right-left)*1000,rel_tol=1e-6,abs_tol=1e-7):
            raise ValueError('A stored AP half-width has inconsistent crossing times.')
    if event.get('isi_ms') is not None and _finite(event['isi_ms'],'Inter-spike interval')<0:
        raise ValueError('A stored inter-spike interval cannot be negative.')


def _validate(recording,result,plan):
    if not isinstance(result,dict) or result.get('method')!='action_potentials':
        raise ValueError('This figure requires a stored action-potential analysis.')
    current=_normalize(recording,plan);stored=_normalize(recording,result.get('plan',{}))
    if _signature(current)!=_signature(stored):
        raise ValueError('AP settings, masks or review decisions changed. Recompute the AP analysis before plotting those choices.')
    digest=result.get('source_sha256')
    if digest not in (None,'','unavailable') and digest!=getattr(recording,'source_hash',None):
        raise ValueError('These reviewed AP measurements belong to a different recording source.')
    selections={(row['channel'],row['sweep']):row for row in _selection_rows(recording,current)}
    masks=_mask_rows(result,selections)
    accepted=result.get('events');candidates=result.get('candidates',[])
    if not isinstance(accepted,list) or not isinstance(candidates,list) or len(accepted)+len(candidates)>MAX_REVIEW_MARKERS:
        raise ValueError('Reviewed events are missing or too numerous for a readable bounded figure. Select a shorter interval; markers are never silently pruned.')
    events={key:[] for key in selections};rejected={key:[] for key in selections};ids=set()
    for row in accepted:
        key=_event(recording,row,selections)
        if row.get('accepted') is False or row['event_id'] in ids:
            raise ValueError('The accepted AP list contains a rejected or duplicate event.')
        if any(mask['first_sample_index']<=row['peak_sample_index']<mask['stop_sample_index'] for mask in masks[key]):
            raise ValueError('An accepted AP peak lies inside an excluded region.')
        _check_measurements(row)
        ids.add(row['event_id']);events[key].append(row)
    candidate_ids=set()
    for row in candidates:
        key=_event(recording,row,selections)
        if row['event_id'] in candidate_ids:raise ValueError('The candidate list contains duplicate event IDs.')
        candidate_ids.add(row['event_id'])
        if row['event_id'] in ids:continue
        if row.get('accepted') is True:
            raise ValueError('An accepted candidate is missing from the reviewed event list.')
        rejected[key].append(row)
    crossing_samples={key:sorted(row['crossing_sample_index'] for row in rows) for key,rows in events.items()}
    tables=result.get('tables',[])
    bins=next((table.get('rows') for table in tables if table.get('title')=='Binned firing rate'),None)
    if not isinstance(bins,list) or len(bins)>MAX_RATE_BINS:
        raise ValueError('The AP rate-bin table is missing or too large for the figure.')
    rates={key:[] for key in selections}
    for row in bins:
        key=(_integer(row.get('channel'),'Rate channel',1),_integer(row.get('sweep'),'Rate sweep',1))
        if key not in selections:raise ValueError('An AP rate bin lies outside the selected channel or sweep.')
        first=_integer(row.get('first_sample_index'),'Rate first sample')
        stop=_integer(row.get('stop_sample_index'),'Rate stop sample')
        selected=selections[key];rate=selected['sampling_rate_hz']
        if not selected['first_sample_index']<=first<stop<=selected['stop_sample_index']:
            raise ValueError('An AP rate bin lies outside the acquired selection.')
        if any(max(first,mask['first_sample_index'])<min(stop,mask['stop_sample_index']) for mask in masks[key]):
            raise ValueError('A stored rate bin spans excluded samples; recompute AP accounting before plotting.')
        start=_finite(row.get('start_s'),'Rate start');end=_finite(row.get('end_s'),'Rate end')
        duration=_finite(row.get('duration_s'),'Rate exposure');count=_integer(row.get('spike_count'),'Rate count')
        value=_finite(row.get('firing_rate_hz'),'Rate value')
        if not math.isclose(start,first/rate,rel_tol=1e-9,abs_tol=1e-9) or not math.isclose(end,stop/rate,rel_tol=1e-9,abs_tol=1e-9):
            raise ValueError('AP rate-bin times do not match their acquired sample edges.')
        if not math.isclose(duration,(stop-first)/rate,rel_tol=1e-7,abs_tol=1e-9) or duration<=0 or not math.isclose(value,count/duration,rel_tol=1e-7,abs_tol=1e-9):
            raise ValueError('A stored AP rate does not equal the reviewed count divided by included sampled exposure.')
        crossings=crossing_samples[key]
        expected_count=bisect_left(crossings,stop)-bisect_left(crossings,first)
        if count!=expected_count:
            raise ValueError('A stored AP rate count does not match its reviewed crossing samples.')
        rates[key].append(row)
    for key,rows in rates.items():
        rows.sort(key=lambda row:row['first_sample_index'])
        if any(b['first_sample_index']<a['stop_sample_index'] for a,b in zip(rows,rows[1:])):
            raise ValueError('Stored AP rate bins overlap.')
        if sum(row['spike_count'] for row in rows)!=len(events[key]):
            raise ValueError('Stored AP rates do not account for all reviewed accepted events.')
        # An entirely excluded selection may legitimately have no rate bins.
        included=sum(row['stop_sample_index']-row['first_sample_index'] for row in rows)
        expected=selections[key]['stop_sample_index']-selections[key]['first_sample_index']-sum(m['stop_sample_index']-m['first_sample_index'] for m in masks[key])
        if included!=expected:
            raise ValueError('Stored AP rates do not account for the selected included exposure.')
    return current,events,rejected,rates,masks,selections


def _cache_key(plan):
    return (_signature(plan),plan.get('time_reference','sweep'))


def _caption(recording,result,plan,display=None):
    accepted=result['events'];candidates=result.get('candidates',[])
    accepted_ids={e['event_id'] for e in accepted};rejected=[e for e in candidates if e['event_id'] not in accepted_ids]
    manual=sum(e.get('origin')=='manual' for e in accepted)
    text=(f'Reviewed AP measurements for {Path(recording.source_path).name}. '
          f'{len(accepted):,} accepted events ({manual:,} manually added); {len(rejected):,} rejected candidates retained for review. '
          'Filled triangles show accepted automatically located peaks, including manually restored candidates; open circles show manually added peaks; crosses show rejected candidates. '
          'All marker amplitudes and times are original sampled peak coordinates. Manual acceptance can include peaks below the automatic threshold. ')
    threshold=plan['detector']['threshold_mv'];refractory=plan['detector']['refractory_ms']
    text+=f'The automatic detector uses completed upward excursions across {threshold:g} mV and a {refractory:g} ms refractory setting. '
    text+='The horizontal dashed line marks that automatic threshold in the original channel unit; review decisions are not re-detected during plotting. '
    text+='Automatic excursions without a completed below-threshold return at a selection, exclusion, or acquisition boundary are omitted; manual decisions remain logged. '
    measurements=plan.get('measurements',{})
    text+=('Amplitude is sampled peak voltage minus the local median baseline estimate. '
           'The baseline window precedes the sampled peak for every event, regardless of automatic or manual origin; it is a local pre-peak estimate, not resting membrane potential. '
           f'Baseline settings: {measurements.get("baseline_window_ms",2):g} ms window and '
           f'{measurements.get("baseline_gap_ms",.5):g} ms gap; crossing-search settings: '
           f'{measurements.get("search_before_ms",5):g} ms before and {measurements.get("search_after_ms",10):g} ms after the peak, bounded by its included segment and neighboring candidate-peak midpoints. '
           'Half-width uses stored linearly interpolated half-amplitude crossing times; interpolation applies to the derived crossing times, not to the raw waveform. '
           'ISI is peak-to-peak within the same included segment; it does not bridge excluded intervals or sweeps. '
           'Unavailable measurements and quality flags remain in the Results/export tables; events are not hidden because a measurement is unavailable. ')
    regions=result.get('ap_accounting',{}).get('effective_excluded_regions',[])
    if regions:
        text+='Hatched gray regions are excluded from analysis but remain visible in the unaltered raw voltage backdrop. '
        text+='Exclusion scope (within-sweep source time): '+ '; '.join(
            f'ch{region["channel"]}/sweep{region["sweep"]}: {region["start_s"]:g}–{region["end_s"]:g} s' for region in regions)+'. '
        text+='In overlays, shading locates a region in time; it applies only to the listed channel/sweep scopes. '
        reasons=[]
        for region in regions:
            reason=region.get('reasons',region.get('reason',[]))
            reasons.extend([reason] if isinstance(reason,str) else [str(r) for r in reason])
        if reasons:text+='Recorded exclusion reasons: '+ '; '.join(dict.fromkeys(reasons))+'. '
    text+=(f'Rate bins were requested at {plan.get("bin_width_s",.1):g} s and count the reviewed accepted crossings '
           '(manual crossing times equal the chosen manual peak times). Each bin is divided by its actual included sampled duration; '
           'excluded time and acquisition gaps are not denominator exposure. No rate line connects across an exclusion or sweep. '
           'No smoothing or inferential interval is applied. ')
    selected=_selection_rows(recording,plan)
    bins=next(table['rows'] for table in result['tables'] if table['title']=='Binned firing rate')
    detail=[]
    for selection in selected:
        channel=selection['channel'];sweep=selection['sweep'];rate=selection['sampling_rate_hz']
        exposure=sum(row['duration_s'] for row in bins if row['channel']==channel and row['sweep']==sweep)
        detail.append(f'ch{channel}/sweep{sweep}: acquired sample edges {selection["first_sample_index"]/rate:g}–{selection["stop_sample_index"]/rate:g} s at {rate:g} samples/s; included exposure {exposure:g} s')
    text+='Actual selection and exposure: '+ '; '.join(detail)+'. '
    if display:
        total=sum(d['source_sample_count'] for d in display['traces'])
        text+=f'The raw backdrop includes {total:,} selected channel-samples, including excluded regions. '
        reduced=[d for d in display['traces'] if d.get('reduced')]
        text+='Long raw traces use a display-only min/max envelope; measurements and rates use full-resolution included samples. ' if reduced else 'The raw backdrop is shown at full sample resolution. '
        if display.get('ids_labeled'):
            text+='Stable event IDs are labeled where readable and are also available in Results/CSV. '
        else:text+='Stable event IDs are available in Results/CSV and conversational review; dense-view labels are omitted to prevent collisions. '
        if display.get('measurement_segments'):
            text+='Short baseline and half-height width segments are measurement annotations, not uncertainty intervals. '
    else:text+='Long raw backdrops may be display-reduced independently of full-resolution measurement and review. Stable event IDs and measurements are available in Results/CSV. '
    text+='No filtering, baseline subtraction, raw-sample deletion, or biological independence assumption is applied by this renderer. Review choices, masks and unavailable measurements remain part of the analysis record.'
    return text


def ap_caption(recording,result,plan,style=None):
    normalized,*_=_validate(recording,result,plan);_style(normalized,style)
    try:display=_CACHE.get(recording,{}).get(_cache_key(normalized))
    except TypeError:display=None
    return _caption(recording,result,normalized,display)


@_serialized_render
def make_ap_figure(recording,result,plan,style=None):
    plan,events,rejected,rates,masks,selections=_validate(recording,result,plan)
    settings=_style(plan,style);channels=plan['channels']
    minimum_height=65 if len(channels)==1 else 15+42*len(channels)
    if settings['height_mm']<minimum_height:
        raise ValueError(f'{len(channels)} channels need at least {minimum_height:g} mm figure height for readable AP and rate panels.')
    colors=PALETTES[settings['palette']]
    with mpl.rc_context(dict(RC,**{'font.size':settings['font_size']})):
        fig=Figure(figsize=(settings['width_mm']/25.4,settings['height_mm']/25.4),dpi=150,layout='constrained')
        fig.get_layout_engine().set(w_pad=.10,h_pad=.10,hspace=.10)
        grid=fig.add_gridspec(2*len(channels),1,height_ratios=[2,1]*len(channels))
        first_axis=None;axes=[];traces=[];handles=[];labels=[];annotations=[]
        total_markers=sum(len(rows) for rows in events.values())+sum(len(rows) for rows in rejected.values())
        label_ids=total_markers<=MAX_EVENT_LABELS
        measurement_segments=0;auto_count=manual_count=rejected_count=0
        window_lengths=[s['end_s']-s['start_s'] for s in selections.values()]
        show_measurements=len(result['events'])<=8 and max(window_lengths)<=.1
        for position,channel in enumerate(channels):
            voltage=fig.add_subplot(grid[2*position,0],sharex=first_axis)
            if first_axis is None:first_axis=voltage
            rate_axis=fig.add_subplot(grid[2*position+1,0],sharex=first_axis)
            axes.extend((voltage,rate_axis));ch=_channel(recording,channel);unit=str(ch['unit']);factor=_voltage_factor(unit)
            for order,sweep in enumerate(plan['sweeps']):
                key=(channel+1,sweep+1)
                offset=float(_sweep(recording,sweep)['start_s']) if plan['time_reference']=='recording' else 0.
                color,line=_sweep_encoding(order,colors)
                x,y,account=_display_trace(recording,channel,sweep,plan['start_s'],plan['end_s'])
                artist,=voltage.plot(x+offset,y,color=color,linestyle=line,lw=.65,alpha=.9,zorder=2)
                account.update(channel=channel+1,sweep=sweep+1);traces.append(account)
                if position==0:handles.append(artist);labels.append(f'Sweep {sweep+1}')
                for region in masks[key]:
                    for axis in (voltage,rate_axis):
                        axis.axvspan(region['start_s']+offset,region['end_s']+offset,
                            facecolor='#D8D8D4',edgecolor='#9A9E97',alpha=.28,hatch='///',lw=.3,zorder=0)
                automatic=[e for e in events[key] if e['origin']=='automatic']
                manual=[e for e in events[key] if e['origin']=='manual']
                def markers(rows,marker,face,edge,size):
                    return voltage.scatter([e['peak_time_s']+offset for e in rows],[e['peak_value'] for e in rows],
                        marker=marker,s=size,facecolors=face,edgecolors=edge,lw=.7,zorder=5)
                markers(automatic,'^','#111111','white',16)
                markers(manual,'o','none',colors[0],23)
                # The x marker has no filled face, and remains distinct in grayscale.
                voltage.scatter([e['peak_time_s']+offset for e in rejected[key]],[e['peak_value'] for e in rejected[key]],
                    marker='x',s=23,color='#555B55',lw=.8,zorder=6)
                auto_count+=len(automatic);manual_count+=len(manual);rejected_count+=len(rejected[key])
                if label_ids:
                    for event in events[key]+rejected[key]:
                        annotations.append(voltage.annotate(event['event_id'],(event['peak_time_s']+offset,event['peak_value']),
                            xytext=(0,6),textcoords='offset points',ha='center',va='bottom',fontsize=8,color='#404740'))
                if show_measurements:
                    for event in events[key]:
                        baseline=event.get('baseline_value');bstart=event.get('baseline_start_s');bend=event.get('baseline_end_s')
                        if all(v is not None for v in (baseline,bstart,bend)):
                            voltage.plot([bstart+offset,bend+offset],[baseline,baseline],color='#777C77',lw=1.0,zorder=4)
                            measurement_segments+=1
                        left=event.get('half_width_left_time_s');right=event.get('half_width_right_time_s');height=event.get('half_height_mv')
                        if all(v is not None for v in (left,right,height)):
                            voltage.plot([left+offset,right+offset],[height/factor,height/factor],color='#111111',lw=1.2,marker='|',markersize=4,zorder=4)
                            measurement_segments+=1
                rx,ry=_rate_path(rates[key],offset)
                rate_axis.plot(rx,ry,color=color,linestyle=line,lw=1.1 if order==0 else .9)
            voltage.axhline(plan['detector']['threshold_mv']/factor,color='#777C77',linestyle='--',lw=.7,zorder=1)
            ylabel=settings.get('ylabel') or str(ch['name'])
            if not re.search(r'[\[(]\s*'+re.escape(unit)+r'\s*[\])]',ylabel):ylabel+=f' ({unit})'
            voltage.set_ylabel(_safe_label(ylabel,25),fontsize=settings['font_size'])
            rate_axis.set_ylabel('Firing rate\n(spikes/s)',fontsize=settings['font_size']);rate_axis.set_ylim(bottom=0)
            rate_axis.yaxis.set_major_locator(MaxNLocator(nbins=3,min_n_ticks=2));voltage.yaxis.set_major_locator(MaxNLocator(nbins=4))
            for axis in (voltage,rate_axis):
                axis.spines['top'].set_visible(False);axis.spines['right'].set_visible(False)
                axis.tick_params(labelsize=max(8,settings['font_size']-.3));axis.xaxis.set_major_locator(MaxNLocator(nbins=6));axis.margins(x=.01,y=.13)
            if label_ids and total_markers:voltage.margins(y=.35)
            if len(channels)>1:voltage.set_title(f'Channel {channel+1} · {ch["name"]}',loc='left',fontsize=settings['font_size'],pad=6)
            voltage.tick_params(labelbottom=False)
            if position<len(channels)-1:rate_axis.tick_params(labelbottom=False)
        title=settings.get('title') or f'{Path(recording.source_path).stem} · reviewed AP events'
        axes[0].set_title(_safe_label(title,75),loc='left',fontsize=settings['font_size']+1.2,fontweight='bold',pad=12)
        xlabel=settings.get('xlabel') or ('Time within sweep (s)' if plan['time_reference']=='sweep' else 'Recording time (s)')
        if '(s)' not in xlabel and 'second' not in xlabel.casefold():xlabel+=' (s)'
        axes[-1].set_xlabel(xlabel,fontsize=settings['font_size'])
        bounds=[(s['first_sample_index']/s['sampling_rate_hz']+(s['recording_sweep_start_s'] if plan['time_reference']=='recording' else 0),
                 s['stop_sample_index']/s['sampling_rate_hz']+(s['recording_sweep_start_s'] if plan['time_reference']=='recording' else 0)) for s in selections.values()]
        axes[-1].set_xlim(min(b[0] for b in bounds),max(b[1] for b in bounds))
        if len(plan['sweeps'])==1:
            handles=[Line2D([0],[0],color=colors[0],lw=.8)];labels=['Raw voltage / reviewed rate']
        if auto_count:handles.append(Line2D([0],[0],marker='^',linestyle='none',color='#111111',markersize=4));labels.append('Accepted automatic')
        if manual_count:handles.append(Line2D([0],[0],marker='o',markerfacecolor='none',markeredgecolor=colors[0],linestyle='none',markersize=4));labels.append('Accepted manual')
        if rejected_count:handles.append(Line2D([0],[0],marker='x',linestyle='none',color='#555B55',markersize=4));labels.append('Rejected candidate')
        if any(masks.values()):handles.append(Patch(facecolor='#D8D8D4',edgecolor='#9A9E97',alpha=.28,hatch='///'));labels.append('Analysis-excluded region')
        handles.append(Line2D([0],[0],color='#777C77',linestyle='--',lw=.7));labels.append(f'Automatic threshold {plan["detector"]["threshold_mv"]:g} mV')
        legend_columns=2 if len(handles)>=4 or sum(len(lbl) for lbl in labels)>65 else min(3,len(handles))
        fig.legend(handles,labels,frameon=False,loc='outside lower center',fontsize=max(8,settings['font_size']-.7),ncol=legend_columns)
        FigureCanvasAgg(fig).draw()
        if annotations:
            renderer=fig.canvas.get_renderer();boxes=[a.get_window_extent(renderer) for a in annotations]
            # Keep IDs inside the data panel so they cannot collide with a title,
            # axis label or legend. A crowded view leaves stable IDs in the table.
            bad=any(box.x0<a.axes.bbox.x0 or box.y0<a.axes.bbox.y0 or box.x1>a.axes.bbox.x1 or box.y1>a.axes.bbox.y1 for a,box in zip(annotations,boxes))
            bad=bad or any(a.overlaps(b) for i,a in enumerate(boxes) for b in boxes[i+1:])
            if bad:
                for annotation in annotations:annotation.remove()
                label_ids=False;fig.canvas.draw()
        display={'traces':traces,'ids_labeled':bool(label_ids and annotations),'measurement_segments':measurement_segments,
            'accepted_automatic_markers':auto_count,'accepted_manual_markers':manual_count,'rejected_markers':rejected_count,
            'excluded_regions':sum(len(rows) for rows in masks.values()),'raw_excluded_samples_remain_visible':True}
        fig._statweave_trace_display=traces;fig._statweave_ap_display=display;fig._statweave_style=settings
        fig._statweave_caption=_caption(recording,result,plan,display)
        try:
            cached=_CACHE.setdefault(recording,{})
            if len(cached)>12:cached.clear()
            cached[_cache_key(plan)]=deepcopy(display)
        except TypeError:pass
        _assert_not_clipped(fig)
        return fig
