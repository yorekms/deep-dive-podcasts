"""Bounded packaged API-to-local-engine check with simulated Responses only."""
from __future__ import annotations

from copy import deepcopy
import json
from pathlib import Path
import time
import zipfile

from .api_provider import OpenAIPlanner
from .api_tools import ApiToolbox
from .session import Session, sha256, verify_audit


def run(workspace):
    started = time.monotonic()
    root = Path(workspace).resolve() / 'api-self-test'
    root.mkdir(parents=True, exist_ok=True)
    source = root / 'synthetic-observations.csv'
    source.write_text('Subject,Group,Score\n1,Reference,3\n2,Reference,5\n3,Variant,7\n4,Variant,9\n')
    original = sha256(source)
    session = Session(root)
    session.import_file(source)
    session.style['dpi'] = 100
    calls = []
    secret = 'synthetic-only-transport-key'

    def require(value, message):
        if not value:
            raise ValueError(message)

    def response(text=None, tool=None, arguments=None):
        output = ([{'type': 'function_call', 'call_id': 'fixture-call', 'name': tool,
                    'arguments': json.dumps(arguments)}] if tool else
                  [{'type': 'message', 'role': 'assistant', 'content': [{'type': 'output_text', 'text': text}]}])
        return {'status': 'completed', 'output': output,
                'usage': {'input_tokens': 11, 'output_tokens': 5, 'total_tokens': 16}}

    def planner(envelopes):
        queue = list(envelopes)
        model = OpenAIPlanner(api_key=secret)

        def simulated(payload, credential, deadline):
            # This override has no network path and never resolves a real key.
            require(credential == secret, 'The synthetic transport credential changed.')
            require(payload['store'] is False, 'Response storage was enabled.')
            require(payload['model'] == 'gpt-6-luna', 'The default API model changed.')
            encoded = json.dumps(payload)
            require(secret not in encoded and str(source) not in encoded,
                    'A credential or source path entered the conversation body.')
            calls.append({'stored': payload['store'], 'tool_response': any(i.get('type') == 'function_call_output' for i in payload['input'])})
            require(bool(queue), 'The synthetic response sequence was exhausted.')
            return queue.pop(0)

        model._request = simulated
        return model

    box = ApiToolbox(session, '')
    schema = next(t['parameters'] for t in box.definitions if t['name'] == 'propose_analysis')
    args = {key: None for key in schema['properties']}
    args.update(method='describe', columns=['Score'], plot='box')
    style_schema = next(s for s in schema['properties']['style']['anyOf'] if s.get('type') == 'object')
    args['style'] = {key: None for key in style_schema['properties']}
    args['style'].update(palette='blue', title='Synthetic scores')
    reply = session.command('Summarize the scores with a blue box figure.', model=planner([
        response(tool='propose_analysis', arguments=args), response(text='Here is the proposed summary and figure.')]))
    require(session.result is None and session.context.get('api_proposal'), 'A proposal was not staged before execution.')
    pending = deepcopy(session.context['api_proposal'])
    session.command('Why does that presentation fit?', model=planner([response(text='A box figure displays the recorded score distribution.')]))
    require(session.context['api_proposal'] == pending, 'Discussion lost the displayed proposal.')
    reply = session.command('Yes, please proceed.', model=planner([
        response(tool='request_execution', arguments={'proposal_id': pending['proposal_id']}),
        response(text='The application can now validate your direct agreement.')]))
    require(session.result and session.result['method'] == 'describe', 'The agreed local analysis did not run: ' + reply['message'])
    require(session.plan['plot'] == 'box' and session.style['palette'] == 'blue', 'The agreed figure settings were lost.')
    exported = session.export_bundle()
    folder = Path(exported['folder'])
    require(all((folder / ('figure.' + suffix)).stat().st_size > 0 for suffix in ('pdf', 'svg', 'png')), 'Publication figure formats were not exported.')
    with zipfile.ZipFile(exported['archive']) as archive:
        require(archive.testzip() is None, 'The exported archive failed integrity verification.')
    require(sha256(source) == original == sha256(session.dataset.source_path), 'Synthetic source bytes changed.')
    verify_audit(session.project_dir / 'history.jsonl', session.last_hash)
    require(secret not in (session.project_dir / 'project.json').read_text()
            and secret not in (session.project_dir / 'history.jsonl').read_text(), 'A credential entered project persistence.')
    report = {'status': 'passed', 'scope': 'Synthetic CSV, actual API provider/tool/session code, simulated transport only. No real key, wallet, network or paid request.',
              'checks': ['strict_nullable_tool_arguments', 'store_false', 'source_path_and_credential_withheld',
                         'proposal_before_execution', 'discussion_preserves_proposal', 'direct_agreement_executes_local_analysis',
                         'agreed_figure_settings', 'pdf_svg_png_export', 'export_archive_integrity',
                         'original_source_preserved', 'audit_chain_verified', 'credential_absent_from_project_and_audit',
                         'function_call_outputs_replayed'],
              'simulated_requests': len(calls), 'seconds': time.monotonic() - started}
    require(any(c['tool_response'] for c in calls), 'Function outputs were not replayed.')
    (root / 'result.json').write_text(json.dumps(report, indent=2))
    return report
