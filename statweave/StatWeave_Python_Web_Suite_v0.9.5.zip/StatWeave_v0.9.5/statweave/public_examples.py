"""Explicit public-example retrieval through the pinned, checksum-verified fetcher."""
from pathlib import Path
import runpy
import sys


def _resource_root():
    return Path(getattr(sys,'_MEIPASS',Path(__file__).resolve().parents[1]))


def example_catalog():
    root=_resource_root()
    manifest=root/'examples/abf/SOURCES.json'
    script=root/('tools/fetch_abf_examples.py' if getattr(sys,'frozen',False) else 'scripts/fetch_abf_examples.py')
    fetcher=runpy.run_path(str(script))
    return fetcher,fetcher['entries'](manifest)


def fetch_public_example(filename,workspace):
    """Called only after an explicit menu action; never at application startup."""
    fetcher,items=example_catalog()
    found=[item for item in items if item['filename']==filename]
    if len(found)!=1:raise ValueError('That public example is not registered.')
    destination=Path(workspace).resolve()/'examples/abf'
    outcome=fetcher['fetch_one'](found[0],destination)
    return {'path':str(destination/filename),'source':found[0],**outcome}
