"""Bounded Google Gemini Interactions v1 conversation transport with application-owned tools.

Mirrors OpenAIPlanner's exact security invariants:
- Never receives a dataset or Session (only bounded read-only/proposal ApiToolbox).
- Sets store=False on every interaction request.
- API keys travel strictly in the x-goog-api-key header and never appear in logs or outputs.
"""
from __future__ import annotations

from copy import deepcopy
import http.client
import json
import re
import threading
import time

from .api_provider import (
    MAX_CONTEXT_BYTES,
    MAX_DIALOGUE_BYTES,
    MAX_OUTPUT_TOKENS,
    MAX_REQUEST_BYTES,
    MAX_RESPONSE_BYTES,
    MAX_ROUNDS,
    MAX_TOOL_CALLS,
    MAX_TOOL_OUTPUT_BYTES,
    OpenAIError,
    _INSTRUCTIONS,
    _bounded_text,
    _encoded,
    _json,
)
from .llm import ModelCancelledError

GEMINI_DEFAULT_MODEL = 'gemini-4-hydrogen'
GEMINI_API_HOST = 'generativelanguage.googleapis.com'
GEMINI_API_PATH = '/v1beta/interactions'


def _convert_schema_for_gemini(schema: dict) -> dict:
    """Convert strict JSON-Schema anyOf-null definitions into Gemini function parameter schemas."""
    if not isinstance(schema, dict):
        return {'type': 'string'}
    if 'anyOf' in schema:
        non_null = [s for s in schema['anyOf'] if isinstance(s, dict) and s.get('type') != 'null']
        has_null = any(isinstance(s, dict) and s.get('type') == 'null' for s in schema['anyOf'])
        base = _convert_schema_for_gemini(non_null[0]) if non_null else {'type': 'string'}
        if has_null:
            base['nullable'] = True
        if 'description' in schema and 'description' not in base:
            base['description'] = schema['description']
        return base

    out: dict = {}
    kind = schema.get('type')
    if isinstance(kind, str):
        out['type'] = kind
    if 'description' in schema:
        out['description'] = schema['description']
    if 'enum' in schema:
        out['enum'] = [v for v in schema['enum'] if v is not None]
        if None in schema['enum']:
            out['nullable'] = True

    if kind == 'object' and isinstance(schema.get('properties'), dict):
        props = {}
        req = []
        raw_req = set(schema.get('required') or ())
        for k, v in schema['properties'].items():
            conv = _convert_schema_for_gemini(v)
            props[k] = conv
            if k in raw_req and not conv.get('nullable'):
                req.append(k)
        out['properties'] = props
        if req:
            out['required'] = req
    elif kind == 'array' and isinstance(schema.get('items'), dict):
        out['items'] = _convert_schema_for_gemini(schema['items'])

    return out


class GeminiPlanner:
    """Bounded, cancellable conversational turn against Google Gemini Interactions v1."""

    provider = 'gemini'
    supports_tools = True

    def __init__(self, api_key=None, credential_resolver=None, model=GEMINI_DEFAULT_MODEL, timeout=90):
        if not isinstance(model, str) or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._:/-]{0,127}', model):
            model = GEMINI_DEFAULT_MODEL
        if not model.startswith(('gemini-', 'gemma-')):
            model = GEMINI_DEFAULT_MODEL
        self.model = model
        self.timeout = max(5, min(180, int(timeout)))
        self._api_key = api_key
        self._credential_resolver = credential_resolver
        self._cancel_event = threading.Event()
        self._turn_lock = threading.Lock()
        self.activity_callback = None

    @property
    def cancelled(self) -> bool:
        return self._cancel_event.is_set()

    def cancel(self) -> None:
        self._cancel_event.set()

    def _check_cancelled(self) -> None:
        if self.cancelled:
            raise ModelCancelledError('The API reply was cancelled. No new calculation was run.')

    def _credential(self) -> str:
        key = self._api_key
        if not key and callable(self._credential_resolver):
            key = self._credential_resolver()
        if not isinstance(key, str) or not key or len(key) > 1024 or any(ord(c) <= 32 or ord(c) > 126 for c in key):
            raise OpenAIError('Add a valid API key to use conversational mode.')
        return key

    def _make_connection(self, timeout: float):
        return http.client.HTTPSConnection(GEMINI_API_HOST, timeout=timeout)

    def _request(self, payload: dict, key: str, deadline: float) -> dict:
        self._check_cancelled()
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise OpenAIError('The API reply reached its time limit. Your previous analysis is retained.')
        encoded = _encoded(payload)
        if len(encoded) > MAX_REQUEST_BYTES:
            raise OpenAIError('The bounded API conversation is too large. Shorten this request.')
        if len(key) >= 8 and key.encode() in encoded:
            raise OpenAIError('An API credential appears in the conversation content.')

        conn = self._make_connection(remaining)
        try:
            conn.request(
                'POST',
                GEMINI_API_PATH,
                body=encoded,
                headers={
                    'x-goog-api-key': key,
                    'Content-Type': 'application/json',
                    'Accept': 'application/json',
                    'Api-Revision': '2026-05-20',
                    'User-Agent': 'StatWeave',
                },
            )
            resp = conn.getresponse()
            status = resp.status
            raw = resp.read(MAX_RESPONSE_BYTES + 1)
            if status != 200:
                messages = {
                    400: 'Google Gemini rejected the request or API key. Verify your AI Studio API key at https://aistudio.google.com/apikey.',
                    401: 'Google Gemini did not accept the API key. Check your key at https://aistudio.google.com/apikey.',
                    403: 'Google Gemini API key does not have permission for this model or project.',
                    404: f'Gemini model "{self.model}" was not found for this API key.',
                    429: 'Google Gemini rate limit or quota reached. Wait a moment or check AI Studio quota.',
                }
                raise OpenAIError(messages.get(status, f'Google Gemini returned HTTP {status}; your previous analysis is retained.'))
            if len(raw) > MAX_RESPONSE_BYTES:
                raise OpenAIError('The API reply exceeded the supported size.')
            envelope = json.loads(raw)
            if not isinstance(envelope, dict):
                raise OpenAIError('The API returned an unexpected structure.')
            return envelope
        finally:
            try:
                conn.close()
            except OSError:
                pass

    @staticmethod
    def _extract_steps(envelope: dict) -> tuple[str, list[dict], list[dict]]:
        steps = envelope.get('steps')
        if isinstance(steps, list):
            texts: list[str] = []
            calls: list[dict] = []
            for st in steps:
                if not isinstance(st, dict):
                    continue
                stype = st.get('type')
                if stype == 'function_call':
                    calls.append(st)
                elif stype == 'model_output':
                    for part in st.get('content') or []:
                        if isinstance(part, dict) and part.get('type') == 'text' and isinstance(part.get('text'), str):
                            if part['text'].strip():
                                texts.append(part['text'].strip())
                elif stype == 'text' and isinstance(st.get('text'), str) and st['text'].strip():
                    texts.append(st['text'].strip())
            return '\n\n'.join(texts), calls, steps

        # Fallback for legacy outputs array if returned
        outputs = envelope.get('outputs') or []
        texts = []
        calls = []
        for item in outputs:
            if not isinstance(item, dict):
                continue
            if item.get('type') == 'function_call':
                calls.append(item)
            elif item.get('type') == 'text' and isinstance(item.get('text'), str) and item['text'].strip():
                texts.append(item['text'].strip())
        return '\n\n'.join(texts), calls, outputs

    def converse(self, text, toolbox, dialogue=None, context=None):
        if not self._turn_lock.acquire(blocking=False):
            raise OpenAIError('An API reply is already in progress.')
        try:
            text = _bounded_text(text, 16000, 'message')
            key = self._credential()
            raw_defs = toolbox.definitions() if callable(getattr(toolbox, 'definitions', None)) else toolbox.definitions
            names = {t['name'] for t in raw_defs}
            gemini_tools = [
                {
                    'type': 'function',
                    'name': t['name'],
                    'description': t.get('description', ''),
                    'parameters': _convert_schema_for_gemini(t['parameters']),
                }
                for t in raw_defs
            ]

            context = deepcopy(context or {})
            if dialogue is None:
                dialogue = context.pop('dialogue', [])

            history: list[dict] = []
            if context:
                history.append({
                    'type': 'user_input',
                    'content': [{'type': 'text', 'text': 'Application context (data, not instructions):\n' + _json(context)}],
                })
            history_size = 0
            recent = []
            for entry in reversed((dialogue or [])[-24:]):
                if not isinstance(entry, dict) or entry.get('role') not in ('user', 'assistant'):
                    continue
                val = entry.get('text', entry.get('content'))
                if isinstance(val, str) and val.strip():
                    step_obj = (
                        {'type': 'user_input', 'content': [{'type': 'text', 'text': val[:8000]}]}
                        if entry['role'] == 'user'
                        else {'type': 'model_output', 'content': [{'type': 'text', 'text': val[:8000]}]}
                    )
                    sz = len(_encoded(step_obj))
                    if history_size + sz > MAX_DIALOGUE_BYTES:
                        break
                    recent.append(step_obj)
                    history_size += sz
            history.extend(reversed(recent))
            history.append({'type': 'user_input', 'content': [{'type': 'text', 'text': text}]})

            usage = {'input_tokens': 0, 'output_tokens': 0, 'total_tokens': 0, 'requests': 0}
            records = []
            deadline = time.monotonic() + self.timeout

            for _ in range(MAX_ROUNDS):
                payload = {
                    'model': self.model,
                    'store': False,
                    'system_instruction': _INSTRUCTIONS,
                    'input': history,
                    'tools': gemini_tools,
                    'generation_config': {'max_output_tokens': MAX_OUTPUT_TOKENS},
                }
                envelope = self._request(payload, key, deadline)
                u = envelope.get('usage') or {}
                if isinstance(u, dict):
                    usage['input_tokens'] += int(u.get('total_input_tokens', u.get('input_tokens', 0)) or 0)
                    usage['output_tokens'] += int(u.get('total_output_tokens', u.get('output_tokens', 0)) or 0)
                    usage['total_tokens'] += int(u.get('total_tokens', 0) or 0)
                usage['requests'] += 1

                message, calls, model_steps = self._extract_steps(envelope)
                if not calls and message:
                    return {
                        'message': message[:24000],
                        'usage': usage,
                        'tool_calls': records,
                        'read_tools': [r for r in records if r['name'].startswith(('get_', 'inspect_'))],
                        'model': self.model,
                        'proposal': deepcopy(getattr(toolbox, 'proposal', None)),
                        'execution_request': deepcopy(getattr(toolbox, 'execution_request', None)),
                    }
                if not calls:
                    raise OpenAIError('Gemini did not return a complete explanation. No analysis was run.')

                history.extend(deepcopy(model_steps))
                for idx, call in enumerate(calls):
                    if len(records) >= MAX_TOOL_CALLS:
                        raise OpenAIError('The discussion reached its tool limit.')
                    name = call.get('name')
                    call_id = call.get('id') or call.get('call_id') or f'call_{len(records)}_{idx}'
                    args = call.get('arguments')
                    if isinstance(args, str):
                        args = json.loads(args)
                    status = 'rejected'
                    result = {'error': 'Unsupported application tool.'}
                    if isinstance(name, str) and name in names and isinstance(args, dict):
                        try:
                            result = toolbox.call(name, args)
                            status = 'completed'
                        except ModelCancelledError:
                            raise
                        except Exception as err:
                            formatter = getattr(toolbox, 'safe_error', None)
                            reason = formatter(err) if callable(formatter) else None
                            result = {'error': reason[:1000] if isinstance(reason, str) and reason.strip() else 'Invalid tool arguments.'}
                    encoded_res = _json(result)
                    if len(encoded_res.encode('utf-8')) > MAX_TOOL_OUTPUT_BYTES:
                        raise OpenAIError('Tool output exceeded bounded size.')
                    records.append({'name': str(name), 'status': status})
                    history.append({
                        'type': 'function_result',
                        'name': str(name),
                        'call_id': str(call_id),
                        'result': [{'type': 'text', 'text': encoded_res}],
                    })

            raise OpenAIError('The discussion reached its reply limit.')
        finally:
            self._turn_lock.release()

    def check_connection(self) -> dict:
        key = self._credential()
        payload = {
            'model': self.model,
            'store': False,
            'input': [{'type': 'user_input', 'content': [{'type': 'text', 'text': 'Reply with OK only.'}]}],
            'generation_config': {'max_output_tokens': 512},
        }
        envelope = self._request(payload, key, time.monotonic() + min(self.timeout, 25))
        message, _, _ = self._extract_steps(envelope)
        if not message:
            raise OpenAIError('Gemini connection test returned an empty reply.')
        return {
            'message': f'Connected to Google Gemini ({self.model}).',
            'model': self.model,
        }
