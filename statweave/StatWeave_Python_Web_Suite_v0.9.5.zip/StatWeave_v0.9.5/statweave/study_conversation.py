"""Grounded study conversation and user-owned agreement for closed adapters.

Language models can suggest the same small proposal schema as the offline
interpreter. Neither a suggestion nor its prose can confirm or run anything.
Only a later, directly supplied user assent to the last displayed preview can
commit that preview. Saved proposals must be presented again after reopening.
"""
from copy import deepcopy
import re
import uuid

from .study_bridge import (_execution, _hash, _compile, _run, result_is_current, status_text)


_AGREEMENT = re.compile(
    r"(?:(?:please\s+)?proceed(?:\s+with\s+(?:that|it|the\s+analysis|the\s+plan))?|ok(?:ay)?|sure|sounds\s+good|looks\s+good|that\s+works|let['’]s\s+(?:do|run)\s+(?:it|that)|"
    r"yes[, ]+let['’]s\s+(?:do|run)\s+(?:it|that)|yes[, ]+(?:please\s+)?go\s+ahead|"
    r"yes(?:\s+please)?|yes[, ]+(?:please\s+)?(?:run|do|export|apply)\s+(?:that|it|the\s+analysis|the\s+plan)|"
    r"(?:please\s+)?(?:go\s+ahead|run\s+(?:that|it|the\s+proposed\s+analysis)|"
    r"export\s+(?:that|it)|apply\s+(?:that|it))|"
    r"that\s+(?:looks|sounds)\s+good[, ]+(?:please\s+)?(?:go\s+ahead|run\s+it))", re.I)
_NEGATION = re.compile(r"\b(?:do\s+not|don['’]?t|not\s+yet|never|cancel|stop|hold\s+off|wait)\b", re.I)
_QUESTION_ONLY = re.compile(r"\b(?:what\s+if|what\s+would|how\s+would|should\s+(?:we|i)|could\s+we|would\s+it)\b", re.I)


def _children(session):
    result=session.result or {}
    if result.get('method')!='study_execution':return []
    return ([m['result'] for m in result.get('measures',[]) if m.get('status')=='executed']
            if result.get('report') else [result])


def statistics_status(session):
    """Answer from saved engine results, without asking a model or calculating."""
    result=session.result or {};children=_children(session)
    if not children:
        return ('No completed numerical analysis is saved in this project yet. We can discuss the scientific question, '
                'choose the experimental unit and trial handling, and review a proposed analysis before I run it.')
    comparisons=[comparison for child in children
                 for comparison in (child.get('comparison',[]) if isinstance(child.get('comparison'),list) else [])
                 if isinstance(comparison,dict) and isinstance(comparison.get('p_two_sided'),(int,float))
                 and not isinstance(comparison.get('p_two_sided'),bool) and 0<=comparison['p_two_sided']<=1]
    groups=sorted({row['group'] for child in children for row in child.get('plot_data',{}).get('group_rows',[])})
    subjects={binding['subject'] for binding in result.get('recipe',{}).get('source_bindings',[])}
    lines=[f"Yes. This project contains completed descriptive statistics for {len(children)} measure{'s' if len(children)!=1 else ''}, with recorded figures and tables.",
           'The descriptives include counts, means, sample SD, SEM, medians, quartiles and ranges where available.']
    if comparisons:
        lines.append(f"It also contains {len(comparisons)} explicitly requested Welch comparison{'s' if len(comparisons)!=1 else ''} of subject slopes, including p-values and confidence intervals.")
    else:
        lines.append('We have not run a group hypothesis test: there are no group-comparison p-values in this report. Descriptive statistics describe the observations; a hypothesis test addresses a specified group contrast.')
    if subjects:lines.append(f"The reviewed design uses {len(subjects)} subjects"+(' in '+', '.join(groups) if groups else '')+'; repeated trials are not extra independent subjects.')
    if not result_is_current(session):lines.append('These are historical results. Your current scientific choices differ, so a revised analysis needs a new review and agreement.')
    else:lines.append('These saved results match the current scientific choices.')
    if not comparisons:
        lines.append('If you want a group comparison, tell me which measure and scientific contrast matter. This pleth adapter can compare per-subject CO₂ slopes when the doses and distinct-subject independence are explicitly established; mixed-effects and Bayesian analyses are not implemented yet.')
    return '\n\n'.join(lines)


def _status_question(text):
    lower=text.casefold()
    return bool((re.search(r'\b(?:did|have|has|were|was)\b',lower) and
                 re.search(r'\b(?:run|ran|done|perform(?:ed)?|calculat(?:e|ed)|comput(?:e|ed)|tested|analy[sz]ed)\b',lower) and
                 re.search(r'\b(?:stats|statistic\w*|analys\w*|test\w*|p[- ]?values?)\b',lower)) or
                re.search(r'\bwhat\s+(?:stats|statistics|analyses|tests)\s+(?:have|did|were|are|do)\b',lower) or
                re.search(r'\b(?:do|have|are|any)\b.*\bp[- ]?values?\b',lower) or
                lower in {'what have we done so far','what did we run','what has been calculated','have we compared the groups'})


def _preview(session,proposal):
    """Compile an unexecuted proposal against a copy of the current choices."""
    from .study_execution import build_recipe,build_report_recipe,OUTCOMES,recipe_digest
    intent=proposal['intent'];state=deepcopy(session.context['study_state'])
    options=deepcopy(_execution(session)['options'])
    if proposal.get('pooling'):state['pooling']=proposal['pooling']
    for key in ('outcome','normalization','normalization_order','inference'):
        if proposal.get(key) is not None:options[key]=proposal[key]
    if 'fit_doses' in proposal and proposal['fit_doses'] is not None:options['fit_doses']=proposal['fit_doses']
    if intent=='report_measures':options.update(method='measure_report',outcome='all_available',inference='none',fit_doses=[])
    elif intent=='response_curve':
        if proposal.get('inference')=='welch_slopes':raise ValueError('A Welch slope comparison requires per-subject CO₂ slopes, not a response-curve-only report.')
        options.update(method='response_curve',inference='none',fit_doses=[])
    elif intent=='co2_slopes':options['method']='co2_slope'
    elif intent!='normalize':raise ValueError('That analysis proposal is not supported.')
    options['pooling']=state.get('pooling','undecided')
    builder=build_report_recipe if options.get('method')=='measure_report' else build_recipe
    recipe=builder(session.dataset,state,options)
    opts=recipe['options']
    label=('all available source measures, retaining unavailable measures in the inventory'
           if opts['method']=='measure_report' else OUTCOMES[opts['outcome']]['label']+' ('+OUTCOMES[opts['outcome']]['unit']+')')
    bindings=recipe.get('source_bindings',[])
    groups={}
    for row in bindings:groups.setdefault(row['group'],set()).add(row['subject'])
    roster=', '.join(f'{name}: {len(subjects)} subjects' for name,subjects in sorted(groups.items()))
    pooling=('give each trial equal weight within its subject, then summarize subjects'
             if opts['pooling']=='equal_within_subject' else 'retain separate trials; do not count trials as independent subjects')
    normalization={'none':'original source units', 'fold_baseline':'fold of baseline',
                   'percent_baseline':'percent of baseline (baseline = 100%)',
                   'percent_change':'percent change from baseline (baseline = 0%)'}[opts['normalization']]
    windows=opts['windows'];omitted=sum(w['phase']=='omit' for w in windows)
    lines=[f"Here is the analysis I propose for {label}:",
           f"• Use the reviewed subject/session/group mapping ({roster}).",
           f"• {pooling[0].upper()+pooling[1:]}.",
           f"• Show {normalization}; normalization order: {opts['normalization_order'].replace('_',' ')}.",
           f"• Retain the reviewed protocol windows: {len(windows)-omitted} admitted, {omitted} explicitly omitted with their recorded reasons. Baseline and recovery remain distinct."]
    if opts['method']=='co2_slope':lines.append('• Fit each subject’s CO₂ response slope over '+', '.join(f'{x:g}%' for x in opts['fit_doses'])+'; exclude recovery from slope fitting.')
    else:lines.append('• Produce response figures and descriptive tables, retaining the underlying subject values.')
    if opts['inference']=='welch_slopes':lines.append('• Run the requested two-sided Welch comparison of subject slopes using your explicit independent-subject declaration. With small groups, uncertainty and power are limited.')
    else:lines.append('• Calculate descriptives only; no group hypothesis test or p-value. Figure error bars show sample SD, not a confidence interval.')
    if proposal.get('rationale'):lines+=['',proposal['rationale']]
    lines+=['','Nothing new has been calculated. Would you like me to run this plan? You can say “yes, run that”, or tell me what to change. The complete row-by-row recipe remains available on request.']
    return recipe,options,state,'\n'.join(lines)


def propose_action(session,proposal,origin='user_language'):
    """Stage an app-owned preview. The caller validates model schemas first."""
    intent=proposal['intent'];execution=_execution(session)
    if intent in {'export','style'}:
        if not _children(session):return {'message':'There is no completed result to '+('export' if intent=='export' else 'restyle')+' yet. Let’s first agree on an analysis.','refresh':False}
        recipe=None;options=None;state=None
        if intent=='export':message='I can export the current recorded figures as PDF, SVG and PNG, with tables and the processing record. The originals stay in the project. Shall I export them?'
        else:message='I can apply these figure settings to the saved result: '+', '.join(f'{k} = {v}' for k,v in proposal.get('style',{}).items())+'. Numerical results and raw sources stay unchanged. Shall I apply that?'
    else:
        try:recipe,options,state,message=_preview(session,proposal)
        except ValueError as error:
            execution['conversation_proposal']=None
            session.context['study_clarification']={'proposal':deepcopy(proposal),'reason':str(error),'origin':origin}
            return {'message':'We can develop that analysis, but I need to settle one requirement before presenting a runnable plan:\n\n'+str(error)+'\n\nTell me the missing choice in your own words. I have not changed your current analysis or run anything.','refresh':False}
    token=getattr(session,'_study_conversation_token',None)
    if token is None:token=uuid.uuid4().hex;session._study_conversation_token=token
    pending={'version':1,'proposal':deepcopy(proposal),'recipe':recipe,'options':options,'state':state,
             'base_state_sha256':_hash(session.context['study_state']),
             'base_options_sha256':_hash(execution['options']),'base_result_sha256':_hash(session.result),
             'base_style_sha256':_hash(session.style),'live_session_token':token,
             'preview_message_sha256':_hash(message),'origin':origin}
    if recipe:
        from .study_execution import recipe_digest
        pending['recipe_sha256']=recipe_digest(recipe)
    execution['conversation_proposal']=pending
    session.context.pop('study_clarification',None)
    session._event('study_conversation_proposal',{'proposal':proposal,'origin':origin,
        'recipe_sha256':pending.get('recipe_sha256'),'base_state_sha256':pending['base_state_sha256'],
        'calculations_performed':False})
    return {'message':message,'refresh':False}


def _agree(session,pending):
    from .study_execution import recipe_digest
    execution=_execution(session)
    previous=session.conversation[-2] if len(session.conversation)>=2 else {}
    current=(pending.get('live_session_token')==getattr(session,'_study_conversation_token',None)
             and pending.get('preview_message_sha256')==_hash(previous.get('text'))
             and pending.get('base_state_sha256')==_hash(session.context['study_state'])
             and pending.get('base_options_sha256')==_hash(execution['options'])
             and pending.get('base_result_sha256')==_hash(session.result)
             and pending.get('base_style_sha256')==_hash(session.style))
    if not current:
        return {'message':'I need to show the proposed plan again before using that agreement. Your choices or conversation context have changed, or this project was reopened. Ask me to show the proposed analysis, then approve the displayed plan. No new calculation has run.','refresh':False}
    intent=pending['proposal']['intent']
    if intent=='export':
        execution['conversation_proposal']=None
        session._event('study_conversation_agreement',{'origin':'explicit_user_assent','intent':'export'})
        return {'message':'Exporting the recorded figures, tables and processing record.','refresh':False,
                'export_request':{'action':'study_analysis_export','include_source':False}}
    if intent=='style':
        from .study_figures import make_figure
        style={**session.style,**pending['proposal']['style']}
        if not session.defer_figure_validation:make_figure(session.dataset,session.result,session.plan,style)
        session.style=style;execution['conversation_proposal']=None
        session._event('study_figure_style_changed',{'style':style,'origin':'explicit_user_assent'})
        return {'message':'Updated the figure settings. The numerical result and raw sources are unchanged.','refresh':True}
    session.context['study_state']=deepcopy(pending['state'])
    execution['options']=deepcopy(pending['options']);execution['options'].pop('pooling',None)
    compiled=_compile(session)
    if recipe_digest(compiled)!=pending['recipe_sha256']:raise ValueError('The proposed analysis changed. Let’s review the current plan before running.')
    execution['candidate_recipe']=compiled;execution['approved_digest']=pending['recipe_sha256']
    execution['approved_state_sha256']=_hash(session.context['study_state'])
    execution['conversation_proposal']=None
    session._event('study_execution_recipe_reviewed',{'recipe':compiled,'recipe_sha256':pending['recipe_sha256'],'origin':'displayed_conversation_preview'})
    session._event('study_execution_recipe_confirmed',{'recipe':compiled,'recipe_sha256':pending['recipe_sha256'],'origin':'explicit_user_assent'})
    return {'message':_run(session),'refresh':True}


def _outcome(text):
    from .study_execution import OUTCOMES
    names=[key for key in OUTCOMES if re.search(r'(?<![\w])'+re.escape(key)+r'(?![\w])',text,re.I)]
    aliases={'RR_bpm':r'\b(?:rr|respiratory\s+(?:frequency|rate)|breathing\s+(?:frequency|rate)|respiration\s+rate)\b',
             'VT_syringe_mL':r'\bsyringe(?:[- ]equivalent|[- ]scaled)?\s+tidal\s+(?:excursion|volume)\b',
             'MV_syringe_mL_per_min':r'\bsyringe(?:[- ]equivalent|[- ]scaled)?\s+minute\s+(?:signal|volume|ventilation)\b'}
    names+= [name for name,pattern in aliases.items() if re.search(pattern,text,re.I)]
    return next(iter(set(names))) if len(set(names))==1 else None


def _human_scientific_fact(session,text,is_question=False):
    """Record only directly stated human design facts, never model prose."""
    if is_question or _NEGATION.search(text):return None
    value=re.sub(r'^(?:yes|okay|ok)[, ]+','',text.casefold()).strip()
    kind=None
    if re.fullmatch(r'(?:the |these |our )?(?:(?:different|distinct|individual) )?(?:mice|animals|subjects|participants|patients) are (?:statistically )?independent(?: (?:animals|subjects|observations))?',value):
        kind='independence'
    elif re.fullmatch(r'(?:the |each |every )?(?:mouse|animal|subject|participant|patient) is (?:the |an? )?experimental unit',value):
        kind='experimental_unit'
    elif re.fullmatch(r'(?:please )?(?:average|pool|weight) (?:the )?(?:repeated )?trials equally within (?:each |every |the )?(?:mouse|animal|subject|participant|patient)',value):
        kind='pooling'
    if kind is None:return None
    execution=_execution(session)
    continuation=(session.context.get('study_clarification') or {}).get('proposal')
    if not continuation and execution.get('conversation_proposal'):
        continuation=execution['conversation_proposal']['proposal']
    from .study_bridge import _set,invalidate_approval
    if kind=='independence':
        _set(session,independent_subjects=True)
        message='Recorded your declaration that different subjects are independent. Repeated trials remain nested within their subjects; I have not treated them as extra mice.'
    elif kind=='experimental_unit':
        _set(session,experimental_unit='subject')
        message='Recorded the mouse or subject as the experimental unit. Trials and breathing windows are not additional independent subjects.'
    else:
        from .study_planner import apply_study_command
        updated,_=apply_study_command(session.dataset,session.context['study_state'],{'action':'study_pooling','pooling':'equal_within_subject'})
        session.context['study_state']=updated;invalidate_approval(session)
        message='Recorded equal weighting of trials within each subject. Group summaries will use subjects, not trials, as their units.'
    session._event('study_human_design_declaration',{'kind':kind,'origin':'direct_user_statement',
        'text':text,'calculations_performed':False})
    if continuation:
        reply=propose_action(session,continuation,origin='clarified_user_request')
        reply['message']=message+'\n\n'+reply['message']
        current=_execution(session).get('conversation_proposal')
        if current:current['preview_message_sha256']=_hash(reply['message'])
        return reply
    return {'message':message+' No new analysis has been run for this declaration. Tell me the analysis you want to develop, and I’ll show its choices before running it.','refresh':True}


def handle_natural_conversation(session,text):
    """Fast grounded requests first; unfamiliar language still reaches the LLM."""
    simple=text.strip().rstrip('.!?').strip();lower=simple.casefold();execution=session.context.get('study_execution',{})
    if _status_question(simple):return {'message':statistics_status(session),'refresh':False}
    if lower.startswith(('my goal ', 'goal:', 'study note:', 'metadata note:', 'remember ', 'group subjects ',
                         'resolve source ', 'select method ', 'confirm study ', 'confirm analysis ',
                         'accept proposed ', 'save import profile ', 'apply import profile ')):
        return None
    from .planner import _blocked_request
    if _blocked_request(simple):return None
    pending=execution.get('conversation_proposal')
    if pending and lower in {'run agreed analysis','run approved analysis','run the agreed analysis',
                             'run the approved analysis','run analysis','rerun agreed analysis','confirm execution recipe'}:
        # A previous literal-command approval must not silently run an older
        # recipe behind the newer conversational preview. Re-present it first.
        return propose_action(session,pending['proposal'],pending.get('origin','user_language'))
    if pending and lower in {'review execution recipe','show execution recipe','prepare execution recipe'} and pending.get('recipe'):
        from .study_bridge import recipe_text
        reply=propose_action(session,pending['proposal'],pending.get('origin','user_language'))
        current=_execution(session).get('conversation_proposal')
        if current:
            reply['message']=recipe_text(current['recipe'])+'\n\nThese are proposed choices; they have not been applied or run. Say “yes, run that” to use this exact recipe.'
            current['preview_message_sha256']=_hash(reply['message'])
        return reply
    if _NEGATION.search(simple):
        if pending and (re.search(r'\b(?:run|analysis|plan|that|it)\b',lower) or lower in {'not yet','cancel','stop','wait'}):
            execution['conversation_proposal']=None
            session._event('study_conversation_proposal_cancelled',{'origin':'user_instruction'})
            return {'message':'I have set that proposed run aside. Your saved analysis and raw sources remain intact. We can keep discussing the choices.','refresh':False}
        return None
    declaration=_human_scientific_fact(session,simple,is_question=text.rstrip().endswith('?'))
    if declaration is not None:return declaration
    if _AGREEMENT.fullmatch(simple) and not text.rstrip().endswith('?'):
        if pending:return _agree(session,pending)
        return {'message':'There is no analysis preview awaiting your agreement. Tell me what you want to examine, and I’ll show you the proposed choices before running it.','refresh':False}
    if re.fullmatch(r'(?:can|could) you (?:please )?(?:rerun|repeat|run) (?:the |our |this )?(?:analysis|report|same analysis)(?: again)?',lower) or lower in {'rerun the analysis','rerun this analysis','run it again','repeat the report','run the analysis','please run the analysis','please rerun the analysis','can we run the analysis now',"let's run the analysis",'let’s run the analysis'}:
        return propose_action(session,{'intent':'normalize'})
    if lower in {'show the proposed analysis','show proposed analysis','show the plan again','show the proposed plan','what is the proposed plan','what’s the proposed plan',"what's the proposed plan"}:
        if pending:return propose_action(session,pending['proposal'],pending.get('origin','user_language'))
        clarification=session.context.get('study_clarification')
        if clarification:return propose_action(session,clarification['proposal'],clarification.get('origin','user_language'))
        return propose_action(session,{'intent':'normalize'})
    if lower in {'show all figures','show all plots','show the overview','show all measures again',
                 'show all measures','show all available measures','show all the available measures',
                 'what measures are available','list available measures','list all available measures'}:
        if session.result and session.result.get('report'):
            session.context.pop('study_figure_focus',None)
            session._event('study_figure_view_changed',{'outcome':None,'calculations_performed':False})
            return {'message':'Showing the saved all-measures overview. The complete report and all individual figures remain available in the export; no new calculation was run.','refresh':True}
        from .study_execution import OUTCOMES
        items=', '.join(f"{name} ({info['label']}, {info['unit']})" for name,info in OUTCOMES.items())
        return {'message':'Available plethysmography measures in this adapter: '+items+'. Tell me whether you want an all-measures report or a specific outcome; no calculation has run.','refresh':False}
    outcome=_outcome(simple)
    if outcome and not _QUESTION_ONLY.search(simple) and re.search(r'\b(?:show|display|plot|graph|see)\b',lower) and not re.search(r'\b(?:normaliz\w*|test|compar\w*|slopes?|recalculat\w*|rerun|run|analy[sz]\w*)\b',lower):
        selected=next((child for child in _children(session) if child['plot_data']['endpoint']['column']==outcome),None)
        if selected:
            session.context['study_figure_focus']=outcome
            session._event('study_figure_view_changed',{'outcome':outcome,'calculations_performed':False})
            return {'message':'Showing the saved '+selected['plot_data']['endpoint']['label']+' figure. These are the recorded results; no new calculation or scientific choice was made. '+status_text(session),'refresh':True}
    # Explicit exports are reversible user requests; a model can only propose one.
    if not _QUESTION_ONLY.search(simple) and re.fullmatch(r'(?:can|could) you (?:please )?(?:export|save|give me)(?: (?:all|the|these|my|current|completed|publication.ready))* (?:figures|plots|results|report)(?: (?:please|for me|with tables|and tables|and the tables))?',lower):
        if _children(session):return {'message':'Preparing your recorded figures, tables and processing record.','refresh':False,'export_request':{'action':'study_analysis_export','include_source':False}}
    if re.search(r'\b(?:trials?|breaths?|windows?)\b.*\b(?:independent|separate)\s+(?:mice|animals?|subjects?)\b',lower):
        return {'message':'Repeated trials, breaths and windows are not additional independent subjects. I have not changed the reviewed experimental unit. We can retain trials separately or summarize within each mouse; which scientific comparison do you want?','refresh':False}
    if re.search(r'\b(?:mixed[- ]effects?|mixed models?|bayesian|anova|t[- ]test)\b',lower):
        return {'message':'We can discuss that method and its assumptions. This pleth Summary adapter currently executes descriptive response reports, per-subject CO₂ slopes and an explicitly declared Welch comparison of those slopes. It does not yet execute repeated-measures ANOVA, mixed-effects or Bayesian models. A hierarchical model can represent repeated trials within subjects without treating trials as independent mice. Bayesian work also needs specified priors and a contrast of interest. What outcome and group contrast would you like to address? I will not substitute a different test without your agreement. No calculation was run.','refresh':False}
    # These are proposal recognizers, not implicit execution commands. More
    # varied phrasing is interpreted by the model's closed proposal schema.
    proposal=None
    if re.search(r'\b(?:all|every|each)\s+(?:the\s+)?(?:available\s+)?(?:measures?|metrics?|outcomes?|parameters?)\b',lower) and re.search(r'\b(?:report|plot|figures?|analyse|analyze|analysis|describ|summar|statistics)\w*\b',lower) and lower not in {'report all available measures','report all measures','use all available measures','analyze all available measures'}:
        proposal={'intent':'report_measures'}
    norm=None
    if re.search(r'\b(?:normaliz\w*|baseline)\b',lower):
        if re.search(r'percent(?:age)?\s+change|%\s*change',lower):norm='percent_change'
        elif re.search(r'percent(?:age)?\s+(?:of\s+)?(?:the\s+)?baseline|baseline\s*(?:at|=|is|to)\s*100|%\s*(?:of\s+)?baseline',lower):norm='percent_baseline'
        elif re.search(r'fold(?:\s+(?:of|from))?\s+(?:the\s+)?baseline|fold\s+change',lower):norm='fold_baseline'
        elif re.search(r'normaliz\w*\s+(?:it|them|that|these|the\s+data)?\s*(?:to|by|against)\s+(?:the\s+)?baseline',lower):
            session.context['study_clarification']={'kind':'normalization','proposal':({'intent':'response_curve','outcome':_outcome(simple)} if _outcome(simple) else {'intent':'normalize'})}
            execution['conversation_proposal']=None
            return {'message':'How would you like baseline normalization expressed: percent of baseline (baseline = 100%), percent change from baseline (baseline = 0%), or fold of baseline? The calculation order also matters; I’ll retain the reviewed order unless you change it. No new calculation has run.','refresh':False}
    outcome=_outcome(simple)
    clarification=session.context.get('study_clarification',{})
    if norm and clarification.get('kind')=='normalization':proposal=deepcopy(clarification['proposal'])
    if outcome and re.search(r'\b(?:plot|graph|figure|analy[sz]e|look\s+at|focus\s+on|show\s+me)\b',lower):proposal={'intent':'response_curve','outcome':outcome}
    if norm:
        exact={'normalize as percent of baseline','use percent baseline','normalize to percent baseline',
               'normalize as percent change from baseline','use percent change from baseline',
               'normalize to baseline as fold change','use fold baseline'}
        if lower not in exact:
            proposal=proposal or {'intent':'normalize'};proposal['normalization']=norm
    if re.search(r'\bslopes?\b',lower) and re.search(r'\b(?:co2|co₂|response|frequency|rr_bpm)\b',lower) and lower not in {'use co2 slopes','use a co2 slope','use frequency response slopes'}:
        proposal={'intent':'co2_slopes',**({'outcome':outcome} if outcome else {})}
        doses=re.search(r'\b(?:over|using|at)\s+((?:\d+(?:\.\d+)?\s*%?\s*(?:,|and)?\s*){3,})',lower)
        if doses:proposal['fit_doses']=[float(x) for x in re.findall(r'\d+(?:\.\d+)?',doses[1])]
        if re.search(r'\b(?:compare|difference|welch)\b',lower):proposal['inference']='welch_slopes'
    if proposal:return propose_action(session,proposal)
    if re.search(r'\b(?:compare|difference|different|significan\w*|p[- ]?values?)\b',lower) and re.search(r'\b(?:groups?|mice|subjects?|control|treat\w*)\b',lower):
        return {'message':statistics_status(session)+'\n\nFor a new group test, which measure and contrast do you want to estimate? We can discuss a comparison of per-subject CO₂ slopes, with the fitted doses explicit. I also need your declaration of independence between distinct subjects before that test can run. Repeated trials will stay within their subjects.','refresh':False}
    return None
