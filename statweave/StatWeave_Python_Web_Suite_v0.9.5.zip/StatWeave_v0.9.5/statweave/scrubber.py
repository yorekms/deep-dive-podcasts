"""Archive safety guards, OOXML/filename deidentification, and CSV formula guards."""
from __future__ import annotations

import math
from pathlib import Path, PurePosixPath
import re
import xml.etree.ElementTree as ET
import zipfile

import warnings as _warnings

try:
    with _warnings.catch_warnings():
        _warnings.simplefilter('ignore', DeprecationWarning)
        import defusedxml
        from defusedxml import ElementTree as SafeET
        defusedxml.defuse_stdlib()
except ImportError:  # pragma: no cover - optional fallback in minimal reproduction envs
    SafeET = ET

MAX_ZIP_UNCOMPRESSED_BYTES = 256 * 1024 * 1024
MAX_ZIP_MEMBERS = 10_000

CLAMPFLOW_SHEETS = (
    '1_Master_Wide',
    '2_PerSweep_LONG',
    '3_PerSweep_WIDE',
    '4_Master_LONG',
    '5_ISI_Matrix',
    '6_Phase_Data',
)

_NON_NAME_TOKEN = re.compile(
    r'^(?:\d+|(?:cell|rec|recording|slice|mouse|animal|rat|donor|subj|subject|sweep|ch|channel|trial|day|plate|batch|group|wt|ko|ctrl|control|drug|veh|vehicle)s?\d*)$',
    re.I,
)


def is_clampflow_sheets(sheets: list[str] | tuple[str, ...]) -> bool:
    present = {str(s).strip() for s in (sheets or ())}
    overlap = present.intersection(CLAMPFLOW_SHEETS)
    return len(overlap) >= 2 or '1_Master_Wide' in overlap


def sanitize_source_filename(name_or_path: str | Path) -> dict:
    """Return a clean basename and scrub student identifiers from ClampFlow exports."""
    raw_name = Path(str(name_or_path).replace('\\', '/')).name or 'table.csv'
    raw_name = re.sub(r'[\x00-\x1f\x7f]+', '_', raw_name).strip()
    suffix_match = re.match(r'^(.+?)(_ClampFlow_Compiled)(\.[A-Za-z0-9]+)$', raw_name, re.I)
    scrubbed = False
    if suffix_match:
        prefix, tag, ext = suffix_match.groups()
        parts = [p for p in prefix.split('_') if p]
        if len(parts) >= 2 and not _NON_NAME_TOKEN.match(parts[-1]):
            parts = parts[:-1]
            scrubbed = True
        elif len(parts) == 1 and not _NON_NAME_TOKEN.match(parts[0]) and not any(c.isdigit() for c in parts[0]):
            parts = ['Recording']
            scrubbed = True
        clean_name = '_'.join(parts) + tag + ext
    else:
        clean_name = raw_name
    return {
        'original_basename': raw_name,
        'sanitized_name': clean_name,
        'student_name_scrubbed': scrubbed,
    }


def zip_guard(
    path: str | Path,
    max_uncompressed_bytes: int = MAX_ZIP_UNCOMPRESSED_BYTES,
    max_members: int = MAX_ZIP_MEMBERS,
) -> None:
    """Validate ZIP member count, paths, symlinks, encryption, and real decompressed bytes."""
    try:
        with zipfile.ZipFile(path) as archive:
            members = archive.infolist()
            if len(members) > max_members:
                raise ValueError('The workbook exceeds the bounded ZIP member count.')
            declared_total = 0
            actual_total = 0
            for member in members:
                if member.flag_bits & 1:
                    raise ValueError('Encrypted workbooks are unsupported.')
                parts = PurePosixPath(member.filename).parts
                if '..' in parts or member.filename.startswith(('/', '\\')):
                    raise ValueError('The workbook archive contains an unsafe member path.')
                mode = (member.external_attr >> 16) & 0o170000
                if mode == 0o120000:
                    raise ValueError('The workbook archive contains an unsupported symbolic link.')
                declared_total += max(0, int(member.file_size))
                if declared_total > max_uncompressed_bytes:
                    raise ValueError('The workbook exceeds the bounded expanded ZIP size.')
                if member.is_dir():
                    continue
                with archive.open(member, 'r') as stream:
                    while True:
                        chunk = stream.read(1024 * 1024)
                        if not chunk:
                            break
                        actual_total += len(chunk)
                        if actual_total > max_uncompressed_bytes:
                            raise ValueError('The workbook exceeds the bounded expanded ZIP size.')
    except zipfile.BadZipFile as error:
        raise ValueError('This workbook file is not a readable ZIP archive.') from error


def inspect_ooxml_workbook(path: str | Path) -> dict:
    """Inspect an OOXML (.xlsx/.xlsm) archive for VBA macros, hidden sheets, and author metadata."""
    info = {'has_vba_macros': False, 'hidden_sheets': [], 'author_fields': {}}
    try:
        with zipfile.ZipFile(path) as archive:
            names = set(archive.namelist())
            if any(name.casefold().endswith('vbaproject.bin') for name in names):
                info['has_vba_macros'] = True
            if 'xl/workbook.xml' in names:
                root = SafeET.fromstring(archive.read('xl/workbook.xml'))
                for elem in root.iter():
                    if elem.tag.endswith('}sheet') or elem.tag == 'sheet':
                        state = elem.attrib.get('state', 'visible')
                        if state in ('hidden', 'veryHidden'):
                            info['hidden_sheets'].append(elem.attrib.get('name', 'unnamed'))
            for prop_path in ('docProps/core.xml', 'docProps/app.xml'):
                if prop_path in names:
                    root = SafeET.fromstring(archive.read(prop_path))
                    for elem in root.iter():
                        local = elem.tag.split('}')[-1]
                        if local in ('creator', 'lastModifiedBy', 'Company', 'Manager') and elem.text and elem.text.strip():
                            info['author_fields'][local] = elem.text.strip()
    except Exception:
        pass
    return info


def scrub_xlsx_copy(src: str | Path, dst: str | Path) -> dict:
    """Write a copy of an OOXML workbook with author/company properties scrubbed."""
    src_path, dst_path = Path(src), Path(dst)
    zip_guard(src_path)
    inspected = inspect_ooxml_workbook(src_path)
    if inspected['has_vba_macros']:
        raise ValueError('Workbooks containing embedded VBA macros (vbaProject.bin) cannot be exported as contributor packages; save as macro-free .xlsx first.')
    removed_fields = []
    with zipfile.ZipFile(src_path, 'r') as zin, zipfile.ZipFile(dst_path, 'w', compression=zipfile.ZIP_DEFLATED) as zout:
        for member in zin.infolist():
            payload = zin.read(member.filename)
            if member.filename in ('docProps/core.xml', 'docProps/app.xml'):
                try:
                    root = SafeET.fromstring(payload)
                    changed = False
                    for elem in root.iter():
                        local = elem.tag.split('}')[-1]
                        if (
                            local in (
                                'creator', 'lastModifiedBy', 'Company', 'Manager',
                                'title', 'subject', 'description', 'keywords', 'HyperlinkBase',
                            )
                            and elem.text
                        ):
                            removed_fields.append(local)
                            elem.text = ''
                            changed = True
                    if changed:
                        payload = ET.tostring(root, encoding='utf-8', xml_declaration=True)
                except Exception:
                    pass
            info = zipfile.ZipInfo(filename=member.filename, date_time=(2026, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = member.external_attr
            zout.writestr(info, payload)
    return {'removed_fields': sorted(set(removed_fields)), 'hidden_sheets': inspected['hidden_sheets']}


def escape_csv_cell(value):
    """Neutralize spreadsheet formula triggers in derived summary CSV text cells."""
    if not isinstance(value, str) or not value:
        return value
    if value[0] in ('=', '+', '-', '@', '\t', '\r'):
        try:
            parsed = float(value)
            if math.isfinite(parsed):
                return value
        except (TypeError, ValueError):
            pass
        return "'" + value
    return value


def escape_csv_rows(rows: list[dict], columns: list[str] | None = None) -> list[dict]:
    escaped = []
    for row in rows:
        if columns is None:
            escaped.append({k: escape_csv_cell(v) for k, v in row.items()})
        else:
            escaped.append({k: escape_csv_cell(row.get(k)) for k in columns if k in row or columns is not None})
    return escaped
