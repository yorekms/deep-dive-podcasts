"""Bounded standalone measurement/review/pipeline smoke test on public voltage ABFs."""
from copy import deepcopy
from pathlib import Path
import hashlib
import json
import shutil
import zipfile
from .session import Session,verify_audit
from .pipelines import batch_projects,record_batch_exports


def run(workspace,examples_dir):
    root=Path(workspace).resolve()/'ap-self-test';root.mkdir(parents=True,exist_ok=True)
    source=Path(examples_dir).resolve()/'17o05027_ic_ramp.abf'
    before=hashlib.sha256(source.read_bytes()).hexdigest()
    session=Session(root);session.import_file(source)
    commands=['show full sweep','overlay sweeps 1 through 2',
        'measure action potential amplitude half-width and inter-spike intervals',
        'set baseline window to 3 ms',
        'exclude region from 100 to 150 ms on channel 1 sweep 1 because software review demonstration',
        'reject peak ch1-sw2-p876 because software review demonstration']
    for command in commands:
        reply=session.command(command);assert reply['refresh'],reply['message']
    assert session.result['method']=='action_potentials' and len(session.result['events'])==13
    assert session.result['ap_accounting']['excluded_channel_samples']==1000
    assert all(e['amplitude_mv'] is not None and e['half_width_ms'] is not None for e in session.result['events'])
    snapshot=deepcopy(session.result)
    reply=session.command('show analysis plan');assert not reply['refresh']
    reply=session.command('export as SVG');assert 'export_request' in reply
    output=session.export_bundle(reply['export_request'])
    restored=Session(root);restored.open_project(session.save());assert restored.result==snapshot
    session=restored
    inputs=root/'inputs';inputs.mkdir(exist_ok=True)
    for name in ['cell-a.abf','cell-b.ABF']:shutil.copy2(source,inputs/name)
    other=source.parent/'16d22006_kim_gapfree.abf'
    if other.exists():shutil.copy2(other,inputs/'different-protocol.abf')
    session.command('save pipeline as "Standalone AP check"')
    session.command(f'run pipeline on folder "{inputs}"')
    folder,report,projects=batch_projects(session.context['last_batch']);assert len(projects)==2
    exports=[]
    for project in projects:
        child=Session(folder);child.open_project(project)
        assert len(child.result['events'])==15
        assert not child.plan['event_decisions'] and not child.plan['excluded_regions']
        exports.append({'project':str(project),'status':'exported',**child.export_bundle()})
    record_batch_exports(session,folder,exports)
    for item in [output,*exports]:
        directory=Path(item['folder'])
        for name,digest in json.loads((directory/'SHA256.json').read_text()).items():
            assert hashlib.sha256((directory/name).read_bytes()).hexdigest()==digest
        with zipfile.ZipFile(item['archive']) as archive:assert archive.testzip() is None
    assert hashlib.sha256(source.read_bytes()).hexdigest()==before
    session._assert_integrity();head,count=verify_audit(session.project_dir/'history.jsonl',session.last_hash)
    return {'status':'passed','commands':commands,'source_sha256':before,'source_unchanged':True,
        'reviewed_events':13,'excluded_channel_samples':1000,'project_reopen':'exact match',
        'audit_events':count,'audit_head':head,'export':output,'batch_dir':str(folder),
        'batch_files':report['files'],'batch_exports':exports,
        'limits':'Public recording without physiological ground-truth labels; review masks/decisions are software demonstrations.'}
