"""Restricted offline queries for indexed large tables; source rows stay intact."""
from __future__ import annotations
from copy import deepcopy
import ast
import json
import math
import re

_METHODS={'profile','count_by','find','summary','histogram','scatter'}
_PLAN_FIELDS={'action','method','columns','groupby','x','y','bins','limit','offset','predicates'}
_NUMBER=r'[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:e[-+]?\d+)?'
_QUOTED=r'''(?:"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*')'''


def _help(message,unsupported=True):
    value={'action':'help','message':message}
    if unsupported:value['unsupported']=True
    return value


def _columns(dataset):
    metadata=dataset.metadata()
    values=metadata.get('columns',[])
    names=[value if isinstance(value,str) else value.get('name') for value in values]
    if not names or any(not isinstance(name,str) for name in names):
        raise ValueError('The indexed table does not provide a valid column schema.')
    return names


def _unquote(text):
    text=text.strip()
    if text[:1] in ('"',"'"):
        try:value=ast.literal_eval(text)
        except (ValueError,SyntaxError):raise ValueError('Close each quoted column or value before running a query.') from None
        if not isinstance(value,str):raise ValueError('Quoted column names and values must be text.')
        return value
    return text


def _masked(text):
    """Keep syntax outside literal column/value labels available for guards."""
    return re.sub(_QUOTED,lambda match:' '*len(match.group()),text)


def _resolve(text,names):
    label=_unquote(text)
    exact=[name for name in names if name==label]
    matches=exact or [name for name in names if name.casefold()==label.casefold()]
    if len(matches)!=1:
        if len(matches)>1:raise ValueError('That column spelling is ambiguous. Quote its exact spelling.')
        raise ValueError('Unknown column '+repr(label)+'. Use “show columns” and quote the exact column name.')
    return matches[0]


def _split_syntax(text,pattern):
    positions=list(re.finditer(pattern,_masked(text),re.I))
    if not positions:return [text]
    pieces=[];start=0
    for position in positions:
        pieces.append(text[start:position.start()].strip());start=position.end()
    pieces.append(text[start:].strip())
    return pieces


def _scalar(text,numeric=False):
    text=text.strip()
    if not text:raise ValueError('Every query condition needs an explicit value.')
    if text[:1] in ('"',"'"):return _unquote(text)
    if text.casefold() in ('null','missing','blank'):return None
    if re.fullmatch(_NUMBER,text,re.I):
        if not numeric:return text  # Keep source spelling, including leading zeros.
        number=float(text)
        if not math.isfinite(number):raise ValueError('Numeric query values must be finite.')
        return int(number) if number.is_integer() else number
    if re.fullmatch(r'[^\s,;\[\]{}()=<>!]+',text):return text
    raise ValueError('Quote a text value containing spaces or punctuation, for example where ContrastID is "treatment versus control".')


def _condition(text,names):
    # Match the longest actual column first, so operators inside a column label
    # cannot become query instructions. Quoted labels are untrusted literals.
    candidates=[]
    for name in names:
        pattern=rf'^(?:{re.escape(name)}|"{re.escape(name)}"|\'{re.escape(name)}\')(?=\s|[<>=!])'
        match=re.match(pattern,text,re.I)
        if match:candidates.append((len(match.group()),match))
    if not candidates:raise ValueError('Start every condition with an existing column name; use “show columns” if needed.')
    _,match=max(candidates,key=lambda item:item[0]);column=_resolve(match.group(),names);tail=text[match.end():].strip()
    operator=re.match(r'^(is\s+not|is|equals?|does\s+not\s+equal|contains|in|<=|>=|!=|==|=|<|>)\s*(.*)$',tail,re.I)
    if not operator:raise ValueError('Use an explicit condition operator: is, is not, contains, in, =, !=, <, <=, > or >=.')
    token,value_text=operator.groups();token=' '.join(token.casefold().split())
    op={'is':'eq','equal':'eq','equals':'eq','=':'eq','==':'eq','is not':'ne','does not equal':'ne','!=':'ne','contains':'contains','in':'in','<':'lt','<=':'le','>':'gt','>=':'ge'}[token]
    if op=='in':
        try:value=json.loads(value_text)
        except (json.JSONDecodeError,TypeError):raise ValueError('For “in”, provide a JSON list of exact values, for example Species in ["mouse", "human"].') from None
        if not isinstance(value,list) or not value or len(value)>200 or any(isinstance(v,(list,dict)) for v in value):raise ValueError('An “in” condition needs 1–200 scalar values.')
    else:value=_scalar(value_text,numeric=op in {'lt','le','gt','ge'})
    return {'column':column,'op':op,'value':value}


def _predicates(text,names):
    if not text.strip():raise ValueError('Give at least one explicit condition after “where”.')
    conditions=_split_syntax(text,r'\band\b')
    if len(conditions)>32:raise ValueError('Use at most 32 explicit query conditions.')
    return [_condition(condition,names) for condition in conditions]


def _previous(previous_plan):
    if previous_plan and previous_plan.get('method') in _METHODS:
        return {k:deepcopy(v) for k,v in previous_plan.items() if k in _PLAN_FIELDS}
    return None


def _guidance(names=None):
    names=names or []
    examples=['“describe this data”','“show columns”']
    if names:
        group='Species' if 'Species' in names else names[0]
        examples.append('“count rows by '+json.dumps(group,ensure_ascii=False)+'”')
    if 'GeneSymbol' in names:examples.append('“find gene RAB7A”')
    if 'logFC' in names:examples.extend(['“summarize logFC”','“histogram logFC”'])
    if 'logFC' in names and 'AdjPValue' in names:examples.append('“scatter logFC against AdjPValue”')
    message=('I can discuss the data structure and propose an explicit descriptive query before calculating. '
             'Try '+', '.join(examples)+'. '
             'The supported queries are column profiles, counts by a named column, exact-value searches, numeric summaries, histograms and bounded scatter plots. '
             'Add explicit column conditions with “where”; these create documented derived selections while original rows remain intact. '
             'The meaning of a row, its units and the study or operational design must be established before choosing inferential methods. '
             'An enabled local language model can help translate discussion into supported queries; it does not add unimplemented tests.')
    omics='GeneSymbol' in names and any(name in names for name in ['logFC','AdjPValue','ContrastID'])
    if omics:
        message+=(' For a transcriptomics effect/results table, each row may be a gene–contrast result rather than an independent biological sample. '
                  'Retain species, study, cohort and contrast provenance where present. Existing adjusted p-values retain their original testing family; they cannot be pooled or recalculated from a selected subset. '
                  'Raw-count methods such as DESeq2 require original count matrices, sample metadata and an appropriate design. '
                  'This descriptive workflow does not rerun differential expression or perform an automatic gene-level t-test.')
    return message


def interpret_large(text,dataset,previous_plan=None,context=None):
    """Return a closed large-table query, explanation, style, or global-route None."""
    if getattr(dataset,'kind',None)!='large_table':return None
    if not isinstance(text,str) or not text.strip():return _help(_guidance())
    text=text.strip();outside=_masked(text);low=outside.casefold()
    # Opening and exporting use the controller's file operations. Do not let a
    # quoted destination or a label become an analysis plan here.
    if re.match(r'^(?:open|load|import|export|save\s+(?:the\s+)?(?:figure|plot|chart|results|package|analysis))\b',low):return None
    from .planner import _parse_style,_blocked_request
    style=_parse_style(text)
    if style and set(style)&{'title','xlabel','ylabel'} and re.match(r'^(?:please\s+)?(?:set|change|label|title|do\s+not|don\x27t)\b',low):
        prefix=re.split(r'\b(?:title|label)\b',low,maxsplit=1)[0]
        if re.search(r"\b(?:do\s+not|don['’]?t|never|avoid|cancel|stop)\b",prefix):return _help('The presentation instruction is negated. No presentation change was applied.')
        return {'action':'style','style':style,'message':'I will update the figure label. The indexed source and query remain unchanged.'}
    derived_filter=bool(re.match(r'^(?:filter(?:\s+rows)?|select\s+rows)\s+where\b',low))
    if (not derived_filter and _blocked_request(outside)) or re.search(r'\b(?:delete|drop|prune|discard|remove|winsori[sz]\w*)\b',low):
        return {'action':'blocked','unsupported':True,'message':'No source rows were removed and no significance search was run. Use explicit column conditions for a documented derived query; the original table remains preserved.'}
    if re.search(r'\b(?:best|smallest|lowest|optimi[sz]\w*)\b.{0,45}\b(?:p[ -]?values?|significan\w*)\b',low):
        return {'action':'blocked','unsupported':True,'message':'I will not choose rows or tune a query to optimize statistical significance. State a scientific contrast and an explicit, justified selection.'}
    if ';' in outside or '\n' in outside or re.search(r'\b(?:then|followed by|after that)\b',low):return _help('Give one table query or presentation instruction at a time; no partial instruction was applied.')
    if style and (set(style)&{'title','xlabel','ylabel'} or re.match(r'^(?:please\s+)?(?:set|change|make|label|title|colou?r|use)\b',low)):
        if re.search(r"\b(?:do\s+not|don['’]?t|never|avoid|cancel|stop)\b",low.split('title')[0].split('label')[0]):return _help('The presentation instruction is negated. No presentation change was applied.')
        # Literal labels remain presentation text; a query plus a style edit is
        # not partially executed by this route.
        if not re.search(r'\b(?:where|histogram|scatter|summari[sz]e|count\s+rows|find\s+gene)\b',low):return {'action':'style','style':style,'message':'I will update the figure presentation. The indexed source and query remain unchanged.'}
    if re.search(r"\b(?:do\s+not|don['’]?t|dont|never|without|stop|cancel|avoid)\b",low):return _help('This instruction negates part of the query. No query or selection was changed; state one positive query instruction.')
    if re.search(r'\b(?:deseq2?|edger|t[ -]?tests?|anova|regression|bayesian|bayes\w*|mixed[ -]effects?|repeated[ -]measures)\b',low):return _help('That inferential method is not implemented for this large indexed table. '+_guidance(_columns(dataset)))
    try:
        names=_columns(dataset);prior=_previous(previous_plan)
        parts=_split_syntax(text,r'\bwhere\b')
        if len(parts)>2:raise ValueError('Use one “where” clause; join explicit conditions with “and”.')
        base=parts[0].strip();base_low=base.casefold();conditions=_predicates(parts[1],names) if len(parts)==2 else []
        prior_conditions=deepcopy(prior.get('predicates',[])) if prior else []
        extra={}
        suffix=re.search(r'\s+(?:limit|at\s+most)\s+(\d+)\s*(?:rows|points|pairs|results)?\s*$',base,re.I)
        if suffix:extra['limit']=int(suffix.group(1));base=base[:suffix.start()].strip();base_low=base.casefold()
        if re.fullmatch(r'(?:use|show)\s+all\s+rows|clear\s+(?:the\s+)?(?:derived\s+)?selection',base_low):
            if conditions or extra:raise ValueError('Reset the derived selection in its own instruction.')
            plan=deepcopy(prior) if prior else {'action':'large_analyze','method':'profile'};plan['predicates']=[]
        elif (not base and conditions) or (base_low in ('filter','filter rows','select rows','where') and conditions):
            if extra:raise ValueError('Change the page limit separately from the derived-selection condition.')
            plan=deepcopy(prior) if prior else {'action':'large_analyze','method':'find'}
            plan['predicates']=prior_conditions+conditions
            if plan['method']=='find':plan['offset']=0
        elif re.fullmatch(r'(?:show\s+)?next\s+(?:page|results|rows)',base_low):
            if not prior or prior['method']!='find' or conditions or extra:raise ValueError('Run a “find” query first, then ask “next page”.')
            plan=deepcopy(prior);plan['offset']=prior.get('offset',0)+prior.get('limit',200)
        else:
            plan={'action':'large_analyze','predicates':prior_conditions+conditions,**extra}
            if re.fullmatch(r'(?:please\s+)?(?:describe(?:\s+(?:this|the|my))?\s+(?:data|dataset|table)|describe|profile(?:\s+(?:this|the))?(?:\s+(?:data|table|dataset))?|what\s+kind\s+of\s+data\s+is\s+this\??|show\s+(?:the\s+)?columns|list\s+(?:the\s+)?columns)',base_low):
                plan['method']='profile'
            elif match:=re.fullmatch(r'count\s+(?:the\s+)?rows\s+by\s+(.+)',base,re.I):
                plan.update(method='count_by',groupby=_resolve(match.group(1),names))
            elif match:=re.fullmatch(r'(?:summari[sz]e|summary(?:\s+of)?)\s+(.+)',base,re.I):
                plan.update(method='summary',columns=[_resolve(value,names) for value in _split_syntax(match.group(1),r',|\band\b')])
            elif match:=re.fullmatch(r'(?:plot\s+(?:a\s+)?)?histogram(?:\s+of)?\s+(.+)',base,re.I):
                field=match.group(1);bins=re.search(r'\s+(?:using|with)\s+(\d+)\s+bins\s*$',field,re.I)
                if bins:plan['bins']=int(bins.group(1));field=field[:bins.start()].strip()
                plan.update(method='histogram',x=_resolve(field,names))
            elif match:=re.fullmatch(r'(?:plot\s+(?:a\s+)?)?scatter(?:plot)?(?:\s+of)?\s+(.+)',base,re.I):
                axes=_split_syntax(match.group(1),r'\bagainst\b|\bversus\b|\bvs\.?\b')
                if len(axes)!=2:raise ValueError('Name two existing columns, for example scatter logFC against AdjPValue.')
                plan.update(method='scatter',x=_resolve(axes[0],names),y=_resolve(axes[1],names))
            elif match:=re.fullmatch(r'find\s+gene\s+(.+)',base,re.I):
                gene_columns=[name for name in names if name.casefold()=='genesymbol']
                if len(gene_columns)!=1:raise ValueError('There is no unambiguous GeneSymbol column. Use “find exact "value" in "column"” with an existing column name.')
                value=_scalar(match.group(1))
                if not isinstance(value,str):raise ValueError('Provide a gene symbol as text.')
                kept=[p for p in prior_conditions if not (p.get('column')==gene_columns[0] and p.get('op') in ('eq','ieq'))]
                plan.update(method='find',predicates=kept+[{'column':gene_columns[0],'op':'ieq','value':value}]+conditions)
            elif match:=re.fullmatch(r'find\s+(?:exact\s+)?(.+?)\s+in\s+(.+)',base,re.I):
                target_col=_resolve(match.group(2),names)
                kept=[p for p in prior_conditions if not (p.get('column')==target_col and p.get('op') in ('eq','ieq'))]
                plan.update(method='find',predicates=kept+[{'column':target_col,'op':'eq','value':_scalar(match.group(1))}]+conditions)
            elif base_low in ('find','find rows','show rows','show matching rows') and conditions:
                plan['method']='find'
            else:
                # An attempted known operation must never silently fall back to
                # another calculation, even when the local model is enabled.
                if re.match(r'^(?:find|count|summary|summari[sz]e|histogram|scatter|filter|select|where|show\s+rows)\b',base_low):raise ValueError('I could not account for the whole query. '+_guidance(names))
                return {'action':'recommend','message':_guidance(names)}
        from .large_table import validate_large_plan
        normalized=validate_large_plan(dataset,plan)
        normalized['message']=(f"I will run the supported {normalized['method'].replace('_',' ')} query across the indexed source using {len(normalized.get('predicates',[]))} explicit condition(s). "
            'This is a derived selection; source rows and their provenance remain preserved. '
            +('Matching rows are returned in bounded pages; use “next page” for more. ' if normalized['method']=='find' else '')
            +('The figure uses at most '+str(normalized['limit'])+' finite pairs with the reduction recorded; it does not imply every source row is plotted. ' if normalized['method']=='scatter' else '')
            +'No inferential analysis is requested.')
        return normalized
    except (ValueError,TypeError,KeyError) as error:return _help(str(error))
