"""Bounded source evidence for study intake; no analysis, pooling or dataframe.

Workbook inspection reads headers and small metadata/design/Summary windows.
PerBreath and other observation sheets are never traversed beyond their header.
All interpretations remain proposed; literal source evidence is preserved.
"""
from __future__ import annotations

from copy import deepcopy
import codecs
import csv
from datetime import date,datetime
import hashlib
import json
import math
from os.path import commonprefix
from pathlib import Path,PurePosixPath
import re
import uuid
import zipfile

import warnings as _warnings

import openpyxl

try:
    with _warnings.catch_warnings():
        _warnings.simplefilter('ignore', DeprecationWarning)
        import defusedxml
        defusedxml.defuse_stdlib()
except ImportError:  # pragma: no cover
    pass

from .scrubber import zip_guard as _streaming_zip_guard

MAX_FILES=100
MAX_FILE_BYTES=32*1024*1024
MAX_TOTAL_BYTES=512*1024*1024
MAX_UNCOMPRESSED_BYTES=256*1024*1024
MAX_SHEETS=32
MAX_COLUMNS=256
MAX_ROWS=64
MAX_TEXT=2048
MAX_MANIFEST_BYTES=8*1024*1024
MAX_MODEL_BYTES=60_000
ROLES={'standardized_export','reference_analysis','generic_table'}
CAL_FLAGS={'Volume_calibrated':'volume_calibrated','Syringe_calibrated':'syringe_calibrated',
           'Thermobarometric_corrected':'thermobarometric_corrected'}


def _canonical(value):return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)


def _sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as handle:
        for chunk in iter(lambda:handle.read(1024*1024),b''):h.update(chunk)
    return h.hexdigest()


def _stat(path):
    s=Path(path).stat();return (s.st_size,s.st_mtime_ns,s.st_ctime_ns)


def _value(value):
    if isinstance(value,(date,datetime)):return value.isoformat()
    if isinstance(value,float) and not math.isfinite(value):return {'nonfinite_source_number':repr(value)}
    if value is None or isinstance(value,(bool,int,float)):return value
    text=str(value)
    return text if len(text)<=MAX_TEXT else text[:MAX_TEXT]+' [intake text truncated]'


def _blank(value):return value is None or isinstance(value,str) and not value.strip()


def _unique(values):
    result=[];seen=set()
    for value in values:
        value=_value(value);token=_canonical({'type':type(value).__name__,'value':value})
        if token not in seen:seen.add(token);result.append(value)
    return result


def _boolean(values):
    values=[v for v in values if not _blank(v)];converted=[]
    for value in values:
        if value is True or type(value) in (int,float) and value==1 or isinstance(value,str) and value.casefold()=='true':converted.append(True)
        elif value is False or type(value) in (int,float) and value==0 or isinstance(value,str) and value.casefold()=='false':converted.append(False)
        else:return None
    return converted[0] if converted and len(set(converted))==1 else None


def _present(rows,key):return any(not _blank(row.get(key)) for _,row in rows)


def _header(values):
    values=list(values)
    while values and values[-1] is None:values.pop()
    if len(values)>MAX_COLUMNS:raise ValueError('Study intake supports at most 256 columns per sheet.')
    return [_value(value) if value is not None else None for value in values]


def _zip_guard(path):
    _streaming_zip_guard(path, max_uncompressed_bytes=MAX_UNCOMPRESSED_BYTES, max_members=10000)


def _inspect_xlsx(path):
    _zip_guard(path);sheets=[];windows={}
    try:
        book=openpyxl.load_workbook(path,read_only=True,data_only=True,keep_links=False)
        try:
            if len(book.sheetnames)>MAX_SHEETS:raise ValueError('Study intake supports at most 32 sheets per workbook.')
            for sheet in book:
                if sheet.max_column is not None and sheet.max_column>MAX_COLUMNS:raise ValueError('A worksheet exceeds the 256-column intake bound.')
                first=next(sheet.iter_rows(min_row=1,max_row=1,max_col=MAX_COLUMNS+1,values_only=True),())
                headers=_header(first)
                names=[str(v) if v is not None else f'Column {i+1}' for i,v in enumerate(headers)]
                capture=sheet.title.casefold() in {'metadata','summary','textmarks','studydesign_selected','studydesign_all'}
                rows=[]
                if capture:
                    for excel_row,values in enumerate(sheet.iter_rows(min_row=2,max_row=MAX_ROWS+1,max_col=max(1,len(headers)),values_only=True),2):
                        if all(_blank(v) for v in values):continue
                        rows.append((excel_row,{name:value for name,value in zip(names,values)}))
                declared=max(0,sheet.max_row-1) if sheet.max_row is not None else None
                complete=capture and declared is not None and declared<=MAX_ROWS
                sheets.append({'name':sheet.title,'headers':headers,'header_row':1,'declared_data_rows':declared,
                    'declared_columns':sheet.max_column,'inspected_data_rows':len(rows),
                    'inspection_complete':complete,'inspection_scope':'bounded metadata/design/Summary rows' if capture else 'header only; no observation rows read'})
                windows[sheet.title.casefold()]=rows
        finally:book.close()
    except Exception as error:
        raise ValueError('The workbook could not be inspected safely: '+str(error)) from error
    return sheets,windows,{}


def _text_encoding(path):
    utf=codecs.getincrementaldecoder('utf-8-sig')('strict');cp=codecs.getincrementaldecoder('cp1252')('strict')
    valid_utf=valid_cp=True
    with path.open('rb') as handle:
        for block in iter(lambda:handle.read(1024*1024),b''):
            if b'\0' in block:raise ValueError('UTF-16/binary input is unsupported; provide UTF-8 or Windows-1252 delimited text.')
            if valid_utf:
                try:utf.decode(block)
                except UnicodeDecodeError:valid_utf=False
            if valid_cp:
                try:cp.decode(block)
                except UnicodeDecodeError:valid_cp=False
    if valid_utf:
        try:utf.decode(b'',final=True)
        except UnicodeDecodeError:valid_utf=False
    if not valid_utf and not valid_cp:raise ValueError('The text is not valid UTF-8 or Windows-1252.')
    return 'utf-8-sig' if valid_utf else 'cp1252'


def _inspect_text(path):
    encoding=_text_encoding(path);delimiter='\t' if path.suffix.casefold()=='.tsv' else ','
    with path.open(encoding=encoding,newline='') as handle:
        if path.suffix.casefold()=='.txt':
            sample=handle.read(65536);handle.seek(0)
            try:delimiter=csv.Sniffer().sniff(sample,delimiters=',\t;|').delimiter
            except csv.Error:pass
        csv.field_size_limit(MAX_TEXT*16)
        reader=csv.reader(handle,delimiter=delimiter,strict=True)
        try:
            headers=_header(next(reader));count=0;last_line=reader.line_num
            if not headers:raise ValueError('The text has no nonempty header.')
            # Inspection establishes the bounded layout, not a validated full
            # CSV import. Numeric outcome values are not retained in evidence.
            for row in reader:
                if len(row)!=len(headers):raise ValueError('The inspected CSV records do not match the header width.')
                count+=1;last_line=reader.line_num
                if count>=MAX_ROWS:break
        except StopIteration:raise ValueError('The text file is empty.') from None
        except csv.Error as error:raise ValueError('The inspected text is malformed: '+str(error)) from error
    sheet={'name':'Data','headers':headers,'header_row':1,'declared_data_rows':None,'declared_columns':len(headers),
        'inspected_data_rows':count,'inspection_complete':False,'inspection_scope':'header and bounded shape check; outcome rows not retained'}
    return [sheet],{}, {'encoding':encoding,'delimiter':delimiter,'last_inspected_physical_line':last_line,'complete_file_validation':False}


def _filename_identifiers(name):
    subject=re.search(r'#\s*([A-Za-z0-9]+)(?:\([^)]*\))?',name)
    if not subject:subject=re.search(r'\b(?:mouse|animal|subject)[ _-]*([A-Za-z0-9]+)',name,re.I)
    session=re.search(r'(?:^|[_\s-])((?:trial|session|run)[ _-]*[A-Za-z0-9]+)',name,re.I)
    return (subject.group(1) if subject else None,session.group(1) if session else None)


def _session_key(value):
    match=re.fullmatch(r'(trial|session|run)[ _-]*([0-9]+)',str(value).strip(),re.I)
    return (match.group(1).casefold(),str(int(match.group(2)))) if match else ('literal',str(value).strip().casefold())


def _field_values(rows,field):return [_value(row.get(field)) for _,row in rows if field in row]


def _evidence(sheets,windows,name):
    by_name={s['name'].casefold():s for s in sheets};summary=windows.get('summary',[])
    metadata=[];fields={}
    for rownum,row in windows.get('metadata',[]):
        keys=list(row);key=row.get('Field',row.get(keys[0]) if keys else None);value=row.get('Value',row.get(keys[1]) if len(keys)>1 else None)
        metadata.append({'source_excel_row':rownum,'field':_value(key),'value':_value(value)})
        if isinstance(key,str):fields.setdefault(key,[]).append(_value(value))
    sh=set(str(v) for v in by_name.get('summary',{}).get('headers',[]));ph=set(str(v) for v in by_name.get('perbreath',{}).get('headers',[]))
    signals=[]
    if {'metadata','summary','perbreath'}<=set(by_name):signals.append('Metadata, Summary and PerBreath worksheets')
    if {'Condition','Animal_ID','RR_bpm'}<=sh and len(sh&{'Ti_s','Te_s','VT_mL','VT_syringe_mL','MV_mL_per_min'})>=2:signals.append('Summary respiratory measures and condition/animal identifiers')
    if {'Breath','Start_s','End_s','Condition'}<=ph:signals.append('PerBreath indexed respiratory timing schema')
    if any('pleth' in key.casefold() for key in fields):signals.append('Explicit pleth acquisition metadata fields')
    if set(CAL_FLAGS)<=sh:signals.append('Explicit volume/syringe/thermobarometric calibration flags')
    pleth=len(signals)>=3 and any('respiratory' in s for s in signals)
    reference=[]
    if {'studydesign_all','studydesign_selected'}<=set(by_name):reference.append('StudyDesign_All and StudyDesign_Selected worksheets')
    if {'stats','effectsizes','descriptive'}<=set(by_name):reference.append('Stats, EffectSizes and Descriptive worksheets')
    compiled=set(str(v) for v in by_name.get('compileddata',{}).get('headers',[]))
    if {'Group','MouseID','Session','FilePath','Condition','ConditionOrder'}<=compiled:reference.append('CompiledData analysis/provenance schema')
    if {'analysisselection','publicationnumeric','analysis_notes'}<=set(by_name):reference.append('AnalysisSelection, PublicationNumeric and Analysis_Notes worksheets')
    role='reference_analysis' if len(reference)>=3 else 'standardized_export' if pleth else 'generic_table'
    subject_from_name,session_from_name=_filename_identifiers(name)
    observed=[]
    for origin,values in [('Metadata.Internal animal ID',fields.get('Internal animal ID',[])),('Summary.Animal_ID',_field_values(summary,'Animal_ID'))]:
        for value in _unique(values):
            if not _blank(value):observed.append({'origin':origin,'value':value})
    subject_values=_unique([str(v['value']) for v in observed]);subject=subject_from_name or (subject_values[0] if len(subject_values)==1 else None)
    trials=[];observed_sessions=[]
    for field,values in fields.items():
        normalized=field.casefold().replace('_',' ').strip()
        if 'textmark' in normalized or normalized in {'session','trial','run'}:
            for value in values:
                if not isinstance(value,(str,int,float)) or isinstance(value,bool):continue
                text=str(value) if normalized not in {'session','trial','run'} else normalized+' '+str(value)
                found=[m.group(0) for m in re.finditer(r'(?<![A-Za-z0-9])(?:trial|session|run)[ _-]*[0-9]+',text,re.I)]
                trials.extend(found)
                if found:observed_sessions.append({'origin':'Metadata.'+field,'value':value,'tokens':found})
    for rownum,row in summary:
        for key in ['Condition','Condition_short']:
            value=row.get(key)
            if isinstance(value,str):
                found=[m.group(0) for m in re.finditer(r'(?<![A-Za-z0-9])(?:trial|session|run)[ _-]*[0-9]+',value,re.I)]
                trials.extend(found)
                if found:observed_sessions.append({'origin':'Summary.'+key,'source_excel_row':rownum,'value':_value(value),'tokens':found})
    trials=_unique(trials)
    session=session_from_name or (trials[0] if len({_session_key(t) for t in trials})==1 else None)
    conditions=[];weight_conflicts=[]
    for rownum,row in summary:
        label=_value(row.get('Condition'));short=_value(row.get('Condition_short'));dose=_value(row.get('CO2_percent'))
        if 'Condition' in row:
            percent=re.findall(r'(?<![0-9.])([0-9]+(?:\.[0-9]+)?)\s*%',label) if isinstance(label,str) else []
            conditions.append({'source_excel_row':rownum,'label':label,'short_label':short,'dose_percent':dose,
                'percent_label_candidates':percent,'phase_status':'unconfirmed' if percent or dose is not None else 'unclassified'})
        weights=re.findall(r'([0-9]+(?:\.[0-9]+)?)\s*g\b',label) if isinstance(label,str) else []
        if len(weights)==1 and isinstance(row.get('Weight_g'),(int,float)) and float(weights[0])!=row['Weight_g']:
            weight_conflicts.append({'source_excel_row':rownum,'label_weight_candidate_g':weights[0],'source_Weight_g':row['Weight_g']})
    calibration={key:_boolean(_field_values(summary,field)) for field,key in CAL_FLAGS.items()}
    calibration.update(body_temperature_present=_present(summary,'BodyTemp_C'),weight_present=_present(summary,'Weight_g'),
        absolute_volume_values_present=_present(summary,'VT_mL'),syringe_volume_values_present=_present(summary,'VT_syringe_mL'),
        dose_column_present='CO2_percent' in sh,dose_missing_rows=sum(_blank(row.get('CO2_percent')) for _,row in summary),
        summary_rows_inspected=len(summary),summary_inspection_complete=by_name.get('summary',{}).get('inspection_complete',False))
    calibration['absolute_minute_ventilation_values_present']=True if _present(summary,'MV_mL_per_min') else False if calibration['summary_inspection_complete'] else None
    reference_design=[]
    for rownum,row in windows.get('studydesign_selected',[]):
        reference_design.append({'source_excel_row':rownum,**{key:_value(row[key]) for key in ['Group','MouseID','Session','Include','Reviewed'] if key in row}})
    evidence={'metadata_fields':metadata,'source_identifiers':{'observed_subjects':observed,'filename_subject_candidate':subject_from_name,
        'metadata_genotype_literals':fields.get('Genotype',[]),'metadata_source_file':fields.get('Source file',[]),
        'filename_session_candidate':session_from_name,'metadata_trial_tokens':trials,'observed_sessions':observed_sessions},
        'calibration':calibration,'summary_flag_values':{key:_unique(_field_values(summary,key)) for key in CAL_FLAGS},
        'conditions':conditions,'reference_design_proposals':reference_design,'interpretation_status':'proposed; source labels are not validated biological groups or genotype'}
    findings=[]
    def add(kind,severity,message,blocks=(),facts=None):findings.append({'type':kind,'severity':severity,'message':message,'blocks':list(blocks),'evidence':facts or {}})
    if subject_from_name and subject_values and any(str(value)!=subject_from_name for value in subject_values):
        add('subject_conflict','required','Filename subject and observed source identifiers disagree; preserve both and resolve explicitly.',['mapping'],{'filename_candidate':subject_from_name,'observed_values':subject_values})
    elif len(subject_values)>1:add('subject_conflict','required','More than one source subject identifier is present.',['mapping'],{'observed_values':subject_values})
    if not subject and role!='reference_analysis':add('missing_subject','required','Choose the subject identifier or explain that these files do not represent subjects.',['mapping'])
    if not session and role!='reference_analysis':add('missing_session','required','Choose the session/trial identifier or explain the design.',['mapping'])
    session_conflict=(session_from_name is not None and any(_session_key(value)!=_session_key(session_from_name) for value in trials)) or len({_session_key(value) for value in trials})>1
    if session_conflict:add('session_conflict','required','Filename session/trial and observed source tokens disagree; preserve both and resolve the session explicitly.',['mapping'],{'filename_candidate':session_from_name,'observed_values':trials})
    if fields.get('Genotype'):add('unvalidated_genotype','warning','The source Genotype field is a literal source label, not a validated biological genotype.',['genotype_inference'],{'values':fields['Genotype']})
    if pleth:
        if calibration['dose_missing_rows']:add('missing_dose','endpoint','Numeric CO2_percent is missing in inspected Summary rows; label tokens require confirmation.',['dose_response'],{'missing_rows':calibration['dose_missing_rows'],'label_candidates':_unique([v for c in conditions for v in c['percent_label_candidates']])})
        if calibration['volume_calibrated'] is not True or calibration['thermobarometric_corrected'] is not True:
            add('calibration_incomplete','endpoint','Absolute/corrected ventilation readiness is not established; keep syringe-only and raw measures separately labelled.',['absolute_ventilation'],calibration)
        if weight_conflicts:add('weight_conflict','endpoint','Condition-label weights disagree with the numeric source weight; no source value was replaced.',['weight_normalized_ventilation'],{'rows':weight_conflicts})
        if any(c['phase_status']=='unclassified' for c in conditions):add('unclassified_condition','endpoint','An inspected window has no explicit numeric dose or percent label; do not silently drop or classify it.',['dose_response'])
        if len(conditions)!=4:add('condition_window_count','warning','Condition-window count differs from a four-window sequence; preserve every source window.',[],{'inspected_windows':len(conditions)})
    if pleth and len(reference)>=3:
        role='reference_analysis';add('mixed_source_reference_layout','required','Both source-export and analysis schemas occur; review file roles before using observations.',['mapping'])
    return role,signals,reference,evidence,{'value':subject,'status':'conflict' if any(f['type']=='subject_conflict' for f in findings) else 'proposed','basis':'filename and/or observed source metadata; requires confirmation','observed_values':subject_values}, {'value':session,'status':'conflict' if session_conflict else 'proposed','basis':'filename and/or source trial tokens; requires confirmation','observed_values':trials},findings


def _seal(manifest):
    result=deepcopy(manifest);result.pop('evidence_sha256',None)
    result['evidence_sha256']=hashlib.sha256(_canonical(result).encode('utf-8')).hexdigest()
    return result


def _validate_manifest(value):
    if not isinstance(value,dict) or type(value.get('version')) is not int or value.get('version')!=1 or value.get('kind')!='study':raise ValueError('Unsupported study manifest.')
    if set(value)!={'version','kind','sources','domain','issues','evidence_sha256'}:raise ValueError('The study manifest fields are malformed.')
    try:serialized=_canonical(value)
    except (ValueError,TypeError) as error:raise ValueError('Study evidence must contain only finite JSON-compatible values.') from error
    if len(serialized.encode('utf-8'))>MAX_MANIFEST_BYTES:raise ValueError('The study manifest exceeds its bounded size.')
    if _seal(value)['evidence_sha256']!=value.get('evidence_sha256'):raise ValueError('Study manifest evidence changed outside its recorded digest.')
    domain=value.get('domain');sources=value.get('sources');issues=value.get('issues')
    if not isinstance(domain,dict) or not isinstance(domain.get('name'),str) or domain.get('status')!='proposed' or not isinstance(domain.get('evidence'),list) or any(not isinstance(e,str) for e in domain['evidence']):raise ValueError('Study domain evidence is malformed.')
    if not isinstance(sources,list) or not 1<=len(sources)<=MAX_FILES or not isinstance(issues,list):raise ValueError('A study needs 1–100 structured sources.')
    total=0;paths=[]
    for index,source in enumerate(sources,1):
        if not isinstance(source,dict) or source.get('source_id')!=f'S{index:03d}' or not isinstance(source.get('role'),str) or source.get('role') not in ROLES:raise ValueError('Study source identities/roles are malformed.')
        if set(source)!={'source_id','relative_path','original_name','sha256','bytes','role','sheets','metadata','proposed_subject','proposed_session','issues'}:raise ValueError('Study source fields are malformed.')
        name=source.get('original_name');rel=source.get('relative_path');sha=source.get('sha256');size=source.get('bytes')
        if not isinstance(name,str) or not name or '/' in name or '\\' in name or Path(name).suffix.casefold() not in {'.xlsx','.csv','.tsv','.txt'}:raise ValueError('Study source names must be supported-file basenames.')
        if not isinstance(rel,str) or not rel or '\\' in rel or '\0' in rel or PurePosixPath(rel).is_absolute() or any(p in ('.','..') for p in rel.split('/')) or re.match(r'^[A-Za-z]:',rel):raise ValueError('A study source path is not contained relative evidence.')
        if not isinstance(sha,str) or not re.fullmatch(r'[0-9a-f]{64}',sha) or type(size) is not int or not 0<=size<=MAX_FILE_BYTES:raise ValueError('Study source hash/size evidence is malformed.')
        total+=size;paths.append(rel)
        if not isinstance(source.get('metadata'),dict) or not isinstance(source.get('issues'),list) or not isinstance(source.get('sheets'),list) or len(source['sheets'])>MAX_SHEETS:raise ValueError('Study source metadata is malformed.')
        metadata=source['metadata']
        if not {'metadata_fields','source_identifiers','calibration','conditions','summary_flag_values','reference_design_proposals','interpretation_status','domain_signals','reference_signals'}<=set(metadata) or not isinstance(metadata['source_identifiers'],dict) or not isinstance(metadata['calibration'],dict) or not isinstance(metadata['conditions'],list):raise ValueError('Study metadata evidence is incomplete or malformed.')
        for sheet in source['sheets']:
            if not isinstance(sheet,dict) or not isinstance(sheet.get('name'),str) or not isinstance(sheet.get('headers'),list) or len(sheet['headers'])>MAX_COLUMNS or any(v is not None and not isinstance(v,(str,int,float,bool)) for v in sheet['headers']):raise ValueError('Study sheet evidence is malformed.')
            if type(sheet.get('header_row')) is not int or sheet['header_row']<1:raise ValueError('Study sheet header positions are malformed.')
            if sheet.get('declared_data_rows') is not None and (type(sheet['declared_data_rows']) is not int or sheet['declared_data_rows']<0):raise ValueError('Study sheet row metadata is malformed.')
        for key in ['proposed_subject','proposed_session']:
            proposal=source.get(key)
            if not isinstance(proposal,dict) or not isinstance(proposal.get('status'),str) or proposal.get('status') not in {'proposed','conflict'} or proposal.get('value') is not None and not isinstance(proposal.get('value'),str) or not isinstance(proposal.get('observed_values'),list) or any(not isinstance(v,str) for v in proposal['observed_values']) or not isinstance(proposal.get('basis'),str):raise ValueError('Study proposed identifier evidence is malformed.')
    if total>MAX_TOTAL_BYTES or len(paths)!=len(set(paths)):raise ValueError('Study sources exceed total size or repeat a relative source path.')
    identifiers={source['source_id'] for source in sources};seen=set()
    for issue in issues:
        if not isinstance(issue,dict) or not isinstance(issue.get('id'),str) or issue['id'] in seen or issue.get('source_id') not in identifiers or not isinstance(issue.get('type'),str) or not isinstance(issue.get('message'),str) or not isinstance(issue.get('severity'),str) or not isinstance(issue.get('blocks'),list) or any(not isinstance(v,str) for v in issue['blocks']) or not isinstance(issue.get('evidence'),dict):raise ValueError('Study issue evidence is malformed.')
        seen.add(issue['id'])
    if any(any(not isinstance(i,str) or i not in seen for i in source['issues']) for source in sources):raise ValueError('A source references unknown study issues.')
    return value


def _private_free(value):
    if isinstance(value,dict):return {k:_private_free(v) for k,v in value.items() if k not in {'relative_path','source_path','sha256','metadata_fields','reference_design_proposals','metadata_source_file'}}
    if isinstance(value,list):return [_private_free(v) for v in value]
    if isinstance(value,str):
        if re.search(r'(?:[A-Za-z]:[\\/]|(?:^|\s)/(?:[^\s/]+/)|file://|https?://)',value):return '[source path or URL withheld]'
        return value[:MAX_TEXT]
    return value


class Study:
    kind='study'
    def __init__(self,paths,manifest_path=None):
        if not isinstance(paths,(list,tuple)) or not 1<=len(paths)<=MAX_FILES:raise ValueError('Choose 1–100 local study files.')
        candidates=[]
        for value in paths:
            if not isinstance(value,(str,Path)):raise ValueError('Study file paths must be local text paths.')
            path=Path(value).expanduser().resolve()
            if not path.is_file() or path.suffix.casefold() not in {'.xlsx','.csv','.tsv','.txt'}:raise ValueError('Study intake currently supports existing XLSX, CSV, TSV and delimited TXT files only.')
            if path.stat().st_size>MAX_FILE_BYTES:raise ValueError('Each study file must be at most 32 MiB; larger adapters are separate workflows.')
            candidates.append(path)
        if len(set(candidates))!=len(candidates):raise ValueError('A study source was selected more than once.')
        if sum(p.stat().st_size for p in candidates)>MAX_TOTAL_BYTES:raise ValueError('Study intake supports at most 512 MiB of sources.')
        candidates.sort(key=lambda p:(p.name.casefold(),p.name,str(p)))
        self.source_path=None;self.source_hash=None;self._paths={};self._source_stats={};self._manifest_stat=None
        sources=[];issues=[];domain_evidence=[]
        for index,path in enumerate(candidates,1):
            sid=f'S{index:03d}';before=_stat(path);sha=_sha(path)
            sheets,windows,text=_inspect_xlsx(path) if path.suffix.casefold()=='.xlsx' else _inspect_text(path)
            role,signals,reference,metadata,subject,session,findings=_evidence(sheets,windows,path.name)
            if _stat(path)!=before:raise ValueError('A study source changed during inspection; intake stopped.')
            if text:metadata['delimited_text']=text
            metadata['domain_signals']=signals;metadata['reference_signals']=reference
            source_issues=[]
            for finding in findings:
                identity=f'I{len(issues)+1:04d}';issues.append({'id':identity,'source_id':sid,**finding});source_issues.append(identity)
            if role=='standardized_export':domain_evidence.append(sid+': '+ '; '.join(signals))
            sources.append({'source_id':sid,'relative_path':path.name,'original_name':path.name,'sha256':sha,'bytes':before[0],
                'role':role,'sheets':sheets,'metadata':metadata,'proposed_subject':subject,'proposed_session':session,'issues':source_issues})
            self._paths[sid]=path;self._source_stats[sid]=before
        self._manifest=_seal({'version':1,'kind':'study','sources':sources,'domain':{'name':'plethysmography' if domain_evidence else 'unknown','evidence':domain_evidence,'status':'proposed'},'issues':issues})
        if len(_canonical(self._manifest).encode('utf-8'))>MAX_MANIFEST_BYTES:raise ValueError('The bounded intake evidence exceeds the manifest size limit; inspect fewer files.')
        self._manifest_hash=None
        if manifest_path is not None:self._set_relative_paths(Path(manifest_path).expanduser().resolve())

    def _set_relative_paths(self,path):
        root=path.parent;relative={}
        for source in self._manifest['sources']:
            original=self._paths[source['source_id']]
            if not original.is_relative_to(root) or original==path:raise ValueError('Every source must be contained beside the study manifest; copy snapshots into its project first.')
            relative[source['source_id']]=original.relative_to(root).as_posix()
        for source in self._manifest['sources']:source['relative_path']=relative[source['source_id']]
        self._manifest=_seal(self._manifest)

    def manifest(self):return deepcopy(self._manifest)

    def metadata(self):return self.manifest()

    @property
    def sources(self):return deepcopy(self._manifest['sources'])

    @property
    def domain(self):return deepcopy(self._manifest['domain'])

    @property
    def issues(self):return deepcopy(self._manifest['issues'])

    def write_manifest(self,path):
        path=Path(path).expanduser().resolve();self.verify_integrity(full=True);self._set_relative_paths(path)
        _validate_manifest(self._manifest)
        payload=json.dumps(self._manifest,indent=2,ensure_ascii=False,allow_nan=False)+'\n'
        if len(payload.encode('utf-8'))>MAX_MANIFEST_BYTES:raise ValueError('Study evidence exceeds the manifest size bound.')
        path.parent.mkdir(parents=True,exist_ok=True)
        if path.exists():
            if path.read_text(encoding='utf-8')!=payload:raise ValueError('A study manifest already exists; it is never overwritten with changed evidence.')
        else:
            temporary=path.parent/f'.study-{uuid.uuid4().hex}.tmp'
            try:temporary.write_text(payload,encoding='utf-8');temporary.replace(path)
            finally:temporary.unlink(missing_ok=True)
        path.chmod(0o444);self.source_path=str(path);self.source_hash=_sha(path)
        self._manifest_hash=self.source_hash;self._manifest_stat=_stat(path)
        return self.source_path

    @classmethod
    def open(cls,manifest_path):
        path=Path(manifest_path).expanduser().resolve()
        if not path.is_file() or path.stat().st_size>MAX_MANIFEST_BYTES:raise ValueError('The study manifest is missing or exceeds its supported size.')
        try:evidence=_validate_manifest(json.loads(path.read_text(encoding='utf-8')))
        except (ValueError,TypeError,UnicodeError) as error:raise ValueError('The saved study manifest is invalid: '+str(error)) from error
        obj=cls.__new__(cls);obj.source_path=str(path);obj.source_hash=_sha(path);obj._manifest_hash=obj.source_hash
        obj._manifest=deepcopy(evidence);obj._manifest_stat=_stat(path);obj._paths={};obj._source_stats={}
        for source in evidence['sources']:
            candidate=(path.parent/source['relative_path']).resolve()
            if not candidate.is_relative_to(path.parent) or candidate==path or not candidate.is_file():raise ValueError('A saved study source points outside the project or is missing.')
            if candidate.name!=source['original_name']:raise ValueError('A saved study source basename differs from its evidence.')
            if candidate.stat().st_size!=source['bytes'] or _sha(candidate)!=source['sha256']:raise ValueError('A preserved study source changed; opening stopped.')
            obj._paths[source['source_id']]=candidate;obj._source_stats[source['source_id']]=_stat(candidate)
        return obj

    def verify_integrity(self,full=False):
        try:
            if self.source_path:
                if Path(self.source_path).resolve()!=Path(self.source_path):raise ValueError('The study manifest path changed through a symbolic link; planning stopped.')
                current=_stat(self.source_path)
                if full or current!=self._manifest_stat:
                    if _sha(self.source_path)!=self._manifest_hash:raise ValueError('The study manifest changed; planning stopped.')
                    self._manifest_stat=current
            for source in self._manifest['sources']:
                sid=source['source_id']
                if self._paths[sid].resolve()!=self._paths[sid] or self.source_path and not self._paths[sid].is_relative_to(Path(self.source_path).parent):raise ValueError('A study source path changed or escaped its project; planning stopped.')
                current=_stat(self._paths[sid])
                if current[0]!=source['bytes']:raise ValueError('A preserved study source changed; planning stopped.')
                if full or current!=self._source_stats[sid]:
                    if _sha(self._paths[sid])!=source['sha256']:raise ValueError('A preserved study source changed; planning stopped.')
                    self._source_stats[sid]=current
        except OSError as error:raise ValueError('A study source or manifest is missing.') from error
        return True

    def model_context(self):
        self.verify_integrity()
        sources=[];schemas=[];registry={}
        for source in self._manifest['sources'][:20]:
            metadata=source['metadata']
            sheet_refs=[]
            for sheet in source['sheets'][:6]:
                key=_canonical(sheet['headers'])
                if key not in registry:
                    identity=f'H{len(schemas)+1:03d}';registry[key]=identity
                    schemas.append({'schema_id':identity,'headers':sheet['headers'][:64],
                        'omitted_headers':max(0,len(sheet['headers'])-64)})
                sheet_refs.append({'name':sheet['name'],'schema_id':registry[key],'inspection_scope':sheet['inspection_scope']})
            conditions=deepcopy(metadata['conditions'][:8])
            labels=[c[key] for c in conditions for key in ['label','short_label'] if isinstance(c.get(key),str)]
            prefix=commonprefix(labels) if labels else ''
            for condition in conditions:
                for key in ['label','short_label']:
                    if isinstance(condition.get(key),str):condition[key]=condition[key][len(prefix):]
            identifiers=metadata['source_identifiers']
            sources.append({'source_id':source['source_id'],'original_name':source['original_name'],'role':source['role'],
                'sheets':sheet_refs,
                'proposed_subject':{k:v for k,v in source['proposed_subject'].items() if k!='basis'},
                'proposed_session':{k:v for k,v in source['proposed_session'].items() if k!='basis'},
                'metadata':{'source_identifiers':{'observed_subject_values':source['proposed_subject']['observed_values'],
                    'metadata_genotype_literals':identifiers['metadata_genotype_literals']},
                    'calibration':metadata['calibration'],'condition_label_prefix':prefix,'conditions':conditions,
                    'reference_design_proposals':metadata.get('reference_design_proposals',[])[:8],
                    'reference_design_scope':'Bounded existing design rows; proposals only, never current-study confirmation.'}})
        grouped={}
        for issue in sorted(self._manifest['issues'],key=lambda i:('mapping' not in i['blocks'],i['id'])):
            # Individual conflicts retain full facts. Common readiness issues
            # are stated once with all affected source IDs, without repeating
            # the same calibration boilerplate for every file.
            key=issue['id'] if issue['type'] in {'subject_conflict','session_conflict','weight_conflict'} else issue['type']
            if key not in grouped:
                grouped[key]=deepcopy(issue);grouped[key]['source_ids']=[]
                if key!=issue['id']:grouped[key]['evidence']={'scope':'Source-specific literal evidence remains in intake manifest and metadata.'}
            grouped[key]['source_ids'].append(issue['source_id'])
        selected_issues=list(grouped.values())[:12]
        domain=self.domain;domain['evidence']=_unique([signal for source in self._manifest['sources'] for signal in source['metadata']['domain_signals']])
        all_sources=[{'source_id':s['source_id'],'original_name':s['original_name'],'role':s['role'],
            'proposed_subject':s['proposed_subject']['value'],'proposed_session':s['proposed_session']['value']} for s in self._manifest['sources']]
        result={'kind':'study','version':1,'domain':domain,'source_count':len(self._manifest['sources']),
            'all_sources':all_sources,'schema_registry':schemas,'sources':sources,'issues':selected_issues,'omitted_source_count':len(self._manifest['sources'])-len(sources),
            'omitted_issue_count':len(grouped)-len(selected_issues),
            'condition_label_encoding':'Prepend a source metadata.condition_label_prefix to each condition label/short_label to recover the exact source label.',
            'scope':'Bounded intake metadata and proposed identifiers only. No raw numeric outcome rows, source paths or per-breath samples; no analysis or pooling has run.'}
        result=_private_free(result)
        while len(_canonical(result).encode('utf-8'))>MAX_MODEL_BYTES and result['sources']:
            result['sources'].pop();result['omitted_source_count']+=1
        if len(_canonical(result).encode('utf-8'))>MAX_MODEL_BYTES:
            result['issues']=[];result['domain']['evidence']=result['domain']['evidence'][:3]
        while len(_canonical(result).encode('utf-8'))>MAX_MODEL_BYTES and result['schema_registry']:
            result['schema_registry'].pop()
        if len(_canonical(result).encode('utf-8'))>MAX_MODEL_BYTES:
            result['all_sources']=[{'source_id':s['source_id'],'original_name':s['original_name'][:48],
                'name_truncated':len(s['original_name'])>48,'role':s['role']} for s in all_sources]
        if len(_canonical(result).encode('utf-8'))>MAX_MODEL_BYTES:
            raise ValueError('Study model context exceeds its safe bound; use the complete local intake overview instead.')
        return result
