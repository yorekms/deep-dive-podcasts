"""Read-only conversational reporting from stored AP measurements."""


def _value(value,unit):
    return 'unavailable' if value is None else f'{value:.6g} {unit}'


def measurement_message(result,start=0,stop=8,event_id=None):
    if not result or result.get('method')!='action_potentials':
        raise ValueError('Measure action potentials first, then request their stored measurements.')
    if event_id:
        rows=[row for row in result.get('candidates',[]) if row['event_id']==event_id]
        if not rows:raise ValueError('That peak ID is not present in the current analysis. No new measurement was run.')
    else:
        events=result['events']
        if isinstance(start,bool) or isinstance(stop,bool) or not isinstance(start,int) or not isinstance(stop,int) or start<0 or stop<=start or stop-start>100:
            raise ValueError('Request up to 100 measurement rows at a time, numbered from 1.')
        if not events:return 'No accepted peaks are present in this analysis. Candidate decisions and analysis regions remain recorded.'
        if start>=len(events):raise ValueError(f'This analysis contains {len(events)} accepted peaks. Measurement row numbering starts at 1.')
        rows=events[start:min(stop,len(events))]
    lines=[]
    for row in rows:
        line=(f"{row['event_id']} · peak at {row['peak_time_s']:.6g} s within sweep {row['sweep']}: "
              f"baseline {_value(row.get('baseline_mv'),'mV')}; amplitude {_value(row.get('amplitude_mv'),'mV')}; "
              f"half-width {_value(row.get('half_width_ms'),'ms')}; previous ISI {_value(row.get('isi_ms'),'ms')}.")
        if not row.get('accepted',True):line+=' Candidate is rejected in the current review; it is not included in rates or accepted-event measurements.'
        flags=row.get('quality_flags',[])
        if flags:line+=' Notes: '+', '.join(str(flag).replace('_',' ') for flag in flags)+'.'
        lines.append(line)
    if not event_id:
        lines.append(f'Showing accepted measurement rows {start+1}–{start+len(rows)} of {len(result["events"])}. Peak IDs remain tied to original samples.')
        if start+len(rows)<len(result['events']):
            next_start=start+len(rows)+1
            lines.append(f'Ask “show measurements from {next_start} to {min(len(result["events"]),next_start+19)}”, or “show measurements for peak {rows[0]["event_id"]}”.')
    lines.append('Amplitude uses the stated local pre-peak median. ISI is unavailable for the first accepted peak of an included segment. These are stored values; no additional calculation or source edit was performed for this report.')
    return '\n'.join(lines)
