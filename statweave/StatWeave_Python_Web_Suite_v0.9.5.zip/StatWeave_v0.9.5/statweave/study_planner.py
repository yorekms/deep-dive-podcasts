"""Deterministic study intake conversation; records plans, never calculations."""
from __future__ import annotations

from copy import deepcopy
import json
import re

_MAX_TEXT = 12000
_PLANNING = 'Study planning only: no calculation, statistical test, or new figure has been run.'
_MODEL_PREFIX = 'Local model discussion — no new calculation was performed.\n\n'
_ACTION_FIELDS = {
    'study_show': set(), 'study_conflicts': set(), 'study_unknown': {'message'},
    'study_goal': {'goal'}, 'study_group': {'subjects', 'group'},
    'study_resolve_subject': {'source_id', 'value'}, 'study_resolve_session': {'source_id', 'value'},
    'study_accept_proposals': set(), 'study_confirm_mapping': set(),
    'study_pooling': {'pooling'}, 'study_select_method': {'method_id'},
    'study_figures': set(), 'study_confirm_plan': set(), 'study_confirm_goal': set(),
    'study_confirm_domain': {'domain'},
    'study_profile_save': {'name'}, 'study_profile_apply': {'name'},
    'study_export': {'include_source'},
}


def _manifest(study):
    value = study.manifest()
    if not isinstance(value, dict) or not isinstance(value.get('sources'), list):
        raise ValueError('The study did not provide an intake manifest.')
    return value


def _cards(study, state=None):
    from .study_methods import method_cards
    return method_cards(study, state)


def initial_state(study):
    _manifest(study)
    return {'goal': None, 'domain_confirmation': None, 'groups': {},
            'subject_resolutions': {}, 'session_resolutions': {},
            'mapping_confirmed': False, 'pooling': 'undecided',
            'approved_plan': False, 'selected_methods': [],
            'pending_proposal': None, 'proposed_figures': []}


def _bounded(value, label, limit=2000):
    if not isinstance(value, str) or not value.strip() or len(value) > limit or '\x00' in value:
        raise ValueError(f'{label} must contain 1–{limit} characters.')
    return value.strip()


def _value(text):
    text = text.strip()
    if len(text) >= 2 and text[0] == text[-1] and text[0] in '\"\'':
        text = text[1:-1]
    return _bounded(text, 'The value', 200)


def _proposal(source, name):
    value = source.get('proposed_' + name)
    return value.get('value') if isinstance(value, dict) else value


def _observations(study):
    return [source for source in _manifest(study)['sources'] if source.get('role') != 'reference_analysis']


def _invalidate(state, mapping=False):
    state['approved_plan'] = False
    state['proposed_figures'] = []
    if mapping:
        state['mapping_confirmed'] = False


def _mapping_gaps(study, state):
    gaps = []
    observations = _observations(study)
    observation_ids = {source.get('source_id') for source in observations}
    if not observations:
        gaps.append('No observation sources are identified; reference analyses cannot establish a study observation mapping')
    for source in observations:
        sid = source.get('source_id', '?')
        for kind in ('subject', 'session'):
            if sid not in state.get(kind + '_resolutions', {}):
                gaps.append(f'{sid}: confirm {kind} identity')
        subject = state.get('subject_resolutions', {}).get(sid)
        if subject is not None and str(subject) not in state.get('groups', {}):
            gaps.append(f'{sid}: assign subject {subject} to a group')
    # Identity conflicts cannot be accepted collectively from proposed filenames.
    for issue in _manifest(study).get('issues', []):
        if issue.get('source_id') in observation_ids and issue.get('type') in {'subject_conflict', 'session_conflict', 'identity_conflict'}:
            kind = 'session' if issue.get('type') == 'session_conflict' else 'subject'
            if issue.get('source_id') not in state.get(kind + '_resolutions', {}):
                gaps.append(f"{issue.get('id', 'Identity conflict')}: resolve the conflicting {kind}")
    return list(dict.fromkeys(gaps))


def _questions(study, state):
    questions = []
    if not state.get('goal'):
        questions.append('What biological or practical question should this study answer? You can say “my goal is …”.')
    if not state.get('mapping_confirmed'):
        gaps = _mapping_gaps(study, state)
        if gaps:
            questions.append('Which source-to-subject/session mappings and group assignments are correct? First: ' + '; '.join(gaps[:2]) + '.')
        else:
            questions.append('Have you reviewed the subject, session, and group mapping? Say “confirm study mapping” when ready.')
    if state.get('pooling') == 'undecided':
        questions.append('Should trials remain separate, or receive equal weight within each subject? This choice is recorded as a plan only.')
    if not questions and not state.get('selected_methods'):
        questions.append('Which candidate method should we develop? Use “suggest analyses”, then “select method CARD_ID”.')
    if not questions and not state.get('approved_plan'):
        questions.append('Would you like to review proposed figures and then acknowledge the analysis plan?')
    return questions[:3]


def study_reply(study, state):
    manifest = _manifest(study)
    domain = manifest.get('domain', {})
    domain_name = domain.get('name', 'unknown') if isinstance(domain, dict) else 'unknown'
    issues = manifest.get('issues', [])
    sources = manifest['sources']
    refs = sum(source.get('role') == 'reference_analysis' for source in sources)
    message = (f"Study intake contains {len(sources)} source file(s), including {refs} reference/derived analysis file(s). "
               f"Proposed domain: {domain_name}. Metadata issues: {len(issues)}. "
               f"Goal: {state.get('goal') or 'not yet stated'}. "
               f"Mapping: {'confirmed by you' if state.get('mapping_confirmed') else 'awaiting your review'}. "
               f"Trial handling: {state.get('pooling', 'undecided').replace('_', ' ')}. "
               f"Selected methods: {', '.join(state.get('selected_methods', [])) or 'none'}.\n\n" + _PLANNING)
    questions = _questions(study, state)
    if questions:
        message += '\n\nNext useful questions:\n' + '\n'.join(f'{i + 1}. {q}' for i, q in enumerate(questions))
    return message


def _method_message(study, state, hcvr=False):
    cards = _cards(study, state)
    if hcvr:
        chosen = [card for card in cards if card['id'].startswith('pleth_')]
        if not chosen:
            return ('HCVR planning needs evidence that these sources describe a CO₂ respiratory challenge. '
                    'The intake has not established that domain. What signal is measured, what are its units, '
                    'and how were CO₂ levels or PCO₂ calibrated? ' + _PLANNING)
        cards = chosen
    lines = [_PLANNING, 'Candidate methods (a suggestion does not select or approve one):']
    for card in cards:
        readiness = card.get('readiness', {})
        missing = readiness.get('missing', []) if isinstance(readiness, dict) else []
        execution = card.get('execution_status', {})
        status = execution.get('message', 'Planning only; study execution is unavailable.') if isinstance(execution, dict) else str(execution)
        line = f"{card['id']}: {card['title']}. {card.get('question', '')} {status}"
        if missing:
            line += ' Needed: ' + '; '.join(map(str, missing[:4])) + '.'
        lines.append(line)
    return '\n\n'.join(lines)


def interpret_study(text, study, state):
    """Return one closed offline command; unknown scientific questions may use LLM."""
    if not isinstance(text, str) or not text.strip() or len(text) > _MAX_TEXT:
        return {'action': 'study_unknown', 'message': 'Enter one study instruction of 1–12,000 characters. ' + _PLANNING}
    text = text.strip()
    simple = text.rstrip('.!?').strip()
    if re.search(r"\b(?:don't|do not|never)\b", simple, re.I):
        return {'action': 'study_unknown', 'message': 'Negated instructions are not applied automatically. State one positive planning instruction. ' + _PLANNING, 'unsupported': True}
    if re.search(r'[;\n]|\b(?:and|then)\s+(?:confirm|resolve|group|select|choose|save|apply|export|run|fit|calculate|compute)\b', simple, re.I):
        return {'action': 'study_unknown', 'message': 'Give one planning or review action at a time; no part of a combined instruction was applied. ' + _PLANNING, 'unsupported': True}
    exact = {
        'show study': 'study_show', 'show study plan': 'study_show', 'show analysis plan': 'study_show',
        'show metadata conflicts': 'study_conflicts', 'show conflicts': 'study_conflicts',
        'confirm study mapping': 'study_confirm_mapping',
        'accept proposed subject and session mappings': 'study_accept_proposals',
        'accept proposed mappings': 'study_accept_proposals',
        'confirm proposed subject and session mappings': 'study_accept_proposals',
        'confirm analysis plan': 'study_confirm_plan', 'confirm proposed goal': 'study_confirm_goal',
        'plan figures': 'study_figures',
    }
    action = exact.get(simple.lower())
    if action:
        return {'action': action}
    if simple.lower() in ('suggest analyses', 'suggest analysis', 'discuss hcvr', 'explain hcvr'):
        return {'action': 'study_discuss', 'message': _method_message(study, state, 'hcvr' in simple.lower()),
                'questions': _questions(study, state), 'suggested_methods': [c['id'] for c in _cards(study, state) if 'hcvr' not in simple.lower() or c['id'].startswith('pleth_')]}
    match = re.fullmatch(r'(?:my goal is|my aim is|set (?:my )?goal to)\s+(.+)', simple, re.I)
    if match:
        return {'action': 'study_goal', 'goal': _bounded(match[1], 'The study goal')}
    match = re.fullmatch(r'group (?:subjects?|mice|animals?|participants?|patients?)\s+(.+?)\s+as\s+(.+)', simple, re.I)
    if match:
        raw = re.split(r'\s*,\s*|\s+and\s+', match[1])
        if not raw or len(raw) > 100 or any(not re.fullmatch(r'[\w.-]{1,100}', item) for item in raw):
            return {'action': 'study_unknown', 'message': 'List explicit subject IDs separated by commas, followed by “as GROUP”.', 'unsupported': True}
        return {'action': 'study_group', 'subjects': list(dict.fromkeys(raw)), 'group': _value(match[2])}
    match = re.fullmatch(r'resolve source\s+(S\d{3})\s+(subject|session)\s+as\s+(.+)', simple, re.I)
    if match:
        return {'action': 'study_resolve_' + match[2].lower(), 'source_id': match[1].upper(), 'value': _value(match[3])}
    match = re.fullmatch(r'(?:select|choose) method\s+([a-z][a-z0-9_]{0,100})', simple, re.I)
    if match:
        return {'action': 'study_select_method', 'method_id': match[1].lower()}
    match = re.fullmatch(r'(?:select|choose)(?:\s+method)?\s+["\x27]?(.+?)["\x27]?', simple, re.I)
    if match:
        label=match[1].strip().casefold()
        aliases={'descriptive overview':'study_descriptive_overview','study design comparison':'study_design_comparison',
                 'co2 response curve':'pleth_co2_response_curve','co₂ response curve':'pleth_co2_response_curve',
                 'hcvr slope':'pleth_ventilation_hcvr_slope','minute ventilation hcvr slope':'pleth_ventilation_hcvr_slope',
                 'frequency response':'pleth_frequency_response','baseline normalization':'pleth_baseline_normalization',
                 'repeated measures':'study_repeated_measures','bayesian hierarchical model':'study_bayesian_hierarchical'}
        cards=_cards(study,state)
        exact=next((c['id'] for c in cards if c['title'].casefold()==label),None)
        method=exact or aliases.get(label)
        if method and method in {c['id'] for c in cards}:return {'action':'study_select_method','method_id':method}
    if simple.lower() in ('keep trials separate', 'pool trials equally within subject'):
        return {'action': 'study_pooling', 'pooling': 'separate' if simple.lower().startswith('keep') else 'equal_within_subject'}
    match = re.fullmatch(r'confirm (?:study )?domain as\s+(.+)', simple, re.I)
    if match:
        return {'action': 'study_confirm_domain', 'domain': _value(match[1])}
    match = re.fullmatch(r'(save|apply) import profile\s+([\w][\w .-]{0,79})', simple, re.I)
    if match:
        return {'action': 'study_profile_' + ('save' if match[1].lower() == 'save' else 'apply'), 'name': match[2].strip()}
    if simple.lower() in ('export study plan', 'export study plan with sources', 'export study plan including sources'):
        return {'action': 'study_export', 'include_source': simple.lower() != 'export study plan'}
    if re.match(r'^(?:export|save\s+(?:a\s+|the\s+)?(?:figure|plot|chart))\b',simple,re.I):
        return {'action':'study_unknown','unsupported':True,'message':'Study mode exports a Markdown/JSON planning package. No scientific figure has been calculated. Use “export study plan” to save the proposal and source record.'}
    if re.search(r'\b(?:delete|prune|remove|winsori[sz]e|outliers?|significan\w*|p\s*[<-])\b', simple, re.I):
        # Discussion about significance is allowed; commands to optimize/delete are not.
        if re.search(r'\b(?:delete|prune|remove|winsori[sz]e|optimi[sz]e|make|hide|drop|exclude)\b', simple, re.I):
            return {'action': 'study_unknown', 'message': 'Source pruning and significance optimization are not supported. We can record the study question, design, and transparent inclusion rules for review. ' + _PLANNING, 'unsupported': True}
    if re.match(r'^(?:please\s+)?(?:run|analy[sz]e|test|fit|calculate|compute)\b', simple, re.I) and re.search(r'\b(?:anova|bayesian|mixed[- ]effects?|mixed models?|t[- ]test)\b',simple,re.I):
        return {'action':'study_unknown','unsupported':True,'message':'That method is not implemented for this study adapter. We can discuss its design and requirements; no calculation was run.'}
    if re.match(r'^(?:please\s+)?(?:run|analy[sz]e|test|fit|calculate|compute)\b', simple, re.I):
        return {'action': 'study_unknown', 'message': 'Tell me the outcome and scientific contrast you want to examine. I can discuss a supported analysis, show its choices and ask for your agreement before running it. The optional local model can interpret a more detailed request; no calculation was run.', 'unsupported': False}
    return {'action': 'study_unknown', 'message': 'We can discuss the scientific question, experimental units, metadata, candidate methods, and figure plans. ' + study_reply(study, state)}


def apply_study_command(study, state, command):
    """Copy state, validate one action, and return a planning-only response."""
    if not isinstance(command, dict) or not isinstance(command.get('action'), str):
        raise ValueError('Invalid study command.')
    action = command['action']
    if action == 'study_discuss':
        response = validate_discussion(command, study, state)
        updated = deepcopy(state)
        if response.get('proposed_goal'):
            updated['pending_proposal'] = {'goal': response['proposed_goal'], 'origin': 'local_model', 'status': 'proposed'}
        message = response['message']
        if response['questions']:
            message += '\n\n' + '\n'.join(f'{i + 1}. {q}' for i, q in enumerate(response['questions']))
        return updated, message
    fields = _ACTION_FIELDS.get(action)
    if fields is None or set(command) - ({'action', 'unsupported'} | fields):
        raise ValueError('Unsupported study command fields; no state was changed.')
    if fields - set(command):
        raise ValueError('The study command is missing a required field.')
    updated = deepcopy(state)
    if action == 'study_unknown':
        return updated, _bounded(command['message'], 'The explanation', 12000)
    if action == 'study_show':
        return updated, study_reply(study, updated)
    if action == 'study_conflicts':
        issues = _manifest(study).get('issues', [])
        lines = [f"{issue.get('id', '?')} ({issue.get('source_id', 'study')}): {issue.get('message', issue.get('type', 'metadata issue'))}. Affects: {', '.join(issue.get('blocks', [])) or 'review only'}." for issue in issues[:24]]
        if len(issues)>24:
            lines.append(f'{len(issues)-24} more issue(s) remain in the complete intake manifest and metadata view.')
        return updated, ('\n'.join(lines) if lines else 'No metadata issues were identified by the bounded intake checks.') + '\n\n' + _PLANNING
    if action == 'study_goal':
        updated['goal'] = _bounded(command['goal'], 'The study goal')
        updated['pending_proposal'] = None
        _invalidate(updated)
    elif action == 'study_confirm_goal':
        pending = updated.get('pending_proposal')
        if not isinstance(pending, dict) or not pending.get('goal'):
            raise ValueError('There is no pending model-proposed goal to confirm.')
        updated['goal'] = _bounded(pending['goal'], 'The study goal')
        updated['pending_proposal'] = None
        _invalidate(updated)
    elif action == 'study_group':
        subjects = command['subjects']
        if not isinstance(subjects, list) or not 1 <= len(subjects) <= 100 or any(not isinstance(s, str) or not re.fullmatch(r'[\w.-]{1,100}', s) for s in subjects):
            raise ValueError('Supply 1–100 explicit subject IDs.')
        known = {str(_proposal(source, 'subject')) for source in _observations(study) if _proposal(source, 'subject') is not None}
        known.update(map(str, updated.get('subject_resolutions', {}).values()))
        if set(subjects) - known:
            raise ValueError('A group assignment names an unknown subject. Resolve a source subject identity first.')
        group = _bounded(command['group'], 'The group label', 200)
        updated.setdefault('groups', {}).update({s: group for s in subjects})
        _invalidate(updated, mapping=True)
    elif action in ('study_resolve_subject', 'study_resolve_session'):
        sid = command['source_id']
        if sid not in {source.get('source_id') for source in _observations(study)}:
            raise ValueError('Resolve an existing observation source ID, not a reference analysis or unknown source.')
        kind = action.removeprefix('study_resolve_')
        updated.setdefault(kind + '_resolutions', {})[sid] = _bounded(command['value'], 'The resolved identity', 200)
        _invalidate(updated, mapping=True)
    elif action == 'study_accept_proposals':
        conflicts = {(issue.get('source_id'),'session' if issue.get('type')=='session_conflict' else 'subject')
                     for issue in _manifest(study).get('issues', []) if issue.get('type') in {'subject_conflict','session_conflict','identity_conflict'}}
        missing = []
        for source in _observations(study):
            sid = source.get('source_id')
            for kind in ('subject', 'session'):
                if sid in updated.get(kind + '_resolutions', {}):
                    continue
                value = _proposal(source, kind)
                if (sid,kind) in conflicts or value is None or str(value).strip() == '':
                    missing.append(f'{sid} {kind}')
                else:
                    updated.setdefault(kind + '_resolutions', {})[sid] = str(value)
        if missing:
            raise ValueError('Proposals with missing/conflicting identities require explicit resolution first: ' + ', '.join(missing[:8]) + '.')
        _invalidate(updated, mapping=True)
    elif action == 'study_confirm_mapping':
        gaps = _mapping_gaps(study, updated)
        if gaps:
            raise ValueError('Study mapping remains unconfirmed: ' + '; '.join(gaps[:8]) + '. Review and explicitly resolve or accept proposed mappings, and assign groups.')
        updated['mapping_confirmed'] = True
        _invalidate(updated)
    elif action == 'study_pooling':
        if command['pooling'] not in ('separate', 'equal_within_subject'):
            raise ValueError('Choose separate trials or equal weighting within subject.')
        updated['pooling'] = command['pooling']
        _invalidate(updated)
    elif action == 'study_confirm_domain':
        updated['domain_confirmation'] = _bounded(command['domain'], 'The confirmed domain', 200)
        _invalidate(updated)
    elif action == 'study_select_method':
        method = command['method_id']
        if method not in {card['id'] for card in _cards(study, updated)}:
            raise ValueError('Choose a method ID from the current study method cards.')
        if method not in updated.setdefault('selected_methods', []):
            updated['selected_methods'].append(method)
        _invalidate(updated)
    elif action == 'study_figures':
        cards = _cards(study, updated)
        chosen = updated.get('selected_methods', [])
        updated['proposed_figures'] = [{'method_id': card['id'], 'proposal': deepcopy(card.get('suggested_figure'))} for card in cards if not chosen or card['id'] in chosen]
        return updated, 'Figure proposals only; no figure has been calculated or rendered:\n\n' + '\n\n'.join(f"{row['method_id']}: {row['proposal']}" for row in updated['proposed_figures'])
    elif action == 'study_confirm_plan':
        if not updated.get('goal') or not updated.get('mapping_confirmed') or not updated.get('selected_methods'):
            raise ValueError('State a goal, confirm study mapping, and select at least one method before acknowledging the plan.')
        if _mapping_gaps(study, updated):
            raise ValueError('The source-to-subject/session mapping still needs review.')
        updated['approved_plan'] = True
        return updated, 'You acknowledged the analysis plan. This records your review only; it does not authorize or run a calculation. ' + _PLANNING
    else:
        raise ValueError('This command requires the Session profile/export handler; no planning state was changed.')
    return updated, study_reply(study, updated)


def discussion_schema(study, state):
    from .study_execution import OUTCOMES
    from .llm import _schema
    ids = [card['id'] for card in _cards(study, state)]
    return {'type': 'object', 'additionalProperties': False,
            'required': ['action', 'message', 'questions', 'suggested_methods'], 'properties': {
                'action': {'type': 'string', 'enum': ['study_discuss']},
                'message': {'type': 'string', 'minLength': 1, 'maxLength': 6000},
                'questions': {'type': 'array', 'maxItems': 3, 'items': {'type': 'string', 'minLength': 1, 'maxLength': 1000}},
                'suggested_methods': {'type': 'array', 'maxItems': len(ids), 'uniqueItems': True, 'items': {'type': 'string', 'enum': ids}},
                'proposed_goal': {'type': 'string', 'minLength': 1, 'maxLength': 2000},
                'proposed_action': {'type': 'object', 'additionalProperties': False, 'required': ['intent'], 'properties': {
                    'intent': {'type': 'string', 'enum': ['report_measures', 'response_curve', 'co2_slopes', 'normalize', 'style', 'export']},
                    'outcome': {'type': ['string', 'null'], 'enum': [*OUTCOMES, None]},
                    'normalization': {'type': ['string', 'null'], 'enum': ['none', 'fold_baseline', 'percent_baseline', 'percent_change', None]},
                    'normalization_order': {'type': ['string', 'null'], 'enum': ['after_pooling', 'within_trial', None]},
                    'pooling': {'type': ['string', 'null'], 'enum': ['equal_within_subject', 'separate', None]},
                    'inference': {'type': ['string', 'null'], 'enum': ['none', 'welch_slopes', None]},
                    'fit_doses': {'type': 'array', 'maxItems': 20, 'uniqueItems': True,
                                  'items': {'type': 'number', 'minimum': 0, 'maximum': 100}},
                    'style': _schema()['properties']['style']}}}}


def validate_proposed_action(value):
    """Validate a model suggestion; this never declares design or authorizes a run."""
    from .study_execution import OUTCOMES
    from .llm import _validate_style, _finite_number
    allowed={'intent','outcome','normalization','normalization_order','pooling','inference','fit_doses','style'}
    if not isinstance(value,dict) or set(value)-allowed:
        raise ValueError('The model proposed unsupported analysis choices; no action was approved.')
    intent=value.get('intent')
    if not isinstance(intent,str) or intent not in {'report_measures','response_curve','co2_slopes','normalize','style','export'}:
        raise ValueError('The model proposed an unsupported study action.')
    for key,choices in [('outcome',set(OUTCOMES)),('normalization',{'none','fold_baseline','percent_baseline','percent_change'}),
                        ('normalization_order',{'after_pooling','within_trial'}),('pooling',{'equal_within_subject','separate'}),
                        ('inference',{'none','welch_slopes'})]:
        if key in value and value[key] is not None and (not isinstance(value[key],str) or value[key] not in choices):
            raise ValueError('The model proposed an invalid '+key.replace('_',' ')+'.')
    if 'fit_doses' in value:
        doses=value['fit_doses']
        if not isinstance(doses,list) or len(doses)>20 or any(not _finite_number(dose) or not 0<=dose<=100 for dose in doses) or len(set(doses))!=len(doses):
            raise ValueError('The model proposed invalid inspired CO2 concentrations.')
    if 'style' in value:_validate_style(value['style'])
    if intent=='style' and (not value.get('style') or set(value)-{'intent','style'}):
        raise ValueError('A presentation suggestion must contain appearance settings only.')
    if intent=='export' and set(value)-{'intent'}:
        raise ValueError('An export suggestion cannot select paths, sources or scientific settings.')
    if intent!='style' and 'style' in value:
        raise ValueError('Discuss appearance and scientific choices as separate proposals.')
    return deepcopy(value)


def validate_discussion(value, study, state):
    if not isinstance(value, dict) or set(value) - {'action', 'message', 'questions', 'suggested_methods', 'proposed_goal', 'proposed_action'} or value.get('action') != 'study_discuss':
        raise ValueError('The local model may discuss a study plan only; it cannot calculate, execute code, export, or confirm state.')
    required = {'action', 'message', 'questions', 'suggested_methods'}
    if not required <= set(value):
        raise ValueError('The study discussion is missing its structured fields.')
    result = deepcopy(value)
    model_labeled = isinstance(value['message'], str) and value['message'].startswith(_MODEL_PREFIX)
    body = value['message'][len(_MODEL_PREFIX):] if model_labeled else value['message']
    result['message'] = _bounded(body, 'The model explanation', 6000)
    questions = value['questions']
    if not isinstance(questions, list) or len(questions) > 3:
        raise ValueError('The model may ask at most three next questions.')
    result['questions'] = [_bounded(q, 'A study question', 1000) for q in questions]
    methods = value['suggested_methods']
    cards = _cards(study, state)
    ids = {card['id'] for card in cards}
    if not isinstance(methods, list) or any(not isinstance(m, str) or m not in ids for m in methods) or len(set(methods)) != len(methods):
        raise ValueError('The model suggested a method outside the current planning cards.')
    if 'proposed_goal' in value:
        result['proposed_goal'] = _bounded(value['proposed_goal'], 'The proposed goal')
    if 'proposed_action' in value:
        result['proposed_action']=validate_proposed_action(value['proposed_action'])
    bibliography = [source for card in cards for source in card.get('sources', []) if isinstance(source, dict)]
    allowed_urls = {source.get('url') for source in bibliography}
    allowed_dois = {str(source.get('doi', '')).lower() for source in bibliography if source.get('doi')}
    all_text = '\n'.join([result['message'], *result['questions'], result.get('proposed_goal', '')])
    for url in re.findall(r'https?://[^\s<>\]\)]+', all_text):
        if url.rstrip('.,;') not in allowed_urls and not (url.lower().startswith('https://doi.org/') and url[16:].lower().rstrip('.,;') in allowed_dois):
            raise ValueError('The model cited an unreviewed source URL. Use the supplied method-card bibliography only.')
    known_ids = {source.get('id') for source in bibliography}
    for citation in re.findall(r'\[([a-z][a-z0-9_]+_\d{4}[a-z0-9_]*)\]', all_text, re.I):
        if citation not in known_ids:
            raise ValueError('The model cited an unknown bibliography ID.')
    if model_labeled or not result['message'].startswith('Study planning only:'):
        result['message'] = _MODEL_PREFIX + result['message']
    return result
