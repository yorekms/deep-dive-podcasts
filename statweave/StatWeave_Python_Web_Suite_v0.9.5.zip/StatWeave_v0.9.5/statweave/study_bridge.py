"""Explicit human review and execution of closed, versioned study recipes.

Only literal user instructions enter this module. Model responses stay in the
planning-only validator. Scientific state, recipe approval and results are
separate records, with failed requests retaining the previous result.
"""
from copy import deepcopy
from datetime import datetime
import hashlib
import json
from pathlib import Path
import re
import shutil
import sys
import uuid


ADAPTERS = {
    'pleth_summary_v1': {
        'title': 'Standard plethysmography Summary workbooks',
        'methods': ['response_curve', 'co2_slope'],
        'source_format': 'XLSX Metadata + Summary + PerBreath schema; Summary values only',
    },
    'pleth_summary_report_v1': {
        'title': 'Available-measure pleth Summary report',
        'methods': ['measure_report'],
        'source_format': 'Closed measure registry; per-measure readiness, descriptives and supported figures',
    },
}


def _hash(value):
    from .session import canonical
    return hashlib.sha256(canonical(value).encode()).hexdigest()


def _execution(session):
    return session.context.setdefault('study_execution', {
        'options': {'method': 'response_curve', 'normalization': 'none',
                    'normalization_order': 'after_pooling', 'inference': 'none',
                    'independent_subjects': False, 'fit_doses': []},
        'candidate_recipe': None, 'approved_digest': None, 'runs': [],
    })


def invalidate_approval(session):
    execution=session.context.get('study_execution')
    if execution:
        execution['candidate_recipe']=None
        execution['approved_digest']=None
        execution.pop('approved_state_sha256',None)


def result_is_current(session):
    execution=session.context.get('study_execution',{})
    return bool(session.result and session.result.get('method')=='study_execution'
        and execution.get('last_state_sha256')==_hash(session.context['study_state'])
        and execution.get('last_options_sha256')==_hash(execution.get('options',{})))


def verify_run_records(session,full=False):
    """Verify registered run artifacts independently of embedded project results."""
    from .session import sha256
    root=session.project_dir.resolve()
    for run in session.context.get('study_execution',{}).get('runs',[]):
        directory=(root/run['directory']).resolve()
        if not directory.is_relative_to(root/'runs') or not directory.is_dir():
            raise ValueError('A registered study execution run is missing or outside the project.')
        for name,digest in run['files'].items():
            path=(directory/name).resolve()
            if not path.is_relative_to(directory) or not path.is_file():raise ValueError('A recorded study run artifact is missing or outside its run.')
            if full and sha256(path)!=digest:raise ValueError('A recorded study run artifact changed outside its processing history.')
        if full:
            try:recorded=json.loads((directory/'SHA256.json').read_text())
            except (OSError,ValueError):raise ValueError('The recorded run checksum manifest is missing or invalid.') from None
            if recorded!=run['files']:raise ValueError('The recorded run checksum manifest changed outside its processing history.')
    return True


def status_text(session):
    execution=session.context.get('study_execution',{})
    if session.result and session.result.get('method')=='study_execution':
        return ('Completed result matches current scientific choices.' if result_is_current(session)
                else 'Historical result: scientific choices have changed. Review, confirm and run the revised recipe to update it.')
    if execution.get('approved_digest'):
        return 'Exact recipe confirmed; ready for “run agreed analysis”.'
    return 'Review and confirm an execution recipe before running an analysis.'


def _staged_options(session):
    options=deepcopy(_execution(session)['options'])
    options['pooling']=session.context['study_state'].get('pooling','undecided')
    return options


def _set(session,**values):
    execution=_execution(session)
    execution['options'].update(values)
    invalidate_approval(session)
    session._event('study_execution_choices',{'changes':values,'approval_invalidated':True})


def _windows(session):
    from .study_execution import inspect_summary
    return inspect_summary(session.dataset)


def propose_windows(session):
    """Candidate phases from labels/time; never an automatic omission."""
    rows=_windows(session);result=[]
    for sid in dict.fromkeys(row['source_id'] for row in rows):
        source=[r for r in rows if r['source_id']==sid]
        source.sort(key=lambda r:(r.get('start_s') if isinstance(r.get('start_s'),(int,float)) else float('inf'),r['row']))
        doses=[]
        for row in source:
            dose=row.get('observed_co2_percent')
            if type(dose) not in (int,float):
                tokens=set(re.findall(r'(?<![\d.])(\d+(?:\.\d+)?)\s*%',str(row.get('label',''))+' '+str(row.get('short_label',''))))
                dose=float(next(iter(tokens))) if len(tokens)==1 else None
            doses.append(dose)
        positive=[i for i,d in enumerate(doses) if type(d) in (int,float) and d>0]
        for i,(row,dose) in enumerate(zip(source,doses)):
            phase=('exposure' if type(dose) in (int,float) and dose>0 else
                   'baseline' if dose==0 and positive and i<min(positive) else
                   'recovery' if dose==0 and positive and i>max(positive) else None)
            result.append({'source_id':sid,'row':row['row'],'phase':phase,'co2_percent':dose,
                'reason':'Proposed from source concentration labels and temporal order; included only after exact recipe review.'})
    return result


def windows_text(session):
    rows=_windows(session)
    choices={(w['source_id'],w['row']):w for w in _execution(session)['options'].get('windows',[])}
    lines=['Summary window ledger (physical worksheet rows; no source edits):']
    for row in rows:
        choice=choices.get((row['source_id'],row['row']),{})
        lines.append(f"{row['source_id']} row {row['row']}: {row.get('start_s')}–{row.get('end_s')} s · "
                     f"{choice.get('phase') or 'phase unassigned'} · CO₂ {choice.get('co2_percent')}% · {row.get('short_label') or row.get('label')}")
        if choice.get('phase')=='omit':lines.append('  Omission reason: '+choice.get('reason',''))
    return '\n'.join(lines)


def recipe_text(recipe):
    from .study_execution import recipe_digest
    options=recipe['options'];endpoint=recipe.get('endpoint',{})
    lines=['Execution recipe · '+recipe['adapter_id'],
        'Digest: '+recipe_digest(recipe),
        'Outcome: '+str(endpoint.get('label',options['outcome']))+' · '+str(endpoint.get('unit','')),
        'Method: '+options['method']+'; experimental unit: subject',
        'Trials: '+options['pooling']+'; normalization: '+options['normalization']+'; order: '+options['normalization_order'],
        'Slope concentrations (% inspired CO₂): '+str(options['fit_doses']),
        'Group inference: '+options['inference']+'; independent subjects declared: '+str(options['independent_subjects']),
        'Source → subject / session / group:']
    for binding in recipe.get('source_bindings',[]):
        lines.append(f"{binding['source_id']} → {binding['subject']} / {binding['session']} / {binding['group']}")
    if options.get('inference')=='welch_slopes':
        groups=sorted({b['group'] for b in recipe['source_bindings']})
        if len(groups)==2:lines.append('Signed slope contrast: '+groups[0]+' minus '+groups[1])
    lines.append('All source Summary rows, including explicitly omitted windows:')
    for w in options['windows']:
        lines.append(f"{w['source_id']} row {w['row']}: {w['phase']} · {w['co2_percent']}% · {w.get('reason','')}")
    if recipe.get('adapter_id')=='pleth_summary_report_v1':
        lines+=['','Available-measure report: every registered source measure is inventoried. Only supported, complete and calibrated measures receive study curves; blocked measures retain their counts and explanation. No automatic group testing.']
        for measure in recipe.get('measures',[]):
            counts=measure.get('counts',{})
            lines.append(f"{measure['outcome']} · {measure.get('unit','')} · {measure['status']}: "
                f"{counts.get('numeric_windows',0)} numeric / {counts.get('missing_windows',0)} missing / {counts.get('invalid_windows',0)} invalid admitted windows. {measure.get('reason','')}")
        lines.append('The full bound child recipes are retained in the saved execution record; all share the window and subject roster printed above.')
    lines+=['','Review this exact recipe, then say “confirm execution recipe”. Confirmation records these scientific choices; “run agreed analysis” performs the calculation.']
    return '\n'.join(lines)


def _compile(session):
    from .study_execution import build_recipe,build_report_recipe
    options=_staged_options(session)
    builder=build_report_recipe if options.get('method')=='measure_report' else build_recipe
    return builder(session.dataset,session.context['study_state'],options)


def _run(session):
    from .study_execution import run_recipe,run_report_recipe,recipe_digest
    from .session import canonical,clean,sha256,versions
    execution=_execution(session)
    if not execution.get('approved_digest') or not execution.get('candidate_recipe'):
        raise ValueError('Review the execution recipe and explicitly confirm it before running. No calculation was run.')
    recipe=_compile(session)
    digest=recipe_digest(recipe)
    if digest!=execution['approved_digest'] or execution.get('approved_state_sha256')!=_hash(session.context['study_state']):
        raise ValueError('Scientific choices changed after recipe approval. Review and confirm the current recipe before running.')
    from .storage import require_space, MIB
    require_space(session.project_dir, 64 * MIB, 'run and record an analysis')
    session._assert_integrity(full=True)
    runner=run_report_recipe if recipe['adapter_id']=='pleth_summary_report_v1' else run_recipe
    result=runner(session.dataset,session.context['study_state'],recipe)
    if not session.defer_figure_validation:
        from .study_figures import make_figure
        make_figure(session.dataset,result,recipe,session.style)
    session._assert_integrity(full=True)
    run_id=f'{datetime.now():%Y%m%d-%H%M%S}-{uuid.uuid4().hex[:8]}'
    folder=session.project_dir/'runs'/run_id
    folder.mkdir(parents=True,exist_ok=False)
    try:
        files={'recipe.json':recipe,'result.json':result,'environment.json':versions(),
               'planning-state.json':deepcopy(session.context['study_state']),
               'processing-steps.json':result.get('processing_steps',[])}
        for name,value in files.items():
            (folder/name).write_text(json.dumps(clean(value),indent=2,ensure_ascii=False,allow_nan=False))
        module_root=Path(__file__).parent
        if getattr(sys,'frozen',False):module_root=Path(sys._MEIPASS)/'reproduction-source/statweave'
        code=folder/'reproduction-source/statweave';code.mkdir(parents=True)
        for name in ['__init__.py','scrubber.py','study.py','study_execution.py','study_figures.py','figures.py']:
            shutil.copy2(module_root/name,code/name)
        hashes={str(path.relative_to(folder)):sha256(path) for path in sorted(folder.rglob('*')) if path.is_file()}
        (folder/'SHA256.json').write_text(json.dumps(hashes,indent=2))
        for path in folder.rglob('*'):
            if path.is_file():path.chmod(0o444)
        run={'run_id':run_id,'recipe_sha256':digest,'directory':str(folder.relative_to(session.project_dir)),
             'files':hashes,'state_sha256':_hash(session.context['study_state']),
             'options_sha256':_hash(execution['options'])}
        execution['runs'].append(run)
        execution.update(last_state_sha256=run['state_sha256'],last_options_sha256=run['options_sha256'])
        session.plan={'action':'study_execution','recipe':recipe,'recipe_sha256':digest,'run_id':run_id}
        session.result=clean(result)
        for index,step in enumerate(result.get('processing_steps',[]),1):
            session._event('study_processing_step',{'run_id':run_id,'step_number':index,'step':step})
        session._event('study_analysis_completed',{'run':run,'result_sha256':_hash(result),'environment':versions()})
    except Exception:
        # Incomplete run directories remain visibly failed rather than looking completed.
        try:
            (folder/'FAILED.txt').write_text('Execution persistence failed; no completed run should be inferred.')
        except OSError:
            pass  # A full disk must not hide the original persistence failure.
        raise
    return result['summary']+'\n\nRaw sources are intact. The recipe, window ledger, processing steps and result are recorded in a new run. '+status_text(session)


def handle_execution_command(session,text):
    """Return a reply payload, or None when this is a planning instruction."""
    simple=text.strip().rstrip('.!?').strip();lower=simple.casefold()
    summary_match=re.fullmatch(r'(?:summarize|describe|show results for|what do the)\s+([A-Za-z][A-Za-z0-9_]{0,79})(?:\s+results show)?',simple,re.I)
    if summary_match and session.result and session.result.get('method')=='study_execution':
        result=session.result
        children=[m['result'] for m in result.get('measures',[]) if m.get('status')=='executed'] if result.get('report') else [result]
        selected=next((child for child in children if child['plot_data']['endpoint']['column'].casefold()==summary_match[1].casefold()),None)
        if selected:
            return {'message':status_text(session)+'\n\nRecorded calculated summaries (no new analysis):\n'+\
                '\n'.join(computed_summary_lines(selected))+\
                '\n\nThese are descriptive subject summaries. Choose a specific contrast and justify any independence assumption before requesting inference.','refresh':False}
    if lower in {'report all available measures','report all measures','use all available measures','analyze all available measures','prepare a report of all measures',
                 'give me figures tables and descriptives for all measures','give me a report of all measures','create a report of all available measures'}:
        _set(session,method='measure_report',outcome='all_available',inference='none',fit_doses=[])
        return {'message':'Selected a comprehensive available-measure report: source-window descriptives and missingness for every registered measure, with study curves for measures that meet the recipe and calibration requirements. No automatic group tests. Review protocol windows and the execution recipe next.','refresh':True}
    if lower in {'show execution options','show outcomes','show supported outcomes','show execution capabilities'}:
        from .study_execution import OUTCOMES
        return {'message':'Executable adapter: pleth_summary_v1. Outcomes:\n'+json.dumps(OUTCOMES,ensure_ascii=False,indent=2)+
            '\nSet an outcome, experimental unit and trial handling; propose/review protocol windows; review, confirm and run the exact execution recipe.', 'refresh':False}
    if lower in {'show windows','show summary windows','review windows','show window ledger'}:
        return {'message':windows_text(session),'refresh':False}
    if lower in {'propose protocol windows','propose summary windows','use source summary windows'}:
        candidates=propose_windows(session);_set(session,windows=candidates)
        return {'message':'Proposed the Summary window assignments without omitting any rows. Labels and temporal order are proposals, not measured gas metadata. Review every phase/dose before confirming the recipe.\n\n'+windows_text(session),'refresh':True}
    from .study_execution import OUTCOMES
    match=re.fullmatch(r'(?:use|set|choose)\s+(?:the\s+)?(?:outcome\s+)?([A-Za-z][A-Za-z0-9_]{0,79})(?:\s+as\s+(?:the\s+)?outcome)?',simple,re.I)
    if match and match[1].casefold() not in {key.casefold() for key in OUTCOMES}:match=None
    aliases={'use respiratory frequency':'RR_bpm','use frequency':'RR_bpm','analyze respiratory frequency':'RR_bpm',
             'use syringe scaled minute signal':'MV_syringe_mL_per_min','use syringe-scaled minute signal':'MV_syringe_mL_per_min',
             'use absolute minute ventilation':'MV_mL_per_min'}
    if match or lower in aliases:
        from .study_execution import OUTCOMES
        name=next(k for k in OUTCOMES if k.casefold()==match[1].casefold()) if match else aliases[lower]
        values={'outcome':name}
        if _execution(session)['options'].get('method')=='measure_report':values.update(method='response_curve',fit_doses=[])
        _set(session,**values)
        return {'message':'Selected source outcome '+name+'. '+str(OUTCOMES[name])+'. Source calibration and required numeric cells will be checked before the recipe can run.','refresh':True}
    if re.fullmatch(r'(?:the\s+)?experimental unit (?:is|=|to) (?:the\s+)?(?:mouse|animal|subject|participant|patient)s?',lower) or re.fullmatch(r'use (?:the\s+)?(?:mouse|animal|subject|participant|patient) as (?:the\s+)?experimental unit',lower):
        _set(session,experimental_unit='subject')
        return {'message':'Recorded the subject as the experimental unit. Repeated trials, condition rows and breaths will not be counted as additional independent subjects.','refresh':True}
    if lower in {'subjects are independent','the subjects are independent','independent subjects'}:
        _set(session,independent_subjects=True)
        return {'message':'Recorded your declaration that distinct subjects are independent. Group inference still requires an explicit method choice.','refresh':True}
    if lower in {'do not assume independence','independence is unknown'}:
        _set(session,independent_subjects=False,inference='none')
        return {'message':'Independent-subject inference disabled. Descriptive subject estimates remain available.','refresh':True}
    methods={'use a co2 response curve':'response_curve','use co2 response curve':'response_curve',
             'use a response curve':'response_curve','use response curve':'response_curve',
             'use co2 slopes':'co2_slope','use a co2 slope':'co2_slope','use frequency response slopes':'co2_slope',
             'use hcvr slope':'co2_slope'}
    if lower in methods:
        values={'method':methods[lower]}
        if methods[lower]=='response_curve':values['fit_doses']=[]
        if lower=='use frequency response slopes':values['outcome']='RR_bpm'
        if 'hcvr' in lower:values['outcome']='MV_mL_per_min'
        _set(session,**values)
        return {'message':'Selected '+methods[lower]+'. Slopes are named for the actual outcome and source units. Physiological HCVR requires calibrated minute ventilation; an RR slope is a frequency-response component.','refresh':True}
    match=re.fullmatch(r'(?:fit|use|set) (?:the )?slope (?:over|using|at|doses(?: to)?)\s+(.+)',simple,re.I)
    if match:
        parts=re.split(r'\s*(?:,|\band\b)\s*',match[1].replace('%',''))
        try:doses=[float(p.strip()) for p in parts if p.strip()]
        except ValueError:raise ValueError('List explicit fit concentrations, for example “fit slope over 0, 3, 6%”.') from None
        if len(doses)<3 or len(set(doses))!=len(doses) or any(not 0<=d<=100 for d in doses):raise ValueError('Choose at least three distinct finite concentrations from0 to100 percent.')
        _set(session,fit_doses=sorted(doses))
        return {'message':'Recorded explicit slope concentrations: '+str(sorted(doses))+' percent inspired CO₂. Recovery is excluded from slope fitting.','refresh':True}
    norms={'no normalization':'none','use raw outcome values':'none','do not normalize':'none',
           'normalize to baseline as fold change':'fold_baseline','use fold baseline':'fold_baseline',
           'normalize as percent of baseline':'percent_baseline','use percent baseline':'percent_baseline',
           'normalize to percent baseline':'percent_baseline',
           'normalize as percent change from baseline':'percent_change','use percent change from baseline':'percent_change'}
    if lower in norms:
        _set(session,normalization=norms[lower]);return {'message':'Normalization: '+norms[lower]+'. Only explicitly assigned baseline windows supply the denominator.','refresh':True}
    if lower in {'normalize after pooling','pool then normalize','normalize within each trial','normalize before pooling'}:
        order='after_pooling' if lower in {'normalize after pooling','pool then normalize'} else 'within_trial'
        _set(session,normalization_order=order);return {'message':'Recorded normalization order: '+order+'. This order is included in the recipe and processing record.','refresh':True}
    if lower in {'no group inference','descriptive only','do not compare groups'}:
        _set(session,inference='none');return {'message':'Descriptive estimates only; no group p-value will be calculated.','refresh':True}
    if lower in {'compare subject slopes with welch','use welch comparison of slopes'}:
        _set(session,inference='welch_slopes');return {'message':'Selected a two-sided Welch comparison of subject slopes. It requires exactly two groups, independent subjects explicitly declared, and at least two subject slopes per group; small samples will be flagged.','refresh':True}
    match=re.fullmatch(r'(?:set|assign) window\s+(S\d{3})\s+(?:row\s+)?(\d+)\s+(?:to|as)\s+(baseline|exposure|recovery)\s+(?:at\s+)?(\d+(?:\.\d+)?)\s*%(?:\s+CO2)?',simple,re.I)
    omission=re.fullmatch(r'(?:set|assign) window\s+(S\d{3})\s+(?:row\s+)?(\d+)\s+(?:to|as)\s+omit\s+(?:because|reason:?|for)\s+(.+)',simple,re.I)
    if match or omission:
        found=match or omission;sid=found[1].upper();row=int(found[2])
        actual={(r['source_id'],r['row']) for r in _windows(session)}
        if (sid,row) not in actual:raise ValueError('That source/physical Summary row does not exist.')
        windows=deepcopy(_execution(session)['options'].get('windows',[]))
        if not windows:raise ValueError('First say “propose protocol windows”, then review and edit their assignments.')
        if omission:
            reason=omission[3].strip()
            if len(reason)>1000 or re.search(r'significan|p[- ]?value|outlier|improve.*(?:result|effect)',reason,re.I):raise ValueError('An omission requires a documented protocol/measurement reason; significance-based pruning is not supported.')
            value={'source_id':sid,'row':row,'phase':'omit','co2_percent':None,'reason':reason}
        else:value={'source_id':sid,'row':row,'phase':match[3].lower(),'co2_percent':float(match[4]),'reason':'Explicit user-assigned protocol phase and concentration.'}
        windows=[value if (w['source_id'],w['row'])==(sid,row) else w for w in windows]
        _set(session,windows=windows);return {'message':'Recorded window assignment: '+json.dumps(value,ensure_ascii=False)+'. Original source fields are unchanged.','refresh':True}
    if lower in {'review execution recipe','show execution recipe','prepare execution recipe'}:
        recipe=_compile(session);execution=_execution(session)
        execution['candidate_recipe']=recipe;execution['approved_digest']=None
        session._event('study_execution_recipe_reviewed',{'recipe':recipe,'recipe_sha256':_hash(recipe)})
        return {'message':recipe_text(recipe),'refresh':True}
    if lower=='confirm execution recipe':
        from .study_execution import recipe_digest
        execution=_execution(session);previous=execution.get('candidate_recipe')
        if not previous:raise ValueError('First say “review execution recipe” to inspect the exact inputs and scientific choices.')
        recipe=_compile(session)
        if recipe_digest(recipe)!=recipe_digest(previous):raise ValueError('The recipe changed since review. Review it again before confirmation.')
        execution['approved_digest']=recipe_digest(recipe);execution['approved_state_sha256']=_hash(session.context['study_state'])
        session._event('study_execution_recipe_confirmed',{'origin':'explicit_user_instruction','recipe_sha256':execution['approved_digest'],'recipe':recipe})
        return {'message':'Confirmed this exact execution recipe: '+execution['approved_digest']+'. Say “run agreed analysis” to execute it locally.','refresh':True}
    if lower in {'run agreed analysis','run approved analysis','run the agreed analysis','run the approved analysis','run analysis','rerun agreed analysis'}:
        return {'message':_run(session),'refresh':True}
    if lower in {'export analysis','export analysis with sources','export figure and record','export figures','export results'}:
        if not session.result or session.result.get('method')!='study_execution':raise ValueError('Run a confirmed execution recipe before exporting calculated results and figures. “export study plan” remains available.')
        return {'message':'Preparing the recorded analysis, publication figure and reproducible processing record.',
                'refresh':False,'export_request':{'action':'study_analysis_export','include_source':lower=='export analysis with sources'}}
    if session.result and session.result.get('method')=='study_execution':
        from .planner import _parse_style,_blocked_request
        if re.search(r'confidence intervals?|\b95\s*%?\s*ci\b|credible intervals?',lower):
            return {'message':'These study figures show descriptive sample SD when error bars are enabled. Confidence/credible intervals were not calculated. Say “show error bars” or “hide error bars” to change SD display; an inferential interval needs its own defined method.','refresh':False}
        if re.match(r"^(?:do not|don't|dont|not)\b",lower):
            return {'message':'That negated style request was not applied. State the desired setting explicitly, for example “use teal” or “hide error bars”.','refresh':False}
        change=_parse_style(text)
        if lower in {'show sd','show standard deviation','show sample sd'}:change={'ci':True}
        visual_only_hide=bool(re.fullmatch(r'hide (?:the )?(?:(?:individual|raw|data) )?points',lower))
        if change and (not _blocked_request(text) or visual_only_hide) and not re.search(r'\b(?:run|test|fit|analy[sz]e|compute|calculate|exclude|omit)\b',text,re.I):
            from .study_figures import make_figure
            style={**session.style,**change}
            if not session.defer_figure_validation:make_figure(session.dataset,session.result,session.plan,style)
            session.style=style;session._event('study_figure_style_changed',{'style':style})
            return {'message':'Updated the figure style; the recorded numerical result and source files are unchanged.','refresh':True}
    return None


def computed_summary_lines(result):
    data=result['plot_data'];endpoint=data['endpoint']
    unit={'fold_baseline':'fold baseline','percent_baseline':'% baseline','percent_change':'% change from baseline'}.get(data.get('normalization'),endpoint['unit'])
    lines=[]
    for row in data.get('group_rows',[])[:20]:
        sd='unavailable' if row.get('sd') is None else f"{row['sd']:.4g}"
        lines.append(f"{endpoint['column']} · {row['group']} · {row['phase']} at {row['co2_percent']:g}% CO₂: mean {row['mean']:.4g} {unit}; sample SD {sd}; n={row['n_subjects']} subjects.")
    for row in data.get('slope_group_rows',[])[:6]:
        lines.append(f"{endpoint['column']} slope · {row['group']}: mean {row['mean']:.4g} {unit} per CO₂ percentage point; n={row['n_subjects']} subjects.")
    if not lines:lines.append('Separate-trial mode: no independent group summary was computed. See recorded trial values in Results.')
    return lines


def discussion_context(session,instruction=''):
    """Small typed capabilities/decisions plus computed summaries, never source rows."""
    execution=session.context.get('study_execution',{});options=execution.get('options',{})
    result=session.result if session.result and session.result.get('method')=='study_execution' else None
    context={'available_adapters':list(ADAPTERS),'execution_control':'The model may propose closed supported analysis choices. The app presents the exact proposal; only a later direct user agreement to the displayed plan can approve and run it. Model prose cannot change confirmed choices or approve itself.',
             'status':status_text(session),'choices':{key:options[key] for key in ('method','outcome','experimental_unit','normalization','normalization_order','inference','fit_doses') if key in options},
             'window_assignments':len(options.get('windows',[])),'recipe_confirmed':bool(execution.get('approved_digest'))}
    context['confirmed_decisions']={'experimental_unit':options.get('experimental_unit','not yet declared'),
        'trial_handling':session.context['study_state'].get('pooling','undecided'),
        'repeated_trials_are_independent_subjects':False,
        'distinct_subject_independence_declared':options.get('independent_subjects',False),
        'instruction':'Do not ask again for recorded unit or trial handling. Distinct-subject independence and scientific contrast are separate choices.'}
    if result:
        context['recorded_result_summary']=result['summary'][:700]
        context['result_matches_current_choices']=result_is_current(session)
        if result.get('report'):
            context['measure_statuses']={m['outcome']:m['status'] for m in result.get('measures',[])[:28]}
            context['measure_blockers']={m['outcome']:m.get('reason','')[:160] for m in result.get('measures',[]) if m['status']=='blocked'}
        else:
            context['row_accounting']={key:result.get('row_accounting',{}).get(key) for key in ('total','used','omitted')}
        candidates=([m['result'] for m in result.get('measures',[]) if m.get('status')=='executed'] if result.get('report') else [result])
        requested=[child for child in candidates if child['plot_data']['endpoint']['column'].casefold() in instruction.casefold()]
        if not requested and re.search(r'\bfrequency|respiratory rate\b',instruction,re.I):
            requested=[child for child in candidates if child['plot_data']['endpoint']['column']=='RR_bpm']
        if not requested:requested=candidates[:1]
        aggregates=[]
        for child in requested[:2]:
            data=child['plot_data']
            aggregates.append({'endpoint':data['endpoint'],'normalization':data.get('normalization'),
                'pooling':data.get('pooling'),'verified_summary_statements':computed_summary_lines(child),
                'group_summary_semantics':'These statements come from recorded deterministic results. SD is descriptive subject SD, not SEM/CI. Groups summarize subjects, not breaths/trials.',
                'comparison':child.get('comparison',[])[:2],
                'omitted_group_rows':max(0,len(data.get('group_rows',[]))-20)})
        context['recorded_computed_aggregates']=aggregates
        context['aggregate_selection']='Explicitly named supported outcomes, otherwise first executed outcome as a disclosed default; at most two measures. No source observation rows.'
    return context
