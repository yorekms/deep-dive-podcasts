"""StatWeave: local, reproducible statistics directed through conversation."""
__version__ = '0.9.0'
