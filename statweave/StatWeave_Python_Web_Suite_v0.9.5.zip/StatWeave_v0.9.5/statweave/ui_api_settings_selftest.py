"""Native API settings/progress/cancel verification using a fake transport only."""
from __future__ import annotations

import json
from pathlib import Path
import threading
import time

from PySide6.QtCore import QTimer
from PySide6.QtWidgets import QLineEdit

from .credentials import Credentials


def schedule(window,app,workspace):
    from . import api_provider
    from .app import Settings
    output=Path(workspace).resolve()/'ui-api-settings-self-test'
    output.mkdir(parents=True,exist_ok=True)
    app.setQuitOnLastWindowClosed(False)
    original_planner=api_provider.OpenAIPlanner
    original_command=window.session.command
    started=time.monotonic()
    state={'stage':'starting','ticks':0,'checks':[],'models':[],'error':None}
    timer=QTimer(app);window._api_settings_selftest_timer=timer

    class NoWallet:
        def read(self):raise ValueError('The synthetic check must never read a wallet')
        def write(self,key):raise ValueError('The synthetic check must never write a wallet')

    credentials=Credentials(environment={},wallet=NoWallet())

    class FakePlanner:
        provider='openai'
        def __init__(self,**options):
            self.model=options['model'];self.resolver=options['credential_resolver']
            self.activity_callback=None;self.stopped=threading.Event();self.cancelled=False
            state['models'].append(self)
        def cancel(self):self.cancelled=True;self.stopped.set()
        def check_connection(self):
            require(self.resolver()=='synthetic-selftest-key','The synthetic resolver returned an unexpected value')
            return {'model':self.model,'usage':{'input_tokens':4,'output_tokens':1}}

    def command(text,model=None):
        if model.activity_callback:model.activity_callback(True)
        try:
            if not model.stopped.wait(5):raise ValueError('Synthetic API reply was not cancelled')
            raise ValueError('The synthetic API reply was cancelled. No calculation was run.')
        finally:
            if model.activity_callback:model.activity_callback(False)

    def require(value,message):
        if not value:raise ValueError(message)

    dialog=None

    def finish(error=None):
        if window.busy or dialog is not None and dialog.test_thread is not None:
            state['error']=error or state['error'] or 'Native API check could not finish safely'
            for model in state['models']:model.cancel()
            return
        timer.stop();api_provider.OpenAIPlanner=original_planner
        window.session.command=original_command
        credentials.set_session(None)
        if dialog is not None:dialog.reject();dialog.deleteLater()
        window.close()
        report={'status':'failed' if error else 'passed','scope':'Synthetic provider settings and fake API transport only; no real credentials, wallet access, network, private project, or billed request.',
                'checks':state['checks'],'event_loop_ticks':state['ticks'],'seconds':time.monotonic()-started}
        if error:report['error']=str(error)
        (output/'result.json').write_text(json.dumps(report,indent=2))
        app.exit(1 if error else 0)

    def tick():
        state['ticks']+=1
        try:
            if state['error']:finish(state['error']);return
            require(time.monotonic()-started<12,'The bounded native API settings check exceeded twelve seconds')
            if state['stage']=='testing':
                if dialog.test_thread is not None:return
                require(dialog.connection_verified,'The fake connection test was not reported')
                require('4 input tokens' in dialog.test_status.text(),'Test usage was not visible')
                require(credentials.source() is None,'The test unexpectedly saved a credential')
                state['checks']+=['explicit_test_only','minimal_test_usage_visible','test_does_not_save_key']
                dialog.api_key.clear()
                require(dialog.grab().save(str(output/'provider-settings.png')),'The settings view could not be captured')
                dialog.reject()
                credentials.set_session('synthetic-selftest-key')
                window.credentials=credentials
                window.config={'enabled':True,'provider':'openai','openai_model':'gpt-6-luna','model':'preserved-local-model'}
                window.update_mode()
                require('not tested' in window.mode_label.text(),'An untested key was shown as connected')
                window.session.command=command
                state['stage']='reply'
                window.send('Please discuss the analysis choices with me.')
                return
            if state['stage']=='reply':
                if not window.cancel_button.isVisible():return
                require('with OpenAI' in window.progress.text(),'The remote reply was described as local')
                state['checks']+=['untested_state_is_honest','remote_progress_visible','native_cancel_control_visible']
                window.cancel_button.click();state['stage']='cancelling';return
            if state['stage']=='cancelling':
                if window.busy:return
                require(window.thread is None and window.isVisible(),'Cancellation did not finish native cleanup')
                require(state['models'][-1].cancelled,'The API planner did not receive cancellation')
                require(all('synthetic-selftest-key' not in message['text'] for message in window.messages),'A credential entered the conversation')
                state['checks']+=['reply_cancelled','worker_cleaned_up','credential_absent_from_conversation']
                finish()
        except Exception as error:
            state['error']=str(error) or type(error).__name__
            finish(state['error'])

    try:
        api_provider.OpenAIPlanner=FakePlanner
        dialog=Settings({'enabled':True,'model':'preserved-local-model','model_digest':'synthetic-digest'},window,credentials)
        dialog.show();app.processEvents()
        require(dialog.provider.currentData()=='ollama','Legacy local settings did not migrate')
        dialog.provider.setCurrentIndex(dialog.provider.findData('openai'))
        require(dialog.api_key.echoMode()==QLineEdit.EchoMode.Password,'The key field is not masked')
        dialog.api_key.setText('synthetic-selftest-key')
        values=dialog.values()
        require(values['model']=='preserved-local-model' and values['model_digest']=='synthetic-digest','Switching providers discarded the local model')
        require('synthetic-selftest-key' not in json.dumps(values),'A credential entered preference data')
        require(not state['models'],'Opening settings contacted a model')
        state['checks']+=['legacy_local_model_preserved','provider_switch','masked_key_field','credential_absent_from_settings','no_request_on_open']
        state['stage']='testing'
        timer.timeout.connect(tick);timer.start(10)
        dialog.test_button.click()
    except Exception as error:
        state['error']=str(error) or type(error).__name__
        finish(state['error'])
