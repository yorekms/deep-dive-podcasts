# Public ABF development examples

These four original ABF files were downloaded at the user's request to test StatWeave's first recording importer and trace plotting. They come from Scott Harden's public pyABF development collection, pinned to commit `3ad9cd6f2cdfe79bc1978736ab46314866ca1c4c`.

The collection is a **reader-test source**, not an independently verified biological dataset. No species, donor, treatment, or experimental-method claim is inferred from a filename or protocol label.

| File | Fixture role | Reader-verified shape and units |
|---|---|---|
| `16d22006_kim_gapfree.abf` | Gap-free ABF2; mixed channel units | Two channels, dB and mV; 10 kHz; one 48.3 s sweep. The voltage channel is channel 2 in the app's 1-based numbering. |
| `17o05027_ic_ramp.abf` | Compact episodic ABF2 | One mV channel; 20 kHz; two 1 s sweeps. |
| `05210017_vc_abf1.abf` | Episodic ABF1 calibration and discontinuous timing | Two pA channels; 20 kHz; six 3 s sweeps starting at 0, 60, 120, 180, 240, 300 s. |
| `pclamp11_4ch.abf` | Four-channel ABF2 | Four pA channels; 20 kHz; ten 0.2 s sweeps. |

The total download is 3,813,376 bytes (about 3.8 MB). `SOURCES.json` records fixed URLs, byte counts, SHA-256 hashes, header metadata, reference links, and reuse status.

## Timing caveat

For `05210017_vc_abf1.abf`, the file synchronization information gives 60 s between sweep starts. The six sweeps contain 18 s of sampled data, but the final sweep ends 303 s after recording start. pyABF's convenience `sweepTimesSec` uses a 3 s interval for this fixture and must not be used as an independently verified recording clock. StatWeave's Neo-based reader preserves synchronization-derived starts. Sweep-relative overlays remain a distinct view and do not erase gaps from the source recording.

## Rights and distribution

The repository includes an MIT license for software and associated documentation. Its sample-data README states that many ABFs were emailed by contributors. A separate, unambiguous data-specific redistribution grant was **not found** during this check. We therefore do not assume that the software license establishes rights for every contributed recording.

**Keep raw `.abf` files out of redistributed application archives by default.** Local development downloads are retained with provenance. Before publicly redistributing recordings—or an export bundle that includes its preserved raw source—establish the required permissions. The application has not uploaded or published these files.

Primary sources:

- [Pinned sample-data README](https://github.com/swharden/pyABF/blob/3ad9cd6f2cdfe79bc1978736ab46314866ca1c4c/data/readme.md)
- [Pinned repository license](https://github.com/swharden/pyABF/blob/3ad9cd6f2cdfe79bc1978736ab46314866ca1c4c/LICENSE)
- [pyABF tutorial](https://swharden.com/pyabf/tutorial/)
- [Neo RawIO documentation](https://neo.readthedocs.io/en/stable/rawio.html)

## Fetch or verify the local examples

Run from the StatWeave project folder:

```text
.venv/bin/python scripts/fetch_abf_examples.py --fetch
```

Without `--fetch`, the script only lists the pinned sources. With `--fetch`, an existing file is checked against the register; a differing file is preserved and reported instead of overwritten. New downloads are checked for byte count and SHA-256 before becoming `.abf` files. A custom destination is available with `--destination`.

No statistical analysis, filtering, artifact exclusion, or biological-replicate interpretation is implied by fetching or plotting these recordings.
