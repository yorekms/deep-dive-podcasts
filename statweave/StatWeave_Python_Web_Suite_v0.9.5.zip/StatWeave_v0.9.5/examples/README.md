These datasets are synthetic demonstrations generated with NumPy seed 20261029. They are not research observations.

independent_groups.csv: 36 fictional independent participants, two groups, dose and score.
paired_measurements.csv: 20 fictional participants with before/after measurements on the same row.
