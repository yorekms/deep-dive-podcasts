# Third-party software

StatWeave source is MIT licensed. The standalone bundle contains separately licensed dependencies and their notices in `licenses/` and `_internal/`. `DEPENDENCIES.json` records discovered versions and copied notices. Some installed package distributions contain components not used by this app; the record is not a claim that every component is included.

Qt for Python / PySide6 and Shiboken are separately licensed. The one-directory build retains shared Qt libraries so users can replace compatible libraries as their licenses permit. This app does not statically link Qt or impose an additional prohibition on reverse engineering for debugging modifications to LGPL components. Qt source and license resources: https://code.qt.io/cgit/pyside/pyside-setup.git/ and https://www.qt.io/licensing/open-source-lgpl-obligations .

Python: https://docs.python.org/3/license.html . NumPy, SciPy, pandas, statsmodels and Matplotlib retain their own licenses. Matplotlib's DejaVu fonts retain their font notices. PyInstaller's bootloader redistribution follows its license exception: https://pyinstaller.org/en/stable/license.html .

The reference catalog contains external links only. It does not grant rights to download, redistribute, index, or train on third-party documentation. Source-specific permissions must be established before reference text or training examples are shared.
