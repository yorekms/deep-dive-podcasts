#!/usr/bin/env python3
import sys
if __name__=='__main__':
    if '--api-self-test' in sys.argv:
        import argparse,json
        from statweave.api_selftest import run
        parser=argparse.ArgumentParser()
        parser.add_argument('--api-self-test',action='store_true')
        parser.add_argument('--workspace',default='.')
        args=parser.parse_args()
        print(json.dumps(run(args.workspace),indent=2))
    elif '--execution-self-test' in sys.argv:
        import argparse,json
        from statweave.execution_selftest import run
        parser=argparse.ArgumentParser()
        parser.add_argument('--execution-self-test',action='store_true')
        parser.add_argument('--workspace',default='.')
        parser.add_argument('--reproduce',action='store_true')
        args=parser.parse_args()
        print(json.dumps(run(args.workspace,args.reproduce),indent=2))
    elif '--start-local-ai' in sys.argv:
        import argparse,json
        from statweave.local_ai import ensure_local_service
        parser=argparse.ArgumentParser()
        parser.add_argument('--start-local-ai',action='store_true')
        parser.add_argument('--workspace',default='.')
        args=parser.parse_args()
        print(json.dumps(ensure_local_service(args.workspace),indent=2))
    elif '--study-self-test' in sys.argv:
        import argparse,json
        from statweave.study_selftest import run
        parser=argparse.ArgumentParser()
        parser.add_argument('--study-self-test',action='store_true')
        parser.add_argument('--workspace',default='.')
        parser.add_argument('--study-folder')
        parser.add_argument('--live-model',action='store_true')
        args=parser.parse_args()
        print(json.dumps(run(args.workspace,args.study_folder,args.live_model),indent=2))
    elif '--large-model-self-test' in sys.argv:
        import argparse,json
        from statweave.large_model_selftest import run
        parser=argparse.ArgumentParser()
        parser.add_argument('--large-model-self-test',action='store_true')
        parser.add_argument('--workspace',default='.')
        parser.add_argument('--large-project',required=True)
        args=parser.parse_args()
        print(json.dumps(run(args.workspace,args.large_project),indent=2))
    elif '--large-self-test' in sys.argv:
        import argparse,json
        from statweave.large_selftest import run
        parser=argparse.ArgumentParser()
        parser.add_argument('--large-self-test',action='store_true')
        parser.add_argument('--workspace',default='.')
        args=parser.parse_args()
        print(json.dumps(run(args.workspace),indent=2))
    elif '--ap-self-test' in sys.argv:
        import argparse,json
        from statweave.ap_selftest import run
        parser=argparse.ArgumentParser()
        parser.add_argument('--ap-self-test',action='store_true')
        parser.add_argument('--workspace',default='.')
        parser.add_argument('--examples-dir',required=True)
        args=parser.parse_args()
        print(json.dumps(run(args.workspace,args.examples_dir),indent=2))
    elif '--spike-self-test' in sys.argv:
        import argparse,json
        from statweave.spike_selftest import run
        parser=argparse.ArgumentParser()
        parser.add_argument('--spike-self-test',action='store_true')
        parser.add_argument('--workspace',default='.')
        parser.add_argument('--examples-dir',required=True)
        args=parser.parse_args()
        print(json.dumps(run(args.workspace,args.examples_dir),indent=2))
    elif '--abf-self-test' in sys.argv:
        import argparse,json
        from statweave.abf_selftest import run
        parser=argparse.ArgumentParser()
        parser.add_argument('--abf-self-test',action='store_true')
        parser.add_argument('--workspace',default='.')
        parser.add_argument('--examples-dir',required=True)
        args=parser.parse_args()
        print(json.dumps(run(args.workspace,args.examples_dir),indent=2))
    elif '--self-test' in sys.argv:
        import argparse,json
        from statweave.selftest import run
        parser=argparse.ArgumentParser()
        parser.add_argument('--self-test',action='store_true')
        parser.add_argument('--workspace',default='.')
        args=parser.parse_args()
        print(json.dumps(run(args.workspace),indent=2))
    else:
        from statweave.app import main
        raise SystemExit(main())
