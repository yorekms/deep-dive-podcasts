# StatWeave Web Workbench & Carrd Portal — Quick Deploy & Laptop Handoff Guide

This guide covers everything needed to get StatWeave running online **before sending this computer in**, so you and your students can test from any browser via your `carrd.co` portal while the laptop is away.

---

## 1. Before Sending This Computer In: Push to a Private GitHub Repo (2 min)

Nothing sensitive (`.env`, API keys, SQLite databases, or `web_data/`) is tracked in Git. Push `statweave_working` to a **private** GitHub repository so you can deploy and manage it from any computer:

```bash
cd /home/yorekms/Documents/StatsLLM/statweave_working

# Create a new PRIVATE repo on github.com (e.g. statweave-workbench), then:
git remote add origin https://github.com/<your-github-username>/statweave-workbench.git
git push -u origin sprint-2
# (Optional) Also push sprint-2 as main so cloud hosts pick it up by default:
git push origin sprint-2:main
```

> **Note:** Also back up `/home/yorekms/Documents/StatsLLM/*.md` and `*.json` (your independent audit & evaluation specs) to Google Drive or a second repo if you want them handy while the machine is away.

---

## 2. Deploy the Backend in ~5 Minutes (Pick Render, Railway, or Fly.io)

The repository includes ready-made Docker configs for **Render** (`render.yaml`), **Railway** (`railway.json`), and **Fly.io** (`fly.toml`). No Qt/GUI libraries are needed—the server runs headless on `python:3.12-slim` with persistent `/data` storage.

### Option A: Render (Simplest — Blueprint UI)
1. In Render, click **New + -> Blueprint** and select your private `statweave-workbench` GitHub repo.
2. Render reads `render.yaml`, automatically provisions the Docker container + a **10 GB persistent `/data` disk**, and generates `STATWEAVE_SESSION_SECRET`.
3. Fill in the prompted environment variables in the Render dashboard (never in code):
   - `STATWEAVE_PUBLIC_BASE_URL`: your Render URL once assigned (e.g. `https://statweave-workbench.onrender.com`, no trailing slash)
   - `STATWEAVE_BETA_OPENAI_API_KEY`: your dedicated OpenAI Project API key (`sk-proj-...`) + set a monthly hard spend cap (e.g. \$25/mo) in the OpenAI dashboard
   - `STATWEAVE_INVITE_CODE`: a lab passphrase for immediate testing (e.g. `clampflow-beta-2026`)
   - `STATWEAVE_ADMIN_TOKEN`: a long random secret for downloading your learning corpus (`python3 -c "import secrets; print(secrets.token_urlsafe(32))"`)
   - `STATWEAVE_CARRD_URL`: your Carrd site URL (e.g. `https://my-statweave.carrd.co`)
4. Verify health: open `https://<your-service-url>/healthz` -> should return `{"status": "ok", ...}`.

### Option B: Railway
1. Click **New Project -> Deploy from GitHub repo** -> select `statweave-workbench`.
2. Right-click the service -> **Attach Volume** mounted at `/data`.
3. Under **Variables**, set `STATWEAVE_DATA_DIR=/data`, `STATWEAVE_SESSION_SECRET`, `STATWEAVE_PUBLIC_BASE_URL`, `STATWEAVE_BETA_OPENAI_API_KEY`, `STATWEAVE_INVITE_CODE`, `STATWEAVE_ADMIN_TOKEN`, and `STATWEAVE_CARRD_URL`.
4. Generate a public domain under **Settings -> Networking**.

### Option C: Fly.io
```bash
fly launch --no-deploy
fly volumes create statweave_data --size 10
fly secrets set \
  STATWEAVE_SESSION_SECRET="$(python3 -c 'import secrets; print(secrets.token_hex(32))')" \
  STATWEAVE_PUBLIC_BASE_URL="https://statweave-workbench.fly.dev" \
  STATWEAVE_BETA_OPENAI_API_KEY="sk-proj-..." \
  STATWEAVE_INVITE_CODE="clampflow-beta-2026" \
  STATWEAVE_ADMIN_TOKEN="$(python3 -c 'import secrets; print(secrets.token_urlsafe(32))')"
fly deploy
```

---

## 3. Embed Into Your `carrd.co` Site (Matches `my-clampflow.carrd.co` 1:1)

1. Open your Carrd site editor (e.g. clone `my-clampflow.carrd.co` as `my-statweave.carrd.co`).
2. In the **Embed** element (**Type: Code**, **Style: Inline**), use the exact GitHub Pages hub loader (so you never have to re-edit Carrd if your backend URL changes):

```html
<div id="crp-hub-root" data-hub="statweave"></div>
<script src="https://yorekms.github.io/deep-dive-podcasts/hub/statweave-portal.js" data-hub="statweave"></script>
```

*(Alternatively, `<script src="https://<your-service-url>/portal/statweave-portal.js"></script>` also works directly.)*

3. Set `"workbenchUrl": "https://<your-service-url>"` inside `hub/statweave-config.json` in `yorekms/deep-dive-podcasts`.
4. Publish `my-statweave.carrd.co`.

What `statweave-portal.js` gives you automatically:
- Full **16-site top Network Hub bar (`#crp-top-hub-nav`)** synced automatically from `https://yorekms.github.io/deep-dive-podcasts/hub/network.json` (with `📊 StatWeave Stats` highlighted active and instant link back to `https://my-clampflow.carrd.co`)
- Step workflow chips (`1. Sign in & Consent` -> `2. Paste 2+ Columns or Drop *_ClampFlow_Compiled.xlsx` -> `3. Refine Stats & Figures -> Export SVG/PDF/ZIP`)
- Popup OAuth sign-in bridge (`window.open` + `postMessage`) so browser third-party cookie restrictions inside iframes never break ORCID or GitHub login
- Full-screen Workbench pop-out button + shareable QR code card

### Adding the StatWeave Tab Across All 15 Existing Carrd Sites (1-File Edit)
Because all of your existing Carrd portals read their top navigation pills dynamically from `https://yorekms.github.io/deep-dive-podcasts/hub/network.json`, you **do not** need to edit 15 separate Carrd sites. Simply add this single entry to the `"sites"` array in `hub/network.json` inside `yorekms/deep-dive-podcasts` and push to GitHub:

```json
  {
   "slug": "statweave",
   "label": "📊 StatWeave Stats",
   "url": "https://my-statweave.carrd.co"
  }
```

Within 5 minutes (`v=` cache window), every site in your Carrd collection (`my-clampflow.carrd.co`, `my-scientist.carrd.co`, `my-biophysics.carrd.co`, etc.) will automatically display the new **📊 StatWeave Stats** tab!

---

## 4. Immediate Testing vs. Adding ORCID & GitHub OAuth

### Immediate Testing (Zero OAuth Registration Wait)
As soon as `STATWEAVE_INVITE_CODE` and `STATWEAVE_BETA_OPENAI_API_KEY` are set, students and colleagues can sign in immediately using **Lab Invite Code**, check the **Contributor Beta Consent** box (deidentified evaluation + model-training consent), and:
- Click **Synthetic ClampFlow 6-Tab** or **2-Group Demo** to test in 10 seconds
- Paste a 2-column spreadsheet directly from Excel/Prism/Google Sheets
- Upload a `<Prefix>_<StudentName>_ClampFlow_Compiled.xlsx` file (student names in filenames and Excel `docProps` author metadata are scrubbed automatically on intake)
- Chat in plain English, click **Approve & Run**, restyle colors/fonts/presets at **zero OpenAI token cost**, export **SVG / PDF / 600 DPI PNG / Reproducible ZIP**, and click **Contribute Case**

### Enabling GitHub & ORCID OAuth 2.0 (Anytime)
1. **GitHub OAuth App** (`GitHub Settings -> Developer settings -> OAuth Apps -> New OAuth App`):
   - Homepage URL: `https://my-statweave.carrd.co`
   - Authorization callback URL: `https://<your-service-url>/api/auth/github/callback`
   - Copy Client ID & Secret into `STATWEAVE_GITHUB_CLIENT_ID` and `STATWEAVE_GITHUB_CLIENT_SECRET`.
2. **ORCID Public API Client** (`https://orcid.org/developer-tools`):
   - Redirect URI: `https://<your-service-url>/api/auth/orcid/callback`
   - Copy Client ID & Secret into `STATWEAVE_ORCID_CLIENT_ID` and `STATWEAVE_ORCID_CLIENT_SECRET`.
3. Once both are set, if you want **only** ORCID/GitHub sign-in without open invite login, set `STATWEAVE_ALLOW_INVITE_LOGIN=false` (or set `STATWEAVE_REQUIRE_INVITE_CODE=true` to require OAuth **plus** your lab invite code).

---

## 5. Checking Usage & Downloading Collected Learning Sets From Any Computer

While your primary computer is in for service, you can check beta telemetry and download all deidentified trajectories (`trajectories/*/trajectory.json` + scrubbed `S001.*` + `accepted_figure.svg`) and `CONTRIBUTION_CASE_SCHEMA.json`-validated cases from any terminal:

```bash
# Check user/project/trajectory counts and total OpenAI token usage:
curl -sS -H "Authorization: Bearer $STATWEAVE_ADMIN_TOKEN" \
  "https://<your-service-url>/api/admin/summary" | python3 -m json.tool

# Download the complete private learning corpus ZIP:
curl -fL -H "Authorization: Bearer $STATWEAVE_ADMIN_TOKEN" \
  "https://<your-service-url>/api/admin/corpus.zip" -o statweave_learning_corpus.zip
```

Optional off-box backups (pick either or both):
- **Private Google Drive Vault Mirror (Zero Storage Cost):** Deploy [`scripts/google_drive_bridge.gs`](./scripts/google_drive_bridge.gs) at `https://script.google.com` (pre-targeted to your private folder `05_StatWeave_Live_Vault`, ID `1JjIa1BdIMsnqsKjiuADLrW7x-3jvV27V`) and set `STATWEAVE_GDRIVE_WEBHOOK_URL` + `STATWEAVE_GDRIVE_WEBHOOK_SECRET`. Every scrubbed trajectory, accepted SVG figure, and `CONTRIBUTION_CASE.json` mirrors directly into your Google Drive automatically (including anonymization updates on withdrawal).
- **Cloudflare R2 / S3 Mirror:** Set `STATWEAVE_R2_ENDPOINT_URL`, `STATWEAVE_R2_BUCKET`, `STATWEAVE_R2_ACCESS_KEY_ID`, and `STATWEAVE_R2_SECRET_ACCESS_KEY` to mirror via S3 Signature V4.

> **Working From Light Mac Notebook or Locked-Down Work PC?** See [`START_FROM_ANY_COMPUTER.md`](./START_FROM_ANY_COMPUTER.md) and `notebooks/StatWeave_Cloud_Workbench_Colab.ipynb` to run or edit everything in the cloud straight from Google Drive or GitHub Codespaces with 0% load on your laptop.

---

## 6. Local Smoke Run (Optional)

```bash
python -m statweave.web --host 127.0.0.1 --port 8000 --data-dir ./web_data
# Open http://127.0.0.1:8000/app
```
